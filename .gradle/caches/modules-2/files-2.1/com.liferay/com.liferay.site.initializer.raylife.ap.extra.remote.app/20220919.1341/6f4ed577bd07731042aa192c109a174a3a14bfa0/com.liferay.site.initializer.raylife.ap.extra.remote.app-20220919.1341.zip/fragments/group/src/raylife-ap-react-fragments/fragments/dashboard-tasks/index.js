Liferay.Loader.define('__FRAGMENT_MODULE_NAME__', [
    'module',
    'require',
    '__REACT_PROVIDER__$react'
], function (__MODULE__, __REQUIRE__) {
    (function (modules) {
        var installedModules = {};
        function __webpack_require__(moduleId) {
            if (installedModules[moduleId]) {
                return installedModules[moduleId].exports;
            }
            var module = installedModules[moduleId] = {
                i: moduleId,
                l: false,
                exports: {}
            };
            modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
            module.l = true;
            return module.exports;
        }
        __webpack_require__.m = modules;
        __webpack_require__.c = installedModules;
        __webpack_require__.d = function (exports, name, getter) {
            if (!__webpack_require__.o(exports, name)) {
                Object.defineProperty(exports, name, {
                    enumerable: true,
                    get: getter
                });
            }
        };
        __webpack_require__.r = function (exports) {
            if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
                Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
            }
            Object.defineProperty(exports, '__esModule', { value: true });
        };
        __webpack_require__.t = function (value, mode) {
            if (mode & 1)
                value = __webpack_require__(value);
            if (mode & 8)
                return value;
            if (mode & 4 && typeof value === 'object' && value && value.__esModule)
                return value;
            var ns = Object.create(null);
            __webpack_require__.r(ns);
            Object.defineProperty(ns, 'default', {
                enumerable: true,
                value: value
            });
            if (mode & 2 && typeof value != 'string')
                for (var key in value)
                    __webpack_require__.d(ns, key, function (key) {
                        return value[key];
                    }.bind(null, key));
            return ns;
        };
        __webpack_require__.n = function (module) {
            var getter = module && module.__esModule ? function getDefault() {
                return module['default'];
            } : function getModuleExports() {
                return module;
            };
            __webpack_require__.d(getter, 'a', getter);
            return getter;
        };
        __webpack_require__.o = function (object, property) {
            return Object.prototype.hasOwnProperty.call(object, property);
        };
        __webpack_require__.p = '';
        return __webpack_require__(__webpack_require__.s = './build/liferay-npm-bundler-workdir/generated/dashboard-tasks.js');
    }({
        './build/liferay-npm-bundler-workdir/generated/dashboard-tasks.js': function (module, exports, __webpack_require__) {
            __MODULE__.exports = __webpack_require__('./src/raylife-ap-react-fragments/fragments/dashboard-tasks/index.js');
        },
        './node_modules/@clayui/icon/lib/index.js': function (module, exports, __webpack_require__) {
            'use strict';
            Object.defineProperty(exports, '__esModule', { value: true });
            exports.default = exports.ClayIconSpriteContext = void 0;
            var _classnames = _interopRequireDefault(__webpack_require__('./node_modules/classnames/index.js'));
            var _react = _interopRequireDefault(__REQUIRE__('__REACT_PROVIDER__$react'));
            var _warning = _interopRequireDefault(__webpack_require__('./node_modules/warning/warning.js'));
            var _excluded = [
                'className',
                'spritemap',
                'symbol'
            ];
            function _interopRequireDefault(obj) {
                return obj && obj.__esModule ? obj : { default: obj };
            }
            function _extends() {
                _extends = Object.assign || function (target) {
                    for (var i = 1; i < arguments.length; i++) {
                        var source = arguments[i];
                        for (var key in source) {
                            if (Object.prototype.hasOwnProperty.call(source, key)) {
                                target[key] = source[key];
                            }
                        }
                    }
                    return target;
                };
                return _extends.apply(this, arguments);
            }
            function _objectWithoutProperties(source, excluded) {
                if (source == null)
                    return {};
                var target = _objectWithoutPropertiesLoose(source, excluded);
                var key, i;
                if (Object.getOwnPropertySymbols) {
                    var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
                    for (i = 0; i < sourceSymbolKeys.length; i++) {
                        key = sourceSymbolKeys[i];
                        if (excluded.indexOf(key) >= 0)
                            continue;
                        if (!Object.prototype.propertyIsEnumerable.call(source, key))
                            continue;
                        target[key] = source[key];
                    }
                }
                return target;
            }
            function _objectWithoutPropertiesLoose(source, excluded) {
                if (source == null)
                    return {};
                var target = {};
                var sourceKeys = Object.keys(source);
                var key, i;
                for (i = 0; i < sourceKeys.length; i++) {
                    key = sourceKeys[i];
                    if (excluded.indexOf(key) >= 0)
                        continue;
                    target[key] = source[key];
                }
                return target;
            }
            var ClayIconSpriteContext = _react.default.createContext('');
            exports.ClayIconSpriteContext = ClayIconSpriteContext;
            var ClayIcon = _react.default.forwardRef(function (_ref, ref) {
                var className = _ref.className, spritemap = _ref.spritemap, symbol = _ref.symbol, otherProps = _objectWithoutProperties(_ref, _excluded);
                var spriteMapVal = _react.default.useContext(ClayIconSpriteContext);
                if (spritemap) {
                    spriteMapVal = spritemap;
                }
                false ? undefined : void 0;
                return _react.default.createElement('svg', _extends({}, otherProps, {
                    className: (0, _classnames.default)('lexicon-icon lexicon-icon-'.concat(symbol), className),
                    key: symbol,
                    ref: ref,
                    role: 'presentation'
                }), _react.default.createElement('use', { xlinkHref: ''.concat(spriteMapVal, '#').concat(symbol) }));
            });
            ClayIcon.displayName = 'ClayIcon';
            var _default = ClayIcon;
            exports.default = _default;
        },
        './node_modules/axios/index.js': function (module, exports, __webpack_require__) {
            module.exports = __webpack_require__('./node_modules/axios/lib/axios.js');
        },
        './node_modules/axios/lib/adapters/xhr.js': function (module, exports, __webpack_require__) {
            'use strict';
            var utils = __webpack_require__('./node_modules/axios/lib/utils.js');
            var settle = __webpack_require__('./node_modules/axios/lib/core/settle.js');
            var cookies = __webpack_require__('./node_modules/axios/lib/helpers/cookies.js');
            var buildURL = __webpack_require__('./node_modules/axios/lib/helpers/buildURL.js');
            var buildFullPath = __webpack_require__('./node_modules/axios/lib/core/buildFullPath.js');
            var parseHeaders = __webpack_require__('./node_modules/axios/lib/helpers/parseHeaders.js');
            var isURLSameOrigin = __webpack_require__('./node_modules/axios/lib/helpers/isURLSameOrigin.js');
            var createError = __webpack_require__('./node_modules/axios/lib/core/createError.js');
            module.exports = function xhrAdapter(config) {
                return new Promise(function dispatchXhrRequest(resolve, reject) {
                    var requestData = config.data;
                    var requestHeaders = config.headers;
                    var responseType = config.responseType;
                    if (utils.isFormData(requestData)) {
                        delete requestHeaders['Content-Type'];
                    }
                    var request = new XMLHttpRequest();
                    if (config.auth) {
                        var username = config.auth.username || '';
                        var password = config.auth.password ? unescape(encodeURIComponent(config.auth.password)) : '';
                        requestHeaders.Authorization = 'Basic ' + btoa(username + ':' + password);
                    }
                    var fullPath = buildFullPath(config.baseURL, config.url);
                    request.open(config.method.toUpperCase(), buildURL(fullPath, config.params, config.paramsSerializer), true);
                    request.timeout = config.timeout;
                    function onloadend() {
                        if (!request) {
                            return;
                        }
                        var responseHeaders = 'getAllResponseHeaders' in request ? parseHeaders(request.getAllResponseHeaders()) : null;
                        var responseData = !responseType || responseType === 'text' || responseType === 'json' ? request.responseText : request.response;
                        var response = {
                            data: responseData,
                            status: request.status,
                            statusText: request.statusText,
                            headers: responseHeaders,
                            config: config,
                            request: request
                        };
                        settle(resolve, reject, response);
                        request = null;
                    }
                    if ('onloadend' in request) {
                        request.onloadend = onloadend;
                    } else {
                        request.onreadystatechange = function handleLoad() {
                            if (!request || request.readyState !== 4) {
                                return;
                            }
                            if (request.status === 0 && !(request.responseURL && request.responseURL.indexOf('file:') === 0)) {
                                return;
                            }
                            setTimeout(onloadend);
                        };
                    }
                    request.onabort = function handleAbort() {
                        if (!request) {
                            return;
                        }
                        reject(createError('Request aborted', config, 'ECONNABORTED', request));
                        request = null;
                    };
                    request.onerror = function handleError() {
                        reject(createError('Network Error', config, null, request));
                        request = null;
                    };
                    request.ontimeout = function handleTimeout() {
                        var timeoutErrorMessage = 'timeout of ' + config.timeout + 'ms exceeded';
                        if (config.timeoutErrorMessage) {
                            timeoutErrorMessage = config.timeoutErrorMessage;
                        }
                        reject(createError(timeoutErrorMessage, config, config.transitional && config.transitional.clarifyTimeoutError ? 'ETIMEDOUT' : 'ECONNABORTED', request));
                        request = null;
                    };
                    if (utils.isStandardBrowserEnv()) {
                        var xsrfValue = (config.withCredentials || isURLSameOrigin(fullPath)) && config.xsrfCookieName ? cookies.read(config.xsrfCookieName) : undefined;
                        if (xsrfValue) {
                            requestHeaders[config.xsrfHeaderName] = xsrfValue;
                        }
                    }
                    if ('setRequestHeader' in request) {
                        utils.forEach(requestHeaders, function setRequestHeader(val, key) {
                            if (typeof requestData === 'undefined' && key.toLowerCase() === 'content-type') {
                                delete requestHeaders[key];
                            } else {
                                request.setRequestHeader(key, val);
                            }
                        });
                    }
                    if (!utils.isUndefined(config.withCredentials)) {
                        request.withCredentials = !!config.withCredentials;
                    }
                    if (responseType && responseType !== 'json') {
                        request.responseType = config.responseType;
                    }
                    if (typeof config.onDownloadProgress === 'function') {
                        request.addEventListener('progress', config.onDownloadProgress);
                    }
                    if (typeof config.onUploadProgress === 'function' && request.upload) {
                        request.upload.addEventListener('progress', config.onUploadProgress);
                    }
                    if (config.cancelToken) {
                        config.cancelToken.promise.then(function onCanceled(cancel) {
                            if (!request) {
                                return;
                            }
                            request.abort();
                            reject(cancel);
                            request = null;
                        });
                    }
                    if (!requestData) {
                        requestData = null;
                    }
                    request.send(requestData);
                });
            };
        },
        './node_modules/axios/lib/axios.js': function (module, exports, __webpack_require__) {
            'use strict';
            var utils = __webpack_require__('./node_modules/axios/lib/utils.js');
            var bind = __webpack_require__('./node_modules/axios/lib/helpers/bind.js');
            var Axios = __webpack_require__('./node_modules/axios/lib/core/Axios.js');
            var mergeConfig = __webpack_require__('./node_modules/axios/lib/core/mergeConfig.js');
            var defaults = __webpack_require__('./node_modules/axios/lib/defaults.js');
            function createInstance(defaultConfig) {
                var context = new Axios(defaultConfig);
                var instance = bind(Axios.prototype.request, context);
                utils.extend(instance, Axios.prototype, context);
                utils.extend(instance, context);
                return instance;
            }
            var axios = createInstance(defaults);
            axios.Axios = Axios;
            axios.create = function create(instanceConfig) {
                return createInstance(mergeConfig(axios.defaults, instanceConfig));
            };
            axios.Cancel = __webpack_require__('./node_modules/axios/lib/cancel/Cancel.js');
            axios.CancelToken = __webpack_require__('./node_modules/axios/lib/cancel/CancelToken.js');
            axios.isCancel = __webpack_require__('./node_modules/axios/lib/cancel/isCancel.js');
            axios.all = function all(promises) {
                return Promise.all(promises);
            };
            axios.spread = __webpack_require__('./node_modules/axios/lib/helpers/spread.js');
            axios.isAxiosError = __webpack_require__('./node_modules/axios/lib/helpers/isAxiosError.js');
            module.exports = axios;
            module.exports.default = axios;
        },
        './node_modules/axios/lib/cancel/Cancel.js': function (module, exports, __webpack_require__) {
            'use strict';
            function Cancel(message) {
                this.message = message;
            }
            Cancel.prototype.toString = function toString() {
                return 'Cancel' + (this.message ? ': ' + this.message : '');
            };
            Cancel.prototype.__CANCEL__ = true;
            module.exports = Cancel;
        },
        './node_modules/axios/lib/cancel/CancelToken.js': function (module, exports, __webpack_require__) {
            'use strict';
            var Cancel = __webpack_require__('./node_modules/axios/lib/cancel/Cancel.js');
            function CancelToken(executor) {
                if (typeof executor !== 'function') {
                    throw new TypeError('executor must be a function.');
                }
                var resolvePromise;
                this.promise = new Promise(function promiseExecutor(resolve) {
                    resolvePromise = resolve;
                });
                var token = this;
                executor(function cancel(message) {
                    if (token.reason) {
                        return;
                    }
                    token.reason = new Cancel(message);
                    resolvePromise(token.reason);
                });
            }
            CancelToken.prototype.throwIfRequested = function throwIfRequested() {
                if (this.reason) {
                    throw this.reason;
                }
            };
            CancelToken.source = function source() {
                var cancel;
                var token = new CancelToken(function executor(c) {
                    cancel = c;
                });
                return {
                    token: token,
                    cancel: cancel
                };
            };
            module.exports = CancelToken;
        },
        './node_modules/axios/lib/cancel/isCancel.js': function (module, exports, __webpack_require__) {
            'use strict';
            module.exports = function isCancel(value) {
                return !!(value && value.__CANCEL__);
            };
        },
        './node_modules/axios/lib/core/Axios.js': function (module, exports, __webpack_require__) {
            'use strict';
            var utils = __webpack_require__('./node_modules/axios/lib/utils.js');
            var buildURL = __webpack_require__('./node_modules/axios/lib/helpers/buildURL.js');
            var InterceptorManager = __webpack_require__('./node_modules/axios/lib/core/InterceptorManager.js');
            var dispatchRequest = __webpack_require__('./node_modules/axios/lib/core/dispatchRequest.js');
            var mergeConfig = __webpack_require__('./node_modules/axios/lib/core/mergeConfig.js');
            var validator = __webpack_require__('./node_modules/axios/lib/helpers/validator.js');
            var validators = validator.validators;
            function Axios(instanceConfig) {
                this.defaults = instanceConfig;
                this.interceptors = {
                    request: new InterceptorManager(),
                    response: new InterceptorManager()
                };
            }
            Axios.prototype.request = function request(config) {
                if (typeof config === 'string') {
                    config = arguments[1] || {};
                    config.url = arguments[0];
                } else {
                    config = config || {};
                }
                config = mergeConfig(this.defaults, config);
                if (config.method) {
                    config.method = config.method.toLowerCase();
                } else if (this.defaults.method) {
                    config.method = this.defaults.method.toLowerCase();
                } else {
                    config.method = 'get';
                }
                var transitional = config.transitional;
                if (transitional !== undefined) {
                    validator.assertOptions(transitional, {
                        silentJSONParsing: validators.transitional(validators.boolean, '1.0.0'),
                        forcedJSONParsing: validators.transitional(validators.boolean, '1.0.0'),
                        clarifyTimeoutError: validators.transitional(validators.boolean, '1.0.0')
                    }, false);
                }
                var requestInterceptorChain = [];
                var synchronousRequestInterceptors = true;
                this.interceptors.request.forEach(function unshiftRequestInterceptors(interceptor) {
                    if (typeof interceptor.runWhen === 'function' && interceptor.runWhen(config) === false) {
                        return;
                    }
                    synchronousRequestInterceptors = synchronousRequestInterceptors && interceptor.synchronous;
                    requestInterceptorChain.unshift(interceptor.fulfilled, interceptor.rejected);
                });
                var responseInterceptorChain = [];
                this.interceptors.response.forEach(function pushResponseInterceptors(interceptor) {
                    responseInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
                });
                var promise;
                if (!synchronousRequestInterceptors) {
                    var chain = [
                        dispatchRequest,
                        undefined
                    ];
                    Array.prototype.unshift.apply(chain, requestInterceptorChain);
                    chain = chain.concat(responseInterceptorChain);
                    promise = Promise.resolve(config);
                    while (chain.length) {
                        promise = promise.then(chain.shift(), chain.shift());
                    }
                    return promise;
                }
                var newConfig = config;
                while (requestInterceptorChain.length) {
                    var onFulfilled = requestInterceptorChain.shift();
                    var onRejected = requestInterceptorChain.shift();
                    try {
                        newConfig = onFulfilled(newConfig);
                    } catch (error) {
                        onRejected(error);
                        break;
                    }
                }
                try {
                    promise = dispatchRequest(newConfig);
                } catch (error) {
                    return Promise.reject(error);
                }
                while (responseInterceptorChain.length) {
                    promise = promise.then(responseInterceptorChain.shift(), responseInterceptorChain.shift());
                }
                return promise;
            };
            Axios.prototype.getUri = function getUri(config) {
                config = mergeConfig(this.defaults, config);
                return buildURL(config.url, config.params, config.paramsSerializer).replace(/^\?/, '');
            };
            utils.forEach([
                'delete',
                'get',
                'head',
                'options'
            ], function forEachMethodNoData(method) {
                Axios.prototype[method] = function (url, config) {
                    return this.request(mergeConfig(config || {}, {
                        method: method,
                        url: url,
                        data: (config || {}).data
                    }));
                };
            });
            utils.forEach([
                'post',
                'put',
                'patch'
            ], function forEachMethodWithData(method) {
                Axios.prototype[method] = function (url, data, config) {
                    return this.request(mergeConfig(config || {}, {
                        method: method,
                        url: url,
                        data: data
                    }));
                };
            });
            module.exports = Axios;
        },
        './node_modules/axios/lib/core/InterceptorManager.js': function (module, exports, __webpack_require__) {
            'use strict';
            var utils = __webpack_require__('./node_modules/axios/lib/utils.js');
            function InterceptorManager() {
                this.handlers = [];
            }
            InterceptorManager.prototype.use = function use(fulfilled, rejected, options) {
                this.handlers.push({
                    fulfilled: fulfilled,
                    rejected: rejected,
                    synchronous: options ? options.synchronous : false,
                    runWhen: options ? options.runWhen : null
                });
                return this.handlers.length - 1;
            };
            InterceptorManager.prototype.eject = function eject(id) {
                if (this.handlers[id]) {
                    this.handlers[id] = null;
                }
            };
            InterceptorManager.prototype.forEach = function forEach(fn) {
                utils.forEach(this.handlers, function forEachHandler(h) {
                    if (h !== null) {
                        fn(h);
                    }
                });
            };
            module.exports = InterceptorManager;
        },
        './node_modules/axios/lib/core/buildFullPath.js': function (module, exports, __webpack_require__) {
            'use strict';
            var isAbsoluteURL = __webpack_require__('./node_modules/axios/lib/helpers/isAbsoluteURL.js');
            var combineURLs = __webpack_require__('./node_modules/axios/lib/helpers/combineURLs.js');
            module.exports = function buildFullPath(baseURL, requestedURL) {
                if (baseURL && !isAbsoluteURL(requestedURL)) {
                    return combineURLs(baseURL, requestedURL);
                }
                return requestedURL;
            };
        },
        './node_modules/axios/lib/core/createError.js': function (module, exports, __webpack_require__) {
            'use strict';
            var enhanceError = __webpack_require__('./node_modules/axios/lib/core/enhanceError.js');
            module.exports = function createError(message, config, code, request, response) {
                var error = new Error(message);
                return enhanceError(error, config, code, request, response);
            };
        },
        './node_modules/axios/lib/core/dispatchRequest.js': function (module, exports, __webpack_require__) {
            'use strict';
            var utils = __webpack_require__('./node_modules/axios/lib/utils.js');
            var transformData = __webpack_require__('./node_modules/axios/lib/core/transformData.js');
            var isCancel = __webpack_require__('./node_modules/axios/lib/cancel/isCancel.js');
            var defaults = __webpack_require__('./node_modules/axios/lib/defaults.js');
            function throwIfCancellationRequested(config) {
                if (config.cancelToken) {
                    config.cancelToken.throwIfRequested();
                }
            }
            module.exports = function dispatchRequest(config) {
                throwIfCancellationRequested(config);
                config.headers = config.headers || {};
                config.data = transformData.call(config, config.data, config.headers, config.transformRequest);
                config.headers = utils.merge(config.headers.common || {}, config.headers[config.method] || {}, config.headers);
                utils.forEach([
                    'delete',
                    'get',
                    'head',
                    'post',
                    'put',
                    'patch',
                    'common'
                ], function cleanHeaderConfig(method) {
                    delete config.headers[method];
                });
                var adapter = config.adapter || defaults.adapter;
                return adapter(config).then(function onAdapterResolution(response) {
                    throwIfCancellationRequested(config);
                    response.data = transformData.call(config, response.data, response.headers, config.transformResponse);
                    return response;
                }, function onAdapterRejection(reason) {
                    if (!isCancel(reason)) {
                        throwIfCancellationRequested(config);
                        if (reason && reason.response) {
                            reason.response.data = transformData.call(config, reason.response.data, reason.response.headers, config.transformResponse);
                        }
                    }
                    return Promise.reject(reason);
                });
            };
        },
        './node_modules/axios/lib/core/enhanceError.js': function (module, exports, __webpack_require__) {
            'use strict';
            module.exports = function enhanceError(error, config, code, request, response) {
                error.config = config;
                if (code) {
                    error.code = code;
                }
                error.request = request;
                error.response = response;
                error.isAxiosError = true;
                error.toJSON = function toJSON() {
                    return {
                        message: this.message,
                        name: this.name,
                        description: this.description,
                        number: this.number,
                        fileName: this.fileName,
                        lineNumber: this.lineNumber,
                        columnNumber: this.columnNumber,
                        stack: this.stack,
                        config: this.config,
                        code: this.code
                    };
                };
                return error;
            };
        },
        './node_modules/axios/lib/core/mergeConfig.js': function (module, exports, __webpack_require__) {
            'use strict';
            var utils = __webpack_require__('./node_modules/axios/lib/utils.js');
            module.exports = function mergeConfig(config1, config2) {
                config2 = config2 || {};
                var config = {};
                var valueFromConfig2Keys = [
                    'url',
                    'method',
                    'data'
                ];
                var mergeDeepPropertiesKeys = [
                    'headers',
                    'auth',
                    'proxy',
                    'params'
                ];
                var defaultToConfig2Keys = [
                    'baseURL',
                    'transformRequest',
                    'transformResponse',
                    'paramsSerializer',
                    'timeout',
                    'timeoutMessage',
                    'withCredentials',
                    'adapter',
                    'responseType',
                    'xsrfCookieName',
                    'xsrfHeaderName',
                    'onUploadProgress',
                    'onDownloadProgress',
                    'decompress',
                    'maxContentLength',
                    'maxBodyLength',
                    'maxRedirects',
                    'transport',
                    'httpAgent',
                    'httpsAgent',
                    'cancelToken',
                    'socketPath',
                    'responseEncoding'
                ];
                var directMergeKeys = ['validateStatus'];
                function getMergedValue(target, source) {
                    if (utils.isPlainObject(target) && utils.isPlainObject(source)) {
                        return utils.merge(target, source);
                    } else if (utils.isPlainObject(source)) {
                        return utils.merge({}, source);
                    } else if (utils.isArray(source)) {
                        return source.slice();
                    }
                    return source;
                }
                function mergeDeepProperties(prop) {
                    if (!utils.isUndefined(config2[prop])) {
                        config[prop] = getMergedValue(config1[prop], config2[prop]);
                    } else if (!utils.isUndefined(config1[prop])) {
                        config[prop] = getMergedValue(undefined, config1[prop]);
                    }
                }
                utils.forEach(valueFromConfig2Keys, function valueFromConfig2(prop) {
                    if (!utils.isUndefined(config2[prop])) {
                        config[prop] = getMergedValue(undefined, config2[prop]);
                    }
                });
                utils.forEach(mergeDeepPropertiesKeys, mergeDeepProperties);
                utils.forEach(defaultToConfig2Keys, function defaultToConfig2(prop) {
                    if (!utils.isUndefined(config2[prop])) {
                        config[prop] = getMergedValue(undefined, config2[prop]);
                    } else if (!utils.isUndefined(config1[prop])) {
                        config[prop] = getMergedValue(undefined, config1[prop]);
                    }
                });
                utils.forEach(directMergeKeys, function merge(prop) {
                    if (prop in config2) {
                        config[prop] = getMergedValue(config1[prop], config2[prop]);
                    } else if (prop in config1) {
                        config[prop] = getMergedValue(undefined, config1[prop]);
                    }
                });
                var axiosKeys = valueFromConfig2Keys.concat(mergeDeepPropertiesKeys).concat(defaultToConfig2Keys).concat(directMergeKeys);
                var otherKeys = Object.keys(config1).concat(Object.keys(config2)).filter(function filterAxiosKeys(key) {
                    return axiosKeys.indexOf(key) === -1;
                });
                utils.forEach(otherKeys, mergeDeepProperties);
                return config;
            };
        },
        './node_modules/axios/lib/core/settle.js': function (module, exports, __webpack_require__) {
            'use strict';
            var createError = __webpack_require__('./node_modules/axios/lib/core/createError.js');
            module.exports = function settle(resolve, reject, response) {
                var validateStatus = response.config.validateStatus;
                if (!response.status || !validateStatus || validateStatus(response.status)) {
                    resolve(response);
                } else {
                    reject(createError('Request failed with status code ' + response.status, response.config, null, response.request, response));
                }
            };
        },
        './node_modules/axios/lib/core/transformData.js': function (module, exports, __webpack_require__) {
            'use strict';
            var utils = __webpack_require__('./node_modules/axios/lib/utils.js');
            var defaults = __webpack_require__('./node_modules/axios/lib/defaults.js');
            module.exports = function transformData(data, headers, fns) {
                var context = this || defaults;
                utils.forEach(fns, function transform(fn) {
                    data = fn.call(context, data, headers);
                });
                return data;
            };
        },
        './node_modules/axios/lib/defaults.js': function (module, exports, __webpack_require__) {
            'use strict';
            (function (process) {
                var utils = __webpack_require__('./node_modules/axios/lib/utils.js');
                var normalizeHeaderName = __webpack_require__('./node_modules/axios/lib/helpers/normalizeHeaderName.js');
                var enhanceError = __webpack_require__('./node_modules/axios/lib/core/enhanceError.js');
                var DEFAULT_CONTENT_TYPE = { 'Content-Type': 'application/x-www-form-urlencoded' };
                function setContentTypeIfUnset(headers, value) {
                    if (!utils.isUndefined(headers) && utils.isUndefined(headers['Content-Type'])) {
                        headers['Content-Type'] = value;
                    }
                }
                function getDefaultAdapter() {
                    var adapter;
                    if (typeof XMLHttpRequest !== 'undefined') {
                        adapter = __webpack_require__('./node_modules/axios/lib/adapters/xhr.js');
                    } else if (typeof process !== 'undefined' && Object.prototype.toString.call(process) === '[object process]') {
                        adapter = __webpack_require__('./node_modules/axios/lib/adapters/xhr.js');
                    }
                    return adapter;
                }
                function stringifySafely(rawValue, parser, encoder) {
                    if (utils.isString(rawValue)) {
                        try {
                            (parser || JSON.parse)(rawValue);
                            return utils.trim(rawValue);
                        } catch (e) {
                            if (e.name !== 'SyntaxError') {
                                throw e;
                            }
                        }
                    }
                    return (encoder || JSON.stringify)(rawValue);
                }
                var defaults = {
                    transitional: {
                        silentJSONParsing: true,
                        forcedJSONParsing: true,
                        clarifyTimeoutError: false
                    },
                    adapter: getDefaultAdapter(),
                    transformRequest: [function transformRequest(data, headers) {
                            normalizeHeaderName(headers, 'Accept');
                            normalizeHeaderName(headers, 'Content-Type');
                            if (utils.isFormData(data) || utils.isArrayBuffer(data) || utils.isBuffer(data) || utils.isStream(data) || utils.isFile(data) || utils.isBlob(data)) {
                                return data;
                            }
                            if (utils.isArrayBufferView(data)) {
                                return data.buffer;
                            }
                            if (utils.isURLSearchParams(data)) {
                                setContentTypeIfUnset(headers, 'application/x-www-form-urlencoded;charset=utf-8');
                                return data.toString();
                            }
                            if (utils.isObject(data) || headers && headers['Content-Type'] === 'application/json') {
                                setContentTypeIfUnset(headers, 'application/json');
                                return stringifySafely(data);
                            }
                            return data;
                        }],
                    transformResponse: [function transformResponse(data) {
                            var transitional = this.transitional;
                            var silentJSONParsing = transitional && transitional.silentJSONParsing;
                            var forcedJSONParsing = transitional && transitional.forcedJSONParsing;
                            var strictJSONParsing = !silentJSONParsing && this.responseType === 'json';
                            if (strictJSONParsing || forcedJSONParsing && utils.isString(data) && data.length) {
                                try {
                                    return JSON.parse(data);
                                } catch (e) {
                                    if (strictJSONParsing) {
                                        if (e.name === 'SyntaxError') {
                                            throw enhanceError(e, this, 'E_JSON_PARSE');
                                        }
                                        throw e;
                                    }
                                }
                            }
                            return data;
                        }],
                    timeout: 0,
                    xsrfCookieName: 'XSRF-TOKEN',
                    xsrfHeaderName: 'X-XSRF-TOKEN',
                    maxContentLength: -1,
                    maxBodyLength: -1,
                    validateStatus: function validateStatus(status) {
                        return status >= 200 && status < 300;
                    }
                };
                defaults.headers = { common: { 'Accept': 'application/json, text/plain, */*' } };
                utils.forEach([
                    'delete',
                    'get',
                    'head'
                ], function forEachMethodNoData(method) {
                    defaults.headers[method] = {};
                });
                utils.forEach([
                    'post',
                    'put',
                    'patch'
                ], function forEachMethodWithData(method) {
                    defaults.headers[method] = utils.merge(DEFAULT_CONTENT_TYPE);
                });
                module.exports = defaults;
            }.call(this, __webpack_require__('./node_modules/process/browser.js')));
        },
        './node_modules/axios/lib/helpers/bind.js': function (module, exports, __webpack_require__) {
            'use strict';
            module.exports = function bind(fn, thisArg) {
                return function wrap() {
                    var args = new Array(arguments.length);
                    for (var i = 0; i < args.length; i++) {
                        args[i] = arguments[i];
                    }
                    return fn.apply(thisArg, args);
                };
            };
        },
        './node_modules/axios/lib/helpers/buildURL.js': function (module, exports, __webpack_require__) {
            'use strict';
            var utils = __webpack_require__('./node_modules/axios/lib/utils.js');
            function encode(val) {
                return encodeURIComponent(val).replace(/%3A/gi, ':').replace(/%24/g, '$').replace(/%2C/gi, ',').replace(/%20/g, '+').replace(/%5B/gi, '[').replace(/%5D/gi, ']');
            }
            module.exports = function buildURL(url, params, paramsSerializer) {
                if (!params) {
                    return url;
                }
                var serializedParams;
                if (paramsSerializer) {
                    serializedParams = paramsSerializer(params);
                } else if (utils.isURLSearchParams(params)) {
                    serializedParams = params.toString();
                } else {
                    var parts = [];
                    utils.forEach(params, function serialize(val, key) {
                        if (val === null || typeof val === 'undefined') {
                            return;
                        }
                        if (utils.isArray(val)) {
                            key = key + '[]';
                        } else {
                            val = [val];
                        }
                        utils.forEach(val, function parseValue(v) {
                            if (utils.isDate(v)) {
                                v = v.toISOString();
                            } else if (utils.isObject(v)) {
                                v = JSON.stringify(v);
                            }
                            parts.push(encode(key) + '=' + encode(v));
                        });
                    });
                    serializedParams = parts.join('&');
                }
                if (serializedParams) {
                    var hashmarkIndex = url.indexOf('#');
                    if (hashmarkIndex !== -1) {
                        url = url.slice(0, hashmarkIndex);
                    }
                    url += (url.indexOf('?') === -1 ? '?' : '&') + serializedParams;
                }
                return url;
            };
        },
        './node_modules/axios/lib/helpers/combineURLs.js': function (module, exports, __webpack_require__) {
            'use strict';
            module.exports = function combineURLs(baseURL, relativeURL) {
                return relativeURL ? baseURL.replace(/\/+$/, '') + '/' + relativeURL.replace(/^\/+/, '') : baseURL;
            };
        },
        './node_modules/axios/lib/helpers/cookies.js': function (module, exports, __webpack_require__) {
            'use strict';
            var utils = __webpack_require__('./node_modules/axios/lib/utils.js');
            module.exports = utils.isStandardBrowserEnv() ? function standardBrowserEnv() {
                return {
                    write: function write(name, value, expires, path, domain, secure) {
                        var cookie = [];
                        cookie.push(name + '=' + encodeURIComponent(value));
                        if (utils.isNumber(expires)) {
                            cookie.push('expires=' + new Date(expires).toGMTString());
                        }
                        if (utils.isString(path)) {
                            cookie.push('path=' + path);
                        }
                        if (utils.isString(domain)) {
                            cookie.push('domain=' + domain);
                        }
                        if (secure === true) {
                            cookie.push('secure');
                        }
                        document.cookie = cookie.join('; ');
                    },
                    read: function read(name) {
                        var match = document.cookie.match(new RegExp('(^|;\\s*)(' + name + ')=([^;]*)'));
                        return match ? decodeURIComponent(match[3]) : null;
                    },
                    remove: function remove(name) {
                        this.write(name, '', Date.now() - 86400000);
                    }
                };
            }() : function nonStandardBrowserEnv() {
                return {
                    write: function write() {
                    },
                    read: function read() {
                        return null;
                    },
                    remove: function remove() {
                    }
                };
            }();
        },
        './node_modules/axios/lib/helpers/isAbsoluteURL.js': function (module, exports, __webpack_require__) {
            'use strict';
            module.exports = function isAbsoluteURL(url) {
                return /^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(url);
            };
        },
        './node_modules/axios/lib/helpers/isAxiosError.js': function (module, exports, __webpack_require__) {
            'use strict';
            module.exports = function isAxiosError(payload) {
                return typeof payload === 'object' && payload.isAxiosError === true;
            };
        },
        './node_modules/axios/lib/helpers/isURLSameOrigin.js': function (module, exports, __webpack_require__) {
            'use strict';
            var utils = __webpack_require__('./node_modules/axios/lib/utils.js');
            module.exports = utils.isStandardBrowserEnv() ? function standardBrowserEnv() {
                var msie = /(msie|trident)/i.test(navigator.userAgent);
                var urlParsingNode = document.createElement('a');
                var originURL;
                function resolveURL(url) {
                    var href = url;
                    if (msie) {
                        urlParsingNode.setAttribute('href', href);
                        href = urlParsingNode.href;
                    }
                    urlParsingNode.setAttribute('href', href);
                    return {
                        href: urlParsingNode.href,
                        protocol: urlParsingNode.protocol ? urlParsingNode.protocol.replace(/:$/, '') : '',
                        host: urlParsingNode.host,
                        search: urlParsingNode.search ? urlParsingNode.search.replace(/^\?/, '') : '',
                        hash: urlParsingNode.hash ? urlParsingNode.hash.replace(/^#/, '') : '',
                        hostname: urlParsingNode.hostname,
                        port: urlParsingNode.port,
                        pathname: urlParsingNode.pathname.charAt(0) === '/' ? urlParsingNode.pathname : '/' + urlParsingNode.pathname
                    };
                }
                originURL = resolveURL(window.location.href);
                return function isURLSameOrigin(requestURL) {
                    var parsed = utils.isString(requestURL) ? resolveURL(requestURL) : requestURL;
                    return parsed.protocol === originURL.protocol && parsed.host === originURL.host;
                };
            }() : function nonStandardBrowserEnv() {
                return function isURLSameOrigin() {
                    return true;
                };
            }();
        },
        './node_modules/axios/lib/helpers/normalizeHeaderName.js': function (module, exports, __webpack_require__) {
            'use strict';
            var utils = __webpack_require__('./node_modules/axios/lib/utils.js');
            module.exports = function normalizeHeaderName(headers, normalizedName) {
                utils.forEach(headers, function processHeader(value, name) {
                    if (name !== normalizedName && name.toUpperCase() === normalizedName.toUpperCase()) {
                        headers[normalizedName] = value;
                        delete headers[name];
                    }
                });
            };
        },
        './node_modules/axios/lib/helpers/parseHeaders.js': function (module, exports, __webpack_require__) {
            'use strict';
            var utils = __webpack_require__('./node_modules/axios/lib/utils.js');
            var ignoreDuplicateOf = [
                'age',
                'authorization',
                'content-length',
                'content-type',
                'etag',
                'expires',
                'from',
                'host',
                'if-modified-since',
                'if-unmodified-since',
                'last-modified',
                'location',
                'max-forwards',
                'proxy-authorization',
                'referer',
                'retry-after',
                'user-agent'
            ];
            module.exports = function parseHeaders(headers) {
                var parsed = {};
                var key;
                var val;
                var i;
                if (!headers) {
                    return parsed;
                }
                utils.forEach(headers.split('\n'), function parser(line) {
                    i = line.indexOf(':');
                    key = utils.trim(line.substr(0, i)).toLowerCase();
                    val = utils.trim(line.substr(i + 1));
                    if (key) {
                        if (parsed[key] && ignoreDuplicateOf.indexOf(key) >= 0) {
                            return;
                        }
                        if (key === 'set-cookie') {
                            parsed[key] = (parsed[key] ? parsed[key] : []).concat([val]);
                        } else {
                            parsed[key] = parsed[key] ? parsed[key] + ', ' + val : val;
                        }
                    }
                });
                return parsed;
            };
        },
        './node_modules/axios/lib/helpers/spread.js': function (module, exports, __webpack_require__) {
            'use strict';
            module.exports = function spread(callback) {
                return function wrap(arr) {
                    return callback.apply(null, arr);
                };
            };
        },
        './node_modules/axios/lib/helpers/validator.js': function (module, exports, __webpack_require__) {
            'use strict';
            var pkg = __webpack_require__('./node_modules/axios/package.json');
            var validators = {};
            [
                'object',
                'boolean',
                'number',
                'function',
                'string',
                'symbol'
            ].forEach(function (type, i) {
                validators[type] = function validator(thing) {
                    return typeof thing === type || 'a' + (i < 1 ? 'n ' : ' ') + type;
                };
            });
            var deprecatedWarnings = {};
            var currentVerArr = pkg.version.split('.');
            function isOlderVersion(version, thanVersion) {
                var pkgVersionArr = thanVersion ? thanVersion.split('.') : currentVerArr;
                var destVer = version.split('.');
                for (var i = 0; i < 3; i++) {
                    if (pkgVersionArr[i] > destVer[i]) {
                        return true;
                    } else if (pkgVersionArr[i] < destVer[i]) {
                        return false;
                    }
                }
                return false;
            }
            validators.transitional = function transitional(validator, version, message) {
                var isDeprecated = version && isOlderVersion(version);
                function formatMessage(opt, desc) {
                    return '[Axios v' + pkg.version + '] Transitional option \'' + opt + '\'' + desc + (message ? '. ' + message : '');
                }
                return function (value, opt, opts) {
                    if (validator === false) {
                        throw new Error(formatMessage(opt, ' has been removed in ' + version));
                    }
                    if (isDeprecated && !deprecatedWarnings[opt]) {
                        deprecatedWarnings[opt] = true;
                        console.warn(formatMessage(opt, ' has been deprecated since v' + version + ' and will be removed in the near future'));
                    }
                    return validator ? validator(value, opt, opts) : true;
                };
            };
            function assertOptions(options, schema, allowUnknown) {
                if (typeof options !== 'object') {
                    throw new TypeError('options must be an object');
                }
                var keys = Object.keys(options);
                var i = keys.length;
                while (i-- > 0) {
                    var opt = keys[i];
                    var validator = schema[opt];
                    if (validator) {
                        var value = options[opt];
                        var result = value === undefined || validator(value, opt, options);
                        if (result !== true) {
                            throw new TypeError('option ' + opt + ' must be ' + result);
                        }
                        continue;
                    }
                    if (allowUnknown !== true) {
                        throw Error('Unknown option ' + opt);
                    }
                }
            }
            module.exports = {
                isOlderVersion: isOlderVersion,
                assertOptions: assertOptions,
                validators: validators
            };
        },
        './node_modules/axios/lib/utils.js': function (module, exports, __webpack_require__) {
            'use strict';
            var bind = __webpack_require__('./node_modules/axios/lib/helpers/bind.js');
            var toString = Object.prototype.toString;
            function isArray(val) {
                return toString.call(val) === '[object Array]';
            }
            function isUndefined(val) {
                return typeof val === 'undefined';
            }
            function isBuffer(val) {
                return val !== null && !isUndefined(val) && val.constructor !== null && !isUndefined(val.constructor) && typeof val.constructor.isBuffer === 'function' && val.constructor.isBuffer(val);
            }
            function isArrayBuffer(val) {
                return toString.call(val) === '[object ArrayBuffer]';
            }
            function isFormData(val) {
                return typeof FormData !== 'undefined' && val instanceof FormData;
            }
            function isArrayBufferView(val) {
                var result;
                if (typeof ArrayBuffer !== 'undefined' && ArrayBuffer.isView) {
                    result = ArrayBuffer.isView(val);
                } else {
                    result = val && val.buffer && val.buffer instanceof ArrayBuffer;
                }
                return result;
            }
            function isString(val) {
                return typeof val === 'string';
            }
            function isNumber(val) {
                return typeof val === 'number';
            }
            function isObject(val) {
                return val !== null && typeof val === 'object';
            }
            function isPlainObject(val) {
                if (toString.call(val) !== '[object Object]') {
                    return false;
                }
                var prototype = Object.getPrototypeOf(val);
                return prototype === null || prototype === Object.prototype;
            }
            function isDate(val) {
                return toString.call(val) === '[object Date]';
            }
            function isFile(val) {
                return toString.call(val) === '[object File]';
            }
            function isBlob(val) {
                return toString.call(val) === '[object Blob]';
            }
            function isFunction(val) {
                return toString.call(val) === '[object Function]';
            }
            function isStream(val) {
                return isObject(val) && isFunction(val.pipe);
            }
            function isURLSearchParams(val) {
                return typeof URLSearchParams !== 'undefined' && val instanceof URLSearchParams;
            }
            function trim(str) {
                return str.trim ? str.trim() : str.replace(/^\s+|\s+$/g, '');
            }
            function isStandardBrowserEnv() {
                if (typeof navigator !== 'undefined' && (navigator.product === 'ReactNative' || navigator.product === 'NativeScript' || navigator.product === 'NS')) {
                    return false;
                }
                return typeof window !== 'undefined' && typeof document !== 'undefined';
            }
            function forEach(obj, fn) {
                if (obj === null || typeof obj === 'undefined') {
                    return;
                }
                if (typeof obj !== 'object') {
                    obj = [obj];
                }
                if (isArray(obj)) {
                    for (var i = 0, l = obj.length; i < l; i++) {
                        fn.call(null, obj[i], i, obj);
                    }
                } else {
                    for (var key in obj) {
                        if (Object.prototype.hasOwnProperty.call(obj, key)) {
                            fn.call(null, obj[key], key, obj);
                        }
                    }
                }
            }
            function merge() {
                var result = {};
                function assignValue(val, key) {
                    if (isPlainObject(result[key]) && isPlainObject(val)) {
                        result[key] = merge(result[key], val);
                    } else if (isPlainObject(val)) {
                        result[key] = merge({}, val);
                    } else if (isArray(val)) {
                        result[key] = val.slice();
                    } else {
                        result[key] = val;
                    }
                }
                for (var i = 0, l = arguments.length; i < l; i++) {
                    forEach(arguments[i], assignValue);
                }
                return result;
            }
            function extend(a, b, thisArg) {
                forEach(b, function assignValue(val, key) {
                    if (thisArg && typeof val === 'function') {
                        a[key] = bind(val, thisArg);
                    } else {
                        a[key] = val;
                    }
                });
                return a;
            }
            function stripBOM(content) {
                if (content.charCodeAt(0) === 65279) {
                    content = content.slice(1);
                }
                return content;
            }
            module.exports = {
                isArray: isArray,
                isArrayBuffer: isArrayBuffer,
                isBuffer: isBuffer,
                isFormData: isFormData,
                isArrayBufferView: isArrayBufferView,
                isString: isString,
                isNumber: isNumber,
                isObject: isObject,
                isPlainObject: isPlainObject,
                isUndefined: isUndefined,
                isDate: isDate,
                isFile: isFile,
                isBlob: isBlob,
                isFunction: isFunction,
                isStream: isStream,
                isURLSearchParams: isURLSearchParams,
                isStandardBrowserEnv: isStandardBrowserEnv,
                forEach: forEach,
                merge: merge,
                extend: extend,
                trim: trim,
                stripBOM: stripBOM
            };
        },
        './node_modules/axios/package.json': function (module) {
            module.exports = JSON.parse('{"name":"axios","version":"0.21.4","description":"Promise based HTTP client for the browser and node.js","main":"index.js","scripts":{"test":"grunt test","start":"node ./sandbox/server.js","build":"NODE_ENV=production grunt build","preversion":"npm test","version":"npm run build && grunt version && git add -A dist && git add CHANGELOG.md bower.json package.json","postversion":"git push && git push --tags","examples":"node ./examples/server.js","coveralls":"cat coverage/lcov.info | ./node_modules/coveralls/bin/coveralls.js","fix":"eslint --fix lib/**/*.js"},"repository":{"type":"git","url":"https://github.com/axios/axios.git"},"keywords":["xhr","http","ajax","promise","node"],"author":"Matt Zabriskie","license":"MIT","bugs":{"url":"https://github.com/axios/axios/issues"},"homepage":"https://axios-http.com","devDependencies":{"coveralls":"^3.0.0","es6-promise":"^4.2.4","grunt":"^1.3.0","grunt-banner":"^0.6.0","grunt-cli":"^1.2.0","grunt-contrib-clean":"^1.1.0","grunt-contrib-watch":"^1.0.0","grunt-eslint":"^23.0.0","grunt-karma":"^4.0.0","grunt-mocha-test":"^0.13.3","grunt-ts":"^6.0.0-beta.19","grunt-webpack":"^4.0.2","istanbul-instrumenter-loader":"^1.0.0","jasmine-core":"^2.4.1","karma":"^6.3.2","karma-chrome-launcher":"^3.1.0","karma-firefox-launcher":"^2.1.0","karma-jasmine":"^1.1.1","karma-jasmine-ajax":"^0.1.13","karma-safari-launcher":"^1.0.0","karma-sauce-launcher":"^4.3.6","karma-sinon":"^1.0.5","karma-sourcemap-loader":"^0.3.8","karma-webpack":"^4.0.2","load-grunt-tasks":"^3.5.2","minimist":"^1.2.0","mocha":"^8.2.1","sinon":"^4.5.0","terser-webpack-plugin":"^4.2.3","typescript":"^4.0.5","url-search-params":"^0.10.0","webpack":"^4.44.2","webpack-dev-server":"^3.11.0"},"browser":{"./lib/adapters/http.js":"./lib/adapters/xhr.js"},"jsdelivr":"dist/axios.min.js","unpkg":"dist/axios.min.js","typings":"./index.d.ts","dependencies":{"follow-redirects":"^1.14.0"},"bundlesize":[{"path":"./dist/axios.min.js","threshold":"5kB"}]}');
        },
        './node_modules/classnames/index.js': function (module, exports, __webpack_require__) {
            var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
            (function () {
                'use strict';
                var hasOwn = {}.hasOwnProperty;
                function classNames() {
                    var classes = [];
                    for (var i = 0; i < arguments.length; i++) {
                        var arg = arguments[i];
                        if (!arg)
                            continue;
                        var argType = typeof arg;
                        if (argType === 'string' || argType === 'number') {
                            classes.push(arg);
                        } else if (Array.isArray(arg)) {
                            if (arg.length) {
                                var inner = classNames.apply(null, arg);
                                if (inner) {
                                    classes.push(inner);
                                }
                            }
                        } else if (argType === 'object') {
                            if (arg.toString === Object.prototype.toString) {
                                for (var key in arg) {
                                    if (hasOwn.call(arg, key) && arg[key]) {
                                        classes.push(key);
                                    }
                                }
                            } else {
                                classes.push(arg.toString());
                            }
                        }
                    }
                    return classes.join(' ');
                }
                if (true && module.exports) {
                    classNames.default = classNames;
                    module.exports = classNames;
                } else if (true) {
                    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = function () {
                        return classNames;
                    }.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
                } else {
                }
            }());
        },
        './node_modules/css-loader/dist/cjs.js!./src/common/components/bubble/index.css': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__('./node_modules/css-loader/dist/runtime/cssWithMappingToString.js');
            var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
            var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__('./node_modules/css-loader/dist/runtime/api.js');
            var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
            var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default.a);
            ___CSS_LOADER_EXPORT___.push([
                module.i,
                '.bubble-element {\n\theight: 24px !important;\n\twidth: 30px !important;\n}\n',
                '',
                {
                    'version': 3,
                    'sources': ['webpack://./src/common/components/bubble/index.css'],
                    'names': [],
                    'mappings': 'AAAA;CACC,uBAAuB;CACvB,sBAAsB;AACvB',
                    'sourcesContent': ['.bubble-element {\n\theight: 24px !important;\n\twidth: 30px !important;\n}\n'],
                    'sourceRoot': ''
                }
            ]);
            __webpack_exports__['default'] = ___CSS_LOADER_EXPORT___;
        },
        './node_modules/css-loader/dist/cjs.js!./src/common/components/section-list/index.css': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__('./node_modules/css-loader/dist/runtime/cssWithMappingToString.js');
            var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
            var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__('./node_modules/css-loader/dist/runtime/api.js');
            var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
            var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default.a);
            ___CSS_LOADER_EXPORT___.push([
                module.i,
                '.section-list-container .section-box.border-bottom-dashed:not(:last-child) {\n\tborder-bottom: 1px dashed #d3d3d4;\n\tpadding-bottom: 10px;\n}\n\n.section-list-container .section-content .subsection-container {\n\tcursor: pointer;\n}\n\n.section-list-container .section-box .section-header {\n\tfont-weight: 900 !important;\n}\n\n.section-list-container .subsection-container .arrow-icon svg {\n\theight: 20px !important;\n\twidth: 20px !important;\n}\n',
                '',
                {
                    'version': 3,
                    'sources': ['webpack://./src/common/components/section-list/index.css'],
                    'names': [],
                    'mappings': 'AAAA;CACC,iCAAiC;CACjC,oBAAoB;AACrB;;AAEA;CACC,eAAe;AAChB;;AAEA;CACC,2BAA2B;AAC5B;;AAEA;CACC,uBAAuB;CACvB,sBAAsB;AACvB',
                    'sourcesContent': ['.section-list-container .section-box.border-bottom-dashed:not(:last-child) {\n\tborder-bottom: 1px dashed #d3d3d4;\n\tpadding-bottom: 10px;\n}\n\n.section-list-container .section-content .subsection-container {\n\tcursor: pointer;\n}\n\n.section-list-container .section-box .section-header {\n\tfont-weight: 900 !important;\n}\n\n.section-list-container .subsection-container .arrow-icon svg {\n\theight: 20px !important;\n\twidth: 20px !important;\n}\n'],
                    'sourceRoot': ''
                }
            ]);
            __webpack_exports__['default'] = ___CSS_LOADER_EXPORT___;
        },
        './node_modules/css-loader/dist/runtime/api.js': function (module, exports, __webpack_require__) {
            'use strict';
            module.exports = function (cssWithMappingToString) {
                var list = [];
                list.toString = function toString() {
                    return this.map(function (item) {
                        var content = cssWithMappingToString(item);
                        if (item[2]) {
                            return '@media '.concat(item[2], ' {').concat(content, '}');
                        }
                        return content;
                    }).join('');
                };
                list.i = function (modules, mediaQuery, dedupe) {
                    if (typeof modules === 'string') {
                        modules = [[
                                null,
                                modules,
                                ''
                            ]];
                    }
                    var alreadyImportedModules = {};
                    if (dedupe) {
                        for (var i = 0; i < this.length; i++) {
                            var id = this[i][0];
                            if (id != null) {
                                alreadyImportedModules[id] = true;
                            }
                        }
                    }
                    for (var _i = 0; _i < modules.length; _i++) {
                        var item = [].concat(modules[_i]);
                        if (dedupe && alreadyImportedModules[item[0]]) {
                            continue;
                        }
                        if (mediaQuery) {
                            if (!item[2]) {
                                item[2] = mediaQuery;
                            } else {
                                item[2] = ''.concat(mediaQuery, ' and ').concat(item[2]);
                            }
                        }
                        list.push(item);
                    }
                };
                return list;
            };
        },
        './node_modules/css-loader/dist/runtime/cssWithMappingToString.js': function (module, exports, __webpack_require__) {
            'use strict';
            function _slicedToArray(arr, i) {
                return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
            }
            function _nonIterableRest() {
                throw new TypeError('Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.');
            }
            function _unsupportedIterableToArray(o, minLen) {
                if (!o)
                    return;
                if (typeof o === 'string')
                    return _arrayLikeToArray(o, minLen);
                var n = Object.prototype.toString.call(o).slice(8, -1);
                if (n === 'Object' && o.constructor)
                    n = o.constructor.name;
                if (n === 'Map' || n === 'Set')
                    return Array.from(o);
                if (n === 'Arguments' || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))
                    return _arrayLikeToArray(o, minLen);
            }
            function _arrayLikeToArray(arr, len) {
                if (len == null || len > arr.length)
                    len = arr.length;
                for (var i = 0, arr2 = new Array(len); i < len; i++) {
                    arr2[i] = arr[i];
                }
                return arr2;
            }
            function _iterableToArrayLimit(arr, i) {
                var _i = arr && (typeof Symbol !== 'undefined' && arr[Symbol.iterator] || arr['@@iterator']);
                if (_i == null)
                    return;
                var _arr = [];
                var _n = true;
                var _d = false;
                var _s, _e;
                try {
                    for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) {
                        _arr.push(_s.value);
                        if (i && _arr.length === i)
                            break;
                    }
                } catch (err) {
                    _d = true;
                    _e = err;
                } finally {
                    try {
                        if (!_n && _i['return'] != null)
                            _i['return']();
                    } finally {
                        if (_d)
                            throw _e;
                    }
                }
                return _arr;
            }
            function _arrayWithHoles(arr) {
                if (Array.isArray(arr))
                    return arr;
            }
            module.exports = function cssWithMappingToString(item) {
                var _item = _slicedToArray(item, 4), content = _item[1], cssMapping = _item[3];
                if (!cssMapping) {
                    return content;
                }
                if (typeof btoa === 'function') {
                    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(cssMapping))));
                    var data = 'sourceMappingURL=data:application/json;charset=utf-8;base64,'.concat(base64);
                    var sourceMapping = '/*# '.concat(data, ' */');
                    var sourceURLs = cssMapping.sources.map(function (source) {
                        return '/*# sourceURL='.concat(cssMapping.sourceRoot || '').concat(source, ' */');
                    });
                    return [content].concat(sourceURLs).concat([sourceMapping]).join('\n');
                }
                return [content].join('\n');
            };
        },
        './node_modules/process/browser.js': function (module, exports) {
            var process = module.exports = {};
            var cachedSetTimeout;
            var cachedClearTimeout;
            function defaultSetTimout() {
                throw new Error('setTimeout has not been defined');
            }
            function defaultClearTimeout() {
                throw new Error('clearTimeout has not been defined');
            }
            (function () {
                try {
                    if (typeof setTimeout === 'function') {
                        cachedSetTimeout = setTimeout;
                    } else {
                        cachedSetTimeout = defaultSetTimout;
                    }
                } catch (e) {
                    cachedSetTimeout = defaultSetTimout;
                }
                try {
                    if (typeof clearTimeout === 'function') {
                        cachedClearTimeout = clearTimeout;
                    } else {
                        cachedClearTimeout = defaultClearTimeout;
                    }
                } catch (e) {
                    cachedClearTimeout = defaultClearTimeout;
                }
            }());
            function runTimeout(fun) {
                if (cachedSetTimeout === setTimeout) {
                    return setTimeout(fun, 0);
                }
                if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
                    cachedSetTimeout = setTimeout;
                    return setTimeout(fun, 0);
                }
                try {
                    return cachedSetTimeout(fun, 0);
                } catch (e) {
                    try {
                        return cachedSetTimeout.call(null, fun, 0);
                    } catch (e) {
                        return cachedSetTimeout.call(this, fun, 0);
                    }
                }
            }
            function runClearTimeout(marker) {
                if (cachedClearTimeout === clearTimeout) {
                    return clearTimeout(marker);
                }
                if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
                    cachedClearTimeout = clearTimeout;
                    return clearTimeout(marker);
                }
                try {
                    return cachedClearTimeout(marker);
                } catch (e) {
                    try {
                        return cachedClearTimeout.call(null, marker);
                    } catch (e) {
                        return cachedClearTimeout.call(this, marker);
                    }
                }
            }
            var queue = [];
            var draining = false;
            var currentQueue;
            var queueIndex = -1;
            function cleanUpNextTick() {
                if (!draining || !currentQueue) {
                    return;
                }
                draining = false;
                if (currentQueue.length) {
                    queue = currentQueue.concat(queue);
                } else {
                    queueIndex = -1;
                }
                if (queue.length) {
                    drainQueue();
                }
            }
            function drainQueue() {
                if (draining) {
                    return;
                }
                var timeout = runTimeout(cleanUpNextTick);
                draining = true;
                var len = queue.length;
                while (len) {
                    currentQueue = queue;
                    queue = [];
                    while (++queueIndex < len) {
                        if (currentQueue) {
                            currentQueue[queueIndex].run();
                        }
                    }
                    queueIndex = -1;
                    len = queue.length;
                }
                currentQueue = null;
                draining = false;
                runClearTimeout(timeout);
            }
            process.nextTick = function (fun) {
                var args = new Array(arguments.length - 1);
                if (arguments.length > 1) {
                    for (var i = 1; i < arguments.length; i++) {
                        args[i - 1] = arguments[i];
                    }
                }
                queue.push(new Item(fun, args));
                if (queue.length === 1 && !draining) {
                    runTimeout(drainQueue);
                }
            };
            function Item(fun, array) {
                this.fun = fun;
                this.array = array;
            }
            Item.prototype.run = function () {
                this.fun.apply(null, this.array);
            };
            process.title = 'browser';
            process.browser = true;
            process.env = {};
            process.argv = [];
            process.version = '';
            process.versions = {};
            function noop() {
            }
            process.on = noop;
            process.addListener = noop;
            process.once = noop;
            process.off = noop;
            process.removeListener = noop;
            process.removeAllListeners = noop;
            process.emit = noop;
            process.prependListener = noop;
            process.prependOnceListener = noop;
            process.listeners = function (name) {
                return [];
            };
            process.binding = function (name) {
                throw new Error('process.binding is not supported');
            };
            process.cwd = function () {
                return '/';
            };
            process.chdir = function (dir) {
                throw new Error('process.chdir is not supported');
            };
            process.umask = function () {
                return 0;
            };
        },
        './node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js': function (module, exports, __webpack_require__) {
            'use strict';
            var isOldIE = function isOldIE() {
                var memo;
                return function memorize() {
                    if (typeof memo === 'undefined') {
                        memo = Boolean(window && document && document.all && !window.atob);
                    }
                    return memo;
                };
            }();
            var getTarget = function getTarget() {
                var memo = {};
                return function memorize(target) {
                    if (typeof memo[target] === 'undefined') {
                        var styleTarget = document.querySelector(target);
                        if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
                            try {
                                styleTarget = styleTarget.contentDocument.head;
                            } catch (e) {
                                styleTarget = null;
                            }
                        }
                        memo[target] = styleTarget;
                    }
                    return memo[target];
                };
            }();
            var stylesInDom = [];
            function getIndexByIdentifier(identifier) {
                var result = -1;
                for (var i = 0; i < stylesInDom.length; i++) {
                    if (stylesInDom[i].identifier === identifier) {
                        result = i;
                        break;
                    }
                }
                return result;
            }
            function modulesToDom(list, options) {
                var idCountMap = {};
                var identifiers = [];
                for (var i = 0; i < list.length; i++) {
                    var item = list[i];
                    var id = options.base ? item[0] + options.base : item[0];
                    var count = idCountMap[id] || 0;
                    var identifier = ''.concat(id, ' ').concat(count);
                    idCountMap[id] = count + 1;
                    var index = getIndexByIdentifier(identifier);
                    var obj = {
                        css: item[1],
                        media: item[2],
                        sourceMap: item[3]
                    };
                    if (index !== -1) {
                        stylesInDom[index].references++;
                        stylesInDom[index].updater(obj);
                    } else {
                        stylesInDom.push({
                            identifier: identifier,
                            updater: addStyle(obj, options),
                            references: 1
                        });
                    }
                    identifiers.push(identifier);
                }
                return identifiers;
            }
            function insertStyleElement(options) {
                var style = document.createElement('style');
                var attributes = options.attributes || {};
                if (typeof attributes.nonce === 'undefined') {
                    var nonce = true ? __webpack_require__.nc : undefined;
                    if (nonce) {
                        attributes.nonce = nonce;
                    }
                }
                Object.keys(attributes).forEach(function (key) {
                    style.setAttribute(key, attributes[key]);
                });
                if (typeof options.insert === 'function') {
                    options.insert(style);
                } else {
                    var target = getTarget(options.insert || 'head');
                    if (!target) {
                        throw new Error('Couldn\'t find a style target. This probably means that the value for the \'insert\' parameter is invalid.');
                    }
                    target.appendChild(style);
                }
                return style;
            }
            function removeStyleElement(style) {
                if (style.parentNode === null) {
                    return false;
                }
                style.parentNode.removeChild(style);
            }
            var replaceText = function replaceText() {
                var textStore = [];
                return function replace(index, replacement) {
                    textStore[index] = replacement;
                    return textStore.filter(Boolean).join('\n');
                };
            }();
            function applyToSingletonTag(style, index, remove, obj) {
                var css = remove ? '' : obj.media ? '@media '.concat(obj.media, ' {').concat(obj.css, '}') : obj.css;
                if (style.styleSheet) {
                    style.styleSheet.cssText = replaceText(index, css);
                } else {
                    var cssNode = document.createTextNode(css);
                    var childNodes = style.childNodes;
                    if (childNodes[index]) {
                        style.removeChild(childNodes[index]);
                    }
                    if (childNodes.length) {
                        style.insertBefore(cssNode, childNodes[index]);
                    } else {
                        style.appendChild(cssNode);
                    }
                }
            }
            function applyToTag(style, options, obj) {
                var css = obj.css;
                var media = obj.media;
                var sourceMap = obj.sourceMap;
                if (media) {
                    style.setAttribute('media', media);
                } else {
                    style.removeAttribute('media');
                }
                if (sourceMap && typeof btoa !== 'undefined') {
                    css += '\n/*# sourceMappingURL=data:application/json;base64,'.concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), ' */');
                }
                if (style.styleSheet) {
                    style.styleSheet.cssText = css;
                } else {
                    while (style.firstChild) {
                        style.removeChild(style.firstChild);
                    }
                    style.appendChild(document.createTextNode(css));
                }
            }
            var singleton = null;
            var singletonCounter = 0;
            function addStyle(obj, options) {
                var style;
                var update;
                var remove;
                if (options.singleton) {
                    var styleIndex = singletonCounter++;
                    style = singleton || (singleton = insertStyleElement(options));
                    update = applyToSingletonTag.bind(null, style, styleIndex, false);
                    remove = applyToSingletonTag.bind(null, style, styleIndex, true);
                } else {
                    style = insertStyleElement(options);
                    update = applyToTag.bind(null, style, options);
                    remove = function remove() {
                        removeStyleElement(style);
                    };
                }
                update(obj);
                return function updateStyle(newObj) {
                    if (newObj) {
                        if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap) {
                            return;
                        }
                        update(obj = newObj);
                    } else {
                        remove();
                    }
                };
            }
            module.exports = function (list, options) {
                options = options || {};
                if (!options.singleton && typeof options.singleton !== 'boolean') {
                    options.singleton = isOldIE();
                }
                list = list || [];
                var lastIdentifiers = modulesToDom(list, options);
                return function update(newList) {
                    newList = newList || [];
                    if (Object.prototype.toString.call(newList) !== '[object Array]') {
                        return;
                    }
                    for (var i = 0; i < lastIdentifiers.length; i++) {
                        var identifier = lastIdentifiers[i];
                        var index = getIndexByIdentifier(identifier);
                        stylesInDom[index].references--;
                    }
                    var newLastIdentifiers = modulesToDom(newList, options);
                    for (var _i = 0; _i < lastIdentifiers.length; _i++) {
                        var _identifier = lastIdentifiers[_i];
                        var _index = getIndexByIdentifier(_identifier);
                        if (stylesInDom[_index].references === 0) {
                            stylesInDom[_index].updater();
                            stylesInDom.splice(_index, 1);
                        }
                    }
                    lastIdentifiers = newLastIdentifiers;
                };
            };
        },
        './node_modules/warning/warning.js': function (module, exports, __webpack_require__) {
            'use strict';
            var __DEV__ = 'development' !== 'production';
            var warning = function () {
            };
            if (__DEV__) {
                var printWarning = function printWarning(format, args) {
                    var len = arguments.length;
                    args = new Array(len > 1 ? len - 1 : 0);
                    for (var key = 1; key < len; key++) {
                        args[key - 1] = arguments[key];
                    }
                    var argIndex = 0;
                    var message = 'Warning: ' + format.replace(/%s/g, function () {
                        return args[argIndex++];
                    });
                    if (typeof console !== 'undefined') {
                        console.error(message);
                    }
                    try {
                        throw new Error(message);
                    } catch (x) {
                    }
                };
                warning = function (condition, format, args) {
                    var len = arguments.length;
                    args = new Array(len > 2 ? len - 2 : 0);
                    for (var key = 2; key < len; key++) {
                        args[key - 2] = arguments[key];
                    }
                    if (format === undefined) {
                        throw new Error('`warning(condition, format, ...args)` requires a warning ' + 'message argument');
                    }
                    if (!condition) {
                        printWarning.apply(null, [format].concat(args));
                    }
                };
            }
            module.exports = warning;
        },
        './src/common/components/bubble/index.css': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__('./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js');
            var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
            var _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__('./node_modules/css-loader/dist/cjs.js!./src/common/components/bubble/index.css');
            var options = {};
            options.insert = 'head';
            options.singleton = false;
            var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__['default'], options);
            __webpack_exports__['default'] = _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__['default'].locals || {};
        },
        './src/common/components/bubble/index.js': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            var _index_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__('./src/common/components/bubble/index.css');
            var React_raw = __REQUIRE__('__REACT_PROVIDER__$react');
            var React = React_raw && React_raw.__esModule ? React_raw['default'] : React_raw;
            var Bubble = function Bubble(_ref) {
                var value = _ref.value;
                return React.createElement('div', { className: 'align-items-center bg-brand-primary-lighten-5 bubble-element d-flex flex-shrink-0 font-weight-bolder justify-content-center ml-3 rounded-xl text-brand-primary text-paragraph-sm' }, value);
            };
            __webpack_exports__['default'] = Bubble;
        },
        './src/common/components/section-list/index.css': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__('./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js');
            var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
            var _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__('./node_modules/css-loader/dist/cjs.js!./src/common/components/section-list/index.css');
            var options = {};
            options.insert = 'head';
            options.singleton = false;
            var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__['default'], options);
            __webpack_exports__['default'] = _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__['default'].locals || {};
        },
        './src/common/components/section-list/index.js': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            var _section__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__('./src/common/components/section-list/section/index.js');
            var _index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__('./src/common/components/section-list/index.css');
            var React_raw = __REQUIRE__('__REACT_PROVIDER__$react');
            var React = React_raw && React_raw.__esModule ? React_raw['default'] : React_raw;
            var SectionList = function SectionList(_ref) {
                var sections = _ref.sections;
                return React.createElement('div', { className: 'd-flex flex-column mx-3 section-list-container' }, sections.map(function (section, index) {
                    if (section.active) {
                        return React.createElement(_section__WEBPACK_IMPORTED_MODULE_0__['default'], {
                            index: index,
                            key: index,
                            section: section
                        });
                    }
                }));
            };
            __webpack_exports__['default'] = SectionList;
        },
        './src/common/components/section-list/section/index.js': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__('./node_modules/classnames/index.js');
            var classnames__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
            var _subsection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__('./src/common/components/section-list/subsection/index.js');
            var React_raw = __REQUIRE__('__REACT_PROVIDER__$react');
            var React = React_raw && React_raw.__esModule ? React_raw['default'] : React_raw;
            var Section = function Section(_ref) {
                var index = _ref.index, section = _ref.section;
                return React.createElement('div', { className: classnames__WEBPACK_IMPORTED_MODULE_0___default()('border-bottom-dashed section-box', { 'mt-2': index !== 0 }) }, React.createElement('div', { className: 'h6 py-2 section-header text-neutral-8 text-small-caps' }, section.name), React.createElement('div', { className: 'd-flex flex-column section-content' }, section.subSections.map(function (subSection, index) {
                    return React.createElement(_subsection__WEBPACK_IMPORTED_MODULE_1__['default'], {
                        key: index,
                        section: section,
                        subSection: subSection
                    });
                })));
            };
            __webpack_exports__['default'] = Section;
        },
        './src/common/components/section-list/subsection/index.js': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            var _clayui_icon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__('./node_modules/@clayui/icon/lib/index.js');
            var _clayui_icon__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(_clayui_icon__WEBPACK_IMPORTED_MODULE_0__);
            var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__('./node_modules/classnames/index.js');
            var classnames__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
            var _utils_liferay__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__('./src/common/utils/liferay.js');
            var _bubble__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__('./src/common/components/bubble/index.js');
            var React_raw = __REQUIRE__('__REACT_PROVIDER__$react');
            var React = React_raw && React_raw.__esModule ? React_raw['default'] : React_raw;
            var SubSection = function SubSection(_ref) {
                var section = _ref.section, subSection = _ref.subSection;
                return React.createElement('div', {
                    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()('my-2 row subsection-container text-neutral-9 text-paragraph', { 'd-none': !subSection.active }),
                    onClick: function onClick() {
                        return Object(_utils_liferay__WEBPACK_IMPORTED_MODULE_2__['redirectTo'])(section.link);
                    }
                }, React.createElement('div', { className: 'col-9' }, subSection.name), React.createElement('div', { className: 'align-items-center col-3 d-flex flex-row justify-content-between p-0' }, React.createElement(_bubble__WEBPACK_IMPORTED_MODULE_3__['default'], { value: subSection.value }), React.createElement('div', { className: 'arrow-icon mr-2' }, React.createElement(_clayui_icon__WEBPACK_IMPORTED_MODULE_0___default.a, {
                    className: 'text-neutral-5',
                    symbol: 'angle-right-small'
                }))));
            };
            __webpack_exports__['default'] = SubSection;
        },
        './src/common/context/ClayIconProvider.js': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            var _clayui_icon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__('./node_modules/@clayui/icon/lib/index.js');
            var _clayui_icon__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(_clayui_icon__WEBPACK_IMPORTED_MODULE_0__);
            var _utils_liferay__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__('./src/common/utils/liferay.js');
            var React_raw = __REQUIRE__('__REACT_PROVIDER__$react');
            var React = React_raw && React_raw.__esModule ? React_raw['default'] : React_raw;
            var getIconSpriteMap = function getIconSpriteMap() {
                var pathThemeImages = _utils_liferay__WEBPACK_IMPORTED_MODULE_1__['Liferay'].ThemeDisplay.getPathThemeImages();
                var spritemap = ''.concat(pathThemeImages, '/clay/icons.svg');
                return spritemap;
            };
            var ClayIconProvider = function ClayIconProvider(_ref) {
                var children = _ref.children;
                return React.createElement(_clayui_icon__WEBPACK_IMPORTED_MODULE_0__['ClayIconSpriteContext'].Provider, { value: getIconSpriteMap() }, children);
            };
            __webpack_exports__['default'] = ClayIconProvider;
        },
        './src/common/services/Application.js': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            __webpack_require__.d(__webpack_exports__, 'getApplicationsStatus', function () {
                return getApplicationsStatus;
            });
            __webpack_require__.d(__webpack_exports__, 'getApplicationsStatusTotal', function () {
                return getApplicationsStatusTotal;
            });
            __webpack_require__.d(__webpack_exports__, 'getApplications', function () {
                return getApplications;
            });
            __webpack_require__.d(__webpack_exports__, 'getNewSubmissions', function () {
                return getNewSubmissions;
            });
            var _liferay_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__('./src/common/services/liferay/api.js');
            var DeliveryAPI = 'o/c/raylifeapplications';
            function getApplicationsStatus(status) {
                return _liferay_api__WEBPACK_IMPORTED_MODULE_0__['axios'].get(''.concat(DeliveryAPI, '/?filter=applicationStatus eq \'').concat(status, '\''));
            }
            function getApplicationsStatusTotal() {
                return _liferay_api__WEBPACK_IMPORTED_MODULE_0__['axios'].get(''.concat(DeliveryAPI, '/?aggregationTerms=applicationStatus'));
            }
            function getApplications() {
                return _liferay_api__WEBPACK_IMPORTED_MODULE_0__['axios'].get(''.concat(DeliveryAPI, '/'));
            }
            function getNewSubmissions(currentYear, currentMonth, periodYear, periodMonth) {
                return _liferay_api__WEBPACK_IMPORTED_MODULE_0__['axios'].get(''.concat(DeliveryAPI, '/?fields=applicationStatus,applicationCreateDate&filter=applicationStatus ne \'Bound\' and applicationStatus ne \'Reviewed\' and applicationCreateDate le ').concat(currentYear, '-').concat(currentMonth, '-31 and applicationCreateDate ge ').concat(periodYear, '-').concat(periodMonth, '-01&pageSize=200'));
            }
        },
        './src/common/services/Claim.js': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            __webpack_require__.d(__webpack_exports__, 'getClaimsStatus', function () {
                return getClaimsStatus;
            });
            var _liferay_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__('./src/common/services/liferay/api.js');
            var DeliveryAPI = 'o/c/raylifeclaims';
            function getClaimsStatus(status) {
                return _liferay_api__WEBPACK_IMPORTED_MODULE_0__['axios'].get(''.concat(DeliveryAPI, '/?filter=claimStatus eq \'').concat(status, '\''));
            }
        },
        './src/common/services/Policy.js': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            __webpack_require__.d(__webpack_exports__, 'getPoliciesStatus', function () {
                return getPoliciesStatus;
            });
            __webpack_require__.d(__webpack_exports__, 'getActivePolicies', function () {
                return getActivePolicies;
            });
            __webpack_require__.d(__webpack_exports__, 'getSixMonthsAgoPolicies', function () {
                return getSixMonthsAgoPolicies;
            });
            __webpack_require__.d(__webpack_exports__, 'getLastYearSixMonthsPolicies', function () {
                return getLastYearSixMonthsPolicies;
            });
            __webpack_require__.d(__webpack_exports__, 'getPoliciesUntilCurrentMonth', function () {
                return getPoliciesUntilCurrentMonth;
            });
            __webpack_require__.d(__webpack_exports__, 'getPoliciesUntilCurrentMonthLastYear', function () {
                return getPoliciesUntilCurrentMonthLastYear;
            });
            __webpack_require__.d(__webpack_exports__, 'getPoliciesForSalesGoal', function () {
                return getPoliciesForSalesGoal;
            });
            var _utils_dateFormatter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__('./src/common/utils/dateFormatter.js');
            var _liferay_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__('./src/common/services/liferay/api.js');
            var DeliveryAPI = 'o/c/raylifepolicies';
            var userId = Liferay.ThemeDisplay.getUserId();
            function getPoliciesStatus(totalCount) {
                return new Promise(function (resolve) {
                    resolve({ data: { totalCount: totalCount } });
                });
            }
            function getActivePolicies() {
                return _liferay_api__WEBPACK_IMPORTED_MODULE_1__['axios'].get(''.concat(DeliveryAPI, '/?fields=policyStatus,productName&pageSize=200&aggregationTerms=policyStatus&filter=policyStatus ne \'expired\' and policyStatus ne \'declined\''));
            }
            function getSixMonthsAgoPolicies() {
                return _liferay_api__WEBPACK_IMPORTED_MODULE_1__['axios'].get(''.concat(DeliveryAPI, '/?filter=policyStatus ne \'declined\' and (startDate le ').concat(_utils_dateFormatter__WEBPACK_IMPORTED_MODULE_0__['currentDate'], ' and startDate ge ').concat(_utils_dateFormatter__WEBPACK_IMPORTED_MODULE_0__['sixMonthsAgoDate'][0], '-').concat(_utils_dateFormatter__WEBPACK_IMPORTED_MODULE_0__['sixMonthsAgoDate'][1], '-01)&pageSize=200'));
            }
            function getLastYearSixMonthsPolicies() {
                return _liferay_api__WEBPACK_IMPORTED_MODULE_1__['axios'].get(''.concat(DeliveryAPI, '/?filter=policyStatus ne \'declined\' and (startDate le ').concat(_utils_dateFormatter__WEBPACK_IMPORTED_MODULE_0__['oneYearAgoDate'], ' and startDate ge ').concat(_utils_dateFormatter__WEBPACK_IMPORTED_MODULE_0__['lastYearSixMonthsAgoPeriod'][0], '-').concat(_utils_dateFormatter__WEBPACK_IMPORTED_MODULE_0__['lastYearSixMonthsAgoPeriod'][1], '-01)&pageSize=200'));
            }
            function getPoliciesUntilCurrentMonth() {
                return _liferay_api__WEBPACK_IMPORTED_MODULE_1__['axios'].get(''.concat(DeliveryAPI, '/?filter=policyStatus ne \'declined\' and (startDate le ').concat(_utils_dateFormatter__WEBPACK_IMPORTED_MODULE_0__['currentDate'], ' and startDate ge ').concat(_utils_dateFormatter__WEBPACK_IMPORTED_MODULE_0__['currentYear'], '-01-01)&pageSize=200'));
            }
            function getPoliciesUntilCurrentMonthLastYear() {
                return _liferay_api__WEBPACK_IMPORTED_MODULE_1__['axios'].get(''.concat(DeliveryAPI, '/?filter=policyStatus ne \'declined\' and (startDate le ').concat(_utils_dateFormatter__WEBPACK_IMPORTED_MODULE_0__['oneYearAgoDate'], ' and startDate ge ').concat(_utils_dateFormatter__WEBPACK_IMPORTED_MODULE_0__['lastYear'], '-01-01)&pageSize=200'));
            }
            function getPoliciesForSalesGoal(currentYear, currentMonth, periodYear, periodMonth) {
                return _liferay_api__WEBPACK_IMPORTED_MODULE_1__['axios'].get(''.concat(DeliveryAPI, '/?fields=boundDate,termPremium&pageSize=200&filter=policyStatus ne \'declined\' and userId eq \'').concat(userId, '\' and boundDate le ').concat(currentYear, '-').concat(currentMonth, '-31 and boundDate ge ').concat(periodYear, '-').concat(periodMonth, '-01'));
            }
        },
        './src/common/services/Products.js': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            __webpack_require__.d(__webpack_exports__, 'getProducts', function () {
                return getProducts;
            });
            __webpack_require__.d(__webpack_exports__, 'getChannelId', function () {
                return getChannelId;
            });
            var _liferay_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__('./src/common/services/liferay/api.js');
            var headlessAPI = 'o/headless-commerce-delivery-catalog/v1.0';
            function getProducts() {
                var result = getChannelId('Raylife AP').then(function (response) {
                    var items = response.data.items;
                    var channelId = items[0].id;
                    return _liferay_api__WEBPACK_IMPORTED_MODULE_0__['axios'].get(''.concat(headlessAPI, '/channels/').concat(channelId, '/products?nestedFields=skus,catalog&page=1&pageSize=50'));
                });
                return result;
            }
            function getChannelId(channelName) {
                return _liferay_api__WEBPACK_IMPORTED_MODULE_0__['axios'].get(''.concat(headlessAPI, '/channels?filter=contains(name, \'').concat(channelName, '\')&fields=id'));
            }
        },
        './src/common/services/Report.js': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            __webpack_require__.d(__webpack_exports__, 'getReportsStatus', function () {
                return getReportsStatus;
            });
            function getReportsStatus(totalCount) {
                return new Promise(function (resolve) {
                    resolve({ data: { totalCount: totalCount } });
                });
            }
        },
        './src/common/services/index.js': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            var _Application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__('./src/common/services/Application.js');
            __webpack_require__.d(__webpack_exports__, 'getApplicationsStatus', function () {
                return _Application__WEBPACK_IMPORTED_MODULE_0__['getApplicationsStatus'];
            });
            __webpack_require__.d(__webpack_exports__, 'getApplicationsStatusTotal', function () {
                return _Application__WEBPACK_IMPORTED_MODULE_0__['getApplicationsStatusTotal'];
            });
            __webpack_require__.d(__webpack_exports__, 'getApplications', function () {
                return _Application__WEBPACK_IMPORTED_MODULE_0__['getApplications'];
            });
            __webpack_require__.d(__webpack_exports__, 'getNewSubmissions', function () {
                return _Application__WEBPACK_IMPORTED_MODULE_0__['getNewSubmissions'];
            });
            var _Claim__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__('./src/common/services/Claim.js');
            __webpack_require__.d(__webpack_exports__, 'getClaimsStatus', function () {
                return _Claim__WEBPACK_IMPORTED_MODULE_1__['getClaimsStatus'];
            });
            var _Policy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__('./src/common/services/Policy.js');
            __webpack_require__.d(__webpack_exports__, 'getPoliciesStatus', function () {
                return _Policy__WEBPACK_IMPORTED_MODULE_2__['getPoliciesStatus'];
            });
            __webpack_require__.d(__webpack_exports__, 'getActivePolicies', function () {
                return _Policy__WEBPACK_IMPORTED_MODULE_2__['getActivePolicies'];
            });
            __webpack_require__.d(__webpack_exports__, 'getSixMonthsAgoPolicies', function () {
                return _Policy__WEBPACK_IMPORTED_MODULE_2__['getSixMonthsAgoPolicies'];
            });
            __webpack_require__.d(__webpack_exports__, 'getLastYearSixMonthsPolicies', function () {
                return _Policy__WEBPACK_IMPORTED_MODULE_2__['getLastYearSixMonthsPolicies'];
            });
            __webpack_require__.d(__webpack_exports__, 'getPoliciesUntilCurrentMonth', function () {
                return _Policy__WEBPACK_IMPORTED_MODULE_2__['getPoliciesUntilCurrentMonth'];
            });
            __webpack_require__.d(__webpack_exports__, 'getPoliciesUntilCurrentMonthLastYear', function () {
                return _Policy__WEBPACK_IMPORTED_MODULE_2__['getPoliciesUntilCurrentMonthLastYear'];
            });
            __webpack_require__.d(__webpack_exports__, 'getPoliciesForSalesGoal', function () {
                return _Policy__WEBPACK_IMPORTED_MODULE_2__['getPoliciesForSalesGoal'];
            });
            var _Products__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__('./src/common/services/Products.js');
            __webpack_require__.d(__webpack_exports__, 'getProducts', function () {
                return _Products__WEBPACK_IMPORTED_MODULE_3__['getProducts'];
            });
            __webpack_require__.d(__webpack_exports__, 'getChannelId', function () {
                return _Products__WEBPACK_IMPORTED_MODULE_3__['getChannelId'];
            });
            var _Report__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__('./src/common/services/Report.js');
            __webpack_require__.d(__webpack_exports__, 'getReportsStatus', function () {
                return _Report__WEBPACK_IMPORTED_MODULE_4__['getReportsStatus'];
            });
        },
        './src/common/services/liferay/api.js': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            (function (process) {
                __webpack_require__.d(__webpack_exports__, 'axios', function () {
                    return axios;
                });
                var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__('./node_modules/axios/index.js');
                var axios__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
                var _utils_liferay__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__('./src/common/utils/liferay.js');
                var _process$env$REACT_AP = process.env.REACT_APP_LIFERAY_API, REACT_APP_LIFERAY_API = _process$env$REACT_AP === void 0 ? window.location.origin : _process$env$REACT_AP;
                var axios = axios__WEBPACK_IMPORTED_MODULE_0___default.a.create({
                    baseURL: REACT_APP_LIFERAY_API,
                    headers: { 'x-csrf-token': _utils_liferay__WEBPACK_IMPORTED_MODULE_1__['Liferay'].authToken }
                });
            }.call(this, __webpack_require__('./node_modules/process/browser.js')));
        },
        './src/common/utils/constants.js': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            __webpack_require__.d(__webpack_exports__, 'CONSTANTS', function () {
                return CONSTANTS;
            });
            var CONSTANTS = {
                MONTHS_ABREVIATIONS: [
                    'Jan',
                    'Feb',
                    'Mar',
                    'Apr',
                    'May',
                    'Jun',
                    'Jul',
                    'Aug',
                    'Sep',
                    'Oct',
                    'Nov',
                    'Dec'
                ],
                STATUS: {
                    APPROVED: 'approved',
                    BOUND: 'bound',
                    INCOMPLETE: 'incomplete',
                    ININVESTIGATION: 'inInvestigation',
                    OPEN: 'open',
                    QUOTED: 'quoted',
                    REJECTED: 'rejected',
                    REVIEWED: 'reviewed',
                    UNDERWRITING: 'underwriting'
                }
            };
        },
        './src/common/utils/dateFormatter.js': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            __webpack_require__.d(__webpack_exports__, 'convertDateToString', function () {
                return convertDateToString;
            });
            __webpack_require__.d(__webpack_exports__, 'getCurrentDay', function () {
                return getCurrentDay;
            });
            __webpack_require__.d(__webpack_exports__, 'currentYear', function () {
                return currentYear;
            });
            __webpack_require__.d(__webpack_exports__, 'currentDate', function () {
                return currentDate;
            });
            __webpack_require__.d(__webpack_exports__, 'currentDateString', function () {
                return currentDateString;
            });
            __webpack_require__.d(__webpack_exports__, 'getCurrentMonth', function () {
                return getCurrentMonth;
            });
            __webpack_require__.d(__webpack_exports__, 'sixMonthsAgo', function () {
                return sixMonthsAgo;
            });
            __webpack_require__.d(__webpack_exports__, 'threeMonthsAgo', function () {
                return threeMonthsAgo;
            });
            __webpack_require__.d(__webpack_exports__, 'lastMonth', function () {
                return lastMonth;
            });
            __webpack_require__.d(__webpack_exports__, 'lastYear', function () {
                return lastYear;
            });
            __webpack_require__.d(__webpack_exports__, 'january', function () {
                return january;
            });
            __webpack_require__.d(__webpack_exports__, 'december', function () {
                return december;
            });
            __webpack_require__.d(__webpack_exports__, 'arrayOfMonthsWith30Days', function () {
                return arrayOfMonthsWith30Days;
            });
            __webpack_require__.d(__webpack_exports__, 'arrayOfMonthsWith31Days', function () {
                return arrayOfMonthsWith31Days;
            });
            __webpack_require__.d(__webpack_exports__, 'lastMonthDate', function () {
                return lastMonthDate;
            });
            __webpack_require__.d(__webpack_exports__, 'threeMonthsAgoDate', function () {
                return threeMonthsAgoDate;
            });
            __webpack_require__.d(__webpack_exports__, 'sixMonthsAgoDate', function () {
                return sixMonthsAgoDate;
            });
            __webpack_require__.d(__webpack_exports__, 'oneYearAgoDate', function () {
                return oneYearAgoDate;
            });
            __webpack_require__.d(__webpack_exports__, 'lastYearSixMonthsAgoPeriod', function () {
                return lastYearSixMonthsAgoPeriod;
            });
            __webpack_require__.d(__webpack_exports__, 'getDayOfYear', function () {
                return getDayOfYear;
            });
            __webpack_require__.d(__webpack_exports__, 'default', function () {
                return formatDate;
            });
            var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__('./src/common/utils/constants.js');
            function convertDateToString(date) {
                var newDate = date.toISOString().substring(0, 10);
                return newDate;
            }
            var getCurrentDay = new Date().getDate();
            var currentYear = new Date().getFullYear();
            var currentDate = convertDateToString(new Date());
            var currentDateString = currentDate.split('-');
            var getCurrentMonth = new Date().getMonth();
            var sixMonthsAgo = getCurrentMonth - 5;
            var threeMonthsAgo = getCurrentMonth - 2;
            var lastMonth = getCurrentMonth - 1;
            var lastYear = currentYear - 1;
            var january = '01';
            var december = '12';
            var arrayOfMonthsWith30Days = [
                3,
                5,
                8,
                10
            ];
            var arrayOfMonthsWith31Days = [
                0,
                2,
                4,
                6,
                7,
                9,
                11
            ];
            var lastMonthDate = convertDateToString(new Date(new Date().setMonth(lastMonth))).split('-');
            var threeMonthsAgoDate = convertDateToString(new Date(new Date().setMonth(threeMonthsAgo))).split('-');
            var sixMonthsAgoDate = convertDateToString(new Date(new Date().setMonth(sixMonthsAgo))).split('-');
            var oneYearAgoDate = convertDateToString(new Date(new Date().setFullYear(lastYear)));
            var lastYearSixMonthsAgoPeriod = convertDateToString(new Date(new Date(new Date().setFullYear(lastYear)).setMonth(sixMonthsAgo))).split('-');
            var getDayOfYear = Math.floor((new Date() - new Date(new Date().getFullYear(), 0, 0)) / 1000 / 60 / 60 / 24);
            function formatDate(date, withSlash) {
                var newDate = date.toISOString().substring(0, 10).split('-');
                if (withSlash) {
                    return ''.concat(newDate[1], '/').concat(newDate[2], '/').concat(newDate[0]);
                }
                return ''.concat(_constants__WEBPACK_IMPORTED_MODULE_0__['CONSTANTS'].MONTHS_ABREVIATIONS[date.getMonth()], ' ').concat(newDate[2], ', ').concat(newDate[0]);
            }
        },
        './src/common/utils/liferay.js': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            __webpack_require__.d(__webpack_exports__, 'Liferay', function () {
                return Liferay;
            });
            __webpack_require__.d(__webpack_exports__, 'getLiferaySiteName', function () {
                return getLiferaySiteName;
            });
            __webpack_require__.d(__webpack_exports__, 'redirectTo', function () {
                return redirectTo;
            });
            var pagePreviewEnabled = false;
            var Liferay = window.Liferay || {
                BREAKPOINTS: {
                    PHONE: 0,
                    TABLET: 0
                },
                ThemeDisplay: {
                    getCanonicalURL: function getCanonicalURL() {
                        return window.location.href;
                    },
                    getCompanyGroupId: function getCompanyGroupId() {
                        return 0;
                    },
                    getPathThemeImages: function getPathThemeImages() {
                        return null;
                    },
                    getScopeGroupId: function getScopeGroupId() {
                        return 0;
                    },
                    getSiteGroupId: function getSiteGroupId() {
                        return 0;
                    }
                },
                authToken: ''
            };
            function getLiferaySiteName() {
                var _URL = new URL(Liferay.ThemeDisplay.getCanonicalURL()), pathname = _URL.pathname;
                var urlPaths = pathname.split('/').filter(Boolean);
                var siteName = '/'.concat(urlPaths.slice(0, urlPaths.length > 2 ? urlPaths.length - 1 : urlPaths.length).join('/'));
                return siteName;
            }
            function redirectTo() {
                var url = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
                var currentSiteName = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : getLiferaySiteName();
                var queryParams = pagePreviewEnabled ? '?p_l_mode=preview' : '';
                window.location.href = ''.concat(currentSiteName, '/').concat(url).concat(queryParams);
            }
        },
        './src/raylife-ap-react-fragments/fragments/dashboard-tasks/index.js': function (module, __webpack_exports__, __webpack_require__) {
            'use strict';
            __webpack_require__.r(__webpack_exports__);
            var _clayui_icon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__('./node_modules/@clayui/icon/lib/index.js');
            var _clayui_icon__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(_clayui_icon__WEBPACK_IMPORTED_MODULE_0__);
            var _common_components_section_list__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__('./src/common/components/section-list/index.js');
            var _common_context_ClayIconProvider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__('./src/common/context/ClayIconProvider.js');
            var _common_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__('./src/common/services/index.js');
            var _common_utils_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__('./src/common/utils/constants.js');
            var React_raw = __REQUIRE__('__REACT_PROVIDER__$react');
            var React = React_raw && React_raw.__esModule ? React_raw['default'] : React_raw;
            var useEffect = __REQUIRE__('__REACT_PROVIDER__$react')['useEffect'];
            var useState = __REQUIRE__('__REACT_PROVIDER__$react')['useState'];
            function _slicedToArray(arr, i) {
                return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
            }
            function _nonIterableRest() {
                throw new TypeError('Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.');
            }
            function _unsupportedIterableToArray(o, minLen) {
                if (!o)
                    return;
                if (typeof o === 'string')
                    return _arrayLikeToArray(o, minLen);
                var n = Object.prototype.toString.call(o).slice(8, -1);
                if (n === 'Object' && o.constructor)
                    n = o.constructor.name;
                if (n === 'Map' || n === 'Set')
                    return Array.from(o);
                if (n === 'Arguments' || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))
                    return _arrayLikeToArray(o, minLen);
            }
            function _arrayLikeToArray(arr, len) {
                if (len == null || len > arr.length)
                    len = arr.length;
                for (var i = 0, arr2 = new Array(len); i < len; i++) {
                    arr2[i] = arr[i];
                }
                return arr2;
            }
            function _iterableToArrayLimit(arr, i) {
                var _i = arr == null ? null : typeof Symbol !== 'undefined' && arr[Symbol.iterator] || arr['@@iterator'];
                if (_i == null)
                    return;
                var _arr = [];
                var _n = true;
                var _d = false;
                var _s, _e;
                try {
                    for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) {
                        _arr.push(_s.value);
                        if (i && _arr.length === i)
                            break;
                    }
                } catch (err) {
                    _d = true;
                    _e = err;
                } finally {
                    try {
                        if (!_n && _i['return'] != null)
                            _i['return']();
                    } finally {
                        if (_d)
                            throw _e;
                    }
                }
                return _arr;
            }
            function _arrayWithHoles(arr) {
                if (Array.isArray(arr))
                    return arr;
            }
            __webpack_exports__['default'] = function () {
                var _useState = useState([]), _useState2 = _slicedToArray(_useState, 2), sections = _useState2[0], setSections = _useState2[1];
                useEffect(function () {
                    Promise.allSettled([
                        Object(_common_services__WEBPACK_IMPORTED_MODULE_3__['getApplicationsStatus'])(_common_utils_constants__WEBPACK_IMPORTED_MODULE_4__['CONSTANTS'].STATUS.INCOMPLETE),
                        Object(_common_services__WEBPACK_IMPORTED_MODULE_3__['getApplicationsStatus'])(_common_utils_constants__WEBPACK_IMPORTED_MODULE_4__['CONSTANTS'].STATUS.QUOTED),
                        Object(_common_services__WEBPACK_IMPORTED_MODULE_3__['getApplicationsStatus'])(_common_utils_constants__WEBPACK_IMPORTED_MODULE_4__['CONSTANTS'].STATUS.REVIEWED),
                        Object(_common_services__WEBPACK_IMPORTED_MODULE_3__['getClaimsStatus'])(_common_utils_constants__WEBPACK_IMPORTED_MODULE_4__['CONSTANTS'].STATUS.ININVESTIGATION),
                        Object(_common_services__WEBPACK_IMPORTED_MODULE_3__['getClaimsStatus'])(_common_utils_constants__WEBPACK_IMPORTED_MODULE_4__['CONSTANTS'].STATUS.APPROVED),
                        Object(_common_services__WEBPACK_IMPORTED_MODULE_3__['getPoliciesStatus'])(4),
                        Object(_common_services__WEBPACK_IMPORTED_MODULE_3__['getPoliciesStatus'])(5),
                        Object(_common_services__WEBPACK_IMPORTED_MODULE_3__['getReportsStatus'])(1),
                        Object(_common_services__WEBPACK_IMPORTED_MODULE_3__['getReportsStatus'])(7)
                    ]).then(function (results) {
                        var getTotalCount = function getTotalCount(result) {
                            var _result$value, _result$value$data;
                            return (result === null || result === void 0 ? void 0 : (_result$value = result.value) === null || _result$value === void 0 ? void 0 : (_result$value$data = _result$value.data) === null || _result$value$data === void 0 ? void 0 : _result$value$data.totalCount) || 0;
                        };
                        var _results = _slicedToArray(results, 9), incompleteApplicationsResult = _results[0], quotedApplicationsResult = _results[1], reviewedApplicationsResult = _results[2], inInvestigationClaimsResult = _results[3], approvedClaimsResult = _results[4], firstPoliciesResult = _results[5], secondPoliciesResult = _results[6], firstReportsResult = _results[7], secondReportsResult = _results[8];
                        var loadSections = [
                            {
                                active: true,
                                index: 0,
                                link: 'Applications',
                                name: 'Applications',
                                subSections: [
                                    {
                                        active: true,
                                        name: 'Review Eligibility Reports',
                                        value: getTotalCount(incompleteApplicationsResult)
                                    },
                                    {
                                        active: true,
                                        name: 'Review Underwriting Questions',
                                        value: getTotalCount(quotedApplicationsResult)
                                    },
                                    {
                                        active: true,
                                        name: 'Policy Ready to Bind',
                                        value: getTotalCount(reviewedApplicationsResult)
                                    }
                                ]
                            },
                            {
                                active: true,
                                index: 2,
                                link: 'Claims',
                                name: 'Claims',
                                subSections: [
                                    {
                                        active: true,
                                        name: 'Request Additional Information',
                                        value: getTotalCount(inInvestigationClaimsResult)
                                    },
                                    {
                                        active: true,
                                        name: 'Notify Repair Options',
                                        value: getTotalCount(approvedClaimsResult)
                                    }
                                ]
                            },
                            {
                                active: true,
                                index: 1,
                                link: 'Policies',
                                name: 'Policies',
                                subSections: [
                                    {
                                        active: true,
                                        name: 'Contact Expiring Policies',
                                        value: getTotalCount(firstPoliciesResult)
                                    },
                                    {
                                        active: true,
                                        name: 'Contact Past Due Payment',
                                        value: getTotalCount(secondPoliciesResult)
                                    }
                                ]
                            },
                            {
                                active: false,
                                index: 3,
                                link: 'Reports',
                                name: 'Reports',
                                subSections: [
                                    {
                                        active: true,
                                        name: 'Renew expiring policies',
                                        value: getTotalCount(firstReportsResult)
                                    },
                                    {
                                        active: true,
                                        name: 'Review Quote',
                                        value: getTotalCount(secondReportsResult)
                                    }
                                ]
                            }
                        ].sort(function (a, b) {
                            return a.index < b.index ? -1 : a.index > b.index ? 1 : 0;
                        });
                        setSections(loadSections);
                    });
                }, []);
                var settingsOnClick = function settingsOnClick() {
                    var EVENT_OPTION = {
                        async: true,
                        fireOn: true
                    };
                    var eventUserAccount = Liferay.publish('open-settings', EVENT_OPTION);
                    eventUserAccount.fire({ modalName: 'tasks-settings-modal' });
                };
                return React.createElement(_common_context_ClayIconProvider__WEBPACK_IMPORTED_MODULE_2__['default'], null, React.createElement('div', { className: 'dashboard-tasks-container flex-shrink-0 pb-4 pt-3 px-3' }, React.createElement('div', { className: 'align-items-center d-flex dashboard-tasks-header justify-content-between' }, React.createElement('div', { className: 'dashboard-tasks-title font-weight-bolder h4 mb-0' }, 'Tasks'), React.createElement('div', { className: 'mr-2 settings-icon' }, React.createElement(_clayui_icon__WEBPACK_IMPORTED_MODULE_0___default.a, {
                    className: 'text-neutral-5',
                    onClick: settingsOnClick,
                    symbol: 'cog'
                }))), React.createElement(_common_components_section_list__WEBPACK_IMPORTED_MODULE_1__['default'], { sections: sections })));
            };
        }
    }));
});
//# sourceMappingURL=index.js.map