/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
export declare type Item = number | string | Record<string, any>;
export declare type Locator = Function | string;
export declare function getLocatorValue<T extends Item>({ item, locator, }: {
    item: T;
    locator?: Locator;
}): string | undefined;
