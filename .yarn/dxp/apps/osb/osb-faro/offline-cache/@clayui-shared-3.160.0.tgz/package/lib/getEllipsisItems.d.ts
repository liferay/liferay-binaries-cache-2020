/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
interface IBufferList {
    /**
     * Component to be used as a Ellipsis.
     */
    EllipsisComponent: React.ComponentType<any>;
    /**
     * Use this property for defining `otherProps` that will be passed to ellipsis dropdown trigger.
     */
    ellipsisProps?: Object;
    /**
     * Property to define BreadcrumbEllipsis's items.
     */
    items: Array<Object>;
    /**
     * Path to the location of the spritemap resource.
     */
    spritemap?: string;
}
export declare function getEllipsisItems(config: IBufferList, ellipsisBuffer: number, activeIndex?: number): (number | Object)[];
export {};
