/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
declare type Props = {
    children: React.ReactElement;
    inert?: boolean;
    isCloseOnInteractOutside?: boolean;
    isKeyboardDismiss?: boolean;
    isModal?: boolean;
    isOpen: boolean;
    menuClassName?: string;
    menuRef: React.RefObject<HTMLElement>;
    onClose: (action: 'escape' | 'blur') => void;
    portalRef?: React.RefObject<HTMLElement>;
    suppress?: Array<React.RefObject<HTMLElement>>;
    triggerRef: React.RefObject<HTMLElement>;
};
/**
 * Overlay component is used for components like dialog and modal.
 * For example, Autocomplete, DatePicker, ColorPicker, DropDown are components
 * that can use and have the same consistent behavior.
 */
export declare function Overlay({ children, inert, isCloseOnInteractOutside, isKeyboardDismiss, isModal, isOpen, menuClassName, menuRef, onClose, portalRef, suppress, triggerRef, }: Props): React.JSX.Element;
export {};
