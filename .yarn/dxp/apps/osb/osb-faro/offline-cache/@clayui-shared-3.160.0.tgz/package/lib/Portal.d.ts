/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface IBaseProps {
    /**
     * Class to add to the root element
     */
    className?: string;
    /**
     * Id fof the root element
     */
    id?: string;
}
interface IProps extends IBaseProps {
    children: React.ReactNode;
    /**
     * Ref of element to render portal into.
     */
    containerRef?: React.RefObject<Element>;
    /**
     * Ref of element to render nested portals into.
     */
    subPortalRef?: React.RefObject<Element>;
}
export declare function ClayPortal({ children, className, containerRef, id, subPortalRef, }: IProps): React.JSX.Element;
export {};
