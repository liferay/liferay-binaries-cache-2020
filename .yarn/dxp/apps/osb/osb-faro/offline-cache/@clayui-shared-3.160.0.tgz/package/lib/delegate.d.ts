/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
declare function delegate(element: HTMLElement, eventName: keyof GlobalEventHandlersEventMap, selector: string, callback: (event: any) => void, capture?: boolean): {
    dispose(): void;
};
export { delegate };
export default delegate;
