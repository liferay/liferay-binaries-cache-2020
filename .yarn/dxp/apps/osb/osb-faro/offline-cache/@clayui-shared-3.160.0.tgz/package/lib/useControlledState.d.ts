/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
export declare type InternalDispatch<Value> = (value: Value) => void;
declare type Props<Value> = {
    defaultName: string;
    defaultValue?: Value | (() => Value);
    handleName: string;
    name: string;
    onChange?: InternalDispatch<Value>;
    value?: Value;
};
export declare function useControlledState<Value>({ defaultName, defaultValue, handleName, name, onChange, value, }: Props<Value>): [Value, InternalDispatch<Value>, boolean];
export {};
