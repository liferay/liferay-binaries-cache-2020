/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export declare type Position = 'left' | 'right';
declare type Props = {
    /**
     * Callback is called every time the panel width changes (Controlled).
     */
    onPanelWidthChange: (width: number) => void;
    /**
     * Property to set the panel width (controlled).
     */
    panelWidth?: number;
    /**
     * The maximum width for the panel.
     */
    panelWidthMax: number;
    /**
     * The minimum width for the panel.
     */
    panelWidthMin: number;
    /**
     * The side of the screen where the panel is located.
     */
    position: Position;
};
export declare function PanelResizer({ onPanelWidthChange, panelWidth, panelWidthMax, panelWidthMin, position, ...otherProps }: Props): React.JSX.Element;
export {};
