/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React, { Children } from 'react';
import { useFocusManagement } from './useFocusManagement';
declare type Children = React.ReactElement & {
    ref?: React.MutableRefObject<HTMLElement> | ((ref: HTMLElement | null) => void);
};
declare type ChildrenFunction = Children | ((focusManager: ReturnType<typeof useFocusManagement>) => Children);
declare type Props = {
    /**
     * Flag indicates whether the focus will also be controlled with the right
     * and left arrow keys.
     */
    arrowKeysLeftRight?: boolean;
    /**
     * Flag that indicates if the focus will be controlled by the arrow keys.
     * Disabling means that it will still be controlled by tab and shift + tab.
     */
    arrowKeysUpDown?: boolean;
    children: ChildrenFunction;
    onFocus?: (element: HTMLElement) => void;
    /**
     * Flag that indicates whether the FocusScope stops keyboard event propagation
     * to parent FocusScope components.
     * */
    stopPropagation?: boolean;
};
/**
 * FocusScope is a component only for controlling focus and listening
 * for children's key down events, since the component handles the `onKeyDown`
 * event.
 */
/**
 * FocusScope is a component only for controlling focus and listening
 * for children's key down events, since the component handles the `onKeyDown`
 * event.
 */
export declare function FocusScope({ arrowKeysLeftRight, arrowKeysUpDown, children, onFocus, stopPropagation, }: Props): React.JSX.Element;
export {};
