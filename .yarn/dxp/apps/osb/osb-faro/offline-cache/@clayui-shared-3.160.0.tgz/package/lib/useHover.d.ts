/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
/// <reference types="react" />
declare type PointerType = 'mouse' | 'pen' | 'touch';
declare type Event = {
    pointerType: PointerType;
    target: HTMLElement;
    type: string;
};
declare type Props = {
    disabled?: boolean;
    onHover: (event: Event) => void;
};
export declare function useHover<T extends HTMLElement>({ disabled, onHover }: Props): import("react").DOMAttributes<T>;
export {};
