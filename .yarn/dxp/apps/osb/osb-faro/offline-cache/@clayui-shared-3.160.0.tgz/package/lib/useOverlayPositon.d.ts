/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
declare type Props = {
    alignmentByViewport?: boolean;
    alignmentPosition?: number | AlignPoints;
    autoBestAlign?: boolean;
    getOffset?: (points: AlignPoints) => [number, number];
    isOpen: boolean;
    ref: React.RefObject<HTMLElement>;
    triggerRef: React.RefObject<HTMLElement>;
};
declare const ALIGN_MAP: {
    readonly BottomCenter: readonly ["tc", "bc"];
    readonly BottomLeft: readonly ["tl", "bl"];
    readonly BottomRight: readonly ["tr", "br"];
    readonly LeftBottom: readonly ["br", "bl"];
    readonly LeftCenter: readonly ["cr", "cl"];
    readonly LeftTop: readonly ["tr", "tl"];
    readonly RightBottom: readonly ["bl", "br"];
    readonly RightCenter: readonly ["cl", "cr"];
    readonly RightTop: readonly ["tl", "tr"];
    readonly TopCenter: readonly ["bc", "tc"];
    readonly TopLeft: readonly ["bl", "tl"];
    readonly TopRight: readonly ["br", "tr"];
};
export declare type AlignPoints = (typeof ALIGN_MAP)[keyof typeof ALIGN_MAP];
export declare function useOverlayPosition({ alignmentByViewport, alignmentPosition, autoBestAlign, getOffset, isOpen, ref, triggerRef, }: Props, deps?: Array<any>): void;
export {};
