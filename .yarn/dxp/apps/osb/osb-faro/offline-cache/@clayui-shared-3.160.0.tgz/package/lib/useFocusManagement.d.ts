/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export declare function isFocusable({ contentEditable, disabled, href, offsetParent, rel, tabIndex, tagName, type, }: {
    contentEditable?: string | boolean;
    disabled?: string | boolean;
    href?: string;
    offsetParent?: Element | null;
    rel?: string;
    tabIndex?: number;
    tagName?: string;
    type?: string;
}): boolean;
export declare const FOCUSABLE_ELEMENTS: string[];
export declare function useFocusManagement(scope: React.RefObject<null | HTMLElement>): {
    focusFirst: () => any;
    focusNext: (persistOnScope?: boolean) => any;
    focusPrevious: (persistOnScope?: boolean) => any;
};
