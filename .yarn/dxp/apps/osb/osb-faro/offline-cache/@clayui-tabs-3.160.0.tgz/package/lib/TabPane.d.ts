/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface ITabPaneProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Flag to indicate if `active` classname should be applied
     */
    active?: boolean;
    /**
     * Flag to indicate if `fade` classname that applies a fading animation should be applied.
     */
    fade?: boolean;
}
declare const TabPane: React.ForwardRefExoticComponent<ITabPaneProps & React.RefAttributes<HTMLDivElement>>;
export default TabPane;
