/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import React from 'react';
export interface IProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * @ignore
     */
    active?: React.Key;
    /**
     * Receives a number that indicates the `tabkey` to be rendered.
     * @deprecated since v3.78.2 - No longer needed in new composition.
     */
    activeIndex?: number;
    /**
     * Children elements received from ClayTabs.Content component.
     */
    children: React.ReactNode;
    /**
     * Flag to indicate if `fade` classname that applies an fading animation should be applied.
     */
    fade?: boolean;
    /**
     * @ignore
     */
    tabsId?: string;
}
declare const Content: React.ForwardRefExoticComponent<IProps & React.RefAttributes<HTMLDivElement>>;
export default Content;
