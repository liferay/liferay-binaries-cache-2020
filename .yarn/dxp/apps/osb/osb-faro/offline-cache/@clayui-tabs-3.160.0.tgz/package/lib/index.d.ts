/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
import { InternalDispatch } from '@clayui/shared';
import React from 'react';
export declare type DisplayType = null | 'basic' | 'underline';
export interface IProps extends React.HTMLAttributes<HTMLUListElement> {
    /**
     * Flag to indicate the navigation behavior in the tab.
     *
     * - manual - it will just move the focus and tab activation is done just
     * by pressing space or enter.
     * - automatic - moves the focus to the tab and activates the tab.
     */
    activation?: 'manual' | 'automatic';
    /**
     * The current tab active (controlled).
     */
    active?: number;
    /**
     * Initial active tab when rendering component (uncontrolled).
     */
    defaultActive?: number;
    /**
     * Determines how tab is displayed.
     * @deprecated since v3.89.0 with no replacement.
     */
    displayType?: null | 'basic' | 'underline';
    /**
     * Flag to indicate if `fade` classname that applies an fading animation
     * should be applied.
     */
    fade?: boolean;
    /**
     * Justify the nav items according the tab content.
     */
    justified?: boolean;
    /**
     * Applies a modern style to the tab.
     * @deprecated since v3.89.0 with no replacement.
     */
    modern?: boolean;
    /**
     * Callback is called when the active tab changes (controlled).
     */
    onActiveChange?: InternalDispatch<number>;
}
declare function Tabs({ activation, active: externalActive, children, className, defaultActive, displayType, fade, justified, modern, onActiveChange, ...otherProps }: IProps): React.JSX.Element;
declare namespace Tabs {
    var Content: React.ForwardRefExoticComponent<import("./Content").IProps & React.RefAttributes<HTMLDivElement>>;
    var Panels: React.ForwardRefExoticComponent<import("./Content").IProps & React.RefAttributes<HTMLDivElement>>;
    var Item: React.ForwardRefExoticComponent<import("./Item").IProps & React.RefAttributes<any>>;
    var List: React.ForwardRefExoticComponent<import("./List").IProps & React.RefAttributes<HTMLUListElement>>;
    var TabPane: React.ForwardRefExoticComponent<import("./TabPane").ITabPaneProps & React.RefAttributes<HTMLDivElement>>;
    var TabPanel: React.ForwardRefExoticComponent<import("./TabPane").ITabPaneProps & React.RefAttributes<HTMLDivElement>>;
}
export default Tabs;
