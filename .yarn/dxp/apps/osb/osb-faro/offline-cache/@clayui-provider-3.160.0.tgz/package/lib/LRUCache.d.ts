/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */
export declare class LRUCache<K, V> {
    _maxSize: number;
    _storage: Map<K, V>;
    constructor(maxSize?: number);
    reset(): Map<K, V>;
    has(key: K): boolean;
    get(key: K): V | undefined;
    set(key: K, value: V): void;
}
