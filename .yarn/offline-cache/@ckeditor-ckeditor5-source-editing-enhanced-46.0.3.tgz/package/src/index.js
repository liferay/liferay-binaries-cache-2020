/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x4d76c3,_0x37211a){var _0x2e3d1b=_0x3ac1,_0x5c7c49=_0x4d76c3();while(!![]){try{var _0x21a324=parseInt(_0x2e3d1b(0x192))/0x1*(parseInt(_0x2e3d1b(0x197))/0x2)+-parseInt(_0x2e3d1b(0x191))/0x3+parseInt(_0x2e3d1b(0x18e))/0x4+-parseInt(_0x2e3d1b(0x190))/0x5+-parseInt(_0x2e3d1b(0x193))/0x6*(-parseInt(_0x2e3d1b(0x195))/0x7)+parseInt(_0x2e3d1b(0x194))/0x8*(-parseInt(_0x2e3d1b(0x196))/0x9)+parseInt(_0x2e3d1b(0x18f))/0xa;if(_0x21a324===_0x37211a)break;else _0x5c7c49['push'](_0x5c7c49['shift']());}catch(_0x204542){_0x5c7c49['push'](_0x5c7c49['shift']());}}}(_0x23a7,0x6f722));function _0x23a7(){var _0x1e8a0f=['704PRfYZD','2334888zEijPi','15542060auaSsX','4047855enBylH','1624929dJKTeQ','50AHhGxQ','258xjsWRA','7204432QLTNpx','89978wbHKIE','9XKywdl'];_0x23a7=function(){return _0x1e8a0f;};return _0x23a7();}export{SourceEditingEnhanced}from'./sourceeditingenhanced.js';export{ReplaceSourceCommand}from'./replacesourcecommand.js';export{EditSourceCommand}from'./ui/editsourcecommand.js';function _0x3ac1(_0x178114,_0x5a4bd3){var _0x23a702=_0x23a7();return _0x3ac1=function(_0x3ac185,_0x4fa797){_0x3ac185=_0x3ac185-0x18e;var _0x260810=_0x23a702[_0x3ac185];return _0x260810;},_0x3ac1(_0x178114,_0x5a4bd3);}import'./augmentation.js';