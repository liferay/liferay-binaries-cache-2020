/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import type { SourceEditingEnhanced, SourceEditingEnhancedConfig, ReplaceSourceCommand, EditSourceCommand } from './index.js';
declare module '@ckeditor/ckeditor5-core' {
    interface EditorConfig {
        /**
         * The configuration of the source editing enhanced feature.
         *
         * Read more in {@link module:source-editing-enhanced/sourceeditingenhancedconfig~SourceEditingEnhancedConfig}.
         */
        sourceEditingEnhanced?: SourceEditingEnhancedConfig;
    }
    interface PluginsMap {
        [SourceEditingEnhanced.pluginName]: SourceEditingEnhanced;
    }
    interface CommandsMap {
        replaceSource: ReplaceSourceCommand;
        editSource: EditSourceCommand;
    }
}
