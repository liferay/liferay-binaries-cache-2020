/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
export function getTranslation(_0x5e365f,_0x5d1990){const t=_0x5e365f['t'];switch(_0x5d1990){case'Edit\x20source\x20modal\x20label':return t({'string':'Edit\x20source','id':'Edit\x20source\x20modal\x20label'});case'Source':return t('Source');case'Source\x20Editing\x20Enhanced':return t('Source\x20Editing\x20Enhanced');case'Copy\x20line\x20down':return t('Copy\x20line\x20down');case'Copy\x20line\x20up':return t('Copy\x20line\x20up');case'Delete\x20line':return t('Delete\x20line');case'Indent\x20less':return t('Indent\x20less');case'Indent\x20more':return t('Indent\x20more');case'Fold\x20all':return t('Fold\x20all');case'Fold\x20code\x20(current\x20level)':return t('Fold\x20code\x20(current\x20level)');case'Move\x20line\x20down':return t('Move\x20line\x20down');case'Move\x20line\x20up':return t('Move\x20line\x20up');case'Redo\x20(keystroke)':return t({'id':'Redo\x20(keystroke)','string':'Redo'});case'Select\x20line':return t('Select\x20line');case'Switch\x20between\x20\x22focus\x20with\x20tab\x22\x20and\x20\x22indent\x20with\x20tab\x22\x20mode':return t('Switch\x20between\x20\x22focus\x20with\x20tab\x22\x20and\x20\x22indent\x20with\x20tab\x22\x20mode');case'Toggle\x20block\x20comment':return t('Toggle\x20block\x20comment');case'Toggle\x20comment':return t('Toggle\x20comment');case'Undo\x20(keystroke)':return t({'id':'Undo\x20(keystroke)','string':'Undo'});case'Unfold\x20all':return t('Unfold\x20all');case'Unfold\x20code\x20(current\x20level)':return t('Unfold\x20code\x20(current\x20level)');case'Are\x20you\x20sure\x20you\x20want\x20to\x20discard\x20your\x20changes?\x20This\x20action\x20cannot\x20be\x20undone.':return t('Are\x20you\x20sure\x20you\x20want\x20to\x20discard\x20your\x20changes?\x20This\x20action\x20cannot\x20be\x20undone.');case'Cancel':return t('Cancel');case'Save':return t('Save');default:return _0x5d1990;}}