/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import type { Editor } from 'ckeditor5/src/core.js';
/**
 * Returns the name of the currently or most recently active root (the root the selection is anchored to).
 */
export declare function getActiveRootName(editor: Editor): string;
