/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x252d(_0x4a74f5,_0x32667a){const _0x3f21fe=_0x3f21();return _0x252d=function(_0x252d4e,_0x4753f3){_0x252d4e=_0x252d4e-0xc4;let _0x4963c7=_0x3f21fe[_0x252d4e];return _0x4963c7;},_0x252d(_0x4a74f5,_0x32667a);}function _0x3f21(){const _0x58c615=['2AcHPht','from','215875nljzns','8NjOLog','rootName','root','201014bgjErY','source-editing-enhanced-editor-no-root','426705OGRhFE','30YbMAOT','94362DZFajs','editing','document','selection','7mmzhqR','190168iahwzL','first','roots','1845810NGNRcx','2490849cAhSWq','getRanges','length','view'];_0x3f21=function(){return _0x58c615;};return _0x3f21();}(function(_0x1d6d49,_0x28f901){const _0x43be74=_0x252d,_0x2c4f69=_0x1d6d49();while(!![]){try{const _0x60e632=-parseInt(_0x43be74(0xd1))/0x1+-parseInt(_0x43be74(0xc7))/0x2*(parseInt(_0x43be74(0xcf))/0x3)+-parseInt(_0x43be74(0xca))/0x4*(parseInt(_0x43be74(0xc9))/0x5)+-parseInt(_0x43be74(0xd9))/0x6*(-parseInt(_0x43be74(0xd5))/0x7)+parseInt(_0x43be74(0xd6))/0x8+parseInt(_0x43be74(0xda))/0x9+-parseInt(_0x43be74(0xd0))/0xa*(parseInt(_0x43be74(0xcd))/0xb);if(_0x60e632===_0x28f901)break;else _0x2c4f69['push'](_0x2c4f69['shift']());}catch(_0x1f7dd4){_0x2c4f69['push'](_0x2c4f69['shift']());}}}(_0x3f21,0x383fe));import{CKEditorError as _0x23468b}from'ckeditor5/src/utils.js';export function getActiveRootName(_0x5850ad){const _0x977d7f=_0x252d,_0x2402c7=_0x5850ad[_0x977d7f(0xd2)][_0x977d7f(0xc6)][_0x977d7f(0xd3)][_0x977d7f(0xd8)],_0x12b3ad=_0x2402c7[_0x977d7f(0xc5)];if(0x0===_0x12b3ad)throw new _0x23468b(_0x977d7f(0xce),_0x5850ad);if(0x1===_0x12b3ad)return _0x2402c7[_0x977d7f(0xd7)][_0x977d7f(0xcb)];return Array[_0x977d7f(0xc8)](_0x5850ad[_0x977d7f(0xd2)][_0x977d7f(0xc6)][_0x977d7f(0xd3)][_0x977d7f(0xd4)][_0x977d7f(0xc4)]())[0x0][_0x977d7f(0xcc)][_0x977d7f(0xcb)];}