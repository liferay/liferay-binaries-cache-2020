/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module source-editing-enhanced/utils/createcodemirroreditor
 */
import { EditorView } from '@codemirror/view';
import { type Extension } from '@codemirror/state';
import type { SourceEditingEnhancedConfig } from '../sourceeditingenhancedconfig.js';
/**
 * Creates an instance of the CodeMirror in a specified parent element.
 *
 * It returns an object with the interface to interact with the editor.
 */
export declare function createCodeMirrorEditor(options: CodeMirrorEditorConfig): CodeMirrorEditorApi;
/**
 * Returns a set of keybindings for the CodeMirror editor.
 */
export declare function getKeybindings(): Array<Extension>;
/**
 * The interface of the CodeMirror editor that allows interacting with the instance.
 */
export type CodeMirrorEditorApi = {
    /**
     * Focuses the code editor.
     */
    focus: () => void;
    /**
     * Retrieves data from the editor.
     */
    getData: () => string;
    /**
     * Sets data to the editor.
     */
    setData: (data: string) => void;
    /**
     * Toggles the read-only state of the editor.
     */
    setReadOnly: (readonly: boolean) => void;
    /**
     * Destroys the editor instance.
     */
    destroy: () => void;
    /**
     * A reference to the CodeMirror instance. It allows for more advanced interactions with the editor.
     */
    instance: EditorView;
};
/**
 * The configuration of the CodeMirror instance.
 */
export type CodeMirrorEditorConfig = {
    /**
     * The parent DOM element hosting the editor.
     */
    parent: HTMLElement;
    /**
     * The syntax highlighting language of the editor.
     */
    syntaxLanguage: 'html' | 'markdown';
    /**
     * The theme of the editor.
     */
    theme?: SourceEditingEnhancedConfig['theme'];
};
