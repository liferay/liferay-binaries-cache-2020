/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x3c62(_0x1e8e22,_0x1fb02e){var _0x10aa82=_0x10aa();return _0x3c62=function(_0x3c62d4,_0x111958){_0x3c62d4=_0x3c62d4-0xcb;var _0x716346=_0x10aa82[_0x3c62d4];return _0x716346;},_0x3c62(_0x1e8e22,_0x1fb02e);}(function(_0x1d65d8,_0x47be82){var _0x356e28=_0x3c62,_0x54a0ca=_0x1d65d8();while(!![]){try{var _0x2f0e23=-parseInt(_0x356e28(0xcf))/0x1+-parseInt(_0x356e28(0xd6))/0x2+parseInt(_0x356e28(0xcb))/0x3+parseInt(_0x356e28(0xd7))/0x4*(parseInt(_0x356e28(0xd1))/0x5)+parseInt(_0x356e28(0xcd))/0x6*(-parseInt(_0x356e28(0xd5))/0x7)+parseInt(_0x356e28(0xd2))/0x8*(-parseInt(_0x356e28(0xcc))/0x9)+parseInt(_0x356e28(0xd4))/0xa*(parseInt(_0x356e28(0xce))/0xb);if(_0x2f0e23===_0x47be82)break;else _0x54a0ca['push'](_0x54a0ca['shift']());}catch(_0x148f81){_0x54a0ca['push'](_0x54a0ca['shift']());}}}(_0x10aa,0x5e7c0));import{formatHtml as _0x2cce3f}from'ckeditor5/src/utils.js';export function formatSource(_0x10b5db){return tr(_0x10b5db)?_0x2cce3f(_0x10b5db):_0x10b5db;}export function unformatSource(_0x2f4d10){var _0x5002a8=_0x3c62;return tr(_0x2f4d10[_0x5002a8(0xd0)](/^[\n\s]*/g,''))?_0x2f4d10[_0x5002a8(0xd0)](/\s+/g,''):_0x2f4d10;}function _0x10aa(){var _0x4bde98=['1469236CTcaHj','12429tELwbc','54OiQWAH','1493394aurgLx','191521cyxMAn','715448fptQNJ','replace','5VvBLJk','224936xVusNI','startsWith','710iHxIHv','7ilFApV','175152kivgNP'];_0x10aa=function(){return _0x4bde98;};return _0x10aa();}function tr(_0x41d345){var _0x5dfdaa=_0x3c62;return _0x41d345[_0x5dfdaa(0xd3)]('<');}