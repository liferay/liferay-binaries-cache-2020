/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module source-editing-enhanced/sourceeditingenhanced
 * @publicApi
 */
import { type Editor, Plugin } from 'ckeditor5/src/core.js';
import { SourceEditingEnhancedUI } from './sourceeditingenhancedui.js';
import '../theme/sourceeditingenhanced.css';
/**
 * The source editing enhanced feature.
 *
 * It provides the possibility to view and edit the source of the document in the modal window.
 *
 * For a detailed overview, check the
 * {@glink features/source-editing/source-editing-enhanced source editing enhanced feature documentation} and the
 * {@glink api/source-editing-enhanced package page}.
 */
export declare class SourceEditingEnhanced extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "SourceEditingEnhanced";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    static get requires(): readonly [typeof SourceEditingEnhancedUI];
    /**
     * @inheritDoc
     */
    constructor(editor: Editor);
    /**
     * @inheritDoc
     */
    init(): void;
    destroy(): void;
}
