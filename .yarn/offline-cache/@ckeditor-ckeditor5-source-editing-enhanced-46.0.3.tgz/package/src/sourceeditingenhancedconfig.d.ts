/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import type { Extension } from '@codemirror/state';
/**
 * @module source-editing-enhanced/sourceeditingenhancedconfig
 * @publicApi
 */
/**
 * The configuration of the source editing enhanced feature.
 *
 * ```ts
 * ClassicEditor
 * 	.create( {
 * 		sourceEditingEnhanced: {
 * 			allowCollaborationFeatures: true
 * 		}
 * 	} )
 * 	.then( ... )
 * 	.catch( ... );
 * ```
 *
 * See {@link module:core/editor/editorconfig~EditorConfig all editor options}.
 */
export interface SourceEditingEnhancedConfig {
    /**
     * Set to `true` to enable source editing feature for real-time collaboration.
     *
     * Please note that source editing feature is not fully compatible with real-time collaboration and using it may lead to data loss.
     * {@glink features/source-editing/source-editing-enhanced#limitations-and-incompatibilities Read more}.
     *
     * @default false
     */
    allowCollaborationFeatures?: boolean;
    /**
     * The theme of the source editor.
     *
     * **Note:** Creating a custom theme via `Extension` is not supported when using
     * {@glink getting-started/installation/cloud/quick-start#installing-ckeditor-5-from-cdn Using CDN},
     * due to technical limitations. This option remains available in all other installation methods.
     * The `'default'` and `'dark'` themes are fully supported in the CDN version.
     *
     * {@glink features/source-editing/source-editing-enhanced#themes Read more} about themes configuration.
     *
     * @default 'default'
     */
    theme?: 'default' | 'dark' | Extension;
}
