/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x19e2b7=_0x2733;(function(_0x5cde98,_0x27b699){const _0x209d73=_0x2733,_0x497899=_0x5cde98();while(!![]){try{const _0x5cc602=parseInt(_0x209d73(0x1aa))/0x1+-parseInt(_0x209d73(0x1a8))/0x2+-parseInt(_0x209d73(0x19f))/0x3*(parseInt(_0x209d73(0x199))/0x4)+parseInt(_0x209d73(0x19d))/0x5*(-parseInt(_0x209d73(0x1a4))/0x6)+parseInt(_0x209d73(0x1a0))/0x7*(parseInt(_0x209d73(0x1a2))/0x8)+parseInt(_0x209d73(0x1a3))/0x9+parseInt(_0x209d73(0x1a5))/0xa*(parseInt(_0x209d73(0x1a1))/0xb);if(_0x5cc602===_0x27b699)break;else _0x497899['push'](_0x497899['shift']());}catch(_0x2ec763){_0x497899['push'](_0x497899['shift']());}}}(_0x4319,0x930c6));function _0x2733(_0x1d3dbe,_0x2ed5a3){const _0x431937=_0x4319();return _0x2733=function(_0x273348,_0x39cfcc){_0x273348=_0x273348-0x198;let _0x3ed25e=_0x431937[_0x273348];return _0x3ed25e;},_0x2733(_0x1d3dbe,_0x2ed5a3);}import{Command as _0x17bbf8}from'ckeditor5/src/core.js';import{getActiveRootName as _0x453a78}from'./utils/getactiverootname.js';function _0x4319(){const _0x11dfc2=['5qkQwap','set','83829hJDcHr','7yoRnyA','55ubNQSn','4382896BogCKg','2283642GORYaT','5362068juqPvz','2794420Jfjitr','data','editor','2062344XHcsIY','execute','523951CgzyOT','refresh','28mLhnUY','isReadOnly','rootName','isEnabled'];_0x4319=function(){return _0x11dfc2;};return _0x4319();}export class ReplaceSourceCommand extends _0x17bbf8{constructor(_0x4973a5){const _0x531097=_0x2733;super(_0x4973a5),this[_0x531097(0x198)]();}[_0x19e2b7(0x198)](){const _0x276c56=_0x19e2b7;this[_0x276c56(0x19c)]=!this[_0x276c56(0x1a7)][_0x276c56(0x19a)];}[_0x19e2b7(0x1a9)](_0x11ea71,_0x112c81){const _0x546724=_0x19e2b7,_0x836773=this[_0x546724(0x1a7)],_0x5bc8f6=_0x112c81?.[_0x546724(0x19b)]??_0x453a78(_0x836773);_0x836773[_0x546724(0x1a6)][_0x546724(0x19e)]({[_0x5bc8f6]:_0x11ea71},{'batchType':{'isUndoable':!0x0},'suppressErrorInCollaboration':!0x0});}}