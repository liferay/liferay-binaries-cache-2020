/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module source-editing-enhanced
 */
export { SourceEditingEnhanced } from './sourceeditingenhanced.js';
export { ReplaceSourceCommand } from './replacesourcecommand.js';
export { EditSourceCommand } from './ui/editsourcecommand.js';
export type { SourceEditingEnhancedConfig } from './sourceeditingenhancedconfig.js';
import './augmentation.js';
