/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x332aa4=_0x3b23;function _0x52f1(){var _0x431523=['ck-code-editor','setReadOnly','change:isReadOnly','syntaxLanguage','setData','setTemplate','set','130ehwMBo','18GYJQRj','render','2253944oKOweV','element','getData','49395sBOITt','theme','focus','565620dTmteL','ck-reset_all-excluded','655965cdpBIQ','200732VFoGTD','24omXqyd','destroy','2594510svbDLx','div','_options','_codeEditorApi','isReadOnly','5079qfqBuL'];_0x52f1=function(){return _0x431523;};return _0x52f1();}(function(_0x27d076,_0x50a459){var _0x2cca00=_0x3b23,_0x333a4c=_0x27d076();while(!![]){try{var _0x537e66=-parseInt(_0x2cca00(0x1d8))/0x1+-parseInt(_0x2cca00(0x1d2))/0x2*(parseInt(_0x2cca00(0x1ca))/0x3)+-parseInt(_0x2cca00(0x1db))/0x4+parseInt(_0x2cca00(0x1dd))/0x5+-parseInt(_0x2cca00(0x1df))/0x6*(-parseInt(_0x2cca00(0x1de))/0x7)+-parseInt(_0x2cca00(0x1d5))/0x8+-parseInt(_0x2cca00(0x1d3))/0x9*(-parseInt(_0x2cca00(0x1c5))/0xa);if(_0x537e66===_0x50a459)break;else _0x333a4c['push'](_0x333a4c['shift']());}catch(_0x2a3a20){_0x333a4c['push'](_0x333a4c['shift']());}}}(_0x52f1,0x2c7c3));function _0x3b23(_0x3c115d,_0x41a8f6){var _0x52f1fb=_0x52f1();return _0x3b23=function(_0x3b23be,_0x6f563c){_0x3b23be=_0x3b23be-0x1c4;var _0x2b312c=_0x52f1fb[_0x3b23be];return _0x2b312c;},_0x3b23(_0x3c115d,_0x41a8f6);}import{View as _0x36792e}from'ckeditor5/src/ui.js';import{createCodeMirrorEditor as _0x75b619}from'../utils/createcodemirroreditor.js';export class CodeEditorView extends _0x36792e{[_0x332aa4(0x1c8)]=null;[_0x332aa4(0x1c7)];constructor(_0x507b5c,_0x350eea){var _0x7eac15=_0x332aa4;super(_0x507b5c),this[_0x7eac15(0x1c7)]=_0x350eea,this[_0x7eac15(0x1d1)](_0x7eac15(0x1c9),!0x1),this[_0x7eac15(0x1d0)]({'tag':_0x7eac15(0x1c6),'attributes':{'class':['ck',_0x7eac15(0x1dc),_0x7eac15(0x1cb)],'tabindex':-0x1}});}[_0x332aa4(0x1d4)](){var _0x28d990=_0x332aa4;super[_0x28d990(0x1d4)](),this[_0x28d990(0x1c8)]=_0x75b619({'parent':this[_0x28d990(0x1d6)],'syntaxLanguage':this[_0x28d990(0x1c7)][_0x28d990(0x1ce)],'theme':this[_0x28d990(0x1c7)][_0x28d990(0x1d9)]}),this['on'](_0x28d990(0x1cd),(_0x93d097,_0x47774b,_0x480359)=>{var _0x5135cb=_0x28d990;this[_0x5135cb(0x1cc)](_0x480359);});}[_0x332aa4(0x1c4)](){var _0x13645b=_0x332aa4;super[_0x13645b(0x1c4)](),this[_0x13645b(0x1c8)][_0x13645b(0x1c4)](),this[_0x13645b(0x1c8)]=null;}[_0x332aa4(0x1da)](){var _0x389103=_0x332aa4;this[_0x389103(0x1c9)]?this[_0x389103(0x1d6)][_0x389103(0x1da)]():this[_0x389103(0x1c8)][_0x389103(0x1da)]();}[_0x332aa4(0x1d7)](){var _0x1cff3b=_0x332aa4;return this[_0x1cff3b(0x1c8)][_0x1cff3b(0x1d7)]();}[_0x332aa4(0x1cf)](_0x211c21){var _0x951c1a=_0x332aa4;this[_0x951c1a(0x1c8)][_0x951c1a(0x1cf)](_0x211c21);}[_0x332aa4(0x1cc)](_0xb45b1c){var _0x1643a8=_0x332aa4;this[_0x1643a8(0x1c8)][_0x1643a8(0x1cc)](_0xb45b1c);}}