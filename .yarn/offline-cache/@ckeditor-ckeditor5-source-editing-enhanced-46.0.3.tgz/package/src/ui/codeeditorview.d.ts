/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module source-editing-enhanced/ui/codeeditorview
 */
import { View } from 'ckeditor5/src/ui.js';
import type { Locale } from 'ckeditor5/src/utils.js';
import { type CodeMirrorEditorConfig } from '../utils/createcodemirroreditor.js';
/**
 * A view that represents a code editor. Internally, it renders a CodeMirror instance. It provides
 * an API to interact with the editor.
 */
export declare class CodeEditorView extends View {
    /**
     * When set to `true`, the code editor becomes read-only.
     */
    isReadOnly: boolean;
    /**
     * @inheritDoc
     */
    constructor(locale: Locale, options: CodeEditorViewOptions);
    /**
     * @inheritDoc
     */
    render(): void;
    /**
     * @inheritDoc
     */
    destroy(): void;
    /**
     * Focuses the code editor.
     */
    focus(): void;
    /**
     * Retrieves data from the editor.
     */
    getData(): string;
    /**
     * Sets data to the editor.
     */
    setData(data: string): void;
    /**
     * Toggles the read-only state of the editor.
     */
    setReadOnly(readOnly: boolean): void;
}
/**
 * The configuration options for the code editor view.
 */
type CodeEditorViewOptions = Omit<CodeMirrorEditorConfig, 'parent'>;
export {};
