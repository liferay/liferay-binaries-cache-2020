/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module source-editing-enhanced/sourceeditingenhancedui
 */
import { Plugin, PendingActions } from 'ckeditor5/src/core.js';
import '../theme/sourceeditingenhanced.css';
/**
 * The source editing enhanced UI feature.
 *
 * It introduces 'Source' button in toolbar and menu bar that opens a modal window with the source code of the document.
 */
export declare class SourceEditingEnhancedUI extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "SourceEditingEnhancedUI";
    /**
     * @inheritDoc
     */
    static get requires(): readonly [typeof PendingActions];
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    init(): void;
    /**
     * @inheritDoc
     */
    afterInit(): void;
}
