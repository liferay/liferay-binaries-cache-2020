Software License Agreement
==========================

**CKEditor&nbsp;5 Enhanced source code editing feature**  (https://ckeditor.com/ckeditor-5/)<br>
Copyright (c) 2003–2024, [CKSource Holding sp. z o.o.](https://cksource.com) All rights reserved.

CKEditor&nbsp;5 Enhanced source code editing feature is licensed under a commercial license and is protected by copyright law.
For more details about available licensing options please contact us at sales@cksource.com.

Sources of Intellectual Property Included in CKEditor&nbsp;5 Enhanced source code editing feature
-------------------------------------------------------------------------------------------------

Where not otherwise indicated, all CKEditor&nbsp;5 Enhanced source code editing feature content is authored by CKSource engineers and consists of CKSource-owned intellectual property.

The following libraries are included in CKEditor&nbsp;5 Source&nbsp;Editing&nbsp;Enhanced under the [MIT license](https://opensource.org/licenses/MIT):

* @codemirror/autocomplete - Copyright (C) 2018 by Marijn Haverbeke <marijn@haverbeke.berlin>, Adrian Heine <mail@adrianheine.de>, and others.
* @codemirror/commands - Copyright (C) 2018 by Marijn Haverbeke <marijn@haverbeke.berlin>, Adrian Heine <mail@adrianheine.de>, and others.
* @codemirror/lang-html - Copyright (C) 2018 by Marijn Haverbeke <marijn@haverbeke.berlin>, Adrian Heine <mail@adrianheine.de>, and others.
* @codemirror/lang-markdown - Copyright (C) 2018 by Marijn Haverbeke <marijn@haverbeke.berlin>, Adrian Heine <mail@adrianheine.de>, and others.
* @codemirror/language - Copyright (C) 2018 by Marijn Haverbeke <marijn@haverbeke.berlin>, Adrian Heine <mail@adrianheine.de>, and others.
* @codemirror/state - Copyright (C) 2018 by Marijn Haverbeke <marijn@haverbeke.berlin>, Adrian Heine <mail@adrianheine.de>, and others.
* @codemirror/theme-one-dark - Copyright (C) 2018 by Marijn Haverbeke <marijn@haverbeke.berlin>, Adrian Heine <mail@adrianheine.de>, and others.
* @codemirror/view - Copyright (C) 2018 by Marijn Haverbeke <marijn@haverbeke.berlin>, Adrian Heine <mail@adrianheine.de>, and others.

Trademarks
----------

**CKEditor** is a trademark of [CKSource Holding sp. z o.o.](https://cksource.com). All other brand and product names are trademarks, registered trademarks, or service marks of their respective holders.
