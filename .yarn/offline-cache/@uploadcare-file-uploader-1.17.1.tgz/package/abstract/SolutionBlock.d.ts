export class SolutionBlock extends Block {
    static set template(value: any);
    static get template(): any;
    init$: {
        '*commonProgress': number;
        '*uploadList': never[];
        '*uploadQueue': import("@uploadcare/upload-client").Queue;
        '*collectionErrors': ReturnType<import("../index.js").OutputErrorCollection>[];
        '*collectionState': import("../index.js").OutputCollectionState | null;
        '*groupInfo': import("@uploadcare/upload-client").UploadcareGroup | null;
        '*uploadTrigger': Set<string>;
        '*secureUploadsManager': import("./SecureUploadsManager.js").SecureUploadsManager | null;
        '*currentActivity': null;
        '*currentActivityParams': {};
        '*history': never[];
        '*historyBack': null;
        '*closeModal': () => void;
    };
    _template: null;
}
import { Block } from './Block.js';
//# sourceMappingURL=SolutionBlock.d.ts.map