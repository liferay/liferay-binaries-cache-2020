/**
 * @typedef {{
 *   'cloud-image-edit': import('../blocks/CloudImageEditorActivity/CloudImageEditorActivity.js').ActivityParams;
 *   external: import('../blocks/ExternalSource/ExternalSource.js').ActivityParams;
 * }} ActivityParamsMap
 */
export class ActivityBlock extends Block {
    /**
     * @private
     * @type {Map<
     *   ActivityBlock,
     *   { activateCallback: (() => void) | undefined; deactivateCallback: (() => void) | undefined }
     * >}
     */
    private static _activityCallbacks;
    /** @protected */
    protected historyTracked: boolean;
    init$: {
        '*currentActivity': null;
        '*currentActivityParams': {};
        '*history': never[];
        '*historyBack': null;
        '*closeModal': () => void;
    };
    _debouncedHistoryFlush: (() => void) & {
        cancel: () => void;
    };
    /** @private */
    private _deactivate;
    /** @private */
    private _activate;
    /** @private */
    private _historyFlush;
    /** @private */
    private _isActivityRegistered;
    get isActivityActive(): boolean | undefined;
    get couldOpenActivity(): boolean;
    /**
     * TODO: remove name argument
     *
     * @param {String} name
     * @param {Object} [options]
     * @param {() => void} [options.onActivate]
     * @param {() => void} [options.onDeactivate]
     */
    registerActivity(name: string, options?: {
        onActivate?: (() => void) | undefined;
        onDeactivate?: (() => void) | undefined;
    }): void;
    unregisterActivity(): void;
    get activityKey(): string;
    /** @type {ActivityParamsMap[keyof ActivityParamsMap]} */
    get activityParams(): ActivityParamsMap[keyof ActivityParamsMap];
    /** @type {String} */
    get initActivity(): string;
    /** @type {String} */
    get doneActivity(): string;
    historyBack(): void;
    ___ACTIVITY_IS_ACTIVE___: boolean | undefined;
}
export namespace ActivityBlock {
    let activities: Readonly<{
        START_FROM: "start-from";
        CAMERA: "camera";
        DRAW: "draw";
        UPLOAD_LIST: "upload-list";
        URL: "url";
        CLOUD_IMG_EDIT: "cloud-image-edit";
        EXTERNAL: "external";
    }>;
}
export type ActivityParamsMap = {
    "cloud-image-edit": import("../blocks/CloudImageEditorActivity/CloudImageEditorActivity.js").ActivityParams;
    external: import("../blocks/ExternalSource/ExternalSource.js").ActivityParams;
};
export type RegisteredActivityType = (typeof ActivityBlock)["activities"][keyof (typeof ActivityBlock)["activities"]];
export type ActivityType = RegisteredActivityType | (string & {}) | null;
import { Block } from './Block.js';
//# sourceMappingURL=ActivityBlock.d.ts.map