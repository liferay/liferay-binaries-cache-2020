export function localeStateKey(key: string): string;
export const DEFAULT_LOCALE: "en";
export class LocaleManager {
    /** @param {import('./Block.js').Block} blockInstance */
    constructor(blockInstance: import("./Block.js").Block);
    /**
     * @private
     * @type {import('./Block.js').Block | null}
     */
    private _blockInstance;
    /** @private */
    private _localeName;
    /**
     * @private
     * @type {Set<() => void>}
     */
    private _callbacks;
    /**
     * @private
     * @type {Map<import('./Block.js').Block, Map<string, () => void>>}
     */
    private _boundBlocks;
    /**
     * @param {() => void} callback
     * @returns {() => void}
     */
    onLocaleChange(callback: () => void): () => void;
    /**
     * @param {import('./Block.js').Block} block
     * @param {string} key
     * @param {() => void} resolver
     */
    bindL10n(block: import("./Block.js").Block, key: string, resolver: () => void): void;
    /** @param {import('./Block.js').Block} block */
    destroyL10nBindings(block: import("./Block.js").Block): void;
    destroy(): void;
}
//# sourceMappingURL=LocaleManager.d.ts.map