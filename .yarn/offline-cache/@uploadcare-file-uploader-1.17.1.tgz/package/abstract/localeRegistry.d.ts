export function defineLocale(localeName: string, definitionOrResolver: LocaleDefinition | LocaleDefinitionResolver): void;
export function resolveLocaleDefinition(localeName: string): Promise<LocaleDefinition>;
export type LocaleDefinition = Record<string, string>;
export type LocaleDefinitionResolver = () => Promise<LocaleDefinition>;
//# sourceMappingURL=localeRegistry.d.ts.map