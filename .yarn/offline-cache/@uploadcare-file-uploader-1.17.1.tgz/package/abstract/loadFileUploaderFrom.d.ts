/**
 * @param {String} url File Uploader pack url
 * @param {Boolean} [register] Register connected package, if it not registered yet
 * @returns {Promise<import('../index.js')>}
 */
export function loadFileUploaderFrom(url: string, register?: boolean): Promise<typeof import("../index.js")>;
export const UC_WINDOW_KEY: "UC";
//# sourceMappingURL=loadFileUploaderFrom.d.ts.map