/**
 * @template {import('./TypedData.js').TypedSchema} T
 * @typedef {(list: string[], added: Set<import('./TypedData.js').TypedData<T>>, removed: Set<TypedData<T>>) => void} TypedCollectionObserverHandler
 */
/** @template {import('./TypedData.js').TypedSchema} T */
export class TypedCollection<T extends import("./TypedData.js").TypedSchema> {
    /**
     * @param {Object} options
     * @param {T} options.typedSchema
     * @param {import('./TypedData.js').ExtractKeysFromSchema<T>[]} [options.watchList]
     * @param {TypedCollectionObserverHandler<T>} [options.handler]
     * @param {string} [options.ctxName]
     */
    constructor(options: {
        typedSchema: T;
        watchList?: Extract<keyof T, string>[] | undefined;
        handler?: TypedCollectionObserverHandler<T> | undefined;
        ctxName?: string | undefined;
    });
    /**
     * @private
     * @type {T}
     */
    private __typedSchema;
    /**
     * @private
     * @type {string}
     */
    private __ctxId;
    /**
     * @private
     * @type {Data}
     */
    private __data;
    /**
     * @private
     * @type {import('./TypedData.js').ExtractKeysFromSchema<T>[]}
     */
    private __watchList;
    /**
     * @private
     * @type {Object<string, ReturnType<TypedData<T>['subscribe']>[]>}
     */
    private __subsMap;
    /**
     * @private
     * @type {Set<Function>}
     */
    private __propertyObservers;
    /**
     * @private
     * @type {Set<TypedCollectionObserverHandler<T>>}
     */
    private __collectionObservers;
    /**
     * @private
     * @type {Set<string>}
     */
    private __items;
    /**
     * @private
     * @type {Set<import('./TypedData.js').TypedData<T>>}
     */
    private __removed;
    /**
     * @private
     * @type {Set<import('./TypedData.js').TypedData<T>>}
     */
    private __added;
    /**
     * @private
     * @param {String} propName
     * @param {String} ctxId
     */
    private __notifyObservers;
    /** @private */
    private __observeTimeout;
    notify(): void;
    /** @private */
    private __notifyTimeout;
    /** @param {TypedCollectionObserverHandler<T>} handler */
    observeCollection(handler: TypedCollectionObserverHandler<T>): () => void;
    /** @param {TypedCollectionObserverHandler<T>} handler */
    unobserveCollection(handler: TypedCollectionObserverHandler<T>): void;
    /**
     * @param {Partial<import('./TypedData.js').ExtractDataFromSchema<T>>} init
     * @returns {string}
     */
    add(init: Partial<import("./TypedData.js").ExtractDataFromSchema<T>>): string;
    /**
     * @param {string} id
     * @returns {TypedData<T> | null}
     */
    read(id: string): TypedData<T> | null;
    /**
     * @template {import('./TypedData.js').ExtractKeysFromSchema<T>} K
     * @param {string} id
     * @param {K} propName
     * @returns {import('./TypedData.js').ExtractDataFromSchema<T>[propName] | null}
     */
    readProp<K extends import("./TypedData.js").ExtractKeysFromSchema<T>>(id: string, propName: K): import("./TypedData.js").ExtractDataFromSchema<T>[K] | null;
    /**
     * @template {import('./TypedData.js').ExtractKeysFromSchema<T>} K
     * @param {string} id
     * @param {K} propName
     * @param {import('./TypedData.js').ExtractDataFromSchema<T>[K]} value
     */
    publishProp<K extends import("./TypedData.js").ExtractKeysFromSchema<T>>(id: string, propName: K, value: import("./TypedData.js").ExtractDataFromSchema<T>[K]): void;
    /** @param {string} id */
    remove(id: string): void;
    clearAll(): void;
    /** @param {Function} handler */
    observeProperties(handler: Function): () => void;
    /** @param {Function} handler */
    unobserveProperties(handler: Function): void;
    /**
     * @param {(item: TypedData<T>) => Boolean} checkFn
     * @returns {string[]}
     */
    findItems(checkFn: (item: TypedData<T>) => boolean): string[];
    items(): string[];
    get size(): number;
    destroy(): void;
}
export type TypedCollectionObserverHandler<T extends import("./TypedData.js").TypedSchema> = (list: string[], added: Set<import("./TypedData.js").TypedData<T>>, removed: Set<TypedData<T>>) => void;
import { TypedData } from './TypedData.js';
//# sourceMappingURL=TypedCollection.d.ts.map