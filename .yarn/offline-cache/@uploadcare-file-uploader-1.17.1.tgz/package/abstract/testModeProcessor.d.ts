/**
 * @template {import('./Block.js').Block} T
 * @param {DocumentFragment} fr
 * @param {T} fnCtx
 */
export function testModeProcessor<T extends import("./Block.js").Block>(fr: DocumentFragment, fnCtx: T): void;
//# sourceMappingURL=testModeProcessor.d.ts.map