export class A11y {
    /**
     * @private
     * @type {(() => void) | undefined}
     */
    private _destroyKeyUX;
    /**
     * @private
     * @type {ScopedMinimalWindow}
     */
    private _scopedWindow;
    /** @param {import('./Block.js').Block} scope */
    registerBlock(scope: import("./Block.js").Block): void;
    destroy(): void;
}
/**
 * MinimalWindow interface is not exported by keyux, so we import it here using tricky way.
 */
export type MinimalWindow = Parameters<import("keyux").KeyUXModule>[0];
//# sourceMappingURL=a11y.d.ts.map