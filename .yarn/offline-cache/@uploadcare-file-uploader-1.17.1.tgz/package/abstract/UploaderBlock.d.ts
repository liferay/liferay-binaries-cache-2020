export class UploaderBlock extends ActivityBlock {
    /** @protected */
    protected couldBeCtxOwner: boolean;
    /** @private */
    private isCtxOwner;
    init$: {
        '*commonProgress': number;
        '*uploadList': never[];
        '*uploadQueue': import("@uploadcare/upload-client").Queue;
        '*collectionErrors': ReturnType<import("../types").OutputErrorCollection>[];
        '*collectionState': import("../types").OutputCollectionState | null;
        '*groupInfo': import("@uploadcare/upload-client").UploadcareGroup | null;
        '*uploadTrigger': Set<string>;
        '*secureUploadsManager': import("./SecureUploadsManager.js").SecureUploadsManager | null;
        '*currentActivity': null;
        '*currentActivityParams': {};
        '*history': never[];
        '*historyBack': null;
        '*closeModal': () => void;
    };
    /** @private */
    private get hasCtxOwner();
    /**
     * @returns {ValidationManager}
     * @protected
     */
    protected get validationManager(): ValidationManager;
    /** @returns {UploaderPublicApi} */
    get api(): UploaderPublicApi;
    getAPI(): UploaderPublicApi;
    /** @returns {TypedCollection<typeof uploadEntrySchema>} */
    get uploadCollection(): TypedCollection<typeof uploadEntrySchema>;
    /** @private */
    private initCtxOwner;
    /** @private */
    private _unobserveCollection;
    /** @private */
    private _unobserveCollectionProperties;
    /**
     * @private
     * @param {import('../types').OutputCollectionState} collectionState
     */
    private _createGroup;
    /** @private */
    private _flushOutputItems;
    /**
     * @private
     * @type {import('./TypedCollection.js').TypedCollectionObserverHandler<typeof uploadEntrySchema>}
     */
    private _handleCollectionUpdate;
    /**
     * @private
     * @param {Record<keyof import('./uploadEntrySchema.js').UploadEntryData, Set<string>>} changeMap
     */
    private _handleCollectionPropertiesUpdate;
    /** @private */
    private _flushCommonUploadProgress;
    openCloudImageEditor(): void;
    /** @private */
    private setInitialCrop;
    /**
     * @param {string} entryId
     * @protected
     */
    protected getMetadataFor(entryId: string): Promise<import("@uploadcare/upload-client").Metadata | undefined>;
    /**
     * @returns {Promise<import('@uploadcare/upload-client').FileFromOptions>}
     * @protected
     */
    protected getUploadClientOptions(): Promise<import("@uploadcare/upload-client").FileFromOptions>;
    /** @returns {import('../types/exported.js').OutputFileEntry[]} */
    getOutputData(): import("../types/exported.js").OutputFileEntry[];
}
export namespace UploaderBlock {
    type extSrcList = string;
    let extSrcList: Readonly<{
        FACEBOOK: "facebook";
        DROPBOX: "dropbox";
        GDRIVE: "gdrive";
        GPHOTOS: "gphotos";
        FLICKR: "flickr";
        VK: "vk";
        EVERNOTE: "evernote";
        BOX: "box";
        ONEDRIVE: "onedrive";
        HUDDLE: "huddle";
    }>;
    type sourceTypes = string;
    let sourceTypes: Readonly<{
        FACEBOOK: "facebook";
        DROPBOX: "dropbox";
        GDRIVE: "gdrive";
        GPHOTOS: "gphotos";
        FLICKR: "flickr";
        VK: "vk";
        EVERNOTE: "evernote";
        BOX: "box";
        ONEDRIVE: "onedrive";
        HUDDLE: "huddle";
        MOBILE_VIDEO_CAMERA: "mobile-video-camera";
        MOBILE_PHOTO_CAMERA: "mobile-photo-camera";
        LOCAL: "local";
        DROP_AREA: "drop-area";
        CAMERA: "camera";
        EXTERNAL: "external";
        API: "js-api";
        URL: "url";
        DRAW: "draw";
    }>;
}
import { ActivityBlock } from './ActivityBlock.js';
import { SecureUploadsManager } from './SecureUploadsManager.js';
import { ValidationManager } from './ValidationManager.js';
import { UploaderPublicApi } from './UploaderPublicApi.js';
import { TypedCollection } from './TypedCollection.js';
import { uploadEntrySchema } from './uploadEntrySchema.js';
//# sourceMappingURL=UploaderBlock.d.ts.map