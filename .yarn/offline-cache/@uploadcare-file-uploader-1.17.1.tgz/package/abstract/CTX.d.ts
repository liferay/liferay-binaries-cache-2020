export function blockCtx(): {};
export function activityBlockCtx(fnCtx: import("./Block").Block): {
    '*currentActivity': null;
    '*currentActivityParams': {};
    '*history': never[];
    '*historyBack': null;
    '*closeModal': () => void;
};
export function uploaderBlockCtx(fnCtx: import("./Block").Block): {
    '*commonProgress': number;
    '*uploadList': never[];
    '*uploadQueue': Queue;
    /** @type {ReturnType<import('../types').OutputErrorCollection>[]} */
    '*collectionErrors': ReturnType<import("../types").OutputErrorCollection>[];
    /** @type {import('../types').OutputCollectionState | null} */
    '*collectionState': import("../types").OutputCollectionState | null;
    /** @type {import('@uploadcare/upload-client').UploadcareGroup | null} */
    '*groupInfo': import("@uploadcare/upload-client").UploadcareGroup | null;
    /** @type {Set<string>} */
    '*uploadTrigger': Set<string>;
    /** @type {import('./SecureUploadsManager.js').SecureUploadsManager | null} */
    '*secureUploadsManager': import("./SecureUploadsManager.js").SecureUploadsManager | null;
    '*currentActivity': null;
    '*currentActivityParams': {};
    '*history': never[];
    '*historyBack': null;
    '*closeModal': () => void;
};
import { Queue } from '@uploadcare/upload-client';
//# sourceMappingURL=CTX.d.ts.map