/**
 * @template {import('../index.js').OutputCollectionStatus} TCollectionStatus
 * @template {import('../index.js').GroupFlag} [TGroupFlag='maybe-has-group'] Default is `'maybe-has-group'`
 * @param {import('./UploaderBlock.js').UploaderBlock} uploaderBlock
 * @returns {import('../index.js').OutputCollectionState<TCollectionStatus, TGroupFlag>}
 */
export function buildOutputCollectionState<TCollectionStatus extends import("../index.js").OutputCollectionStatus, TGroupFlag extends import("../index.js").GroupFlag = "maybe-has-group">(uploaderBlock: import("./UploaderBlock.js").UploaderBlock): import("../index.js").OutputCollectionState<TCollectionStatus, TGroupFlag>;
//# sourceMappingURL=buildOutputCollectionState.d.ts.map