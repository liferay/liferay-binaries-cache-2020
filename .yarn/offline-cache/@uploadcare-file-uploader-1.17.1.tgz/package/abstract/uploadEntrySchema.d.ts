/** @constant */
export const uploadEntrySchema: Readonly<{
    file: Readonly<{
        type: {
            new (fileBits: BlobPart[], fileName: string, options?: FilePropertyBag): File;
            prototype: File;
        };
        value: null;
        nullable: true;
    }>;
    externalUrl: Readonly<{
        type: StringConstructor;
        value: null;
        nullable: true;
    }>;
    fileName: Readonly<{
        type: StringConstructor;
        value: null;
        nullable: true;
    }>;
    fileSize: Readonly<{
        type: NumberConstructor;
        value: null;
        nullable: true;
    }>;
    lastModified: Readonly<{
        type: NumberConstructor;
        value: number;
    }>;
    uploadProgress: Readonly<{
        type: NumberConstructor;
        value: 0;
    }>;
    uuid: Readonly<{
        type: StringConstructor;
        value: null;
        nullable: true;
    }>;
    isImage: Readonly<{
        type: BooleanConstructor;
        value: false;
    }>;
    mimeType: Readonly<{
        type: StringConstructor;
        value: null;
        nullable: true;
    }>;
    ctxName: Readonly<{
        type: StringConstructor;
        value: null;
        nullable: true;
    }>;
    cdnUrl: Readonly<{
        type: StringConstructor;
        value: null;
        nullable: true;
    }>;
    cdnUrlModifiers: Readonly<{
        type: StringConstructor;
        value: null;
        nullable: true;
    }>;
    fileInfo: Readonly<{
        type: typeof UploadcareFile;
        value: null;
        nullable: true;
    }>;
    isUploading: Readonly<{
        type: BooleanConstructor;
        value: false;
    }>;
    abortController: Readonly<{
        type: {
            new (): AbortController;
            prototype: AbortController;
        };
        value: null;
        nullable: true;
    }>;
    thumbUrl: Readonly<{
        type: StringConstructor;
        value: null;
        nullable: true;
    }>;
    silent: Readonly<{
        type: BooleanConstructor;
        value: false;
    }>;
    source: Readonly<{
        type: StringConstructor;
        value: null;
        nullable: true;
    }>;
    fullPath: Readonly<{
        type: StringConstructor;
        value: null;
        nullable: true;
    }>;
    metadata: Readonly<{
        type: ObjectConstructor;
        value: null;
        nullable: true;
    }>;
    errors: Readonly<{
        type: ArrayConstructor;
        value: Error[];
    }>;
    uploadError: Readonly<{
        type: ErrorConstructor;
        value: null;
        nullable: true;
    }>;
    isRemoved: Readonly<{
        type: BooleanConstructor;
        value: false;
    }>;
    isQueued: Readonly<{
        type: BooleanConstructor;
        value: false;
    }>;
}>;
export type UploadEntryData = import("./TypedData").ExtractDataFromSchema<typeof uploadEntrySchema>;
export type UploadEntryTypedData = import("./TypedData.js").TypedData<typeof uploadEntrySchema>;
export type UploadEntryKeys = import("./TypedData.js").ExtractKeysFromSchema<typeof uploadEntrySchema>;
import { UploadcareFile } from '@uploadcare/upload-client';
//# sourceMappingURL=uploadEntrySchema.d.ts.map