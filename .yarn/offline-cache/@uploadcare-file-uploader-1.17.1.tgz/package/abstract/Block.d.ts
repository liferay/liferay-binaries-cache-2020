export class Block extends BaseComponent<any> {
    /** @type {string | null} */
    static StateConsumerScope: string | null;
    /** @type {string[]} */
    static styleAttrs: string[];
    /** @param {String} [name] */
    static reg(name?: string): void;
    constructor();
    /** @protected */
    protected requireCtxName: boolean;
    /** @type {import('./ActivityBlock.js').ActivityType} */
    activityType: import("./ActivityBlock.js").ActivityType;
    init$: {};
    /**
     * @param {String} str
     * @param {{ [key: string]: string | number }} variables
     * @returns {String}
     */
    l10n(str: string, variables?: {
        [key: string]: string | number;
    }): string;
    /**
     * @private
     * @param {string} key
     * @param {number} count
     * @returns {string}
     */
    private pluralize;
    /**
     * @param {string} key
     * @param {() => void} resolver
     * @protected
     */
    protected bindL10n(key: string, resolver: () => void): void;
    /** @type {Map<string, Set<{ remove: () => void }>>} */
    l10nProcessorSubs: Map<string, Set<{
        remove: () => void;
    }>>;
    /**
     * @param {Parameters<import('../blocks/UploadCtxProvider/EventEmitter.js').EventEmitter['emit']>[0]} type
     * @param {Parameters<import('../blocks/UploadCtxProvider/EventEmitter.js').EventEmitter['emit']>[1]} [payload]
     * @param {Parameters<import('../blocks/UploadCtxProvider/EventEmitter.js').EventEmitter['emit']>[2]} [options]
     */
    emit(type: Parameters<import("../blocks/UploadCtxProvider/EventEmitter.js").EventEmitter["emit"]>[0], payload?: Parameters<import("../blocks/UploadCtxProvider/EventEmitter.js").EventEmitter["emit"]>[1], options?: Parameters<import("../blocks/UploadCtxProvider/EventEmitter.js").EventEmitter["emit"]>[2]): void;
    /**
     * @param {(block: Block) => boolean} callback
     * @returns {Boolean}
     */
    hasBlockInCtx(callback: (block: Block) => boolean): boolean;
    /**
     * @param {String} prop
     * @param {any} newVal
     */
    setOrAddState(prop: string, newVal: any): void;
    get testId(): string | null;
    /**
     * @returns {ModalManager}
     * @public
     */
    public get modalManager(): ModalManager;
    /**
     * @private
     * @returns {LocaleManager | null}
     */
    private get localeManager();
    /**
     * @returns {A11y | null}
     * @protected
     */
    protected get a11y(): A11y | null;
    /** @type {Set<Block>} */
    get blocksRegistry(): Set<Block>;
    /**
     * Called when the last block is removed from the context. Note that inheritors must run their callback before that.
     *
     * @protected
     */
    protected destroyCtxCallback(): void;
    /**
     * @param {String} url
     * @returns {Promise<String>}
     * @protected
     */
    protected proxyUrl(url: string): Promise<string>;
    /** @returns {import('../types').ConfigType} } */
    get cfg(): import("../types").ConfigType;
    /** @private */
    private __cfgProxy;
    /**
     * @template {keyof import('../types').ConfigType} T
     * @param {T} key
     * @param {(value: import('../types').ConfigType[T]) => void} callback
     */
    subConfigValue<T extends keyof import("../types").ConfigType>(key: T, callback: (value: import("../types").ConfigType[T]) => void): void;
    /** @param {unknown[]} args */
    debugPrint(...args: unknown[]): void;
}
export { BaseComponent };
import { BaseComponent } from '@symbiotejs/symbiote';
import { ModalManager } from './ModalManager.js';
import { A11y } from './a11y.js';
//# sourceMappingURL=Block.d.ts.map