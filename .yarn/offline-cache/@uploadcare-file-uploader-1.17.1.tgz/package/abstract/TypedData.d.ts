/** @typedef {Record<string, { type: unknown; value: unknown; nullable?: boolean }>} TypedSchema */
/**
 * @template {any} [T=any] Default is `any`
 * @typedef {new (...args: any[]) => T} Constructor
 */
/**
 * @template {unknown} T
 * @template {unknown} V
 * @typedef {T extends StringConstructor
 *   ? string
 *   : T extends BooleanConstructor
 *     ? boolean
 *     : T extends NumberConstructor
 *       ? number
 *       : T extends ArrayConstructor
 *         ? V
 *         : T extends Constructor
 *           ? InstanceType<T>
 *           : T} ExtractType
 */
/**
 * @template {TypedSchema} T
 * @typedef {{
 *   [K in keyof T]: ExtractType<T[K]['type'], T[K]['value']> | (T[K]['nullable'] extends true ? null : never);
 * }} ExtractDataFromSchema
 */
/**
 * @template {TypedSchema} T
 * @typedef {Extract<keyof T, string>} ExtractKeysFromSchema
 */
/** @template {TypedSchema} T */
export class TypedData<T extends TypedSchema> {
    /**
     * @param {T} typedSchema
     * @param {String} [ctxName]
     */
    constructor(typedSchema: T, ctxName?: string);
    /**
     * @private
     * @type {T}
     */
    private __typedSchema;
    /**
     * @private
     * @type {string}
     */
    private __ctxId;
    /**
     * @private
     * @type {ExtractDataFromSchema<T>}
     */
    private __schema;
    /**
     * @private
     * @type {Data}
     */
    private __data;
    /** @returns {string} */
    get uid(): string;
    /**
     * @param {ExtractKeysFromSchema<T>} prop
     * @param {ExtractDataFromSchema<T>[prop]} value
     */
    setValue(prop: ExtractKeysFromSchema<T>, value: ExtractDataFromSchema<T>[Extract<keyof T, string>]): void;
    /** @param {Partial<ExtractDataFromSchema<T>>} updObj */
    setMultipleValues(updObj: Partial<ExtractDataFromSchema<T>>): void;
    /**
     * @template {ExtractKeysFromSchema<T>} K
     * @param {K} prop
     * @returns {ExtractDataFromSchema<T>[K]}
     */
    getValue<K extends ExtractKeysFromSchema<T>>(prop: K): ExtractDataFromSchema<T>[K];
    /**
     * @template {ExtractKeysFromSchema<T>} K
     * @param {K} prop
     * @param {(newVal: ExtractDataFromSchema<T>[K]) => void} handler
     */
    subscribe<K extends ExtractKeysFromSchema<T>>(prop: K, handler: (newVal: ExtractDataFromSchema<T>[K]) => void): {
        remove: () => void;
        callback: Function;
    };
    remove(): void;
}
export type TypedSchema = Record<string, {
    type: unknown;
    value: unknown;
    nullable?: boolean;
}>;
export type Constructor<T extends unknown = any> = new (...args: any[]) => T;
export type ExtractType<T extends unknown, V extends unknown> = T extends StringConstructor ? string : T extends BooleanConstructor ? boolean : T extends NumberConstructor ? number : T extends ArrayConstructor ? V : T extends Constructor ? InstanceType<T> : T;
export type ExtractDataFromSchema<T extends TypedSchema> = { [K in keyof T]: ExtractType<T[K]["type"], T[K]["value"]> | (T[K]["nullable"] extends true ? null : never); };
export type ExtractKeysFromSchema<T extends TypedSchema> = Extract<keyof T, string>;
//# sourceMappingURL=TypedData.d.ts.map