export class ValidationManager {
    /** @param {import('./UploaderBlock.js').UploaderBlock} blockInstance */
    constructor(blockInstance: import("./UploaderBlock.js").UploaderBlock);
    /**
     * @private
     * @type {import('./UploaderBlock.js').UploaderBlock}
     */
    private _blockInstance;
    /** @type {FuncFileValidator[]} */
    _fileValidators: FuncFileValidator[];
    /** @type {FuncCollectionValidator[]} */
    _collectionValidators: FuncCollectionValidator[];
    _uploadCollection: import("./TypedCollection.js").TypedCollection<Readonly<{
        file: Readonly<{
            type: {
                new (fileBits: BlobPart[], fileName: string, options?: FilePropertyBag): File;
                prototype: File;
            };
            value: null;
            nullable: true;
        }>;
        externalUrl: Readonly<{
            type: StringConstructor;
            value: null;
            nullable: true;
        }>;
        fileName: Readonly<{
            type: StringConstructor;
            value: null;
            nullable: true;
        }>;
        fileSize: Readonly<{
            type: NumberConstructor;
            value: null;
            nullable: true;
        }>;
        lastModified: Readonly<{
            type: NumberConstructor;
            value: number;
        }>;
        uploadProgress: Readonly<{
            type: NumberConstructor;
            value: 0;
        }>;
        uuid: Readonly<{
            type: StringConstructor;
            value: null;
            nullable: true;
        }>;
        isImage: Readonly<{
            type: BooleanConstructor;
            value: false;
        }>;
        mimeType: Readonly<{
            type: StringConstructor;
            value: null;
            nullable: true;
        }>;
        ctxName: Readonly<{
            type: StringConstructor;
            value: null;
            nullable: true;
        }>;
        cdnUrl: Readonly<{
            type: StringConstructor;
            value: null;
            nullable: true;
        }>;
        cdnUrlModifiers: Readonly<{
            type: StringConstructor;
            value: null;
            nullable: true;
        }>;
        fileInfo: Readonly<{
            type: typeof import("@uploadcare/upload-client").UploadcareFile;
            value: null;
            nullable: true;
        }>;
        isUploading: Readonly<{
            type: BooleanConstructor;
            value: false;
        }>;
        abortController: Readonly<{
            type: {
                new (): AbortController;
                prototype: AbortController;
            };
            value: null;
            nullable: true;
        }>;
        thumbUrl: Readonly<{
            type: StringConstructor;
            value: null;
            nullable: true;
        }>;
        silent: Readonly<{
            type: BooleanConstructor;
            value: false;
        }>;
        source: Readonly<{
            type: StringConstructor;
            value: null;
            nullable: true;
        }>;
        fullPath: Readonly<{
            type: StringConstructor;
            value: null;
            nullable: true;
        }>;
        metadata: Readonly<{
            type: ObjectConstructor;
            value: null;
            nullable: true;
        }>;
        errors: Readonly<{
            type: ArrayConstructor;
            value: Error[];
        }>;
        uploadError: Readonly<{
            type: ErrorConstructor;
            value: null;
            nullable: true;
        }>;
        isRemoved: Readonly<{
            type: BooleanConstructor;
            value: false;
        }>;
        isQueued: Readonly<{
            type: BooleanConstructor;
            value: false;
        }>;
    }>>;
    /** @param {string[]} [entryIds] */
    runFileValidators(entryIds?: string[]): void;
    runCollectionValidators(): void;
    /**
     * @private
     * @param {import('./TypedData.js').TypedData<typeof import('./uploadEntrySchema.js').uploadEntrySchema>} entry
     */
    private _runFileValidatorsForEntry;
    /**
     * @template T
     * @param {T[]} validators
     * @returns {T[]}
     */
    _addCustomTypeToValidators<T>(validators: T[]): T[];
}
export type FuncFileValidator = (outputEntry: import("../types").OutputFileEntry, api: import("./UploaderPublicApi.js").UploaderPublicApi) => undefined | import("../types").OutputErrorFile;
export type FuncCollectionValidator = (collection: ReturnType<typeof import("./buildOutputCollectionState.js").buildOutputCollectionState<import("../types").OutputCollectionStatus>>, api: import("./UploaderPublicApi.js").UploaderPublicApi) => undefined | import("../types").OutputErrorCollection;
//# sourceMappingURL=ValidationManager.d.ts.map