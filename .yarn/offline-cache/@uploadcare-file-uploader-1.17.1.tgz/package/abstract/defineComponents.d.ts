/** @param {Object<string, any>} blockExports */
export function defineComponents(blockExports: {
    [x: string]: any;
}): void;
//# sourceMappingURL=defineComponents.d.ts.map