export class SecureUploadsManager {
    /** @param {import('./UploaderBlock.js').UploaderBlock} block */
    constructor(block: import("./UploaderBlock.js").UploaderBlock);
    /**
     * @private
     * @type {import('./UploaderBlock.js').UploaderBlock}
     */
    private _block;
    /**
     * @private
     * @type {import('../types').SecureUploadsSignatureAndExpire | null}
     */
    private _secureToken;
    /**
     * @private
     * @param {unknown[]} args
     */
    private _debugPrint;
    /** @returns {Promise<import('../types').SecureUploadsSignatureAndExpire | null>} */
    getSecureToken(): Promise<import("../types").SecureUploadsSignatureAndExpire | null>;
}
//# sourceMappingURL=SecureUploadsManager.d.ts.map