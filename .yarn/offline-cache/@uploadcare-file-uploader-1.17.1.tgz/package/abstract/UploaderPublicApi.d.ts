export class UploaderPublicApi {
    /** @param {import('./UploaderBlock.js').UploaderBlock} ctx */
    constructor(ctx: import("./UploaderBlock.js").UploaderBlock);
    /**
     * @private
     * @type {import('./UploaderBlock.js').UploaderBlock}
     */
    private _ctx;
    /** @private */
    private get _uploadCollection();
    get cfg(): import("../types").ConfigType;
    get l10n(): (str: string, variables?: {
        [key: string]: string | number;
    }) => string;
    /**
     * TODO: Probably we should not allow user to override `source` property
     *
     * @param {string} url
     * @param {{ silent?: boolean; fileName?: string; source?: string }} [options]
     * @returns {import('../types').OutputFileEntry<'idle'>}
     */
    addFileFromUrl: (url: string, { silent, fileName, source }?: {
        silent?: boolean;
        fileName?: string;
        source?: string;
    }) => import("../types").OutputFileEntry<"idle">;
    /**
     * @param {string} uuid
     * @param {{ silent?: boolean; fileName?: string; source?: string }} [options]
     * @returns {import('../types').OutputFileEntry<'idle'>}
     */
    addFileFromUuid: (uuid: string, { silent, fileName, source }?: {
        silent?: boolean;
        fileName?: string;
        source?: string;
    }) => import("../types").OutputFileEntry<"idle">;
    /**
     * @param {string} cdnUrl
     * @param {{ silent?: boolean; fileName?: string; source?: string }} [options]
     * @returns {import('../types').OutputFileEntry<'idle'>}
     */
    addFileFromCdnUrl: (cdnUrl: string, { silent, fileName, source }?: {
        silent?: boolean;
        fileName?: string;
        source?: string;
    }) => import("../types").OutputFileEntry<"idle">;
    /**
     * @param {File} file
     * @param {{ silent?: boolean; fileName?: string; source?: string; fullPath?: string }} [options]
     * @returns {import('../types').OutputFileEntry<'idle'>}
     */
    addFileFromObject: (file: File, { silent, fileName, source, fullPath }?: {
        silent?: boolean;
        fileName?: string;
        source?: string;
        fullPath?: string;
    }) => import("../types").OutputFileEntry<"idle">;
    /** @param {string} internalId */
    removeFileByInternalId: (internalId: string) => void;
    removeAllFiles(): void;
    uploadAll: () => void;
    /** @param {{ captureCamera?: boolean; modeCamera?: import('../blocks/CameraSource/constants.js').ModeCameraType }} options */
    openSystemDialog: (options?: {
        captureCamera?: boolean;
        modeCamera?: import("../blocks/CameraSource/constants.js").ModeCameraType;
    }) => void;
    /**
     * @template {import('../types').OutputFileStatus} TStatus
     * @param {string} entryId
     * @returns {import('../types/exported.js').OutputFileEntry<TStatus>}
     */
    getOutputItem: (entryId: string) => import("../types/exported.js").OutputFileEntry<TStatus>;
    /** @template {import('../types').OutputCollectionStatus} TStatus */
    getOutputCollectionState: () => ReturnType<typeof buildOutputCollectionState<TStatus>>;
    /** @param {Boolean} [force] */
    initFlow: (force?: boolean) => void;
    doneFlow: () => void;
    /**
     * @type {<T extends import('./ActivityBlock.js').ActivityType>(
     *   activityType: T,
     *   ...params: T extends keyof import('./ActivityBlock.js').ActivityParamsMap
     *     ? [import('./ActivityBlock.js').ActivityParamsMap[T]]
     *     : T extends import('./ActivityBlock.js').RegisteredActivityType
     *       ? [undefined?]
     *       : [any?]
     * ) => void}
     */
    setCurrentActivity: <T extends import("./ActivityBlock.js").ActivityType>(activityType: T, ...params: T extends keyof import("./ActivityBlock.js").ActivityParamsMap ? [import("./ActivityBlock.js").ActivityParamsMap[T]] : T extends import("./ActivityBlock.js").RegisteredActivityType ? [undefined?] : [any?]) => void;
    /** @returns {import('./ActivityBlock.js').ActivityType} */
    getCurrentActivity: () => import("./ActivityBlock.js").ActivityType;
    /** @param {boolean} opened */
    setModalState: (opened: boolean) => void;
    /**
     * @private
     * @type {string[]}
     */
    private get _sourceList();
}
import { buildOutputCollectionState } from './buildOutputCollectionState.js';
//# sourceMappingURL=UploaderPublicApi.d.ts.map