export const ModalEvents: Readonly<{
    ADD: "modal:add";
    DELETE: "modal:delete";
    OPEN: "modal:open";
    CLOSE: "modal:close";
    CLOSE_ALL: "modal:closeAll";
    DESTROY: "modal:destroy";
}>;
/** @typedef {import('../abstract/ActivityBlock').ActivityType} ModalId */
/** @typedef {import('../blocks/Modal/Modal.js').Modal} ModalNode */
/** @typedef {(data: { id: ModalId; modal: ModalNode }) => void} ModalCb */
/** @typedef {(typeof ModalEvents)[keyof ModalEvents]} ModalEventType */
export class ModalManager {
    /** @param {import('./Block.js').Block} block */
    constructor(block: import("./Block.js").Block);
    /**
     * @private
     * @type {Map<ModalId, ModalNode>}
     */
    private _modals;
    /**
     * @private
     * @type {Set<ModalId>}
     */
    private _activeModals;
    /**
     * @private
     * @type {Map<ModalEventType, Set<ModalCb>>}
     */
    private _subscribers;
    _block: import("./Block.js").Block;
    /**
     * @private
     * @param {unknown[]} args
     */
    private _debugPrint;
    /**
     * Register a modal with the manager
     *
     * @param {ModalId} id - Unique identifier for the modal
     * @param {ModalNode} modal - Modal component instance
     */
    registerModal(id: ModalId, modal: ModalNode): void;
    /** @param {ModalId} id - Unique identifier for the modal */
    deleteModal(id: ModalId): boolean;
    /**
     * Open a modal by its ID
     *
     * @param {ModalId} id - The ID of the modal to open
     * @returns {boolean} - Success status
     */
    open(id: ModalId): boolean;
    /**
     * Close a specific modal by ID
     *
     * @param {ModalId} id - The ID of the modal to close
     * @returns {boolean} - Success status
     */
    close(id: ModalId): boolean;
    /**
     * Toggle a modal - open if closed, close if open
     *
     * @param {ModalId} id - The ID of the modal to toggle
     * @returns {boolean} - Success status
     */
    toggle(id: ModalId): boolean;
    /**
     * Check if any modals are currently active/open
     *
     * @returns {boolean} - True if there are any active modals
     */
    get hasActiveModals(): boolean;
    /**
     * Close the most recently opened modal and return to the previous one
     *
     * @returns {boolean} - Success status
     */
    back(): boolean;
    /**
     * Close all open modals
     *
     * @returns {number} - Number of modals closed
     */
    closeAll(): number;
    /**
     * Subscribe to modal events
     *
     * @param {ModalEventType} event
     * @param {ModalCb} callback
     * @returns {() => void}
     */
    subscribe(event: ModalEventType, callback: ModalCb): () => void;
    /**
     * Unsubscribe from modal events
     *
     * @param {ModalEventType} event
     * @param {ModalCb | undefined} callback
     */
    unsubscribe(event: ModalEventType, callback: ModalCb | undefined): void;
    /**
     * Notify all subscribers of a modal event
     *
     * @private
     * @param {ModalEventType} event - Event name
     * @param {{
     *       id: ModalId;
     *       modal: ModalNode;
     *     }
     *   | object} data
     */
    private _notify;
    /** Destroy the modal manager, clean up resources */
    destroy(): void;
}
export type ModalId = import("../abstract/ActivityBlock").ActivityType;
export type ModalNode = import("../blocks/Modal/Modal.js").Modal;
export type ModalCb = (data: {
    id: ModalId;
    modal: ModalNode;
}) => void;
export type ModalEventType = (typeof ModalEvents)["ADD" | "DELETE" | "OPEN" | "CLOSE" | "CLOSE_ALL" | "DESTROY"];
//# sourceMappingURL=ModalManager.d.ts.map