export class Select extends Block {
    init$: any;
    value: any;
}
export namespace Select {
    let template: string;
}
import { Block } from '../../abstract/Block.js';
//# sourceMappingURL=Select.d.ts.map