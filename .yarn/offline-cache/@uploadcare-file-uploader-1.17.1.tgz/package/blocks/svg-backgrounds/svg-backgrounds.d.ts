/**
 * @param {String} [color1]
 * @param {String} [color2]
 * @returns {String}
 */
export function checkerboardCssBg(color1?: string, color2?: string): string;
/**
 * @param {String} [color]
 * @returns {String}
 */
export function strokesCssBg(color?: string): string;
/**
 * @param {String} [color]
 * @returns {String}
 */
export function fileCssBg(color?: string, width?: number, height?: number): string;
//# sourceMappingURL=svg-backgrounds.d.ts.map