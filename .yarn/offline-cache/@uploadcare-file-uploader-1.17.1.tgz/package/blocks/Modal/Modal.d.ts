export class Modal extends Block {
    static StateConsumerScope: string;
    init$: {
        closeClicked: () => void;
    };
    _handleBackdropClick: () => void;
    _closeDialog: () => void;
    _handleDialogClose: () => void;
    /** @param {Event} e */
    _handleDialogMouseDown: (e: Event) => void;
    /** @private */
    private _mouseDownTarget;
    /** @param {Event} e */
    _handleDialogMouseUp: (e: Event) => void;
    show(): void;
    hide(): void;
    /**
     * @private
     * @type {import('../../abstract/ModalManager.js').ModalCb}
     */
    private _handleModalOpen;
    /**
     * @private
     * @type {import('../../abstract/ModalManager.js').ModalCb}
     */
    private _handleModalClose;
    /** @private */
    private _handleModalCloseAll;
    handleModalOpen: ((data: {
        id: import("../../abstract/ModalManager.js").ModalId;
        modal: import("../../abstract/ModalManager.js").ModalNode;
    }) => void) | undefined;
    handleModalClose: ((data: {
        id: import("../../abstract/ModalManager.js").ModalId;
        modal: import("../../abstract/ModalManager.js").ModalNode;
    }) => void) | undefined;
    handleModalCloseAll: (() => void) | undefined;
}
export namespace Modal {
    let template: string;
}
import { Block } from '../../abstract/Block.js';
//# sourceMappingURL=Modal.d.ts.map