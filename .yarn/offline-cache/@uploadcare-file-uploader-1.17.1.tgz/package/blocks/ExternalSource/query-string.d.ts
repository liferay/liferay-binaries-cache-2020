/**
 * @param {{ [key: string]: string | number | boolean | null | undefined }} params
 * @returns {string}
 */
export function queryString(params: {
    [key: string]: string | number | boolean | null | undefined;
}): string;
//# sourceMappingURL=query-string.d.ts.map