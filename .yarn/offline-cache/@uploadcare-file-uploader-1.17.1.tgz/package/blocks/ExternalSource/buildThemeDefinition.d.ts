/** @param {HTMLElement} element */
export function buildThemeDefinition(element: HTMLElement): Record<keyof import("./types.js").ThemeDefinition, string>;
//# sourceMappingURL=buildThemeDefinition.d.ts.map