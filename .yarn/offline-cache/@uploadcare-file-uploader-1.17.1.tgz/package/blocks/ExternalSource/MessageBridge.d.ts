export class MessageBridge {
    /** @param {Window} context */
    constructor(context: Window);
    /** @type {Map<string, Set<import('./types').InputMessageHandler<import('./types').InputMessageType>>>} */
    _handlerMap: Map<string, Set<import("./types").InputMessageHandler<import("./types").InputMessageType>>>;
    /** @type {Window} */
    _context: Window;
    /** @param {MessageEvent} e */
    _handleMessage: (e: MessageEvent) => void;
    /**
     * @template {import('./types').InputMessageType} T
     * @param {T} type
     * @param {import('./types').InputMessageHandler<T>} handler
     */
    on<T extends import("./types").InputMessageType>(type: T, handler: import("./types").InputMessageHandler<T>): void;
    /** @param {import('./types').OutputMessage} message */
    send(message: import("./types").OutputMessage): void;
    destroy(): void;
}
//# sourceMappingURL=MessageBridge.d.ts.map