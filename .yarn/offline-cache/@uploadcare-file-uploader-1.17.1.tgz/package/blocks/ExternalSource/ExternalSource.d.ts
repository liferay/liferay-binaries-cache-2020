/** @typedef {{ externalSourceType: string }} ActivityParams */
export class ExternalSource extends UploaderBlock {
    activityType: "external";
    init$: {
        activityIcon: string;
        activityCaption: string;
        /** @type {import('./types.js').InputMessageMap['selected-files-change']['selectedFiles']} */
        selectedList: import("./types.js").InputMessageMap["selected-files-change"]["selectedFiles"];
        total: number;
        isSelectionReady: boolean;
        isDoneBtnEnabled: boolean;
        couldSelectAll: boolean;
        couldDeselectAll: boolean;
        showSelectionStatus: boolean;
        counterText: string;
        doneBtnTextClass: string;
        toolbarVisible: boolean;
        onDone: () => void;
        onCancel: () => void;
        onSelectAll: () => void;
        onDeselectAll: () => void;
        '*commonProgress': number;
        '*uploadList': never[];
        '*uploadQueue': import("@uploadcare/upload-client").Queue;
        '*collectionErrors': ReturnType<import("../../index.js").OutputErrorCollection>[];
        '*collectionState': import("../../index.js").OutputCollectionState | null;
        '*groupInfo': import("@uploadcare/upload-client").UploadcareGroup | null;
        '*uploadTrigger': Set<string>;
        '*secureUploadsManager': import("../../abstract/SecureUploadsManager.js").SecureUploadsManager | null;
        '*currentActivity': null;
        '*currentActivityParams': {};
        '*history': never[];
        '*historyBack': null;
        '*closeModal': () => void;
    };
    /** @type {ActivityParams} */
    get activityParams(): ActivityParams;
    /**
     * @private
     * @param {NonNullable<import('./types.js').InputMessageMap['selected-files-change']['selectedFiles']>[number]} selectedFile
     */
    private extractUrlFromSelectedFile;
    /**
     * @private
     * @param {import('./types.js').InputMessageMap['toolbar-state-change']} message
     */
    private handleToolbarStateChange;
    /**
     * @private
     * @param {import('./types.js').InputMessageMap['selected-files-change']} message
     */
    private handleSelectedFilesChange;
    /** @private */
    private handleIframeLoad;
    /** @private */
    private applyTheme;
    /**
     * @private
     * @param {string} css
     */
    private applyEmbedCss;
    /** @private */
    private setupL10n;
    /** @private */
    private remoteUrl;
    /** @private */
    private mountIframe;
    /** @private */
    private _messageBridge;
    /** @private */
    private unmountIframe;
    /** @private */
    private resetSelectionStatus;
}
export namespace ExternalSource {
    let template: string;
}
export type ActivityParams = {
    externalSourceType: string;
};
import { UploaderBlock } from '../../abstract/UploaderBlock.js';
//# sourceMappingURL=ExternalSource.d.ts.map