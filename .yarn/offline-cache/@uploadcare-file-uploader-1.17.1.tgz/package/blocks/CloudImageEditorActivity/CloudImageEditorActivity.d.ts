/** @typedef {{ internalId: string }} ActivityParams */
export class CloudImageEditorActivity extends UploaderBlock {
    activityType: "cloud-image-edit";
    /**
     * @private
     * @type {import('../../abstract/TypedData.js').TypedData<
     *       import('../../abstract/uploadEntrySchema.js').uploadEntrySchema
     *     >
     *   | undefined}
     */
    private _entry;
    /**
     * @private
     * @type {CloudImageEditorBlock | undefined}
     */
    private _instance;
    /** @type {ActivityParams} */
    get activityParams(): ActivityParams;
    /** @param {CustomEvent<import('../CloudImageEditor/src/types.js').ApplyResult>} e */
    handleApply(e: CustomEvent<import("../CloudImageEditor/src/types.js").ApplyResult>): void;
    handleCancel(): void;
    mountEditor(): void;
    unmountEditor(): void;
}
export type ActivityParams = {
    internalId: string;
};
import { UploaderBlock } from '../../abstract/UploaderBlock.js';
//# sourceMappingURL=CloudImageEditorActivity.d.ts.map