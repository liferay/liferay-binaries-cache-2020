export class Spinner extends BaseComponent<any> {
    constructor();
}
export namespace Spinner {
    let template: string;
}
import { BaseComponent } from '@symbiotejs/symbiote';
//# sourceMappingURL=Spinner.d.ts.map