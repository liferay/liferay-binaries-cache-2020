export class ProgressBar extends Block {
    /** @type {Number} */
    _value: number;
    /** @type {Number} */
    _prevValue: number;
    /** @type {Boolean} */
    _visible: boolean;
    init$: {
        width: number;
        opacity: number;
    };
}
export namespace ProgressBar {
    let template: string;
}
import { Block } from '../../abstract/Block.js';
//# sourceMappingURL=ProgressBar.d.ts.map