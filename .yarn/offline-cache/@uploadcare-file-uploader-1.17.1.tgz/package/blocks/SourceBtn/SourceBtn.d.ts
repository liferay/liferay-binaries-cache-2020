/**
 * @typedef {{
 *   type: string;
 *   activity?: string;
 *   textKey?: string;
 *   icon?: string;
 *   activate?: () => boolean;
 *   activityParams?: Record<string, unknown>;
 * }} TConfig
 */
export class SourceBtn extends UploaderBlock {
    /** @type {string | undefined} */
    type: string | undefined;
    /**
     * @private
     * @type {Record<string, TConfig>}
     */
    private _registeredTypes;
    init$: {
        iconName: string;
        'src-type': string;
        '*commonProgress': number;
        '*uploadList': never[];
        '*uploadQueue': import("@uploadcare/upload-client").Queue;
        '*collectionErrors': ReturnType<import("../../index.js").OutputErrorCollection>[];
        '*collectionState': import("../../index.js").OutputCollectionState | null;
        '*groupInfo': import("@uploadcare/upload-client").UploadcareGroup | null;
        '*uploadTrigger': Set<string>;
        '*secureUploadsManager': import("../../abstract/SecureUploadsManager.js").SecureUploadsManager | null;
        '*currentActivity': null;
        '*currentActivityParams': {};
        '*history': never[];
        '*historyBack': null;
        '*closeModal': () => void;
    };
    initTypes(): void;
    /** @param {TConfig} typeConfig */
    registerType(typeConfig: TConfig): void;
    /** @param {string} type */
    getType(type: string): TConfig;
    activate(): void;
    /** @param {string} type */
    applyType(type: string): void;
}
export namespace SourceBtn {
    let template: string;
}
export type TConfig = {
    type: string;
    activity?: string;
    textKey?: string;
    icon?: string;
    activate?: () => boolean;
    activityParams?: Record<string, unknown>;
};
import { UploaderBlock } from '../../abstract/UploaderBlock.js';
//# sourceMappingURL=SourceBtn.d.ts.map