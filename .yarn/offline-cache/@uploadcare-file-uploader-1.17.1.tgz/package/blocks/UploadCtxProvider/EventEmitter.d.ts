export const EventType: Readonly<{
    FILE_ADDED: "file-added";
    FILE_REMOVED: "file-removed";
    FILE_UPLOAD_START: "file-upload-start";
    FILE_UPLOAD_PROGRESS: "file-upload-progress";
    FILE_UPLOAD_SUCCESS: "file-upload-success";
    FILE_UPLOAD_FAILED: "file-upload-failed";
    FILE_URL_CHANGED: "file-url-changed";
    MODAL_OPEN: "modal-open";
    MODAL_CLOSE: "modal-close";
    DONE_CLICK: "done-click";
    UPLOAD_CLICK: "upload-click";
    ACTIVITY_CHANGE: "activity-change";
    COMMON_UPLOAD_START: "common-upload-start";
    COMMON_UPLOAD_PROGRESS: "common-upload-progress";
    COMMON_UPLOAD_SUCCESS: "common-upload-success";
    COMMON_UPLOAD_FAILED: "common-upload-failed";
    CHANGE: "change";
    GROUP_CREATED: "group-created";
}>;
/**
 * @typedef {{
 *   [EventType.FILE_ADDED]: import('../../index.js').OutputFileEntry<'idle'>;
 *   [EventType.FILE_REMOVED]: import('../../index.js').OutputFileEntry<'removed'>;
 *   [EventType.FILE_UPLOAD_START]: import('../../index.js').OutputFileEntry<'uploading'>;
 *   [EventType.FILE_UPLOAD_PROGRESS]: import('../../index.js').OutputFileEntry<'uploading'>;
 *   [EventType.FILE_UPLOAD_SUCCESS]: import('../../index.js').OutputFileEntry<'success'>;
 *   [EventType.FILE_UPLOAD_FAILED]: import('../../index.js').OutputFileEntry<'failed'>;
 *   [EventType.FILE_URL_CHANGED]: import('../../index.js').OutputFileEntry<'success'>;
 *   [EventType.MODAL_OPEN]: { modalId: import('../../abstract/ModalManager.js').ModalId };
 *   [EventType.MODAL_CLOSE]: { modalId: import('../../abstract/ModalManager.js').ModalId; hasActiveModals: boolean };
 *   [EventType.ACTIVITY_CHANGE]: {
 *     activity: import('../../abstract/ActivityBlock.js').ActivityType;
 *   };
 *   [EventType.UPLOAD_CLICK]: void;
 *   [EventType.DONE_CLICK]: import('../../index.js').OutputCollectionState;
 *   [EventType.COMMON_UPLOAD_START]: import('../../index.js').OutputCollectionState<'uploading'>;
 *   [EventType.COMMON_UPLOAD_PROGRESS]: import('../../index.js').OutputCollectionState<'uploading'>;
 *   [EventType.COMMON_UPLOAD_SUCCESS]: import('../../index.js').OutputCollectionState<'success'>;
 *   [EventType.COMMON_UPLOAD_FAILED]: import('../../index.js').OutputCollectionState<'failed'>;
 *   [EventType.CHANGE]: import('../../index.js').OutputCollectionState;
 *   [EventType.GROUP_CREATED]: import('../../index.js').OutputCollectionState<'success', 'has-group'>;
 * }} EventPayload
 */
export class EventEmitter {
    /** @param {(...args: unknown[]) => void} debugPrint */
    constructor(debugPrint: (...args: unknown[]) => void);
    /**
     * @private
     * @type {Map<string, number>}
     */
    private _timeoutStore;
    /**
     * @private
     * @type {Set<import('../../abstract/Block.js').Block>}
     */
    private _targets;
    /**
     * @private
     * @type {((...args: unknown[]) => void) | null}
     */
    private _debugPrint;
    /** @param {import('../../abstract/Block.js').Block} target */
    bindTarget(target: import("../../abstract/Block.js").Block): void;
    /** @param {import('../../abstract/Block.js').Block} target */
    unbindTarget(target: import("../../abstract/Block.js").Block): void;
    /**
     * @private
     * @template {(typeof EventType)[keyof typeof EventType]} T
     * @param {T} type
     * @param {unknown} [payload]
     */
    private _dispatch;
    /**
     * @template {(typeof EventType)[keyof typeof EventType]} T
     * @template {boolean | number | undefined} TDebounce
     * @param {T} type
     * @param {TDebounce extends false | undefined ? unknown : () => unknown} [payload]
     * @param {{ debounce?: TDebounce }} [options]
     */
    emit<T extends (typeof EventType)[keyof typeof EventType], TDebounce extends boolean | number | undefined>(type: T, payload?: TDebounce extends false | undefined ? unknown : () => unknown, { debounce }?: {
        debounce?: TDebounce;
    }): void;
}
export type EventPayload = {
    [EventType.FILE_ADDED]: import("../../index.js").OutputFileEntry<"idle">;
    [EventType.FILE_REMOVED]: import("../../index.js").OutputFileEntry<"removed">;
    [EventType.FILE_UPLOAD_START]: import("../../index.js").OutputFileEntry<"uploading">;
    [EventType.FILE_UPLOAD_PROGRESS]: import("../../index.js").OutputFileEntry<"uploading">;
    [EventType.FILE_UPLOAD_SUCCESS]: import("../../index.js").OutputFileEntry<"success">;
    [EventType.FILE_UPLOAD_FAILED]: import("../../index.js").OutputFileEntry<"failed">;
    [EventType.FILE_URL_CHANGED]: import("../../index.js").OutputFileEntry<"success">;
    [EventType.MODAL_OPEN]: {
        modalId: import("../../abstract/ModalManager.js").ModalId;
    };
    [EventType.MODAL_CLOSE]: {
        modalId: import("../../abstract/ModalManager.js").ModalId;
        hasActiveModals: boolean;
    };
    [EventType.ACTIVITY_CHANGE]: {
        activity: import("../../abstract/ActivityBlock.js").ActivityType;
    };
    [EventType.UPLOAD_CLICK]: void;
    [EventType.DONE_CLICK]: import("../../index.js").OutputCollectionState;
    [EventType.COMMON_UPLOAD_START]: import("../../index.js").OutputCollectionState<"uploading">;
    [EventType.COMMON_UPLOAD_PROGRESS]: import("../../index.js").OutputCollectionState<"uploading">;
    [EventType.COMMON_UPLOAD_SUCCESS]: import("../../index.js").OutputCollectionState<"success">;
    [EventType.COMMON_UPLOAD_FAILED]: import("../../index.js").OutputCollectionState<"failed">;
    [EventType.CHANGE]: import("../../index.js").OutputCollectionState;
    [EventType.GROUP_CREATED]: import("../../index.js").OutputCollectionState<"success", "has-group">;
};
//# sourceMappingURL=EventEmitter.d.ts.map