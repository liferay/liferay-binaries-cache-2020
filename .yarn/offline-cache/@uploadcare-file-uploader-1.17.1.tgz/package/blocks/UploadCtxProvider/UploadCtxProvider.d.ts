export type UploadCtxProvider = import("../../utils/mixinClass.js").MixinClass<typeof UploadCtxProviderClass, {
    addEventListener<T extends (typeof import("./EventEmitter.js").EventType)[keyof typeof import("./EventEmitter.js").EventType]>(type: T, listener: (e: CustomEvent<import("./EventEmitter.js").EventPayload[T]>) => void, options?: boolean | AddEventListenerOptions): void;
    removeEventListener<T extends (typeof import("./EventEmitter.js").EventType)[keyof typeof import("./EventEmitter.js").EventType]>(type: T, listener: (e: CustomEvent<import("./EventEmitter.js").EventPayload[T]>) => void, options?: boolean | EventListenerOptions): void;
}>;
/**
 * @typedef {import('../../utils/mixinClass.js').MixinClass<
 *   typeof UploadCtxProviderClass,
 *   {
 *     addEventListener<
 *       T extends (typeof import('./EventEmitter.js').EventType)[keyof typeof import('./EventEmitter.js').EventType],
 *     >(
 *       type: T,
 *       listener: (e: CustomEvent<import('./EventEmitter.js').EventPayload[T]>) => void,
 *       options?: boolean | AddEventListenerOptions,
 *     ): void;
 *     removeEventListener<
 *       T extends (typeof import('./EventEmitter.js').EventType)[keyof typeof import('./EventEmitter.js').EventType],
 *     >(
 *       type: T,
 *       listener: (e: CustomEvent<import('./EventEmitter.js').EventPayload[T]>) => void,
 *       options?: boolean | EventListenerOptions,
 *     ): void;
 *   }
 * >} UploadCtxProvider
 */
export const UploadCtxProvider: UploadCtxProvider;
declare class UploadCtxProviderClass extends UploaderBlock {
}
declare namespace UploadCtxProviderClass {
    export { EventType };
}
import { UploaderBlock } from '../../abstract/UploaderBlock.js';
import { EventType } from './EventEmitter.js';
export {};
//# sourceMappingURL=UploadCtxProvider.d.ts.map