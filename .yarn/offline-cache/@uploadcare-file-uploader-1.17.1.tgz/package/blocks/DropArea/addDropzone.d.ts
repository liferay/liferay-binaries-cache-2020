/**
 * @param {Object} desc
 * @param {HTMLElement} desc.element
 * @param {Function} desc.onChange
 * @param {Function} desc.onItems
 * @param {() => Boolean} desc.shouldIgnore
 */
export function addDropzone(desc: {
    element: HTMLElement;
    onChange: Function;
    onItems: Function;
    shouldIgnore: () => boolean;
}): () => void;
export type DropzoneState = number;
export namespace DropzoneState {
    let ACTIVE: number;
    let INACTIVE: number;
    let NEAR: number;
    let OVER: number;
}
//# sourceMappingURL=addDropzone.d.ts.map