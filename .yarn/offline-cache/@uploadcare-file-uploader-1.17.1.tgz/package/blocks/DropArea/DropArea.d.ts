export class DropArea extends UploaderBlock {
    init$: {
        state: number;
        withIcon: boolean;
        isClickable: boolean;
        isFullscreen: boolean;
        isEnabled: boolean;
        isVisible: boolean;
        isInitFlow: boolean;
        text: string;
        "uc-drop-area/registry": null;
        '*commonProgress': number;
        '*uploadList': never[];
        '*uploadQueue': import("@uploadcare/upload-client").Queue;
        '*collectionErrors': ReturnType<import("../../index.js").OutputErrorCollection>[];
        '*collectionState': import("../../index.js").OutputCollectionState | null;
        '*groupInfo': import("@uploadcare/upload-client").UploadcareGroup | null;
        '*uploadTrigger': Set<string>;
        '*secureUploadsManager': import("../../abstract/SecureUploadsManager.js").SecureUploadsManager | null;
        '*currentActivity': null;
        '*currentActivityParams': {};
        '*history': never[];
        '*historyBack': null;
        '*closeModal': () => void;
    };
    isActive(): boolean;
    /** @private */
    private _destroyDropzone;
    _destroyContentWrapperDropzone: (() => void) | undefined;
    /**
     * @private
     * @param {KeyboardEvent | Event} event
     */
    private _onAreaClicked;
    /**
     * Ignore drop events if there are other visible drop areas on the page
     *
     * @private
     * @returns {Boolean}
     */
    private _shouldIgnore;
    /** @private */
    private _couldHandleFiles;
}
export namespace DropArea {
    let template: string;
}
import { UploaderBlock } from '../../abstract/UploaderBlock.js';
//# sourceMappingURL=DropArea.d.ts.map