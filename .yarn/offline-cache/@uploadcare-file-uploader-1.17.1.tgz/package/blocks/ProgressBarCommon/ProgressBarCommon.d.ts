export class ProgressBarCommon extends UploaderBlock {
    init$: any;
}
export namespace ProgressBarCommon {
    let template: string;
}
import { UploaderBlock } from '../../abstract/UploaderBlock.js';
//# sourceMappingURL=ProgressBarCommon.d.ts.map