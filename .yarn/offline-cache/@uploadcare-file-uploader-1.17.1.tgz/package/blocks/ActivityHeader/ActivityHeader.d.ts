export class ActivityHeader extends ActivityBlock {
}
import { ActivityBlock } from '../../abstract/ActivityBlock.js';
//# sourceMappingURL=ActivityHeader.d.ts.map