export class FileItemConfig extends UploaderBlock {
    /** @protected */
    protected _entrySubs: Set<any>;
    /**
     * @type {import('../../abstract/uploadEntrySchema.js').UploadEntryTypedData | null}
     * @protected
     */
    protected _entry: import("../../abstract/uploadEntrySchema.js").UploadEntryTypedData | null;
    /**
     * @template {any[]} A
     * @template {(entry: import('../../abstract/uploadEntrySchema.js').UploadEntryTypedData, ...args: A) => any} T
     * @param {T} fn
     * @returns {(...args: A) => ReturnType<T>}
     * @protected
     */
    protected _withEntry<A extends any[], T extends (entry: import("../../abstract/uploadEntrySchema.js").UploadEntryTypedData, ...args: A) => any>(fn: T): (...args: A) => ReturnType<T>;
    /**
     * @template {import('../../abstract/uploadEntrySchema.js').UploadEntryKeys} K
     * @param {K} prop_
     * @param {(value: import('../../abstract/uploadEntrySchema.js').UploadEntryData[K]) => void} handler_
     * @protected
     */
    protected _subEntry: (prop_: K, handler_: (value: import("../../abstract/uploadEntrySchema.js").UploadEntryData[K]) => void) => void;
    /** @protected */
    protected _reset(): void;
}
import { UploaderBlock } from '../../abstract/UploaderBlock.js';
//# sourceMappingURL=FileItemConfig.d.ts.map