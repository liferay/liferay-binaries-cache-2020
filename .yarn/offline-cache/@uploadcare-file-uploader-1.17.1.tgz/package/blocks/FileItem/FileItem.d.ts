export class FileItem extends FileItemConfig {
    /** @private */
    private _renderedOnce;
    init$: {
        uid: string;
        itemName: string;
        errorText: string;
        hint: string;
        thumbUrl: string;
        progressValue: number;
        progressVisible: boolean;
        badgeIcon: string;
        isFinished: boolean;
        isFailed: boolean;
        isUploading: boolean;
        isFocused: boolean;
        isEditable: boolean;
        showFileNames: boolean;
        state: symbol;
        ariaLabelStatusFile: string;
        onEdit: (...args: any[]) => void;
        onRemove: () => void;
        onUpload: () => void;
        '*commonProgress': number;
        '*uploadList': never[];
        '*uploadQueue': import("@uploadcare/upload-client").Queue;
        '*collectionErrors': ReturnType<import("../../index.js").OutputErrorCollection>[];
        '*collectionState': import("../../index.js").OutputCollectionState | null;
        '*groupInfo': import("@uploadcare/upload-client").UploadcareGroup | null;
        '*uploadTrigger': Set<string>;
        '*secureUploadsManager': import("../../abstract/SecureUploadsManager.js").SecureUploadsManager | null;
        '*currentActivity': null;
        '*currentActivityParams': {};
        '*history': never[];
        '*historyBack': null;
        '*closeModal': () => void;
    };
    /**
     * @private
     * @param {IntersectionObserverEntry[]} entries
     */
    private _observerCallback;
    _isIntersecting: boolean | undefined;
    _thumbRect: DOMRectReadOnly | undefined;
    /** @private */
    private _calculateState;
    /** @private */
    private _debouncedCalculateState;
    _updateHint: (...args: any[]) => void;
    /**
     * @private
     * @param {String} id
     */
    private _handleEntryId;
    /** @param {boolean} value */
    _updateShowFileNames(value: boolean): void;
    _handleState: (...args: any[]) => void;
    /** @private */
    private _observer;
    _settingsOfShrink(): {
        size: number;
        quality: number | undefined;
    };
    /**
     * @private
     * @param {File} file
     */
    private _processShrink;
    upload: (...args: any[]) => Promise<void>;
}
export namespace FileItem {
    let template: string;
    let activeInstances: Set<any>;
}
import { FileItemConfig } from './FileItemConfig.js';
//# sourceMappingURL=FileItem.d.ts.map