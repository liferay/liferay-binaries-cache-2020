export class FormInput extends UploaderBlock {
    _createValidationInput(): HTMLInputElement;
    _validationInputElement: HTMLInputElement | null | undefined;
    _dynamicInputsContainer: HTMLDivElement | undefined;
}
import { UploaderBlock } from '../../abstract/UploaderBlock.js';
//# sourceMappingURL=FormInput.d.ts.map