export class UrlSource extends UploaderBlock {
    activityType: "url";
    init$: any;
}
export namespace UrlSource {
    let template: string;
}
import { UploaderBlock } from '../../abstract/UploaderBlock.js';
//# sourceMappingURL=UrlSource.d.ts.map