export class StartFrom extends ActivityBlock {
}
export namespace StartFrom {
    let template: string;
}
import { ActivityBlock } from '../../abstract/ActivityBlock.js';
//# sourceMappingURL=StartFrom.d.ts.map