/**
 * @param {Number} a Start of sample (int)
 * @param {Number} b End of sample (int)
 * @param {Number} n Number of elements (int)
 * @returns {Number[]}
 */
export function linspace(a: number, b: number, n: number): number[];
//# sourceMappingURL=linspace.d.ts.map