export function classNames(...args: any[]): string;
export function applyClassNames(element: any, ...args: any[]): void;
//# sourceMappingURL=classNames.d.ts.map