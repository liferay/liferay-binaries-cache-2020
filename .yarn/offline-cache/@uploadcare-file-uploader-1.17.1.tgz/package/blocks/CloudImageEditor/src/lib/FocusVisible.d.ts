export class FocusVisible {
    /**
     * @param {boolean} focusVisible
     * @param {HTMLElement} element
     */
    static handleFocusVisible(focusVisible: boolean, element: HTMLElement): void;
    /** @param {ShadowRoot | Document} scope */
    static register(scope: ShadowRoot | Document): void;
    /** @param {Document | ShadowRoot} scope */
    static unregister(scope: Document | ShadowRoot): void;
}
export namespace FocusVisible {
    let _destructors: WeakMap<WeakKey, any>;
}
//# sourceMappingURL=FocusVisible.d.ts.map