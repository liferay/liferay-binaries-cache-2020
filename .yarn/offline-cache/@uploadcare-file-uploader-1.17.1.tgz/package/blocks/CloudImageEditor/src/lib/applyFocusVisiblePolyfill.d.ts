/**
 * Applies the :focus-visible polyfill at the given scope. A scope, in this case, is either the top-level Document or a
 * Shadow Root.
 *
 * @param {Document | ShadowRoot} scope
 * @param {(focusVisible: boolean, el: EventTarget) => void} [callback]
 * @see https://github.com/WICG/focus-visible
 */
export function applyFocusVisiblePolyfill(scope: Document | ShadowRoot, callback?: (focusVisible: boolean, el: EventTarget) => void): () => void;
//# sourceMappingURL=applyFocusVisiblePolyfill.d.ts.map