/**
 * @param {{}} obj
 * @param {String[]} keys
 * @returns {{}}
 */
export function pick(obj: {}, keys: string[]): {};
//# sourceMappingURL=pick.d.ts.map