/**
 * @param {import('../types').Transformations} transformations
 * @returns {string}
 */
export function transformationsToOperations(transformations: import("../types").Transformations): string;
/**
 * @param {string[]} operations
 * @returns {import('../types.js').Transformations}
 */
export function operationsToTransformations(operations: string[]): import("../types.js").Transformations;
/** @type {Record<keyof import('../types').Transformations, unknown>} */
export const OPERATIONS_DEFAULTS: Record<keyof import("../types").Transformations, unknown>;
export const COMMON_OPERATIONS: string;
//# sourceMappingURL=transformationUtils.d.ts.map