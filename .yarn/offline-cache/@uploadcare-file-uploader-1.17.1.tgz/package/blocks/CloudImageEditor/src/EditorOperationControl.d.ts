export class EditorOperationControl extends EditorButtonControl {
    /**
     * @private
     * @type {String}
     */
    private _operation;
}
import { EditorButtonControl } from './EditorButtonControl.js';
//# sourceMappingURL=EditorOperationControl.d.ts.map