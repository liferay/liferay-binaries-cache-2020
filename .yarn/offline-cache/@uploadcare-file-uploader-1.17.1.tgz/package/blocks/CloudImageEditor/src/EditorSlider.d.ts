export const FAKE_ORIGINAL_FILTER: "original";
export class EditorSlider extends Block {
    init$: any;
    /**
     * @param {String} operation
     * @param {String} [filter]
     */
    setOperation(operation: string, filter?: string): void;
    _controlType: string | undefined;
    _operation: string | undefined;
    _iconName: string | undefined;
    _title: string | undefined;
    _filter: string | undefined;
    /** @private */
    private _initializeValues;
    apply(): void;
    cancel(): void;
    _originalUrl: any;
}
export namespace EditorSlider {
    let template: string;
}
import { Block } from '../../../abstract/Block.js';
//# sourceMappingURL=EditorSlider.d.ts.map