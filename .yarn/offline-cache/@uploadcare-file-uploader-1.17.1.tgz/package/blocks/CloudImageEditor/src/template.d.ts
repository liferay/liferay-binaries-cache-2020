export const TEMPLATE: string;
//# sourceMappingURL=template.d.ts.map