export class CropFrame extends Block {
    init$: {
        dragging: boolean;
    };
    /** @private */
    private _handlePointerUp;
    /** @private */
    private _handlePointerMove;
    /** @private */
    private _handleSvgPointerMove;
    /**
     * @private
     * @param {import('./types.js').Direction} direction
     */
    private _shouldThumbBeDisabled;
    /** @private */
    private _createBackdrop;
    _backdropMask: SVGElement | undefined;
    _backdropMaskInner: SVGElement | undefined;
    /**
     * @private Super Tricky workaround for the chromium bug See
     *   https://bugs.chromium.org/p/chromium/issues/detail?id=330815
     */
    private _resizeBackdrop;
    /** @private */
    private _updateBackdrop;
    /** @private */
    private _updateFrame;
    /**
     * @param {import('./types.js').FrameThumbs} frameThumbs
     * @param {import('./types.js').Direction} direction
     */
    _createThumb(frameThumbs: import("./types.js").FrameThumbs, direction: import("./types.js").Direction): void;
    /** @private */
    private _createThumbs;
    /** @private */
    private _createGuides;
    /** @private */
    private _createFrame;
    _frameThumbs: Partial<{
        "": {
            direction: import("./types.js").Direction;
            pathNode: SVGElement;
            interactionNode: SVGElement;
            groupNode: SVGElement;
        };
        n: {
            direction: import("./types.js").Direction;
            pathNode: SVGElement;
            interactionNode: SVGElement;
            groupNode: SVGElement;
        };
        s: {
            direction: import("./types.js").Direction;
            pathNode: SVGElement;
            interactionNode: SVGElement;
            groupNode: SVGElement;
        };
        e: {
            direction: import("./types.js").Direction;
            pathNode: SVGElement;
            interactionNode: SVGElement;
            groupNode: SVGElement;
        };
        w: {
            direction: import("./types.js").Direction;
            pathNode: SVGElement;
            interactionNode: SVGElement;
            groupNode: SVGElement;
        };
        ne: {
            direction: import("./types.js").Direction;
            pathNode: SVGElement;
            interactionNode: SVGElement;
            groupNode: SVGElement;
        };
        nw: {
            direction: import("./types.js").Direction;
            pathNode: SVGElement;
            interactionNode: SVGElement;
            groupNode: SVGElement;
        };
        se: {
            direction: import("./types.js").Direction;
            pathNode: SVGElement;
            interactionNode: SVGElement;
            groupNode: SVGElement;
        };
        sw: {
            direction: import("./types.js").Direction;
            pathNode: SVGElement;
            interactionNode: SVGElement;
            groupNode: SVGElement;
        };
    }> | undefined;
    _frameGuides: SVGElement | undefined;
    /**
     * @private
     * @param {import('./types.js').Direction} direction
     * @param {PointerEvent} e
     */
    private _handlePointerDown;
    _draggingThumb: {
        direction: import("./types.js").Direction;
        pathNode: SVGElement;
        interactionNode: SVGElement;
        groupNode: SVGElement;
    } | undefined;
    _dragStartPoint: number[] | undefined;
    /** @type {import('./types.js').Rectangle} */
    _dragStartCrop: import("./types.js").Rectangle | undefined;
    /**
     * @private
     * @param {PointerEvent} e
     */
    private _handlePointerUp_;
    /**
     * @private
     * @param {PointerEvent} e
     */
    private _handlePointerMove_;
    /**
     * @private
     * @param {import('./types.js').Direction} direction
     * @param {[Number, Number]} delta
     */
    private _calcCropBox;
    /**
     * @private
     * @param {PointerEvent} e
     */
    private _handleSvgPointerMove_;
    _hoverThumb: {
        direction: import("./types.js").Direction;
        pathNode: SVGElement;
        interactionNode: SVGElement;
        groupNode: SVGElement;
    } | undefined;
    /** @private */
    private _updateCursor;
    /**
     * @private
     * @param {String} href
     */
    private _createMask;
    _frameImage: SVGElement | undefined;
    _updateMask(): void;
    /** @private */
    private _render;
    /** @param {boolean} visible */
    toggleThumbs(visible: boolean): void;
    _guidesHidden: boolean | undefined;
}
export namespace CropFrame {
    let template: string;
}
import { Block } from '../../../abstract/Block.js';
//# sourceMappingURL=CropFrame.d.ts.map