export class EditorToolbar extends Block {
    init$: {
        '*sliderEl': null;
        /** @type {import('./types.js').LoadingOperations} */
        '*loadingOperations': import("./types.js").LoadingOperations;
        '*showSlider': boolean;
        '*currentFilter': string;
        '*currentOperation': null;
        showLoader: boolean;
        filters: string[];
        colorOperations: string[];
        cropOperations: string[];
        '*operationTooltip': null;
        'presence.mainToolbar': boolean;
        'presence.subToolbar': boolean;
        'presence.tabToggles': boolean;
        'presence.tabContent.crop': boolean;
        'presence.tabContent.tuning': boolean;
        'presence.tabContent.filters': boolean;
        'presence.tabToggle.crop': boolean;
        'presence.tabToggle.tuning': boolean;
        'presence.tabToggle.filters': boolean;
        'presence.subTopToolbarStyles': {
            hidden: string;
            visible: string;
        };
        'presence.subBottomToolbarStyles': {
            hidden: string;
            visible: string;
        };
        'presence.tabContentStyles': {
            hidden: string;
            visible: string;
        };
        'presence.tabToggleStyles': {
            hidden: string;
            visible: string;
        };
        'presence.tabTogglesStyles': {
            hidden: string;
            visible: string;
        };
        'on.cancel': () => void;
        'on.apply': () => void;
        'on.applySlider': () => void;
        'on.cancelSlider': () => void;
        /** @param {MouseEvent} e */
        'on.clickTab': (e: MouseEvent) => void;
        tab_role: string;
        cancel: string;
        apply: string;
        'a11y-editor-tab-filters': string;
        'a11y-editor-tab-tuning': string;
        'a11y-editor-tab-crop': string;
    };
    /** @private */
    private _debouncedShowLoader;
    /** @private */
    private _onSliderClose;
    /**
     * @private
     * @param {String} operation
     */
    private _createOperationControl;
    /**
     * @private
     * @param {String} filter
     */
    private _createFilterControl;
    /**
     * @private
     * @param {String} operation
     */
    private _createToggleControl;
    /**
     * @private
     * @param {String} tabId
     */
    private _renderControlsList;
    /**
     * @private
     * @param {String} id
     * @param {{ fromViewer?: Boolean }} options
     */
    private _activateTab;
    /**
     * @private
     * @param {String} tabId
     */
    private _unmountTabControls;
    /** @private */
    private _syncTabIndicator;
    /** @private */
    private _preloadEditedImage;
    _cancelPreload: any;
    /**
     * @private
     * @param {boolean} show
     */
    private _showLoader;
    _updateInfoTooltip: (() => void) & {
        cancel: () => void;
    };
}
export namespace EditorToolbar {
    let template: string;
}
import { Block } from '../../../abstract/Block.js';
//# sourceMappingURL=EditorToolbar.d.ts.map