export class EditorCropButtonControl extends EditorButtonControl {
    /** @private */
    private _operation;
}
import { EditorButtonControl } from './EditorButtonControl.js';
//# sourceMappingURL=EditorCropButtonControl.d.ts.map