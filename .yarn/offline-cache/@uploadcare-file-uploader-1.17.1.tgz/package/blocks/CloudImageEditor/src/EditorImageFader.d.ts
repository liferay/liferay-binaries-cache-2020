/**
 * @typedef {Object} Keypoint
 * @property {String} src
 * @property {Number} opacity
 * @property {Number} zIndex
 * @property {HTMLImageElement} image
 * @property {Number} value
 */
export class EditorImageFader extends Block {
    /**
     * @private
     * @type {Boolean}
     */
    private _isActive;
    /**
     * @private
     * @type {Boolean}
     */
    private _hidden;
    /** @private */
    private _addKeypointDebounced;
    /**
     * @private
     * @param {String} src
     * @returns {() => void} Destructor
     */
    private _handleImageLoading;
    /** @private */
    private _flush;
    _raf: number | undefined;
    /**
     * @private
     * @param {Object} options
     * @param {String} [options.url]
     * @param {String} [options.filter]
     * @param {String} [options.operation]
     * @param {Number} [options.value]
     * @returns {Promise<String>}
     */
    private _imageSrc;
    /**
     * @private
     * @param {String} operation
     * @param {Number} value
     * @returns {Promise<Keypoint>}
     */
    private _constructKeypoint;
    /**
     * Check if current operation and filter equals passed ones
     *
     * @private
     * @param {String} operation
     * @param {String} [filter]
     * @returns {Boolean}
     */
    private _isSame;
    /**
     * @private
     * @param {String} operation
     * @param {String | null} filter
     * @param {Number} value
     */
    private _addKeypoint;
    /** @param {String | Number} value */
    set(value: string | number): void;
    /**
     * @private
     * @param {String} operation
     * @param {Number} value
     */
    private _update;
    _operation: string | undefined;
    _value: number | undefined;
    /** @private */
    private _createPreviewImage;
    /** @private */
    private _initNodes;
    _previewImage: any;
    _cancelLastImages: any;
    _container: HTMLDivElement | undefined;
    /** @param {import('./types.js').Transformations} transformations */
    setTransformations(transformations: import("./types.js").Transformations): Promise<void>;
    _transformations: import("./types.js").Transformations | undefined;
    /**
     * @param {object} options
     * @param {String} options.url
     * @param {String} options.operation
     * @param {Number} options.value
     * @param {String} [options.filter]
     */
    preload({ url, filter, operation, value }: {
        url: string;
        operation: string;
        value: number;
        filter?: string | undefined;
    }): Promise<void>;
    _cancelBatchPreload: (() => void) | undefined;
    /** @private */
    private _setOriginalSrc;
    /**
     * @param {object} options
     * @param {String} options.url
     * @param {String} [options.operation]
     * @param {Number} [options.value]
     * @param {String} [options.filter]
     * @param {Boolean} [options.fromViewer]
     */
    activate({ url, operation, value, filter, fromViewer }: {
        url: string;
        operation?: string | undefined;
        value?: number | undefined;
        filter?: string | undefined;
        fromViewer?: boolean | undefined;
    }): Promise<void>;
    _url: string | undefined;
    _filter: string | undefined;
    _fromViewer: boolean | undefined;
    _keypoints: Keypoint[] | undefined;
    /** @param {{ hide?: Boolean }} options */
    deactivate({ hide }?: {
        hide?: boolean;
    }): void;
}
export type Keypoint = {
    src: string;
    opacity: number;
    zIndex: number;
    image: HTMLImageElement;
    value: number;
};
import { Block } from '../../../abstract/Block.js';
//# sourceMappingURL=EditorImageFader.d.ts.map