export class EditorScroller extends Block {
}
export namespace EditorScroller {
    let template: string;
}
import { Block } from '../../../abstract/Block.js';
//# sourceMappingURL=EditorScroller.d.ts.map