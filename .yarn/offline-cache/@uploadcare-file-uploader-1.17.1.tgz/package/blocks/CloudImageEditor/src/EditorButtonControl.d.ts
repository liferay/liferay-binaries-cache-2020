export class EditorButtonControl extends Block {
    init$: any;
    _titleEl: any;
    _iconEl: any;
}
export namespace EditorButtonControl {
    let template: string;
}
import { Block } from '../../../abstract/Block.js';
//# sourceMappingURL=EditorButtonControl.d.ts.map