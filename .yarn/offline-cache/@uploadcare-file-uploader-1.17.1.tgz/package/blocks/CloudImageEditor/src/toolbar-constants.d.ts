export const TabId: Readonly<{
    CROP: "crop";
    TUNING: "tuning";
    FILTERS: "filters";
}>;
export const ALL_TABS: ("crop" | "tuning" | "filters")[];
export const ALL_COLOR_OPERATIONS: string[];
export const ALL_FILTERS: string[];
export const ALL_CROP_OPERATIONS: string[];
/** KeypointsNumber is the number of keypoints loaded from each side of zero, not total number */
export const COLOR_OPERATIONS_CONFIG: Readonly<{
    brightness: {
        zero: unknown;
        range: number[];
        keypointsNumber: number;
    };
    exposure: {
        zero: unknown;
        range: number[];
        keypointsNumber: number;
    };
    gamma: {
        zero: unknown;
        range: number[];
        keypointsNumber: number;
    };
    contrast: {
        zero: unknown;
        range: number[];
        keypointsNumber: number;
    };
    saturation: {
        zero: unknown;
        range: number[];
        keypointsNumber: number;
    };
    vibrance: {
        zero: unknown;
        range: number[];
        keypointsNumber: number;
    };
    warmth: {
        zero: unknown;
        range: number[];
        keypointsNumber: number;
    };
    enhance: {
        zero: unknown;
        range: number[];
        keypointsNumber: number;
    };
    filter: {
        zero: unknown;
        range: number[];
        keypointsNumber: number;
    };
}>;
//# sourceMappingURL=toolbar-constants.d.ts.map