/**
 * Mapping of loading resources per operation
 */
export type LoadingOperations = Map<string, Map<string, boolean>>;
/**
 * Image size
 */
export type ImageSize = {
    width: number;
    height: number;
};
export type Rectangle = {
    x: number;
    y: number;
    width: number;
    height: number;
};
export type Transformations = {
    enhance?: number;
    brightness?: number;
    exposure?: number;
    gamma?: number;
    contrast?: number;
    saturation?: number;
    vibrance?: number;
    warmth?: number;
    rotate?: number;
    mirror?: boolean;
    flip?: boolean;
    filter?: {
        name: string;
        amount: number;
    };
    crop?: {
        dimensions: [number, number];
        coords: [number, number];
    };
};
export type ApplyResult = {
    originalUrl: string;
    cdnUrlModifiers: string;
    cdnUrl: string;
    transformations: Transformations;
};
export type ChangeResult = {
    originalUrl: string;
    cdnUrlModifiers: string;
    cdnUrl: string;
    transformations: Transformations;
};
export type CropAspectRatio = {
    type: "aspect-ratio";
    width: number;
    height: number;
};
export type CropPresetList = CropAspectRatio[];
export type FrameThumbs = Partial<{ [K in Direction]: {
    direction: Direction;
    pathNode: SVGElement;
    interactionNode: SVGElement;
    groupNode: SVGElement;
}; }>;
export type Direction = "" | "n" | "s" | "e" | "w" | "ne" | "nw" | "se" | "sw";
//# sourceMappingURL=types.d.ts.map