export class BtnUi extends Block {
    _iconReversed: boolean;
    _iconSingle: boolean;
    _iconHidden: boolean;
    init$: {
        text: string;
        icon: string;
        iconCss: string;
        theme: null;
        'aria-role': string;
        'aria-controls': string;
        'title-prop': string;
    };
    _iconCss(): string;
    set reverse(val: any);
}
export namespace BtnUi {
    let template: string;
}
import { Block } from '../../../../../abstract/Block.js';
//# sourceMappingURL=BtnUi.d.ts.map