export class LineLoaderUi extends Block {
    _active: boolean;
    _handleTransitionEndRight: () => void;
    _start(): void;
    _stop(): void;
}
export namespace LineLoaderUi {
    let template: string;
}
import { Block } from '../../../../../abstract/Block.js';
//# sourceMappingURL=LineLoaderUi.d.ts.map