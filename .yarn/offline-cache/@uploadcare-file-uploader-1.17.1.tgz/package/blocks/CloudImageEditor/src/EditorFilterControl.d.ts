export class EditorFilterControl extends EditorButtonControl {
    _previewSrc(): string;
    /**
     * @param {IntersectionObserverEntry[]} entries
     * @param {IntersectionObserver} observer
     */
    _observerCallback(entries: IntersectionObserverEntry[], observer: IntersectionObserver): Promise<void>;
    _cancelPreload: (() => void) | undefined;
    _operation: string | undefined;
    _filter: string | undefined;
    _observer: IntersectionObserver | undefined;
    _originalUrl: any;
}
export namespace EditorFilterControl {
    let template: string;
}
import { EditorButtonControl } from './EditorButtonControl.js';
//# sourceMappingURL=EditorFilterControl.d.ts.map