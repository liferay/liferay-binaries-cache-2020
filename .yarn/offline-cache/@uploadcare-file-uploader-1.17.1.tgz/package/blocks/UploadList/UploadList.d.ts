/** @typedef {'grid' | 'list'} FilesViewMode */
/**
 * @typedef {{
 *   total: number;
 *   succeed: number;
 *   uploading: number;
 *   failed: number;
 * }} Summary
 */
export class UploadList extends UploaderBlock {
    activityType: "upload-list";
    init$: {
        doneBtnVisible: boolean;
        doneBtnEnabled: boolean;
        uploadBtnVisible: boolean;
        addMoreBtnVisible: boolean;
        addMoreBtnEnabled: boolean;
        headerText: string;
        commonErrorMessage: string;
        hasFiles: boolean;
        onAdd: () => void;
        onUpload: () => void;
        onDone: () => void;
        onCancel: () => void;
        '*commonProgress': number;
        '*uploadList': never[];
        '*uploadQueue': import("@uploadcare/upload-client").Queue;
        '*collectionErrors': ReturnType<import("../../types").OutputErrorCollection>[];
        '*collectionState': import("../../types").OutputCollectionState | null;
        '*groupInfo': import("@uploadcare/upload-client").UploadcareGroup | null;
        '*uploadTrigger': Set<string>;
        '*secureUploadsManager': import("../../abstract/SecureUploadsManager.js").SecureUploadsManager | null;
        '*currentActivity': null;
        '*currentActivityParams': {};
        '*history': never[];
        '*historyBack': null;
        '*closeModal': () => void;
    };
    /** @private */
    private _throttledHandleCollectionUpdate;
    /** @private */
    private _updateUploadsState;
    /**
     * @private
     * @param {Summary} summary
     */
    private _getHeaderText;
}
export namespace UploadList {
    let template: string;
}
export type FilesViewMode = "grid" | "list";
export type Summary = {
    total: number;
    succeed: number;
    uploading: number;
    failed: number;
};
import { UploaderBlock } from '../../abstract/UploaderBlock.js';
//# sourceMappingURL=UploadList.d.ts.map