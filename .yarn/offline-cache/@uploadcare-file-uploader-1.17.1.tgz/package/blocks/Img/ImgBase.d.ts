export class ImgBase extends ImgConfig {
    _img: HTMLImageElement;
    _imgPreview: HTMLImageElement;
    /**
     * @private
     * @param {String} src
     */
    private _fmtAbs;
    /**
     * Validate size
     *
     * @param {String} [size]
     * @returns {String | Number}
     */
    _validateSize(size?: string): string | number;
    /**
     * Image operations
     *
     * @param {String} [size]
     * @param {String} [blur]
     */
    _getCdnModifiers(size?: string, blur?: string): string;
    /**
     * @private
     * @param {String} [size]
     * @param {String} [blur]
     * @returns {any}
     */
    private _getUrlBase;
    /**
     * @private
     * @param {String} url
     * @returns {String}
     */
    private _proxyUrl;
    /**
     * @param {HTMLElement} el
     * @param {Number} [k]
     * @param {Boolean} [wOnly]
     */
    _getElSize(el: HTMLElement, k?: number, wOnly?: boolean): string | null;
    /** @param {HTMLImageElement} img */
    _setupEventProxy(img: HTMLImageElement): void;
    /** @type {HTMLImageElement} */
    get img(): HTMLImageElement;
    get currentImg(): {
        type: "PREVIEW";
        img: HTMLImageElement;
    } | {
        type: "MAIN";
        img: HTMLImageElement;
    };
    get hasPreviewImage(): any;
    get bgSelector(): any;
    get breakpoints(): number[] | null;
    get hasFormatJPG(): boolean;
    /** @param {HTMLElement} el */
    renderBg(el: HTMLElement): void;
    getSrcset(): string;
    getSrc(): any;
    get srcUrlPreview(): any;
    renderBackground(): void;
    _appendURL({ elNode, src, srcset }: {
        elNode: any;
        src: any;
        srcset: any;
    }): void;
    _setupConfigForImage({ elNode }: {
        elNode: any;
    }): void;
    loaderImage({ src, srcset, elNode }: {
        src: any;
        srcset: any;
        elNode: any;
    }): Promise<any>;
    renderImage(): Promise<void>;
    init(): void;
}
import { ImgConfig } from './ImgConfig.js';
//# sourceMappingURL=ImgBase.d.ts.map