export const CSS_PREF: "--uc-img-";
export const UNRESOLVED_ATTR: "unresolved";
export const HI_RES_K: 2;
export const ULTRA_RES_K: 3;
export const DEV_MODE: boolean;
export const MAX_WIDTH: 3000;
export const MAX_WIDTH_JPG: 5000;
export const ImgTypeEnum: Readonly<{
    PREVIEW: "PREVIEW";
    MAIN: "MAIN";
}>;
//# sourceMappingURL=configurations.d.ts.map