export class ImgConfig extends BaseComponent<any> {
    static get observedAttributes(): string[];
    constructor();
    cssInit$: any;
    /**
     * @param {String} key
     * @returns {any}
     */
    $$(key: string): any;
    /** @param {Object<String, String | Number>} kvObj */
    set$$(kvObj: any): void;
    /**
     * @param {String} key
     * @param {(val: any) => void} kbFn
     */
    sub$$(key: string, kbFn: (val: any) => void): void;
    analyticsParams(): string;
    initAttributes(el: any): void;
    /**
     * @param {HTMLElement} el
     * @param {() => void} cbkFn
     */
    initIntersection(el: HTMLElement, cbkFn: () => void): void;
    /** @private */
    private _isnObserver;
    /** @private */
    private _observed;
    attributeChangedCallback(name: any, oldVal: any, newVal: any): void;
}
import { BaseComponent } from '@symbiotejs/symbiote';
//# sourceMappingURL=ImgConfig.d.ts.map