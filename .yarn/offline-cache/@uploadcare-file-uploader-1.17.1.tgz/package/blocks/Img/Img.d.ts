export class Img extends ImgBase {
}
import { ImgBase } from './ImgBase.js';
//# sourceMappingURL=Img.d.ts.map