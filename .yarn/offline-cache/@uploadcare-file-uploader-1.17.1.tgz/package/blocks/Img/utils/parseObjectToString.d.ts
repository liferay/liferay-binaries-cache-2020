export function parseObjectToString(params: any): any[];
//# sourceMappingURL=parseObjectToString.d.ts.map