export const PROPS_MAP: Readonly<{
    'dev-mode': {};
    pubkey: {};
    uuid: {};
    src: {};
    lazy: {
        default: number;
    };
    intersection: {};
    breakpoints: {};
    'cdn-cname': {
        default: string;
    };
    'proxy-cname': {};
    'secure-delivery-proxy': {};
    'hi-res-support': {
        default: number;
    };
    'ultra-res-support': {};
    format: {};
    'cdn-operations': {};
    progressive: {};
    quality: {};
    'is-background-for': {};
    'is-preview-blur': {
        default: number;
    };
}>;
//# sourceMappingURL=props-map.d.ts.map