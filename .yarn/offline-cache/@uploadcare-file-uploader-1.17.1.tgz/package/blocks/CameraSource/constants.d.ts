export const CameraSourceTypes: Readonly<{
    PHOTO: "photo";
    VIDEO: "video";
}>;
export const CameraSourceEvents: Readonly<{
    IDLE: "idle";
    SHOT: "shot";
    PLAY: "play";
    PAUSE: "pause";
    RESUME: "resume";
    STOP: "stop";
    RETAKE: "retake";
    ACCEPT: "accept";
}>;
export type ModeCameraType = (typeof CameraSourceTypes)[keyof typeof CameraSourceTypes];
//# sourceMappingURL=constants.d.ts.map