export function calcCameraModes(cfg: import("../../types").ConfigType): {
    isVideoRecordingEnabled: boolean;
    isPhotoEnabled: boolean;
};
//# sourceMappingURL=calcCameraModes.d.ts.map