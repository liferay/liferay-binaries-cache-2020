/** @typedef {'photo' | 'video'} CameraMode */
/** @typedef {'shot' | 'retake' | 'accept' | 'play' | 'stop' | 'pause' | 'resume'} CameraStatus */
export class CameraSource extends UploaderBlock {
    activityType: "camera";
    /** @private */
    private _unsubPermissions;
    /** @type {BlobPart[]} */
    _chunks: BlobPart[];
    /** @type {MediaRecorder | null} */
    _mediaRecorder: MediaRecorder | null;
    /** @type {MediaStream | null} */
    _stream: MediaStream | null;
    /** @type {string | null} */
    _selectedAudioId: string | null;
    /** @type {string | null} */
    _selectedCameraId: string | null;
    init$: {
        video: null;
        videoTransformCss: null;
        videoHidden: boolean;
        messageHidden: boolean;
        requestBtnHidden: boolean;
        cameraSelectOptions: null;
        cameraSelectHidden: boolean;
        l10nMessage: string;
        switcher: null;
        panels: null;
        timer: null;
        timerHidden: boolean;
        cameraHidden: boolean;
        cameraActionsHidden: boolean;
        audioSelectOptions: null;
        audioSelectHidden: boolean;
        audioSelectDisabled: boolean;
        audioToggleMicrophoneHidden: boolean;
        tabCameraHidden: boolean;
        tabVideoHidden: boolean;
        currentIcon: string;
        currentTimelineIcon: string;
        toggleMicrophoneIcon: string;
        /** @type {Number} */
        _startTime: number;
        /** @type {Number} */
        _elapsedTime: number;
        _animationFrameId: null;
        mutableClassButton: string;
        /** @param {Event} e */
        onCameraSelectChange: (e: Event) => void;
        /** @param {Event} e */
        onAudioSelectChange: (e: Event) => void;
        onCancel: () => void;
        onShot: () => void;
        onRequestPermissions: () => Promise<void>;
        /** General method for photo and video capture */
        onStartCamera: () => void;
        onStartRecording: () => void;
        onStopRecording: () => void;
        onToggleRecording: () => void;
        onToggleAudio: () => void;
        onRetake: () => void;
        onAccept: () => void;
        /** @param {MouseEvent} e */
        onClickTab: (e: MouseEvent) => void;
        '*commonProgress': number;
        '*uploadList': never[];
        '*uploadQueue': import("@uploadcare/upload-client").Queue;
        '*collectionErrors': ReturnType<import("../../index.js").OutputErrorCollection>[];
        '*collectionState': import("../../index.js").OutputCollectionState | null;
        '*groupInfo': import("@uploadcare/upload-client").UploadcareGroup | null;
        '*uploadTrigger': Set<string>;
        '*secureUploadsManager': import("../../abstract/SecureUploadsManager.js").SecureUploadsManager | null;
        '*currentActivity': null;
        '*currentActivityParams': {};
        '*history': never[];
        '*historyBack': null;
        '*closeModal': () => void;
    };
    _chooseActionWithCamera: () => void;
    _updateTimer: () => void;
    _animationFrameId: number | undefined;
    _startTimer: () => void;
    _stopTimer: () => void;
    _startTimeline: () => void;
    _stopTimeline: () => void;
    _startRecording: () => void;
    _options: {
        audioBitsPerSecond?: number;
        bitsPerSecond?: number;
        mimeType?: string;
        videoBitsPerSecond?: number;
    } | undefined;
    /** @private */
    private _stopRecording;
    /** This method is used to toggle recording pause/resume */
    _toggleRecording: () => void;
    _toggleEnableAudio: () => void;
    /**
     * Previewing the video that was recorded on the camera
     *
     * @private
     */
    private _previewVideo;
    _retake: () => void;
    _accept: () => void;
    /** @param {CameraStatus} status */
    _handlePhoto: (status: CameraStatus) => void;
    /** @param {CameraStatus} status */
    _handleVideo: (status: CameraStatus) => void;
    /**
     * @private
     * @param {CameraStatus} status
     */
    private _setCameraState;
    /** @private */
    private _shot;
    _canvas: HTMLCanvasElement | undefined;
    _ctx: CanvasRenderingContext2D | null | undefined;
    /**
     * @private
     * @param {CameraMode} tabId
     */
    private _handleActiveTab;
    _activeTab: CameraMode | undefined;
    /**
     * @param {'camera' | 'video'} type
     * @param {'jpeg' | 'webm'} ext
     * @param {String} format
     * @param {Blob} blob
     */
    _createFile: (type: "camera" | "video", ext: "jpeg" | "webm", format: string, blob: Blob) => File;
    /** @param {String | undefined} mime */
    _guessExtensionByMime(mime: string | undefined): any;
    /**
     * The send file to the server
     *
     * @param {File} file
     */
    _toSend: (file: File) => void;
    /** @private */
    private get _cameraModes();
    /**
     * @private
     * @param {'granted' | 'denied' | 'prompt'} state
     */
    private _setPermissionsState;
    _makeStreamInactive: () => false | undefined;
    _stopCapture: () => void;
    _capturing: boolean | undefined;
    _capture: () => Promise<void>;
    _handlePermissionsChange: () => void;
    _permissionAccess: () => Promise<void>;
    _getPermission: () => void;
    _requestDeviceAccess: () => Promise<void>;
    _getDevices: () => Promise<void>;
    _cameraDevices: {
        text: string;
        value: string;
    }[] | undefined;
    _audioDevices: false | {
        text: string;
        value: string;
    }[] | undefined;
    _onActivate: () => Promise<void>;
    _onDeactivate: () => Promise<void>;
    /** @param {CameraMode[]} cameraModes */
    _handleCameraModes: (cameraModes: CameraMode[]) => void;
    _destroy(): void;
    destroyCallback(): Promise<void>;
}
export namespace CameraSource {
    let template: string;
}
export type CameraMode = "photo" | "video";
export type CameraStatus = "shot" | "retake" | "accept" | "play" | "stop" | "pause" | "resume";
import { UploaderBlock } from '../../abstract/UploaderBlock.js';
//# sourceMappingURL=CameraSource.d.ts.map