export class Thumb extends FileItemConfig {
    /** @private */
    private _renderedGridOnce;
    /**
     * @private
     * @type {IntersectionObserverEntry['boundingClientRect'] | null}
     */
    private _thumbRect;
    _isIntersecting: boolean;
    _firstViewMode: import("../UploadList/UploadList.js").FilesViewMode;
    init$: {
        thumbUrl: string;
        badgeIcon: string;
        uid: string;
        '*commonProgress': number;
        '*uploadList': never[];
        '*uploadQueue': import("@uploadcare/upload-client").Queue;
        '*collectionErrors': ReturnType<import("../../index.js").OutputErrorCollection>[];
        '*collectionState': import("../../index.js").OutputCollectionState | null;
        '*groupInfo': import("@uploadcare/upload-client").UploadcareGroup | null;
        '*uploadTrigger': Set<string>;
        '*secureUploadsManager': import("../../abstract/SecureUploadsManager.js").SecureUploadsManager | null;
        '*currentActivity': null;
        '*currentActivityParams': {};
        '*history': never[];
        '*historyBack': null;
        '*closeModal': () => void;
    };
    _calculateThumbSize(force?: boolean): number;
    /** @private */
    private _generateThumbnail;
    _debouncedGenerateThumb: ((...args: any[]) => Promise<void>) & {
        cancel: () => void;
    };
    /**
     * @private
     * @param {IntersectionObserverEntry[]} entries
     */
    private _observerCallback;
    /**
     * @private
     * @param {String} id
     */
    private _handleEntryId;
    _observer: IntersectionObserver | undefined;
}
export namespace Thumb {
    let template: string;
}
import { FileItemConfig } from '../FileItem/FileItemConfig.js';
//# sourceMappingURL=Thumb.d.ts.map