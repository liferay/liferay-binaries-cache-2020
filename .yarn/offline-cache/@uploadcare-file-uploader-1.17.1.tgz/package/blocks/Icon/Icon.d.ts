export class Icon extends Block {
    init$: {
        name: string;
        href: string;
    };
}
export namespace Icon {
    let template: string;
}
import { Block } from '../../abstract/Block.js';
//# sourceMappingURL=Icon.d.ts.map