/**
 * Config keys that can't be passed as attribute (because they are object or function)
 *
 * @type {[
 *   'metadata',
 *   'localeDefinitionOverride',
 *   'secureUploadsSignatureResolver',
 *   'secureDeliveryProxyUrlResolver',
 *   'iconHrefResolver',
 *   'fileValidators',
 *   'collectionValidators',
 *   'mediaRecorderOptions',
 * ]}
 */
export const complexConfigKeys: ["metadata", "localeDefinitionOverride", "secureUploadsSignatureResolver", "secureDeliveryProxyUrlResolver", "iconHrefResolver", "fileValidators", "collectionValidators", "mediaRecorderOptions"];
export type Config = import("../../utils/mixinClass.js").MixinClass<typeof ConfigClass, import("../../types").ConfigType>;
/** @typedef {import('../../utils/mixinClass.js').MixinClass<typeof ConfigClass, import('../../types').ConfigType>} Config */
export const Config: Config;
declare class ConfigClass extends Block {
    /**
     * @private
     * @param {keyof import('../../types').ConfigType} key
     * @param {unknown} value
     */
    private _flushValueToAttribute;
    /**
     * @private
     * @param {keyof import('../../types').ConfigType} key
     * @param {unknown} value
     */
    private _flushValueToState;
    /**
     * @private
     * @param {keyof import('../../types').ConfigType} key
     * @param {unknown} value
     */
    private _setValue;
    /**
     * @private
     * @param {keyof import('../../types').ConfigType} key
     */
    private _getValue;
    /**
     * @param {string} key
     * @param {unknown} previousValue
     * @param {unknown} nextValue
     */
    _assertSameValueDifferentReference(key: string, previousValue: unknown, nextValue: unknown): void;
    /**
     * @param {keyof typeof attrStateMapping} name
     * @param {string} oldVal
     * @param {string} newVal
     */
    attributeChangedCallback(name: keyof typeof attrStateMapping, oldVal: string, newVal: string): void;
}
import { Block } from '../../abstract/Block.js';
/** Mapping of attribute names to state */
declare const attrStateMapping: Record<keyof import("../../types").ConfigAttributesType, string>;
export {};
//# sourceMappingURL=Config.d.ts.map