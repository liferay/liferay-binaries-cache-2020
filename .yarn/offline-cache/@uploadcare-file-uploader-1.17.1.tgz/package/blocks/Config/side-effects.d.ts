export function runSideEffects<T extends keyof import("../../types").ConfigType>({ key, value, setValue, getValue }: {
    key: T;
    value: import("../../types").ConfigType[T];
    setValue: (key: T, value: import("../../types").ConfigType[T]) => void;
    getValue: (key: T) => import("../../types").ConfigType[T];
}): void;
//# sourceMappingURL=side-effects.d.ts.map