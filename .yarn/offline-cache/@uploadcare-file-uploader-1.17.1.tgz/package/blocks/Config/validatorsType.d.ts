/** @param {unknown} value */
export function asString(value: unknown): string;
/** @param {unknown} value */
export function asNumber(value: unknown): number;
/** @param {unknown} value */
export function asBoolean(value: unknown): boolean;
/** @param {unknown} value */
export function asStore(value: unknown): boolean | "auto";
/** @param {unknown} value */
export function asCameraCapture(value: unknown): "" | "user" | "environment";
/** @param {unknown} value */
export function asCameraMode(value: unknown): import("../CameraSource/CameraSource.js").CameraMode;
/** @param {unknown} value */
export function asCameraModes(value: unknown): string;
/** @param {unknown} value */
export function asMetadata(value: unknown): import("@uploadcare/upload-client").Metadata | import("../../types").MetadataCallback;
/**
 * @template {{}} T
 * @param {unknown} value
 * @returns {T}
 */
export function asObject<T extends {}>(value: unknown): T;
/**
 * @template {Function} T
 * @param {unknown} value
 * @returns {T}
 */
export function asFunction<T extends Function>(value: unknown): T;
/**
 * @template {Function[] | string | {}} T
 * @param {unknown} value
 * @returns {T}
 */
export function asArray<T extends Function[] | string | {}>(value: unknown): T;
/** @param {unknown} value */
export function asFilesViewMode(value: unknown): import("../UploadList/UploadList.js").FilesViewMode;
//# sourceMappingURL=validatorsType.d.ts.map