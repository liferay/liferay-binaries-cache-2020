/** Runs on every config change and warns about potential issues. */
export const runAssertions: ((cfg: import("../../types").ConfigType) => void) & {
    cancel: () => void;
};
//# sourceMappingURL=assertions.d.ts.map