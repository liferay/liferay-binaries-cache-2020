export function canUsePermissionsApi(): boolean;
//# sourceMappingURL=abilities.d.ts.map