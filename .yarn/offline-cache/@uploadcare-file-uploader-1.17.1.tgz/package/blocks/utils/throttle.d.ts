export function throttle<T extends {
    (...args: any[]): void;
}>(fn: T, wait: number): T & {
    readonly cancel: () => void;
};
//# sourceMappingURL=throttle.d.ts.map