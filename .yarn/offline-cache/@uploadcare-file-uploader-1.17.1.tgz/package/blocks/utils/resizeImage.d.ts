/**
 * @param {File} imgFile
 * @param {Number} [size]
 */
export function generateThumb(imgFile: File, size?: number): string | Promise<any>;
//# sourceMappingURL=resizeImage.d.ts.map