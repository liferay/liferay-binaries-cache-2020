export function preloadImage(src: any): {
    promise: Promise<any>;
    image: HTMLImageElement;
    cancel: () => void;
};
export function batchPreloadImages(list: any): {
    promise: Promise<PromiseSettledResult<any>[]>;
    images: HTMLImageElement[];
    cancel: () => void;
};
//# sourceMappingURL=preloadImage.d.ts.map