export const ExternalUploadSource: Readonly<{
    FACEBOOK: "facebook";
    DROPBOX: "dropbox";
    GDRIVE: "gdrive";
    GPHOTOS: "gphotos";
    FLICKR: "flickr";
    VK: "vk";
    EVERNOTE: "evernote";
    BOX: "box";
    ONEDRIVE: "onedrive";
    HUDDLE: "huddle";
}>;
export const UploadSourceMobile: Readonly<{
    MOBILE_VIDEO_CAMERA: "mobile-video-camera";
    MOBILE_PHOTO_CAMERA: "mobile-photo-camera";
}>;
export const UploadSource: Readonly<{
    FACEBOOK: "facebook";
    DROPBOX: "dropbox";
    GDRIVE: "gdrive";
    GPHOTOS: "gphotos";
    FLICKR: "flickr";
    VK: "vk";
    EVERNOTE: "evernote";
    BOX: "box";
    ONEDRIVE: "onedrive";
    HUDDLE: "huddle";
    MOBILE_VIDEO_CAMERA: "mobile-video-camera";
    MOBILE_PHOTO_CAMERA: "mobile-photo-camera";
    LOCAL: "local";
    DROP_AREA: "drop-area";
    CAMERA: "camera";
    EXTERNAL: "external";
    API: "js-api";
    URL: "url";
    DRAW: "draw";
}>;
export type SourceTypes = (typeof UploadSource)[keyof typeof UploadSource];
//# sourceMappingURL=UploadSource.d.ts.map