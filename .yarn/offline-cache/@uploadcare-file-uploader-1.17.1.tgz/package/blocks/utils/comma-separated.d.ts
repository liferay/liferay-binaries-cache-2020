export function deserializeCsv(value: string): string[];
export function serializeCsv(value: unknown[]): string;
//# sourceMappingURL=comma-separated.d.ts.map