declare module 'https://*';
