export function waitForAttribute({ element, attribute, onSuccess, onTimeout, timeout }: {
    element: HTMLElement;
    attribute: string;
    onSuccess: (value: string) => void;
    onTimeout: () => void;
    timeout?: number;
}): void;
//# sourceMappingURL=waitForAttribute.d.ts.map