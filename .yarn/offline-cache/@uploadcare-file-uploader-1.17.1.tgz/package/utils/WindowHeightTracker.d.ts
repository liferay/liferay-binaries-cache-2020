export class WindowHeightTracker {
    /**
     * @private
     * @type {Set<unknown>}
     */
    private static clientsRegistry;
    /** @private */
    private static flush;
    /**
     * @param {unknown} client
     * @public
     */
    public static registerClient(client: unknown): void;
    /**
     * @param {unknown} client
     * @public
     */
    public static unregisterClient(client: unknown): void;
    /** @private */
    private static attachTracker;
    /** @private */
    private static detachTracker;
}
//# sourceMappingURL=WindowHeightTracker.d.ts.map