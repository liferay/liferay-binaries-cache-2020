export {};
//# sourceMappingURL=getPluralForm.test.d.ts.map