export const ByteUnitEnum: Readonly<{
    AUTO: "auto";
    BYTE: "byte";
    KB: "kb";
    MB: "mb";
    GB: "gb";
    TB: "tb";
    PB: "pb";
}>;
export function prettyBytes(bytes: number, unit?: (typeof ByteUnitEnum)[keyof typeof ByteUnitEnum]): string;
//# sourceMappingURL=prettyBytes.d.ts.map