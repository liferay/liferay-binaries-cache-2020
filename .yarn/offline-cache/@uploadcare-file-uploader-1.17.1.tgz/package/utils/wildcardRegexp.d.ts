export function wildcardRegexp(str: string, flags?: string): RegExp;
//# sourceMappingURL=wildcardRegexp.d.ts.map