export function memoize<TArgs extends any[], TReturn extends unknown, T extends (...args: TArgs) => TReturn>(fn: T): T;
//# sourceMappingURL=memoize.d.ts.map