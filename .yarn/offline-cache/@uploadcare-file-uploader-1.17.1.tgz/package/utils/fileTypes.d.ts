export const BASIC_IMAGE_WILDCARD: "image/*";
export const BASIC_VIDEO_WILDCARD: "video/*";
export const HEIC_IMAGE_MIME_LIST: string[];
export function calcImageAcceptList(): string[];
export const IMAGE_ACCEPT_LIST: string[];
export function mergeFileTypes(fileTypes?: string[]): string[];
export function matchMimeType(mimeType: string, allowedFileTypes: string[]): boolean;
export function matchExtension(fileName: string, allowedFileTypes: string[]): boolean;
export function fileIsImage(file: File | Blob): boolean;
export function isBlob(data: unknown): boolean;
export function isFile(data: unknown): boolean;
//# sourceMappingURL=fileTypes.d.ts.map