export function calcBrowserInfo(): {
    safariDesktop: boolean;
};
export function calcBrowserFeatures(): {
    htmlMediaCapture: boolean;
};
export namespace browserInfo {
    let safariDesktop: boolean;
}
export namespace browserFeatures {
    let htmlMediaCapture: boolean;
}
//# sourceMappingURL=browser-info.d.ts.map