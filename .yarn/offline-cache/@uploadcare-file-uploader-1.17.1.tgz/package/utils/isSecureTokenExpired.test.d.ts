export {};
//# sourceMappingURL=isSecureTokenExpired.test.d.ts.map