export {};
//# sourceMappingURL=memoize.test.d.ts.map