export {};
//# sourceMappingURL=parseCdnUrl.test.d.ts.map