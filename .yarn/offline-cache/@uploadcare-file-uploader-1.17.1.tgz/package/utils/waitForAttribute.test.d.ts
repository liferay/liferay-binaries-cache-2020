export {};
//# sourceMappingURL=waitForAttribute.test.d.ts.map