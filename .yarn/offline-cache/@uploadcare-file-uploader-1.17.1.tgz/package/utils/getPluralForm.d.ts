export function getPluralForm(locale: string, count: number): PluralForm;
export type PluralForm = Intl.LDMLPluralRule;
//# sourceMappingURL=getPluralForm.d.ts.map