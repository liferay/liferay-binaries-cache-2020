export function parseShrink(value: any): {
    size: number;
    quality: number | undefined;
};
//# sourceMappingURL=parseShrink.d.ts.map