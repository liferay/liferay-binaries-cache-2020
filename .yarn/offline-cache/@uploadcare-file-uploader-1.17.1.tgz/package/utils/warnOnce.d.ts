/** @param {string} message */
export function warnOnce(message: string): void;
//# sourceMappingURL=warnOnce.d.ts.map