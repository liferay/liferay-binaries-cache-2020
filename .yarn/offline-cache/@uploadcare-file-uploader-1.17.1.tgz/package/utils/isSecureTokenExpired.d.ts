export function isSecureTokenExpired(secureToken: import("../types").SecureUploadsSignatureAndExpire, { threshold }: {
    threshold?: number;
}): boolean;
//# sourceMappingURL=isSecureTokenExpired.d.ts.map