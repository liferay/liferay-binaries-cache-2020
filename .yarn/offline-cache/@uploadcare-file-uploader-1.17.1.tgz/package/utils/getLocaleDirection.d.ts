export function getLocaleDirection(localeId: string): string;
//# sourceMappingURL=getLocaleDirection.d.ts.map