export function parseCdnUrl({ url, cdnBase }: {
    url: string;
    cdnBase: string;
}): {
    uuid: any;
    cdnUrlModifiers: any;
    filename: any;
} | null;
//# sourceMappingURL=parseCdnUrl.d.ts.map