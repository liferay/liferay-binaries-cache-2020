export function getTopLevelOrigin(): string;
//# sourceMappingURL=get-top-level-origin.d.ts.map