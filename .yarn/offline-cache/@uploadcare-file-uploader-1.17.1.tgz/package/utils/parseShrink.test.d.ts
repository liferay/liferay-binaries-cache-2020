export {};
//# sourceMappingURL=parseShrink.test.d.ts.map