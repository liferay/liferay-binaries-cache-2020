export {};
//# sourceMappingURL=browser-info.test.d.ts.map