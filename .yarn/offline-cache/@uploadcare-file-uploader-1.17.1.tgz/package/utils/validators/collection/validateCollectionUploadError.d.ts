/** @type {import('../../../abstract/ValidationManager.js').FuncCollectionValidator} */
export const validateCollectionUploadError: import("../../../abstract/ValidationManager.js").FuncCollectionValidator;
//# sourceMappingURL=validateCollectionUploadError.d.ts.map