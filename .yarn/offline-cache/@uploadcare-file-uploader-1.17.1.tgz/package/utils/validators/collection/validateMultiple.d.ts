/** @type {import('../../../abstract/ValidationManager.js').FuncCollectionValidator} */
export const validateMultiple: import("../../../abstract/ValidationManager.js").FuncCollectionValidator;
//# sourceMappingURL=validateMultiple.d.ts.map