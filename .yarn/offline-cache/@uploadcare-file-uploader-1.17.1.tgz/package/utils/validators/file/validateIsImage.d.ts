/** @type {import('../../../abstract/ValidationManager.js').FuncFileValidator} */
export const validateIsImage: import("../../../abstract/ValidationManager.js").FuncFileValidator;
//# sourceMappingURL=validateIsImage.d.ts.map