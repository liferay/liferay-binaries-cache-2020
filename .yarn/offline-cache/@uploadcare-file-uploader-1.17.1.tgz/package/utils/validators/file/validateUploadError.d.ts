/** @type {import('../../../abstract/ValidationManager.js').FuncFileValidator} */
export const validateUploadError: import("../../../abstract/ValidationManager.js").FuncFileValidator;
//# sourceMappingURL=validateUploadError.d.ts.map