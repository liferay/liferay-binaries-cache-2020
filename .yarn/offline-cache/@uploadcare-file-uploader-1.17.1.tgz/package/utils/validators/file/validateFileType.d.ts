/** @type {import('../../../abstract/ValidationManager.js').FuncFileValidator} */
export const validateFileType: import("../../../abstract/ValidationManager.js").FuncFileValidator;
//# sourceMappingURL=validateFileType.d.ts.map