/** @type {import('../../../abstract/ValidationManager.js').FuncFileValidator} */
export const validateMaxSizeLimit: import("../../../abstract/ValidationManager.js").FuncFileValidator;
//# sourceMappingURL=validateMaxSizeLimit.d.ts.map