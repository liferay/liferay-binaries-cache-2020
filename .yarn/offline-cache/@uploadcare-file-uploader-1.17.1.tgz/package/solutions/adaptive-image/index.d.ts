export { Img };
import { Img } from '../../blocks/Img/Img.js';
//# sourceMappingURL=index.d.ts.map