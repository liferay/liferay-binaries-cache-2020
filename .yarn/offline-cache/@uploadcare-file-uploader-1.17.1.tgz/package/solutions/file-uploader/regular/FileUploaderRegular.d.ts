export class FileUploaderRegular extends SolutionBlock {
    init$: {
        isHidden: boolean;
        '*commonProgress': number;
        '*uploadList': never[];
        '*uploadQueue': import("@uploadcare/upload-client").Queue;
        '*collectionErrors': ReturnType<import("./index.js").OutputErrorCollection>[];
        '*collectionState': import("./index.js").OutputCollectionState | null;
        '*groupInfo': import("@uploadcare/upload-client").UploadcareGroup | null;
        '*uploadTrigger': Set<string>;
        '*secureUploadsManager': import("../../../abstract/SecureUploadsManager.js").SecureUploadsManager | null;
        '*currentActivity': null;
        '*currentActivityParams': {};
        '*history': never[];
        '*historyBack': null;
        '*closeModal': () => void;
    };
}
export namespace FileUploaderRegular {
    let template: string;
}
import { SolutionBlock } from '../../../abstract/SolutionBlock.js';
//# sourceMappingURL=FileUploaderRegular.d.ts.map