export class FileUploaderInline extends SolutionBlock {
    init$: {
        couldCancel: boolean;
        cancel: () => void;
        '*commonProgress': number;
        '*uploadList': never[];
        '*uploadQueue': import("@uploadcare/upload-client").Queue;
        '*collectionErrors': ReturnType<import("./index.js").OutputErrorCollection>[];
        '*collectionState': import("./index.js").OutputCollectionState | null;
        '*groupInfo': import("@uploadcare/upload-client").UploadcareGroup | null;
        '*uploadTrigger': Set<string>;
        '*secureUploadsManager': import("../../../abstract/SecureUploadsManager.js").SecureUploadsManager | null;
        '*currentActivity': null;
        '*currentActivityParams': {};
        '*history': never[];
        '*historyBack': null;
        '*closeModal': () => void;
    };
    get couldHistoryBack(): boolean;
    get couldShowList(): boolean;
}
export namespace FileUploaderInline {
    let template: string;
}
import { SolutionBlock } from '../../../abstract/SolutionBlock.js';
//# sourceMappingURL=FileUploaderInline.d.ts.map