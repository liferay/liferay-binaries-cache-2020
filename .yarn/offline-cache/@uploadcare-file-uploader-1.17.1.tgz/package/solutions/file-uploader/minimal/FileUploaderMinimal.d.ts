export class FileUploaderMinimal extends SolutionBlock {
    init$: {
        singleUpload: boolean;
        isHiddenStartFrom: boolean;
        classUploadList: string;
        classStartFrom: string;
        '*commonProgress': number;
        '*uploadList': never[];
        '*uploadQueue': import("@uploadcare/upload-client").Queue;
        '*collectionErrors': ReturnType<import("./index.js").OutputErrorCollection>[];
        '*collectionState': import("./index.js").OutputCollectionState | null;
        '*groupInfo': import("@uploadcare/upload-client").UploadcareGroup | null;
        '*uploadTrigger': Set<string>;
        '*secureUploadsManager': import("../../../abstract/SecureUploadsManager.js").SecureUploadsManager | null;
        '*currentActivity': null;
        '*currentActivityParams': {};
        '*history': never[];
        '*historyBack': null;
        '*closeModal': () => void;
    };
    _handleModalOpen(data: {
        id: import("../../../abstract/ModalManager.js").ModalId;
        modal: import("../../../abstract/ModalManager.js").ModalNode;
    }): void;
    _handleModalClose(data: {
        id: import("../../../abstract/ModalManager.js").ModalId;
        modal: import("../../../abstract/ModalManager.js").ModalNode;
    }): void;
    handleModalOpen: ((data: {
        id: import("../../../abstract/ModalManager.js").ModalId;
        modal: import("../../../abstract/ModalManager.js").ModalNode;
    }) => void) | undefined;
    handleModalClose: ((data: {
        id: import("../../../abstract/ModalManager.js").ModalId;
        modal: import("../../../abstract/ModalManager.js").ModalNode;
    }) => void) | undefined;
}
export namespace FileUploaderMinimal {
    let template: string;
}
import { SolutionBlock } from '../../../abstract/SolutionBlock.js';
//# sourceMappingURL=FileUploaderMinimal.d.ts.map