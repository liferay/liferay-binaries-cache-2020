export class CloudImageEditor extends CloudImageEditorBlock {
}
import { CloudImageEditorBlock } from '../../blocks/CloudImageEditor/src/CloudImageEditorBlock.js';
//# sourceMappingURL=CloudImageEditor.d.ts.map