/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x3c5002=_0x5ecb;(function(_0x307a0e,_0xe82baf){const _0x23723e=_0x5ecb,_0x43e41e=_0x307a0e();while(!![]){try{const _0x1feb70=-parseInt(_0x23723e(0xf0))/0x1+-parseInt(_0x23723e(0x100))/0x2*(parseInt(_0x23723e(0xf5))/0x3)+parseInt(_0x23723e(0xfc))/0x4*(-parseInt(_0x23723e(0x106))/0x5)+-parseInt(_0x23723e(0x107))/0x6+parseInt(_0x23723e(0x109))/0x7+-parseInt(_0x23723e(0xef))/0x8+-parseInt(_0x23723e(0x103))/0x9*(-parseInt(_0x23723e(0xfb))/0xa);if(_0x1feb70===_0xe82baf)break;else _0x43e41e['push'](_0x43e41e['shift']());}catch(_0x4feb37){_0x43e41e['push'](_0x43e41e['shift']());}}}(_0x39f7,0x47695));import{Command as _0x88d08a}from'ckeditor5/src/core.js';function _0x39f7(){const _0x586e7a=['checkChild','mergeField','model','2KUHrkE','checkAttribute','document','10875555ICDYia','execute','deleteContent','95OKJRie','1978452aHUyZo','selection','2552984AxkqEM','isEnabled','createElement','setAttribute','1575344czdCfm','493118SOHsxw','schema','getAttributes','focus','refresh','367353fypdQE','string','insertContent','editor','after','change','10bvWMMv','29132GawpBw'];_0x39f7=function(){return _0x586e7a;};return _0x39f7();}function _0x5ecb(_0x3a40b8,_0x26ee81){const _0x39f72b=_0x39f7();return _0x5ecb=function(_0x5ecb5b,_0x8e56ca){_0x5ecb5b=_0x5ecb5b-0xef;let _0x2e91ad=_0x39f72b[_0x5ecb5b];return _0x2e91ad;},_0x5ecb(_0x3a40b8,_0x26ee81);}export class InsertMergeFieldCommand extends _0x88d08a{[_0x3c5002(0xf4)](){const _0x22631a=_0x3c5002,_0x4075e4=this[_0x22631a(0xf8)][_0x22631a(0xff)],_0x192fa5=_0x4075e4[_0x22631a(0xf1)][_0x22631a(0xfd)](_0x4075e4[_0x22631a(0x102)][_0x22631a(0x108)][_0x22631a(0xf3)],_0x22631a(0xfe));this[_0x22631a(0x10a)]=_0x192fa5;}[_0x3c5002(0x104)](_0x239031){const _0x3b89d0=_0x3c5002;if(!_0x239031||_0x3b89d0(0xf6)!=typeof _0x239031)return;const _0x5a8e5d=this[_0x3b89d0(0xf8)][_0x3b89d0(0xff)];_0x5a8e5d[_0x3b89d0(0xfa)](_0x19618c=>{const _0x2e44b6=_0x3b89d0;_0x5a8e5d[_0x2e44b6(0x105)](_0x5a8e5d[_0x2e44b6(0x102)][_0x2e44b6(0x108)]);const _0x42037f=_0x19618c[_0x2e44b6(0x10b)](_0x2e44b6(0xfe),{'id':_0x239031});for(const [_0x5d1b47,_0xfe3bd5]of _0x5a8e5d[_0x2e44b6(0x102)][_0x2e44b6(0x108)][_0x2e44b6(0xf2)]())_0x5a8e5d[_0x2e44b6(0xf1)][_0x2e44b6(0x101)](_0x42037f,_0x5d1b47)&&_0x19618c[_0x2e44b6(0x10c)](_0x5d1b47,_0xfe3bd5,_0x42037f);_0x5a8e5d[_0x2e44b6(0xf7)](_0x42037f,_0x5a8e5d[_0x2e44b6(0x102)][_0x2e44b6(0x108)],0x0,{'setSelection':_0x2e44b6(0xf9)});});}}