/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module merge-fields
 */
export { MergeFields } from './mergefields.js';
export { MergeFieldsEditing } from './mergefieldsediting.js';
export { MergeFieldsUI } from './mergefieldsui.js';
export { InsertMergeFieldBlockCommand } from './insertmergefieldblockcommand.js';
export { InsertMergeFieldCommand } from './insertmergefieldcommand.js';
export { InsertMergeFieldImageCommand } from './insertmergefieldimagecommand.js';
export { PreviewMergeFieldsCommand } from './previewmergefieldscommand.js';
export type { MergeFieldsConfig, MergeFieldsSanitizeOutput, MergeFieldsGroupDefinition, MergeFieldDefinition, MergeFieldsDataSetDefinition, MergeFieldDataSetValue, MergeFieldType } from './mergefieldsconfig.js';
export type { MergeFieldsValues } from './mergefieldsediting.js';
import './augmentation.js';
