/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x48c6b0=_0x513c;(function(_0xdd62f7,_0x1e1a9d){var _0x3222b8=_0x513c,_0x31101b=_0xdd62f7();while(!![]){try{var _0x1cefc2=-parseInt(_0x3222b8(0x19b))/0x1*(parseInt(_0x3222b8(0x19c))/0x2)+-parseInt(_0x3222b8(0x19a))/0x3+parseInt(_0x3222b8(0x1a0))/0x4+parseInt(_0x3222b8(0x19f))/0x5+parseInt(_0x3222b8(0x1a2))/0x6+parseInt(_0x3222b8(0x19e))/0x7*(-parseInt(_0x3222b8(0x198))/0x8)+-parseInt(_0x3222b8(0x199))/0x9;if(_0x1cefc2===_0x1e1a9d)break;else _0x31101b['push'](_0x31101b['shift']());}catch(_0x18be4c){_0x31101b['push'](_0x31101b['shift']());}}}(_0x308c,0xc9c63));function _0x513c(_0x46e323,_0x117c6a){var _0x308c46=_0x308c();return _0x513c=function(_0x513cbd,_0x12578c){_0x513cbd=_0x513cbd-0x195;var _0x5c9cc6=_0x308c46[_0x513cbd];return _0x5c9cc6;},_0x513c(_0x46e323,_0x117c6a);}import{Plugin as _0x14040d}from'ckeditor5/src/core.js';import{MergeFieldsEditing as _0x1dfb62}from'./mergefieldsediting.js';import{MergeFieldsUI as _0x9277b8}from'./mergefieldsui.js';function _0x308c(){var _0x54a6fb=['1YQJWRT','331242OhsKTj','isOfficialPlugin','241206PBODer','934260tVFTOd','4116120IijvuR','requires','7908582Nkzryt','isPremiumPlugin','MergeFields','pluginName','48sYfxLX','6069429mPIdUF','1982286GWhfgh'];_0x308c=function(){return _0x54a6fb;};return _0x308c();}export class MergeFields extends _0x14040d{static get[_0x48c6b0(0x1a1)](){return[_0x1dfb62,_0x9277b8];}static get[_0x48c6b0(0x197)](){var _0x51ecbd=_0x48c6b0;return _0x51ecbd(0x196);}static get[_0x48c6b0(0x19d)](){return!0x0;}static get[_0x48c6b0(0x195)](){return!0x0;}}