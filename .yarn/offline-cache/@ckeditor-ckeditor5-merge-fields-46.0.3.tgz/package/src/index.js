/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x5b7126,_0x400ce1){var _0x5a4731=_0x1351,_0x18ee3b=_0x5b7126();while(!![]){try{var _0xebde4d=parseInt(_0x5a4731(0x145))/0x1*(-parseInt(_0x5a4731(0x13c))/0x2)+-parseInt(_0x5a4731(0x140))/0x3+-parseInt(_0x5a4731(0x13f))/0x4*(parseInt(_0x5a4731(0x144))/0x5)+parseInt(_0x5a4731(0x141))/0x6+-parseInt(_0x5a4731(0x143))/0x7*(-parseInt(_0x5a4731(0x13e))/0x8)+-parseInt(_0x5a4731(0x13d))/0x9+parseInt(_0x5a4731(0x13b))/0xa*(parseInt(_0x5a4731(0x142))/0xb);if(_0xebde4d===_0x400ce1)break;else _0x18ee3b['push'](_0x18ee3b['shift']());}catch(_0x4d2aee){_0x18ee3b['push'](_0x18ee3b['shift']());}}}(_0x50b2,0xb214a));export{MergeFields}from'./mergefields.js';function _0x50b2(){var _0x413fbb=['30UWhtNB','1VlzGpC','743840CkZzTO','1005074sobQmd','3339666VeqkVx','16FsVzcY','433052rXScuB','938847KIqSzP','6405972yvIygL','143NGTwfS','1858157nfksuz'];_0x50b2=function(){return _0x413fbb;};return _0x50b2();}export{MergeFieldsEditing}from'./mergefieldsediting.js';function _0x1351(_0x57b2bc,_0x2b4ae2){var _0x50b286=_0x50b2();return _0x1351=function(_0x135158,_0x420229){_0x135158=_0x135158-0x13b;var _0x3d3c9e=_0x50b286[_0x135158];return _0x3d3c9e;},_0x1351(_0x57b2bc,_0x2b4ae2);}export{MergeFieldsUI}from'./mergefieldsui.js';export{InsertMergeFieldBlockCommand}from'./insertmergefieldblockcommand.js';export{InsertMergeFieldCommand}from'./insertmergefieldcommand.js';export{InsertMergeFieldImageCommand}from'./insertmergefieldimagecommand.js';export{PreviewMergeFieldsCommand}from'./previewmergefieldscommand.js';import'./augmentation.js';