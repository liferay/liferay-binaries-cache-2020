/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x275bf4=_0xd1c8;function _0xd1c8(_0x415ab7,_0x44b737){const _0x113968=_0x1139();return _0xd1c8=function(_0xd1c8d8,_0x1d8110){_0xd1c8d8=_0xd1c8d8-0xf0;let _0x308e2f=_0x113968[_0xd1c8d8];return _0x308e2f;},_0xd1c8(_0x415ab7,_0x44b737);}function _0x1139(){const _0x213919=['plugins','2mubtHs','738CDhInu','8SjwqdR','44hqegxd','MergeFieldsEditing','get','previewMode','affectsData','26736gtxGbd','4997435dOMxWr','2591024UIQjvp','bind','isEnabled','82210fDhoqU','value','refresh','execute','6028788PNNRCl','editor','1094616vBlTzZ','1341198ZxoRYf','1162YwFTQT'];_0x1139=function(){return _0x213919;};return _0x1139();}(function(_0x1c72ad,_0x4c9435){const _0x356199=_0xd1c8,_0x3b5c58=_0x1c72ad();while(!![]){try{const _0x5808a2=-parseInt(_0x356199(0xfc))/0x1*(parseInt(_0x356199(0x100))/0x2)+-parseInt(_0x356199(0xfd))/0x3*(parseInt(_0x356199(0x102))/0x4)+parseInt(_0x356199(0xf2))/0x5+parseInt(_0x356199(0xf1))/0x6*(-parseInt(_0x356199(0xfe))/0x7)+-parseInt(_0x356199(0xf3))/0x8+-parseInt(_0x356199(0x101))/0x9*(-parseInt(_0x356199(0xf6))/0xa)+parseInt(_0x356199(0x103))/0xb*(parseInt(_0x356199(0xfa))/0xc);if(_0x5808a2===_0x4c9435)break;else _0x3b5c58['push'](_0x3b5c58['shift']());}catch(_0x1bf1e8){_0x3b5c58['push'](_0x3b5c58['shift']());}}}(_0x1139,0x9a063));import{Command as _0x10f07e}from'ckeditor5/src/core.js';export class PreviewMergeFieldsCommand extends _0x10f07e{constructor(_0x5e76b2){const _0x10e63d=_0xd1c8;super(_0x5e76b2);const _0x5ec656=this[_0x10e63d(0xfb)][_0x10e63d(0xff)][_0x10e63d(0x105)](_0x10e63d(0x104));this[_0x10e63d(0xf4)](_0x10e63d(0xf7))['to'](_0x5ec656,_0x10e63d(0x106)),this[_0x10e63d(0xf0)]=!0x1;}[_0x275bf4(0xf8)](){const _0x4eb0f9=_0x275bf4;this[_0x4eb0f9(0xf5)]=!0x0;}[_0x275bf4(0xf9)](_0x1afb20){const _0x4e38ed=_0x275bf4;this[_0x4e38ed(0xfb)][_0x4e38ed(0xff)][_0x4e38ed(0x105)](_0x4e38ed(0x104))[_0x4e38ed(0x106)]=_0x1afb20;}}