/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x46cf2c=_0x1248;(function(_0x12d703,_0x5b9dae){const _0x47a6e4=_0x1248,_0x2a591d=_0x12d703();while(!![]){try{const _0x4018b1=parseInt(_0x47a6e4(0x1d8))/0x1+-parseInt(_0x47a6e4(0x1c5))/0x2+parseInt(_0x47a6e4(0x1c4))/0x3+-parseInt(_0x47a6e4(0x1da))/0x4*(parseInt(_0x47a6e4(0x1d4))/0x5)+-parseInt(_0x47a6e4(0x1d5))/0x6+-parseInt(_0x47a6e4(0x1d1))/0x7*(parseInt(_0x47a6e4(0x1dd))/0x8)+parseInt(_0x47a6e4(0x1c9))/0x9;if(_0x4018b1===_0x5b9dae)break;else _0x2a591d['push'](_0x2a591d['shift']());}catch(_0x5b79c5){_0x2a591d['push'](_0x2a591d['shift']());}}}(_0x1641,0x4785d));function _0x1641(){const _0x18da90=['110bmhHTi','3072780oeqxSw','isEnabled','isEmpty','304503XuYvzO','parent','95572gnvFUr','change','editor','16eCYYpd','mergeFieldBlock','string','394173tDJCPG','704880yAUHkp','createElement','checkChild','document','15035445zwyAGM','schema','selection','insertObject','execute','refresh','isLimit','auto','1481641biRjCV','start','model'];_0x1641=function(){return _0x18da90;};return _0x1641();}import{Command as _0xe0973}from'ckeditor5/src/core.js';import{findOptimalInsertionRange as _0x1974ee}from'ckeditor5/src/widget.js';function _0x1248(_0x2b2ee0,_0x13779d){const _0x1641a8=_0x1641();return _0x1248=function(_0x124886,_0x2a34cb){_0x124886=_0x124886-0x1c3;let _0x48ccae=_0x1641a8[_0x124886];return _0x48ccae;},_0x1248(_0x2b2ee0,_0x13779d);}export class InsertMergeFieldBlockCommand extends _0xe0973{[_0x46cf2c(0x1ce)](){const _0x5a3c78=_0x46cf2c,_0x376064=this[_0x5a3c78(0x1dc)][_0x5a3c78(0x1d3)],_0x23864c=_0x376064[_0x5a3c78(0x1c8)][_0x5a3c78(0x1cb)];this[_0x5a3c78(0x1d6)]=function(_0x46884c,_0x56e58d){const _0x6104a0=_0x5a3c78,_0x1ecfca=_0x1974ee(_0x46884c,_0x56e58d);let _0x1c10c5=_0x1ecfca[_0x6104a0(0x1d2)][_0x6104a0(0x1d9)];return _0x1c10c5[_0x6104a0(0x1d7)]&&!_0x56e58d[_0x6104a0(0x1ca)][_0x6104a0(0x1cf)](_0x1c10c5)&&(_0x1c10c5=_0x1c10c5[_0x6104a0(0x1d9)]),_0x56e58d[_0x6104a0(0x1ca)][_0x6104a0(0x1c7)](_0x1c10c5,_0x6104a0(0x1de));}(_0x23864c,_0x376064);}[_0x46cf2c(0x1cd)](_0x522010,_0x25ca4e){const _0x27880e=_0x46cf2c;if(!_0x522010||_0x27880e(0x1c3)!=typeof _0x522010)return;const _0x4886c0=this[_0x27880e(0x1dc)][_0x27880e(0x1d3)];_0x4886c0[_0x27880e(0x1db)](_0x5837d8=>{const _0xef2eb0=_0x27880e,_0x130c7d=_0x5837d8[_0xef2eb0(0x1c6)](_0xef2eb0(0x1de),{'id':_0x522010});_0x4886c0[_0xef2eb0(0x1cc)](_0x130c7d,_0x4886c0[_0xef2eb0(0x1c8)][_0xef2eb0(0x1cb)],null,{'setSelection':'on','findOptimalPosition':!0x1===_0x25ca4e?void 0x0:_0xef2eb0(0x1d0)});});}}