/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x25fd83=_0x5741;(function(_0x475268,_0x150594){const _0x243c4d=_0x5741,_0x2d5a37=_0x475268();while(!![]){try{const _0x41bc7a=-parseInt(_0x243c4d(0x95))/0x1*(-parseInt(_0x243c4d(0x91))/0x2)+-parseInt(_0x243c4d(0x8b))/0x3*(parseInt(_0x243c4d(0x94))/0x4)+-parseInt(_0x243c4d(0x87))/0x5+-parseInt(_0x243c4d(0x8d))/0x6*(-parseInt(_0x243c4d(0x99))/0x7)+parseInt(_0x243c4d(0x86))/0x8+parseInt(_0x243c4d(0x89))/0x9+-parseInt(_0x243c4d(0x84))/0xa;if(_0x41bc7a===_0x150594)break;else _0x2d5a37['push'](_0x2d5a37['shift']());}catch(_0x34039c){_0x2d5a37['push'](_0x2d5a37['shift']());}}}(_0x37d7,0x592be));import{Command as _0x1f5e00}from'ckeditor5/src/core.js';function _0x37d7(){const _0x59a5fe=['1591303iOxZGw','commands','get','539720NMfjkN','MergeFieldsEditing','2010544cDCLYT','2532055dstXVH','plugins','496791PPIfpz','editor','2286ECNgRZ','getMergeFieldWidth','6XPVRYP','breakBlock','isEnabled','insertImage','999974sKpSru','wrapInAffixes','string','568sxSRpX','1kXmOnj','bind','getMergeFieldHeight','execute'];_0x37d7=function(){return _0x59a5fe;};return _0x37d7();}function _0x5741(_0x22fab2,_0x331ffb){const _0x37d732=_0x37d7();return _0x5741=function(_0x574148,_0x1752f5){_0x574148=_0x574148-0x82;let _0x5c447a=_0x37d732[_0x574148];return _0x5c447a;},_0x5741(_0x22fab2,_0x331ffb);}export class InsertMergeFieldImageCommand extends _0x1f5e00{constructor(_0x14dcec){const _0x32783b=_0x5741;super(_0x14dcec),this[_0x32783b(0x96)](_0x32783b(0x8f))['to'](this[_0x32783b(0x8a)][_0x32783b(0x82)][_0x32783b(0x83)](_0x32783b(0x90)));}[_0x25fd83(0x98)](_0x2debb4,_0x255b60){const _0x4cfbc8=_0x25fd83;if(!_0x2debb4||_0x4cfbc8(0x93)!=typeof _0x2debb4)return;const _0x2feb73=this[_0x4cfbc8(0x8a)][_0x4cfbc8(0x88)][_0x4cfbc8(0x83)](_0x4cfbc8(0x85)),_0x4d4e0c=_0x2feb73[_0x4cfbc8(0x8c)](_0x2debb4),_0x52346f=_0x2feb73[_0x4cfbc8(0x97)](_0x2debb4);this[_0x4cfbc8(0x8a)][_0x4cfbc8(0x98)](_0x4cfbc8(0x90),{'source':{'src':_0x2feb73[_0x4cfbc8(0x92)](_0x2debb4),'width':_0x4d4e0c,'height':_0x52346f},'breakBlock':_0x255b60&&_0x255b60[_0x4cfbc8(0x8e)]});}}