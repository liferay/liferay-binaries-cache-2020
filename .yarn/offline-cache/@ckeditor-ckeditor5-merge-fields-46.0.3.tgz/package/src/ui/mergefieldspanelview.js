/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x5196(_0x395b37,_0x55e608){const _0x360de3=_0x360d();return _0x5196=function(_0x5196a6,_0x51e6e){_0x5196a6=_0x5196a6-0xfd;let _0x392078=_0x360de3[_0x5196a6];return _0x392078;},_0x5196(_0x395b37,_0x55e608);}(function(_0x1e8f1e,_0x3de2c9){const _0x1bb362=_0x5196,_0x2ea71d=_0x1e8f1e();while(!![]){try{const _0x382be7=parseInt(_0x1bb362(0x108))/0x1*(-parseInt(_0x1bb362(0xfe))/0x2)+-parseInt(_0x1bb362(0x101))/0x3+parseInt(_0x1bb362(0x102))/0x4+-parseInt(_0x1bb362(0x100))/0x5+parseInt(_0x1bb362(0x106))/0x6+parseInt(_0x1bb362(0x109))/0x7+parseInt(_0x1bb362(0x103))/0x8;if(_0x382be7===_0x3de2c9)break;else _0x2ea71d['push'](_0x2ea71d['shift']());}catch(_0x12130b){_0x2ea71d['push'](_0x2ea71d['shift']());}}}(_0x360d,0xe7657));import{View as _0x403e5b}from'ckeditor5/src/ui.js';export class MergeFieldsPanelView extends _0x403e5b{constructor(_0x2010a5){const _0x1c7bed=_0x5196;super(_0x2010a5),this[_0x1c7bed(0xfd)](_0x1c7bed(0x105),'');const _0x27ee8d=this[_0x1c7bed(0x104)];this[_0x1c7bed(0x10a)]({'tag':_0x1c7bed(0xff),'attributes':{'class':['ck',_0x1c7bed(0x107)]},'children':[{'tag':_0x1c7bed(0xff),'attributes':{'class':['ck',_0x1c7bed(0x10b)]},'children':[{'text':_0x27ee8d['to'](_0x1c7bed(0x105))}]}]});}}function _0x360d(){const _0x4acfe6=['ck-merge-fields-form__status','set','1116806UWsBKJ','div','2432675JLVERo','4012896LNwzPx','2809076uoOVVv','10859240QnNeMm','bindTemplate','text','5299314UJDrPc','ck-merge-fields-form','2RArZKg','6621153FfBwbh','setTemplate'];_0x360d=function(){return _0x4acfe6;};return _0x360d();}