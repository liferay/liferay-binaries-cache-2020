/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x2ae160=_0x52c1;(function(_0x21dc0e,_0x172798){var _0x8efa0=_0x52c1,_0x13a89b=_0x21dc0e();while(!![]){try{var _0x5cb8f1=parseInt(_0x8efa0(0x78))/0x1*(parseInt(_0x8efa0(0x73))/0x2)+parseInt(_0x8efa0(0x72))/0x3+-parseInt(_0x8efa0(0x6f))/0x4*(parseInt(_0x8efa0(0x71))/0x5)+-parseInt(_0x8efa0(0x77))/0x6*(-parseInt(_0x8efa0(0x76))/0x7)+parseInt(_0x8efa0(0x70))/0x8*(-parseInt(_0x8efa0(0x79))/0x9)+parseInt(_0x8efa0(0x74))/0xa*(parseInt(_0x8efa0(0x6c))/0xb)+-parseInt(_0x8efa0(0x75))/0xc;if(_0x5cb8f1===_0x172798)break;else _0x13a89b['push'](_0x13a89b['shift']());}catch(_0x181866){_0x13a89b['push'](_0x13a89b['shift']());}}}(_0x5568,0xd3a74));import{ListView as _0x364169,filterGroupAndItemNames as _0x588340}from'ckeditor5/src/ui.js';function _0x52c1(_0x11ebbc,_0xf117b7){var _0x5568f9=_0x5568();return _0x52c1=function(_0x52c188,_0x38a7f6){_0x52c188=_0x52c188-0x6c;var _0x3622ea=_0x5568f9[_0x52c188];return _0x3622ea;},_0x52c1(_0x11ebbc,_0xf117b7);}function _0x5568(){var _0x5c207b=['2799976ktiRTY','461060JvKifW','2807043FfiDZE','24602wBjEeC','6883430XAHqpY','9828888mdaajl','14273wmDkdb','3270MwDQYq','51WxUHZE','36vHEwIi','11ZfRzYK','filter','items','12LTzRHx'];_0x5568=function(){return _0x5c207b;};return _0x5568();}export class MergeFieldsListView extends _0x364169{[_0x2ae160(0x6d)](_0x27f2de){var _0x3edeb6=_0x2ae160;return _0x588340(_0x27f2de,this[_0x3edeb6(0x6e)]);}}