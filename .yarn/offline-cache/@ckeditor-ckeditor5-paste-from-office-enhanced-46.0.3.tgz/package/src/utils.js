/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x37fb(_0x4b9376,_0x1645d5){const _0xf29f76=_0xf29f();return _0x37fb=function(_0x37fb73,_0x2e3c5b){_0x37fb73=_0x37fb73-0xd3;let _0x2bee1d=_0xf29f76[_0x37fb73];return _0x2bee1d;},_0x37fb(_0x4b9376,_0x1645d5);}(function(_0x507728,_0x203dad){const _0xffcd88=_0x37fb,_0x11bbdf=_0x507728();while(!![]){try{const _0x2c9e61=parseInt(_0xffcd88(0xd3))/0x1+-parseInt(_0xffcd88(0xd5))/0x2+parseInt(_0xffcd88(0xd9))/0x3*(-parseInt(_0xffcd88(0xdc))/0x4)+parseInt(_0xffcd88(0xd4))/0x5*(-parseInt(_0xffcd88(0xdd))/0x6)+-parseInt(_0xffcd88(0xd6))/0x7*(-parseInt(_0xffcd88(0xdb))/0x8)+parseInt(_0xffcd88(0xd7))/0x9+parseInt(_0xffcd88(0xda))/0xa;if(_0x2c9e61===_0x203dad)break;else _0x11bbdf['push'](_0x11bbdf['shift']());}catch(_0x2d63f8){_0x11bbdf['push'](_0x11bbdf['shift']());}}}(_0xf29f,0xe023e));function _0xf29f(){const _0x3b4c69=['test','2226kthSun','30243340ASzYCK','16XVdbNf','5608duVhfO','3535278dhbtiT','634573yHehwP','15meTYVb','2066576ajYEPh','719516rmxrJe','8053254hcedOC'];_0xf29f=function(){return _0x3b4c69;};return _0xf29f();}const m=/<meta\s*name="?generator"?\s*content="?microsoft\s*excel\s*\d+"?\/?>/i;export function isMSExcelContent(_0x280922){const _0x5f568e=_0x37fb;return m[_0x5f568e(0xd8)](_0x280922);}