/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module paste-from-office-enhanced/pastefromofficeenhancedpropagator
 */
import { Plugin } from 'ckeditor5/src/core.js';
/**
 * The Paste from Office Enhanced propagator that propagates inline styles from block elements to:
 * * `span` element with `style` properties,
 * * `HTML` structures based block element styles.
 */
export declare class PasteFromOfficeEnhancedPropagator extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "PasteFromOfficeEnhancedPropagator";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    static get requires(): readonly ["PasteFromOffice"];
    /**
     * @inheritDoc
     */
    init(): void;
    /**
     * @inheritDoc
     */
    destroy(): void;
}
