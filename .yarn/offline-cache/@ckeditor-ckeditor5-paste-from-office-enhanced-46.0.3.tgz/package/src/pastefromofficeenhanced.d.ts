/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module paste-from-office-enhanced/pastefromofficeenhanced
 * @publicApi
 */
import { Plugin } from 'ckeditor5/src/core.js';
import { PasteFromOfficeEnhancedInliner } from './pastefromofficeenhancedinliner.js';
import { PasteFromOfficeEnhancedPropagator } from './pastefromofficeenhancedpropagator.js';
/**
 * The Paste from Office Enhanced feature.
 *
 * Introduces seamless content pasting from MS Office applications with improved formatting retention for a smoother
 * and more efficient workflow.
 *
 * For a detailed overview, check the {@glink features/pasting/paste-from-office Paste from Office Enhanced feature guide}.
 */
export declare class PasteFromOfficeEnhanced extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "PasteFromOfficeEnhanced";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    static get requires(): readonly ["PasteFromOffice", typeof PasteFromOfficeEnhancedInliner, typeof PasteFromOfficeEnhancedPropagator];
}
