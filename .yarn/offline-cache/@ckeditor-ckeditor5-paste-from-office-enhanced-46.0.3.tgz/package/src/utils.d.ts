/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * Check if content was pasted from MS Excel.
 *
 * @param html
 * @returns True if content is pasted from MS Excel
 */
export declare function isMSExcelContent(html: string): boolean;
