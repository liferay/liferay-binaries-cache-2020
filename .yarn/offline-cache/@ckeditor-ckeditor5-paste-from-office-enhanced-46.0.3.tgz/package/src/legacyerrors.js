/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x5f22ba,_0x591ca9){var _0xde6cae=_0x411d,_0x175fd8=_0x5f22ba();while(!![]){try{var _0x16a156=parseInt(_0xde6cae(0xb5))/0x1*(-parseInt(_0xde6cae(0xb2))/0x2)+parseInt(_0xde6cae(0xb6))/0x3*(-parseInt(_0xde6cae(0xad))/0x4)+-parseInt(_0xde6cae(0xb1))/0x5+parseInt(_0xde6cae(0xb3))/0x6*(parseInt(_0xde6cae(0xac))/0x7)+parseInt(_0xde6cae(0xb4))/0x8+parseInt(_0xde6cae(0xaf))/0x9*(parseInt(_0xde6cae(0xae))/0xa)+-parseInt(_0xde6cae(0xb0))/0xb;if(_0x16a156===_0x591ca9)break;else _0x175fd8['push'](_0x175fd8['shift']());}catch(_0x2a7bfa){_0x175fd8['push'](_0x175fd8['shift']());}}}(_0x427b,0xecbaf));function _0x411d(_0x133a0b,_0x1886f5){var _0x427b71=_0x427b();return _0x411d=function(_0x411d54,_0x1d28f1){_0x411d54=_0x411d54-0xac;var _0x26571a=_0x427b71[_0x411d54];return _0x26571a;},_0x411d(_0x133a0b,_0x1886f5);}function _0x427b(){var _0x4db69b=['12799760GejAjQ','9944mYzqHC','15zIcbRT','204771GeYfZQ','17028coTrMv','2910QAphvx','53982KTpPpW','15760855IcROkX','5719970TNlHiT','20tDqzMA','66AxUfJQ'];_0x427b=function(){return _0x4db69b;};return _0x427b();}import{CKEditorError as _0x48325b}from'ckeditor5/src/utils.js';