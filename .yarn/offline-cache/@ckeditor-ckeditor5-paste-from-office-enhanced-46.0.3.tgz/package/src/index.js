/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x555520,_0x3cb37b){var _0x50cf31=_0x4ceb,_0x7892a7=_0x555520();while(!![]){try{var _0x57a86b=-parseInt(_0x50cf31(0x15c))/0x1*(-parseInt(_0x50cf31(0x15a))/0x2)+parseInt(_0x50cf31(0x161))/0x3*(-parseInt(_0x50cf31(0x162))/0x4)+parseInt(_0x50cf31(0x160))/0x5*(-parseInt(_0x50cf31(0x158))/0x6)+-parseInt(_0x50cf31(0x163))/0x7+-parseInt(_0x50cf31(0x15e))/0x8*(parseInt(_0x50cf31(0x15d))/0x9)+-parseInt(_0x50cf31(0x15b))/0xa*(parseInt(_0x50cf31(0x159))/0xb)+parseInt(_0x50cf31(0x15f))/0xc;if(_0x57a86b===_0x3cb37b)break;else _0x7892a7['push'](_0x7892a7['shift']());}catch(_0x107fc7){_0x7892a7['push'](_0x7892a7['shift']());}}}(_0x3bb0,0x8cd92));function _0x4ceb(_0x6967de,_0x2dcf3b){var _0x3bb08e=_0x3bb0();return _0x4ceb=function(_0x4ceb61,_0x29a208){_0x4ceb61=_0x4ceb61-0x158;var _0x267eed=_0x3bb08e[_0x4ceb61];return _0x267eed;},_0x4ceb(_0x6967de,_0x2dcf3b);}function _0x3bb0(){var _0x1ac3d9=['3858WYKovp','1120QQTGuq','6316233gQTHDN','24OYBvsp','11bqFaTY','4VUWuPN','2905130UwqoQc','232126ZHAsJC','5039586FGQeqN','8PJRstY','29038992UeFUqL','242985yUsAYh'];_0x3bb0=function(){return _0x1ac3d9;};return _0x3bb0();}export{PasteFromOfficeEnhanced}from'./pastefromofficeenhanced.js';import'./augmentation.js';