/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module paste-from-office-enhanced/normalizers/msofficestylesinliner/utils
 */
import { type ViewElement } from 'ckeditor5/src/engine.js';
type StyleSelector = string;
type CSSStyleDefinitions = Record<string, string>;
type ExtractedStyles = Record<StyleSelector, CSSStyleDefinitions>;
type ExpandedStyles = Map<ParsedCSSSelector, CSSStyleDefinitions>;
type ParsedCSSSelector = {
    tagName?: StyleSelector;
    className?: StyleSelector;
};
/**
 * Returns style definitions that match given element.
 *
 * @param element
 * @param expandedStyles
 * @returns
 */
export declare function getMatchingStyles(element: ViewElement, expandedStyles: ExpandedStyles): ExpandedStyles;
/**
 * Converts CSSStyleSheets into a simple object format:
 *
 * ```js
 * {
 * 	'p, p.foo': {
 * 		'font-family': 'Arial'
 * 	},
 * 	'td': {
 * 		'background': 'red'
 * 	},
 * 	// ...
 * }
 * ```
 * @param styles
 * @returns
 */
export declare function extractStyles(styles: Array<CSSStyleSheet>): ExtractedStyles;
/**
 * Expands styles object with complex selector into a map of unique parsed selectors and style definitions.
 *
 * ```ts
 * const styles = {
 * 	'p, p.foo': {
 * 		'font-family': 'Arial'
 * 	},
 * 	'td': {
 * 		'background': 'red'
 * 	},
 * 	// ...
 * }
 *
 * expandStyles( styles );
 *
 * {
 * 	{ tagName: 'p' }: {
 * 		'font-family': 'Arial'
 * 	},
 * 	{ tagName: 'p', className: 'foo }: {
 * 		'font-family': 'Arial'
 * 	},
 * 	{ tagName: 'td' }: {
 * 		'background': 'red'
 * 	},
 * 	// ...
 * }
 * ```
 * @param styles
 * @returns
 */
export declare function expandStyles(styles: ExtractedStyles): ExpandedStyles;
/**
 * Converts a native CSSStyleDeclaration into a simple object.
 *
 * ```ts
 * {
 * 	'font-family': 'Arial'
 * 	'background': 'red',
 * 	// ...
 * }
 * ```
 * @param declaration
 * @returns
 */
export declare function parseCSSStyleDeclaration(declaration: CSSStyleDeclaration): CSSStyleDefinitions;
/**
 * Parses CSS selector into an array of objects with tagName and className properties.
 *
 * ```ts
 * parseCSSSelector( 'p, p.foo' );
 * ```
 *
 * returns:
 *
 * ```ts
 * [
 * 	{ tagName: 'p' },
 * 	{ tagName: 'p', className: 'foo' }
 * ]
 * ```
 * @param selector
 * @returns
 */
export declare function parseCSSSelector(selector: string): Array<ParsedCSSSelector>;
/**
 * Flattens multiple style definitions considering their order to simulate a CSS cascade.
 *
 * ```ts
 * flattenStyleDefinitions( [
 * 	{ 'font-family': 'Arial', 'margin-top': '1px', 'font-size': '10px' },
 * 	{ 'font-family': 'monospace', 'margin-top': '3px' }
 * ] );
 * ```
 *
 * returns:
 *
 * ```ts
 * { 'font-family': 'monospace', 'margin-top': '3px', 'font-size': '10px' }
 * ```
 * @param definitions
 * @returns
 */
export declare function flattenStyleDefinitions(definitions: Array<CSSStyleDefinitions>): CSSStyleDefinitions;
export {};
