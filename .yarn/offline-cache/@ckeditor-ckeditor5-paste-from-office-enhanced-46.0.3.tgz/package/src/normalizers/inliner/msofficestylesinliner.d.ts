/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import { type PasteFromOfficeNormalizerData, PasteFromOfficeMSWordNormalizer } from '@ckeditor/ckeditor5-paste-from-office';
/**
 * A normalizer that inlines styles passed along the content from MS Office.
 *
 * Normalizers are registered by the {@link module:paste-from-office-enhanced/pastefromofficeenhanced~PasteFromOfficeEnhanced}
 * plugin and run on {@link module:clipboard/clipboardpipeline~ClipboardPipeline#event:inputTransformation inputTransformation event}.
 * They detect environment-specific quirks and transform it into a form compatible with other CKEditor features.
 *
 * This particular normalizer turns a pasted content such as:
 *
 * ```html
 * <style>
 * 	p { margin-top: 10px }
 * 	.foo { font-family: Arial }
 * <style>
 * <p class="foo">Foo</p>
 * ```
 *
 * into:
 *
 * ```html
 * <style>
 * 	p { margin-top: 10px }
 * 	.foo { font-family: Arial }
 * <style>
 * <p class="foo" style="margin-top: 10px; font-family: Arial">Foo</p>
 * ```
 */
export declare class MSOfficeStylesInliner extends PasteFromOfficeMSWordNormalizer {
    /**
     * @inheritDoc
     */
    execute(data: PasteFromOfficeNormalizerData): void;
    /**
     * @inheritDoc
     */
    isActive(htmlString: string): boolean;
}
