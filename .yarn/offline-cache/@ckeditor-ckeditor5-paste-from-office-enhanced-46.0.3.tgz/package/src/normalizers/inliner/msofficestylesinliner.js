/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x55f278=_0xe13f;(function(_0x108f42,_0x5392f7){const _0x449745=_0xe13f,_0x54ae8a=_0x108f42();while(!![]){try{const _0x299e11=-parseInt(_0x449745(0x79))/0x1*(-parseInt(_0x449745(0x87))/0x2)+parseInt(_0x449745(0x72))/0x3+parseInt(_0x449745(0x70))/0x4*(parseInt(_0x449745(0x74))/0x5)+parseInt(_0x449745(0x7c))/0x6*(parseInt(_0x449745(0x7d))/0x7)+-parseInt(_0x449745(0x83))/0x8*(-parseInt(_0x449745(0x6f))/0x9)+parseInt(_0x449745(0x73))/0xa+parseInt(_0x449745(0x85))/0xb*(-parseInt(_0x449745(0x77))/0xc);if(_0x299e11===_0x5392f7)break;else _0x54ae8a['push'](_0x54ae8a['shift']());}catch(_0x4e9d85){_0x54ae8a['push'](_0x54ae8a['shift']());}}}(_0x2109,0x46863));import{ViewUpcastWriter as _0x264401}from'ckeditor5/src/engine.js';import{PasteFromOfficeMSWordNormalizer as _0x513bfc}from'@ckeditor/ckeditor5-paste-from-office';import{isMSExcelContent as _0x40f253}from'../../utils.js';function _0xe13f(_0x347697,_0x49843c){const _0x2109e3=_0x2109();return _0xe13f=function(_0xe13f93,_0x3ba043){_0xe13f93=_0xe13f93-0x6f;let _0xffcee5=_0x2109e3[_0xe13f93];return _0xffcee5;},_0xe13f(_0x347697,_0x49843c);}import{extractStyles as _0x5a8421,expandStyles as _0x4e41b5,getMatchingStyles as _0xd845f7,flattenStyleDefinitions as _0x388325}from'./utils.js';export class MSOfficeStylesInliner extends _0x513bfc{[_0x55f278(0x80)](_0x4a1946){const _0x11c648=_0x55f278,{body:_0x5a78a1,styles:_0x55aada}=_0x4a1946[_0x11c648(0x7e)],_0x7f243=new _0x264401(_0x5a78a1[_0x11c648(0x71)]),_0x56abeb=_0x7f243[_0x11c648(0x81)](_0x5a78a1),_0x3ac1cb=_0x5a8421(_0x55aada),_0x9eb926=_0x4e41b5(_0x3ac1cb);for(const _0x806fa4 of _0x56abeb){if(_0x11c648(0x88)!==_0x806fa4[_0x11c648(0x7a)])continue;const _0x52b185=_0xd845f7(_0x806fa4[_0x11c648(0x82)],_0x9eb926);if(_0x52b185[_0x11c648(0x75)]){const _0x180eb2=_0x388325(Array[_0x11c648(0x86)](_0x52b185[_0x11c648(0x78)]()));for(const _0x161732 in _0x180eb2){const _0x275355=_0x806fa4[_0x11c648(0x82)];_0x275355[_0x11c648(0x7f)](_0x161732)||_0x7f243[_0x11c648(0x76)](_0x161732,_0x180eb2[_0x161732],_0x275355);}}}_0x4a1946[_0x11c648(0x7b)]=_0x5a78a1;}[_0x55f278(0x84)](_0x66b645){const _0x2fccd5=_0x55f278;return super[_0x2fccd5(0x84)](_0x66b645)||_0x40f253(_0x66b645);}}function _0x2109(){const _0x43e42f=['752CVJKEg','document','568737JUTFlG','5685390mwsqvm','15110qoClMS','size','setStyle','8071968JiIoDo','values','1ldGyqd','type','content','6xIZoxP','2097221QeeJUr','_parsedData','hasStyle','execute','createRangeIn','item','3612792gQSvcX','isActive','33wIJuzg','from','458806jxxONo','elementStart','9jMvHNo'];_0x2109=function(){return _0x43e42f;};return _0x2109();}