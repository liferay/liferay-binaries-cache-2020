/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import { type PasteFromOfficeNormalizerData, PasteFromOfficeMSWordNormalizer } from '@ckeditor/ckeditor5-paste-from-office';
/**
 * A normalizer that propagates inline styles from block element into `span` element with style properties
 * and/or creates an `HTML` structure based on early mentioned block element styles.
 *
 * Normalizers are registered by the {@link module:paste-from-office-enhanced/pastefromofficeenhanced~PasteFromOfficeEnhanced}
 * plugin and run on {@link module:clipboard/clipboardpipeline~ClipboardPipeline#event:inputTransformation inputTransformation event}.
 * They detect environment-specific quirks and transform it into a form compatible with other CKEditor features.
 *
 * This particular normalizer turns a pasted content such as:
 *
 * ```html
 * <p style="color:red;font-size:10px;font-weight:bold;">
 *  foo
 * </p>
 * ```
 *
 * into:
 *
 * ```html
 * <p>
 *  <span style="color:red;font-size:10px">
 *   <strong>
 *    foo
 *   </strong>
 *  </span>
 * </p>
 * ```
 */
export declare class MSOfficeInlineStylePropagator extends PasteFromOfficeMSWordNormalizer {
    /**
     * @inheritDoc
     */
    execute(data: PasteFromOfficeNormalizerData): void;
    /**
     * @inheritDoc
     */
    isActive(htmlString: string): boolean;
}
