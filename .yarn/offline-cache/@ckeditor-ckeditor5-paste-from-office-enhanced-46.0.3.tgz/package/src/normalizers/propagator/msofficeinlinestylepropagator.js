/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x3dcd15=_0x3955;(function(_0x2c98c4,_0x3ffae0){const _0x579b81=_0x3955,_0x34ad74=_0x2c98c4();while(!![]){try{const _0x287de0=-parseInt(_0x579b81(0x84))/0x1+-parseInt(_0x579b81(0x80))/0x2+-parseInt(_0x579b81(0x8f))/0x3+parseInt(_0x579b81(0x89))/0x4*(-parseInt(_0x579b81(0x86))/0x5)+-parseInt(_0x579b81(0x85))/0x6*(-parseInt(_0x579b81(0x8c))/0x7)+-parseInt(_0x579b81(0x92))/0x8*(-parseInt(_0x579b81(0x81))/0x9)+parseInt(_0x579b81(0x7e))/0xa;if(_0x287de0===_0x3ffae0)break;else _0x34ad74['push'](_0x34ad74['shift']());}catch(_0x5e5b5b){_0x34ad74['push'](_0x34ad74['shift']());}}}(_0x381d,0xd157c));function _0x3955(_0x2211f9,_0x429e72){const _0x381dd1=_0x381d();return _0x3955=function(_0x39550b,_0x14d60f){_0x39550b=_0x39550b-0x7d;let _0x5eb5fe=_0x381dd1[_0x39550b];return _0x5eb5fe;},_0x3955(_0x2211f9,_0x429e72);}import{ViewUpcastWriter as _0x26de1f,ViewDomConverter as _0x33db1b,ViewDocument as _0x4988b7}from'ckeditor5/src/engine.js';import{PasteFromOfficeMSWordNormalizer as _0x54c40e}from'@ckeditor/ckeditor5-paste-from-office';import{isMSExcelContent as _0x1252b5}from'../../utils.js';function _0x381d(){const _0x55e4e0=['2988876xUtZaw','font','content','128UMwBMY','isActive','stylesProcessor','31914800pMAGLS','getItems','1412674GvtTZg','14769mIgYFK','document','createRangeIn','735995RVtXdo','69378DKNTAO','937965oQPQPv','blockElements','execute','4HnLWsp','name','element','161bPgbTg','includes','_parsedData'];_0x381d=function(){return _0x55e4e0;};return _0x381d();}import{getStylePropertyNamesToPropagate as _0x386acf,propagateStyleProperties as _0x462f31}from'./utils.js';export class MSOfficeInlineStylePropagator extends _0x54c40e{[_0x3dcd15(0x88)](_0x5a0d86){const _0x3a55c5=_0x3dcd15,{body:_0x4b1e6c}=_0x5a0d86[_0x3a55c5(0x8e)],_0x46b419=new _0x26de1f(_0x4b1e6c[_0x3a55c5(0x82)]),_0x1f9129=_0x46b419[_0x3a55c5(0x83)](_0x4b1e6c),_0x3c6f24=new _0x4988b7(_0x46b419[_0x3a55c5(0x82)][_0x3a55c5(0x7d)]),_0x211214=[...new _0x33db1b(_0x3c6f24)[_0x3a55c5(0x87)],_0x3a55c5(0x90)],_0x5701dc=_0x1f9129[_0x3a55c5(0x7f)]();for(const _0x2e9138 of _0x5701dc)if(_0x2e9138['is'](_0x3a55c5(0x8b))&&_0x211214[_0x3a55c5(0x8d)](_0x2e9138[_0x3a55c5(0x8a)])){const _0x1d27d6=_0x386acf(_0x2e9138);_0x462f31(_0x2e9138,_0x46b419,_0x1d27d6);}_0x5a0d86[_0x3a55c5(0x91)]=_0x4b1e6c;}[_0x3dcd15(0x93)](_0x884822){const _0x287fb1=_0x3dcd15;return super[_0x287fb1(0x93)](_0x884822)||_0x1252b5(_0x884822);}}