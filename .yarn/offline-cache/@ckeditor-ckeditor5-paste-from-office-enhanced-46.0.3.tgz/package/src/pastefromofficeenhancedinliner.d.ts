/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module paste-from-office-enhanced/pastefromofficeenhancedinliner
 */
import { Plugin } from 'ckeditor5/src/core.js';
/**
 * The Paste from Office Enhanced inliner plugin that inlines styles passed along the content from MS Office.
 */
export declare class PasteFromOfficeEnhancedInliner extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "PasteFromOfficeEnhancedInliner";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    static get requires(): readonly ["PasteFromOffice"];
    /**
     * @inheritDoc
     */
    init(): void;
    /**
     * @inheritDoc
     */
    afterInit(): void;
}
