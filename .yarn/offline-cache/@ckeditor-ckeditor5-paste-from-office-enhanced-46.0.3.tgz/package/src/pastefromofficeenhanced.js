/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0xa50cf=_0x46d4;function _0x46d4(_0x55ab6e,_0x309ca7){var _0x1c3472=_0x1c34();return _0x46d4=function(_0x46d46f,_0x467ed4){_0x46d46f=_0x46d46f-0x10b;var _0x1fb3a0=_0x1c3472[_0x46d46f];return _0x1fb3a0;},_0x46d4(_0x55ab6e,_0x309ca7);}function _0x1c34(){var _0x24cfe8=['PasteFromOfficeEnhanced','requires','PasteFromOffice','isPremiumPlugin','39vEuKwQ','2320640dvVAYq','22540tYNAPk','15oXaXPo','4027192hScAXV','69610DTpNQL','2294484GwoHfZ','isOfficialPlugin','1113930PoXfUt','pluginName','9313830RABLCR'];_0x1c34=function(){return _0x24cfe8;};return _0x1c34();}(function(_0x5676c1,_0x3d2cf7){var _0x211ad5=_0x46d4,_0x2ae76a=_0x5676c1();while(!![]){try{var _0x25de7e=parseInt(_0x211ad5(0x117))/0x1+-parseInt(_0x211ad5(0x10b))/0x2*(parseInt(_0x211ad5(0x115))/0x3)+-parseInt(_0x211ad5(0x10c))/0x4+parseInt(_0x211ad5(0x118))/0x5*(-parseInt(_0x211ad5(0x10e))/0x6)+parseInt(_0x211ad5(0x116))/0x7+parseInt(_0x211ad5(0x119))/0x8+parseInt(_0x211ad5(0x110))/0x9;if(_0x25de7e===_0x3d2cf7)break;else _0x2ae76a['push'](_0x2ae76a['shift']());}catch(_0x5c9404){_0x2ae76a['push'](_0x2ae76a['shift']());}}}(_0x1c34,0x4b81e));import{Plugin as _0x4644be}from'ckeditor5/src/core.js';import{PasteFromOfficeEnhancedInliner as _0x3634f1}from'./pastefromofficeenhancedinliner.js';import{PasteFromOfficeEnhancedPropagator as _0x3299e8}from'./pastefromofficeenhancedpropagator.js';export class PasteFromOfficeEnhanced extends _0x4644be{static get[_0xa50cf(0x10f)](){var _0x5374cd=_0xa50cf;return _0x5374cd(0x111);}static get[_0xa50cf(0x10d)](){return!0x0;}static get[_0xa50cf(0x114)](){return!0x0;}static get[_0xa50cf(0x112)](){var _0x406fa8=_0xa50cf;return[_0x406fa8(0x113),_0x3634f1,_0x3299e8];}}