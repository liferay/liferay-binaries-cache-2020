Software License Agreement
==========================

**CKEditor&nbsp;5 Paste from Office enhanced feature** (https://ckeditor.com/ckeditor-5/)<br>
Copyright (c) 2003–2025, [CKSource Holding sp. z o.o.](https://cksource.com) All rights reserved.

CKEditor&nbsp;5 Paste from Office enhanced feature is licensed under a commercial license and is protected by copyright law.
For more information, see: [https://ckeditor.com/pricing](https://ckeditor.com/pricing).

Sources of Intellectual Property Included in CKEditor&nbsp;5 Paste from Office enhanced feature
-----------------------------------------------------------------------------------------------

Where not otherwise indicated, all CKEditor&nbsp;5 Paste from Office enhanced feature content is authored by CKSource engineers and consists of CKSource-owned intellectual property.

Trademarks
----------

**CKEditor** is a trademark of [CKSource Holding sp. z o.o.](https://cksource.com) All other brand and product names are trademarks, registered trademarks, or service marks of their respective holders.
