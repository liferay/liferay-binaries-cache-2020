/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module import-word/importwordediting
 * @publicApi
 */
import { Plugin, type Editor } from 'ckeditor5/src/core.js';
import { Notification } from 'ckeditor5/src/ui.js';
import { ClipboardPipeline } from 'ckeditor5/src/clipboard.js';
import type { InitializedToken } from '@ckeditor/ckeditor5-cloud-services';
/**
 * The editing part of the import from Word feature.
 *
 * It registers the {@link module:import-word/importwordcommand~ImportWordCommand `'importWord'` command}.
 */
export declare class ImportWordEditing extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "ImportWordEditing";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    static get requires(): readonly [typeof Notification, typeof ClipboardPipeline, "CloudServices"];
    /**
     * @inheritDoc
     */
    constructor(editor: Editor);
    /**
     * @inheritDoc
     */
    init(): Promise<void>;
    /**
     * Returns a token used by the import from Word plugin for communication with the Cloud Services.
     */
    getToken(): InitializedToken | null;
}
