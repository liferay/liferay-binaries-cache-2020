/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module import-word/importword
 * @publicApi
 */
import { Plugin } from 'ckeditor5/src/core.js';
import type { TokenUrl } from '@ckeditor/ckeditor5-cloud-services';
import { ImportWordUI } from './importwordui.js';
import { ImportWordEditing } from './importwordediting.js';
/**
 * The import from Word feature.
 *
 * It allows importing content from a Word file directly into CKEditor 5.
 *
 * This is a "glue" plugin which enables:
 *
 * * {@link module:import-word/importwordediting~ImportWordEditing},
 * * {@link module:import-word/importwordui~ImportWordUI},
 *
 * For a detailed overview, check the {@glink features/converters/import-word/import-word import from Word} feature documentation.
 */
export declare class ImportWord extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "ImportWord";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    static get requires(): readonly [typeof ImportWordEditing, typeof ImportWordUI];
}
/**
 * The configuration of the {@link module:import-word/importword~ImportWord import from Word feature}.
 *
 * The configuration for the import from Word feature requires providing the
 * {@link module:import-word/importword~ImportWordConfig#tokenUrl `config.importWord.tokenUrl`}:
 *
 * ```ts
 * ClassicEditor
 * 	.create( editorElement, {
 * 		importWord: {
 * 			tokenUrl: 'https://example.com/cs-token-endpoint'
 * 		}
 * 	} )
 * 	.then( ... )
 * 	.catch( ... );
 * ```
 *
 * See {@link module:core/editor/editorconfig~EditorConfig all editor options}.
 */
export interface ImportWordConfig {
    /**
     * A URL to the Docx converter.
     *
     * ```ts
     * const importWordConfig = {
     * 	converterUrl: 'https://myconverter.com/v1/'
     * }
     * ```
     *
     * **Note:** The plugin uses the default Word to HTML converter delivered by CKEditor Cloud Services.
     * You can provide a URL to an on-premises converter instead.
     *
     * @default 'https://docx-converter.cke-cs.com/v2/convert/docx-html'
     */
    converterUrl?: string;
    /**
     * A token URL or a token request function. This field is optional and should be used only when a different `tokenUrl`
     * is required for the Import from Word feature.
     *
     * **Note:** The token can be disabled with the `false` value provided.
     *
     * See: {@link module:cloud-services/cloudservicesconfig~CloudServicesConfig#tokenUrl}
     */
    tokenUrl?: TokenUrl;
    formatting: ImportWordFormattingOptions;
}
export interface ImportWordFormattingOptions {
    /**
     * Controls whether the additional formatting dedicated to minimizing differences between default Word styles
     * and default HTML formatting should be included in the generated document.
     *
     * If `inline`, the converter service preserves the formatting to be consistent with Word ones.
     * For example, in Word headings are not bold by default, whereas in HTML, they are. Enabling this option
     * appends font-weight: normal to all headings.
     *
     * @default false
     */
    resets?: 'none' | 'inline';
    /**
     * Controls whether formatting set by default (like the default font size or default font family)
     * should be included in the generated document.
     *
     * If `inline`, the converter service preserves the default formatting of the imported Word document.
     *
     * @default 'none'
     */
    defaults?: 'none' | 'inline';
    /**
     * Controls whether Word styles should be included in the generated document.
     *
     * If `inline`, the converter service preserves the default styles of the imported Word document.
     *
     * @default 'inline'
     */
    styles?: 'none' | 'inline';
    /**
     * Defines which formatting styles should be kept for the imported comments text.
     *
     * Possible values are:
     *
     * * `'basic'` - basic styles are kept (bold, italic, underline, strikethrough and links),
     * * `'none'` - comment text is imported without any styling,
     * * `'full'` - all styles are kept (not recommended).
     *
     * **Note:** Please remember that importing comments requires installing the {@link module:comments/comments~Comments} feature.
     *
     * @default 'basic'
     */
    comments?: 'basic' | 'none' | 'full';
}
