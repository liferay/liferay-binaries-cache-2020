/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module import-word/importwordcommand
 * @publicApi
 */
import { Command, type Editor } from 'ckeditor5/src/core.js';
/**
 * The import from Word command.
 *
 * It sends the Word file to the converter endpoint and inserts its content into the editor.
 */
export declare class ImportWordCommand extends Command {
    /**
     * A command state that indicates if the command is currently executing.
     *
     * @observable
     */
    isBusy: boolean;
    /**
     * @inheritDoc
     */
    constructor(editor: Editor);
    /**
     * @inheritDoc
     */
    refresh(): void;
    /**
     * Executes the command. Sends the provided file instance to the converter service endpoint and inserts the result into the model.
     *
     * @fires execute
     * @param file The Word file instance to be uploaded for conversion.
     * @param [serviceConfig] Additional options to pass to the converter service.
     */
    execute(file: File, serviceConfig?: Record<string, unknown>): Promise<unknown>;
}
/**
 * Fired when the converter service returned the HTML content that will be inserted into the editor.
 *
 * @eventName ~ImportWordCommand#dataInsert
 */
export type ImportWordDataInsertEvent = {
    name: 'dataInsert';
    args: [data: ImportWordDataInsertEventData];
};
export interface ImportWordDataInsertEventData {
    /**
     * The HTML content to insertion.
     */
    html: string;
}
