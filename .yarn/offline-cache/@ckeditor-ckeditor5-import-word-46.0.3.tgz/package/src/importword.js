/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0xd8d3f9=_0x16e2;(function(_0x1409ff,_0x9c3d73){var _0x32f3fa=_0x16e2,_0x1c66f3=_0x1409ff();while(!![]){try{var _0x41eea4=parseInt(_0x32f3fa(0x189))/0x1+-parseInt(_0x32f3fa(0x187))/0x2+-parseInt(_0x32f3fa(0x188))/0x3+-parseInt(_0x32f3fa(0x183))/0x4*(-parseInt(_0x32f3fa(0x17c))/0x5)+-parseInt(_0x32f3fa(0x186))/0x6*(-parseInt(_0x32f3fa(0x17e))/0x7)+-parseInt(_0x32f3fa(0x184))/0x8+parseInt(_0x32f3fa(0x180))/0x9;if(_0x41eea4===_0x9c3d73)break;else _0x1c66f3['push'](_0x1c66f3['shift']());}catch(_0x286bd4){_0x1c66f3['push'](_0x1c66f3['shift']());}}}(_0x4a1d,0x714a5));import{Plugin as _0x2ff456}from'ckeditor5/src/core.js';import{ImportWordUI as _0x175da2}from'./importwordui.js';function _0x4a1d(){var _0x542063=['isOfficialPlugin','2739174DjVyXr','1156796mjAREk','2086695iCgdaG','657780YYWrpQ','295315ZDftyb','isPremiumPlugin','14onRxVs','requires','3290589bpVvtR','pluginName','ImportWord','8fhPveM','2532680awrjUv'];_0x4a1d=function(){return _0x542063;};return _0x4a1d();}import{ImportWordEditing as _0x440b50}from'./importwordediting.js';function _0x16e2(_0x5a82d8,_0x9fd756){var _0x4a1d75=_0x4a1d();return _0x16e2=function(_0x16e24e,_0x2ff9c9){_0x16e24e=_0x16e24e-0x17c;var _0x58e38f=_0x4a1d75[_0x16e24e];return _0x58e38f;},_0x16e2(_0x5a82d8,_0x9fd756);}export class ImportWord extends _0x2ff456{static get[_0xd8d3f9(0x181)](){var _0x55a4a6=_0xd8d3f9;return _0x55a4a6(0x182);}static get[_0xd8d3f9(0x185)](){return!0x0;}static get[_0xd8d3f9(0x17d)](){return!0x0;}static get[_0xd8d3f9(0x17f)](){return[_0x440b50,_0x175da2];}}