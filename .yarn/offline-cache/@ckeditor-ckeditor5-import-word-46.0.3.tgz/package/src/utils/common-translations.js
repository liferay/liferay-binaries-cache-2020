/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
export function getTranslation(_0x21b6f7,_0x214e7e){const t=_0x21b6f7['t'];switch(_0x214e7e){case'Import\x20from\x20Word':return t('Import\x20from\x20Word');case'An\x20error\x20occurred\x20while\x20importing\x20the\x20Word\x20file.':return t('An\x20error\x20occurred\x20while\x20importing\x20the\x20Word\x20file.');case'Importing\x20Word\x20document':return t('Importing\x20Word\x20document');default:return _0x214e7e;}}