/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module import-word
 */
export { ImportWord, type ImportWordConfig, type ImportWordFormattingOptions } from './importword.js';
export { ImportWordEditing } from './importwordediting.js';
export { ImportWordUI } from './importwordui.js';
export { ImportWordCommand, type ImportWordDataInsertEvent, type ImportWordDataInsertEventData } from './importwordcommand.js';
import './augmentation.js';
