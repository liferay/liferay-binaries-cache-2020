/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x49e7ab,_0x72acce){var _0x3fab90=_0x3de3,_0x5e6bf2=_0x49e7ab();while(!![]){try{var _0x10475a=parseInt(_0x3fab90(0x1f3))/0x1+parseInt(_0x3fab90(0x1ef))/0x2*(parseInt(_0x3fab90(0x1f4))/0x3)+-parseInt(_0x3fab90(0x1f0))/0x4+parseInt(_0x3fab90(0x1ee))/0x5*(parseInt(_0x3fab90(0x1f6))/0x6)+parseInt(_0x3fab90(0x1f7))/0x7*(parseInt(_0x3fab90(0x1f1))/0x8)+parseInt(_0x3fab90(0x1f2))/0x9*(-parseInt(_0x3fab90(0x1ed))/0xa)+parseInt(_0x3fab90(0x1f5))/0xb*(-parseInt(_0x3fab90(0x1f8))/0xc);if(_0x10475a===_0x72acce)break;else _0x5e6bf2['push'](_0x5e6bf2['shift']());}catch(_0x1d64ee){_0x5e6bf2['push'](_0x5e6bf2['shift']());}}}(_0x2dc6,0x55329));export{ImportWord}from'./importword.js';export{ImportWordEditing}from'./importwordediting.js';export{ImportWordUI}from'./importwordui.js';export{ImportWordCommand}from'./importwordcommand.js';function _0x3de3(_0xb08c6f,_0x582edf){var _0x2dc6d7=_0x2dc6();return _0x3de3=function(_0x3de39f,_0x28ec5b){_0x3de39f=_0x3de39f-0x1ed;var _0x4bbb97=_0x2dc6d7[_0x3de39f];return _0x4bbb97;},_0x3de3(_0xb08c6f,_0x582edf);}import'./augmentation.js';function _0x2dc6(){var _0x9efcc=['128830ftLDKK','395045lnJbOQ','2mkeBpK','1530328wcwUjx','390328APUYag','369RZkkpN','518166mxMAXB','1871406OfFniQ','22RTErCE','18doruOV','7NNaZWm','1008192prMIeU'];_0x2dc6=function(){return _0x9efcc;};return _0x2dc6();}