/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import type { ImportWordConfig, ImportWord, ImportWordEditing, ImportWordUI, ImportWordCommand } from './index.js';
declare module '@ckeditor/ckeditor5-core' {
    interface EditorConfig {
        /**
         * The configuration of the {@link module:import-word/importword~ImportWord import from Word feature}.
         *
         * Read more in {@link module:import-word/importword~ImportWordConfig}.
         */
        importWord?: ImportWordConfig;
    }
    interface PluginsMap {
        [ImportWord.pluginName]: ImportWord;
        [ImportWordEditing.pluginName]: ImportWordEditing;
        [ImportWordUI.pluginName]: ImportWordUI;
    }
    interface CommandsMap {
        importWord: ImportWordCommand;
    }
}
