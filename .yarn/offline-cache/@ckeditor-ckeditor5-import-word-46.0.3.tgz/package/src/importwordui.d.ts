/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module import-word/importwordui
 * @publicApi
 */
import { Plugin } from 'ckeditor5/src/core.js';
/**
 * The ImportWordUI plugin. It introduces the `'importWord'` toolbar button.
 */
export declare class ImportWordUI extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "ImportWordUI";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    init(): void;
}
