/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x1aaf0d=_0x34db;(function(_0x408974,_0x7bd3ce){const _0x396321=_0x34db,_0xd36dc5=_0x408974();while(!![]){try{const _0x5a1118=-parseInt(_0x396321(0x1d7))/0x1*(parseInt(_0x396321(0x1e6))/0x2)+parseInt(_0x396321(0x1e1))/0x3*(parseInt(_0x396321(0x1dd))/0x4)+parseInt(_0x396321(0x1d0))/0x5*(parseInt(_0x396321(0x1cf))/0x6)+-parseInt(_0x396321(0x1df))/0x7+parseInt(_0x396321(0x1dc))/0x8+-parseInt(_0x396321(0x1ce))/0x9+parseInt(_0x396321(0x1e3))/0xa*(parseInt(_0x396321(0x1e5))/0xb);if(_0x5a1118===_0x7bd3ce)break;else _0xd36dc5['push'](_0xd36dc5['shift']());}catch(_0x1e86f8){_0xd36dc5['push'](_0xd36dc5['shift']());}}}(_0x5b2b,0xd511e));import{Plugin as _0x218c13}from'ckeditor5/src/core.js';function _0x5b2b(){const _0x2545ee=['requires','1927046OwvBGV','99734zvzkxP','editor','get','config','inline','_token','token','ImportWordEditing','isOfficialPlugin','cloudServices','none','8121528koPNTq','6zEBVfU','682810UzvyNF','add','registerTokenUrl','pluginName','tokenUrl','commands','define','5XxHWlx','plugins','getToken','isPremiumPlugin','https://docx-converter.cke-cs.com/v2/convert/docx-html','941616eDycCc','20jguLJU','importWord','7530775bNjRre','CloudServices','446274JSmexJ','init','120JUDeJN'];_0x5b2b=function(){return _0x2545ee;};return _0x5b2b();}import{Notification as _0x2a2a49}from'ckeditor5/src/ui.js';import{ClipboardPipeline as _0x185f7d}from'ckeditor5/src/clipboard.js';import{ImportWordCommand as _0xf3ecff}from'./importwordcommand.js';function _0x34db(_0xe6aa18,_0x11a5e6){const _0x5b2bfc=_0x5b2b();return _0x34db=function(_0x34db43,_0x1851a2){_0x34db43=_0x34db43-0x1c5;let _0x4c554e=_0x5b2bfc[_0x34db43];return _0x4c554e;},_0x34db(_0xe6aa18,_0x11a5e6);}export class ImportWordEditing extends _0x218c13{[_0x1aaf0d(0x1c8)];static get[_0x1aaf0d(0x1d3)](){const _0x42e08b=_0x1aaf0d;return _0x42e08b(0x1ca);}static get[_0x1aaf0d(0x1cb)](){return!0x0;}static get[_0x1aaf0d(0x1da)](){return!0x0;}static get[_0x1aaf0d(0x1e4)](){const _0x15a639=_0x1aaf0d;return[_0x2a2a49,_0x185f7d,_0x15a639(0x1e0)];}constructor(_0x3b7208){const _0xe0aabb=_0x1aaf0d;super(_0x3b7208),this[_0xe0aabb(0x1c8)]=null;}async[_0x1aaf0d(0x1e2)](){const _0x2459bd=_0x1aaf0d,_0x11c0f6=this[_0x2459bd(0x1e7)];_0x11c0f6[_0x2459bd(0x1c6)][_0x2459bd(0x1d6)](_0x2459bd(0x1de),{'converterUrl':_0x2459bd(0x1db),'tokenUrl':(_0x11c0f6[_0x2459bd(0x1c6)][_0x2459bd(0x1c5)](_0x2459bd(0x1cc))||{})[_0x2459bd(0x1d4)],'formatting':{'resets':_0x2459bd(0x1cd),'defaults':_0x2459bd(0x1cd),'styles':_0x2459bd(0x1c7)}}),_0x11c0f6[_0x2459bd(0x1d5)][_0x2459bd(0x1d1)](_0x2459bd(0x1de),new _0xf3ecff(_0x11c0f6));const {tokenUrl:_0x5f1cea}=_0x11c0f6[_0x2459bd(0x1c6)][_0x2459bd(0x1c5)](_0x2459bd(0x1de));if(_0x5f1cea){const {tokenUrl:_0x9cca17}=_0x11c0f6[_0x2459bd(0x1c6)][_0x2459bd(0x1c5)](_0x2459bd(0x1cc))||{};this[_0x2459bd(0x1c8)]=_0x5f1cea===_0x9cca17?_0x11c0f6[_0x2459bd(0x1d8)][_0x2459bd(0x1c5)](_0x2459bd(0x1e0))[_0x2459bd(0x1c9)]:await _0x11c0f6[_0x2459bd(0x1d8)][_0x2459bd(0x1c5)](_0x2459bd(0x1e0))[_0x2459bd(0x1d2)](_0x5f1cea);}}[_0x1aaf0d(0x1d9)](){const _0x584099=_0x1aaf0d;return this[_0x584099(0x1c8)];}}