/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x4f7cc1,_0xc9fec4){const _0x502a2c=_0x5652,_0x133ce4=_0x4f7cc1();while(!![]){try{const _0x35a43e=-parseInt(_0x502a2c(0xc7))/0x1*(parseInt(_0x502a2c(0xd8))/0x2)+parseInt(_0x502a2c(0xdc))/0x3+-parseInt(_0x502a2c(0xd0))/0x4*(-parseInt(_0x502a2c(0xce))/0x5)+-parseInt(_0x502a2c(0xd4))/0x6*(-parseInt(_0x502a2c(0xdd))/0x7)+-parseInt(_0x502a2c(0xc3))/0x8*(-parseInt(_0x502a2c(0xda))/0x9)+-parseInt(_0x502a2c(0xc6))/0xa*(parseInt(_0x502a2c(0xd5))/0xb)+-parseInt(_0x502a2c(0xd3))/0xc;if(_0x35a43e===_0xc9fec4)break;else _0x133ce4['push'](_0x133ce4['shift']());}catch(_0x4613cc){_0x133ce4['push'](_0x133ce4['shift']());}}}(_0x4ce5,0xb469c));function _0x5652(_0x383f28,_0x39f3a4){const _0x4ce53f=_0x4ce5();return _0x5652=function(_0x565297,_0x67324){_0x565297=_0x565297-0xc3;let _0x13b8dd=_0x4ce53f[_0x565297];return _0x13b8dd;},_0x5652(_0x383f28,_0x39f3a4);}import{View as _0x106e77}from'ckeditor5/src/ui.js';import{getTranslation as _0x3e32a1}from'../../utils/common-translations.js';export class DocumentOutlineItemView extends _0x106e77{constructor(_0x5cc819,_0x176cb9=!0x1){const _0xe3607d=_0x5652;super(_0x5cc819);const _0x806b8b=this[_0xe3607d(0xd7)],_0x5a50c9=_0x176cb9?'['+_0x3e32a1(_0x5cc819,_0xe3607d(0xd1))+']':'';this[_0xe3607d(0xcb)](_0xe3607d(0xd2),''),this[_0xe3607d(0xcb)](_0xe3607d(0xd9),0x1),this[_0xe3607d(0xcb)](_0xe3607d(0xd6),!0x1),this[_0xe3607d(0xcd)](_0xe3607d(0xc5))['to'](this,_0xe3607d(0xd2),_0x5e1a35=>!_0x5e1a35),this[_0xe3607d(0xc4)]({'tag':_0xe3607d(0xcf),'attributes':{'class':['ck',_0xe3607d(0xde),_0xe3607d(0xc9),_0x806b8b['to'](_0xe3607d(0xd9),_0x55ea5e=>_0xe3607d(0xdb)+_0x55ea5e),_0x806b8b['if'](_0xe3607d(0xd6),_0xe3607d(0xc8)),_0x806b8b['if'](_0xe3607d(0xc5),_0xe3607d(0xca))],'title':_0x806b8b['to'](_0xe3607d(0xd2))},'children':[{'text':_0x806b8b['to'](_0xe3607d(0xd2),_0x413e01=>_0x413e01||_0x5a50c9)}],'on':{'click':_0x806b8b['to'](_0xe3607d(0xcc))}});}}function _0x4ce5(){const _0x1c33ce=['94377QmiLBe','ck-document-outline__item_active','ck-document-outline__item','ck-document-outline__item_empty','set','click','bind','125975GSUfcq','div','164NJaYJX','Empty\x20heading','text','976392PyIARp','443844gKvYMF','6864539jtACKW','isActive','bindTemplate','22Haawsj','level','205515lrxwfg','ck-document-outline__item_level-','3101997neUwCu','35uItumt','ck-reset','16ZtyKrD','setTemplate','isEmpty','10xSmSAA'];_0x4ce5=function(){return _0x1c33ce;};return _0x4ce5();}