/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x567167,_0xbddbc4){const _0x40202b=_0x5b89,_0x216970=_0x567167();while(!![]){try{const _0xba7b4c=-parseInt(_0x40202b(0x131))/0x1+-parseInt(_0x40202b(0x133))/0x2+-parseInt(_0x40202b(0x130))/0x3*(-parseInt(_0x40202b(0x13a))/0x4)+parseInt(_0x40202b(0x134))/0x5+-parseInt(_0x40202b(0x136))/0x6+parseInt(_0x40202b(0x132))/0x7*(-parseInt(_0x40202b(0x120))/0x8)+parseInt(_0x40202b(0x138))/0x9*(parseInt(_0x40202b(0x128))/0xa);if(_0xba7b4c===_0xbddbc4)break;else _0x216970['push'](_0x216970['shift']());}catch(_0x4d23ed){_0x216970['push'](_0x216970['shift']());}}}(_0x4a46,0x65148));import{ModelText as _0x3b7788}from'ckeditor5/src/engine.js';function _0x4a46(){const _0x59965a=['htmlH2','21IOkYYe','680718aCqhVV','28455qwMfGP','1441304FqIche','1406700XDfarp','heading.options','4486440CiwsQX','plugins','23863203nBgKAB','data','199904dcqkUQ','get','1416WvVXPc','htmlH4','push','config','paragraph','reduce','htmlH1','GeneralHtmlSupport','10dPcKtc','getChildren','htmlH5','htmlH6','htmlH3','model','has'];_0x4a46=function(){return _0x59965a;};return _0x4a46();}export function getElementText(_0x25bcf6){const _0x2029f5=_0x5b89;let _0xdfa47e='';for(const _0x537913 of _0x25bcf6[_0x2029f5(0x129)]())_0x537913 instanceof _0x3b7788&&(_0xdfa47e+=_0x537913[_0x2029f5(0x139)]);return _0xdfa47e;}function _0x5b89(_0xe25795,_0x17b123){const _0x4a4672=_0x4a46();return _0x5b89=function(_0x5b89c2,_0x455163){_0x5b89c2=_0x5b89c2-0x120;let _0x15da59=_0x4a4672[_0x5b89c2];return _0x15da59;},_0x5b89(_0xe25795,_0x17b123);}export function getDefaultFeatureHeadingNames(_0x3b9978){const _0xcbab7d=_0x5b89,_0x284760=_0x3b9978[_0xcbab7d(0x123)][_0xcbab7d(0x13b)](_0xcbab7d(0x135));return _0x284760?_0x284760[_0xcbab7d(0x125)]((_0x9b9b97,_0xe0d724)=>(_0xcbab7d(0x124)!==_0xe0d724[_0xcbab7d(0x12d)]&&_0x9b9b97[_0xcbab7d(0x122)](_0xe0d724[_0xcbab7d(0x12d)]),_0x9b9b97),[]):_0x3b9978[_0xcbab7d(0x137)][_0xcbab7d(0x12e)](_0xcbab7d(0x127))?[_0xcbab7d(0x126),_0xcbab7d(0x12f),_0xcbab7d(0x12c),_0xcbab7d(0x121),_0xcbab7d(0x12a),_0xcbab7d(0x12b)]:[];}