/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x5783c9=_0x947c;(function(_0x397f83,_0x34ff2b){var _0x45888d=_0x947c,_0x49d9e8=_0x397f83();while(!![]){try{var _0x164792=parseInt(_0x45888d(0xb3))/0x1*(-parseInt(_0x45888d(0xa9))/0x2)+parseInt(_0x45888d(0xae))/0x3*(parseInt(_0x45888d(0xa3))/0x4)+-parseInt(_0x45888d(0xab))/0x5*(-parseInt(_0x45888d(0xb2))/0x6)+parseInt(_0x45888d(0xb0))/0x7*(parseInt(_0x45888d(0xaa))/0x8)+parseInt(_0x45888d(0xa2))/0x9*(parseInt(_0x45888d(0xa6))/0xa)+-parseInt(_0x45888d(0xa4))/0xb*(parseInt(_0x45888d(0xaf))/0xc)+-parseInt(_0x45888d(0xa8))/0xd;if(_0x164792===_0x34ff2b)break;else _0x49d9e8['push'](_0x49d9e8['shift']());}catch(_0xd9cd7e){_0x49d9e8['push'](_0x49d9e8['shift']());}}}(_0x3c29,0xf3cfb));function _0x3c29(){var _0x1fc56f=['isPremiumPlugin','2230fFyXID','TableOfContents','10026770BARoqC','842rjnrQv','2036184YVGFjI','20OmoOwp','isOfficialPlugin','pluginName','224313yiCIGC','5731404hbyHUc','21wpsNnq','requires','2011980QbohLX','2379KgoHfh','26226vyvfOn','52yHisLL','22ztwZME'];_0x3c29=function(){return _0x1fc56f;};return _0x3c29();}import{Plugin as _0x516f59}from'ckeditor5/src/core.js';function _0x947c(_0x29c92a,_0x2efad6){var _0x3c2935=_0x3c29();return _0x947c=function(_0x947cea,_0x46af9d){_0x947cea=_0x947cea-0xa2;var _0x52024c=_0x3c2935[_0x947cea];return _0x52024c;},_0x947c(_0x29c92a,_0x2efad6);}import{TableOfContentsEditing as _0x34cea5}from'./tableofcontents/tableofcontentsediting.js';import{TableOfContentsUI as _0x4e942f}from'./tableofcontents/tableofcontentsui.js';export class TableOfContents extends _0x516f59{static get[_0x5783c9(0xb1)](){return[_0x34cea5,_0x4e942f];}static get[_0x5783c9(0xad)](){var _0x5e8134=_0x5783c9;return _0x5e8134(0xa7);}static get[_0x5783c9(0xac)](){return!0x0;}static get[_0x5783c9(0xa5)](){return!0x0;}}