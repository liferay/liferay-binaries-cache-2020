/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x2ce4d2,_0x37e21f){var _0x5f18eb=_0x20b0,_0x84f34e=_0x2ce4d2();while(!![]){try{var _0xf588d5=parseInt(_0x5f18eb(0x1bd))/0x1*(-parseInt(_0x5f18eb(0x1c4))/0x2)+-parseInt(_0x5f18eb(0x1bb))/0x3*(-parseInt(_0x5f18eb(0x1c3))/0x4)+-parseInt(_0x5f18eb(0x1c5))/0x5*(-parseInt(_0x5f18eb(0x1c0))/0x6)+-parseInt(_0x5f18eb(0x1c1))/0x7*(-parseInt(_0x5f18eb(0x1be))/0x8)+parseInt(_0x5f18eb(0x1c2))/0x9+-parseInt(_0x5f18eb(0x1bf))/0xa+parseInt(_0x5f18eb(0x1bc))/0xb;if(_0xf588d5===_0x37e21f)break;else _0x84f34e['push'](_0x84f34e['shift']());}catch(_0x8dfddb){_0x84f34e['push'](_0x84f34e['shift']());}}}(_0x51ae,0x592f9));function _0x20b0(_0xf137ff,_0x864c7a){var _0x51ae90=_0x51ae();return _0x20b0=function(_0x20b0eb,_0x3faabc){_0x20b0eb=_0x20b0eb-0x1bb;var _0x5091ac=_0x51ae90[_0x20b0eb];return _0x5091ac;},_0x20b0(_0xf137ff,_0x864c7a);}export{DocumentOutline}from'./documentoutline.js';function _0x51ae(){var _0x21469f=['4816197bOjlJc','2372HIAMWg','27164mJvhvV','370jAngnX','375LlNhqS','2683384ZlAWNs','11Baxxda','91576umZAGl','4969340gbHjxK','10062CHQyAZ','21MMKCjU'];_0x51ae=function(){return _0x21469f;};return _0x51ae();}export{DocumentOutlineUI}from'./documentoutline/documentoutlineui.js';export{DocumentOutlineUtils}from'./documentoutline/documentoutlineutils.js';export{TableOfContents}from'./tableofcontents.js';export{TableOfContentsCommand}from'./tableofcontents/tableofcontentscommand.js';export{TableOfContentsEditing}from'./tableofcontents/tableofcontentsediting.js';export{TableOfContentsUI}from'./tableofcontents/tableofcontentsui.js';export{HeadingId}from'./tableofcontents/headingid.js';import'./augmentation.js';