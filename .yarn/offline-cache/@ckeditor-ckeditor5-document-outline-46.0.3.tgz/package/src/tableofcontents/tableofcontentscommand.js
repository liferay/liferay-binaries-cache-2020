/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x5474(){const _0x1f6e22=['selection','refresh','document','isEnabled','findAllowedParent','change','createElement','tableOfContents','editor','12262662PhNgsV','execute','insertObject','1173312uNjULn','188xjQIol','2WgZjXk','1563208stfOGy','2786000wrztmf','68445fHneVp','296264sZkOzA','getFirstPosition','schema','1070622bISVvp','model'];_0x5474=function(){return _0x1f6e22;};return _0x5474();}const _0x2a0283=_0x316c;(function(_0x86df4,_0x3f89e7){const _0x9cba8a=_0x316c,_0x24dc28=_0x86df4();while(!![]){try{const _0x42cc2a=-parseInt(_0x9cba8a(0xab))/0x1*(-parseInt(_0x9cba8a(0xa7))/0x2)+parseInt(_0x9cba8a(0xa5))/0x3+parseInt(_0x9cba8a(0xa6))/0x4*(parseInt(_0x9cba8a(0xaa))/0x5)+parseInt(_0x9cba8a(0xae))/0x6+parseInt(_0x9cba8a(0xa9))/0x7+-parseInt(_0x9cba8a(0xa8))/0x8+-parseInt(_0x9cba8a(0xa2))/0x9;if(_0x42cc2a===_0x3f89e7)break;else _0x24dc28['push'](_0x24dc28['shift']());}catch(_0x37642c){_0x24dc28['push'](_0x24dc28['shift']());}}}(_0x5474,0x55455));function _0x316c(_0x25012b,_0x1152f0){const _0x5474aa=_0x5474();return _0x316c=function(_0x316ca5,_0x4a8d96){_0x316ca5=_0x316ca5-0x9d;let _0x1d7281=_0x5474aa[_0x316ca5];return _0x1d7281;},_0x316c(_0x25012b,_0x1152f0);}import{Command as _0x1b4d7f}from'ckeditor5/src/core.js';export class TableOfContentsCommand extends _0x1b4d7f{[_0x2a0283(0xa3)](){const _0x577ae4=_0x2a0283;this[_0x577ae4(0xa1)][_0x577ae4(0xaf)][_0x577ae4(0x9e)](_0x9943cb=>{const _0x3a53ee=_0x577ae4;this[_0x3a53ee(0xa1)][_0x3a53ee(0xaf)][_0x3a53ee(0xa4)](_0x9943cb[_0x3a53ee(0x9f)](_0x3a53ee(0xa0)));});}[_0x2a0283(0xb1)](){const _0x4d3099=_0x2a0283,_0x435759=this[_0x4d3099(0xa1)][_0x4d3099(0xaf)],_0x3ed101=_0x435759[_0x4d3099(0xb2)][_0x4d3099(0xb0)][_0x4d3099(0xac)]();this[_0x4d3099(0xb3)]=null!==(_0x3ed101&&_0x435759[_0x4d3099(0xad)][_0x4d3099(0x9d)](_0x3ed101,_0x4d3099(0xa0)));}}