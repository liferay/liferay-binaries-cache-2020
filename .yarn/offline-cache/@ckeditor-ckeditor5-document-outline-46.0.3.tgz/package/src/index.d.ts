/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module document-outline
 */
export { DocumentOutline, type DocumentOutlineConfig } from './documentoutline.js';
export { DocumentOutlineUI } from './documentoutline/documentoutlineui.js';
export { DocumentOutlineUtils } from './documentoutline/documentoutlineutils.js';
export { TableOfContents } from './tableofcontents.js';
export { TableOfContentsCommand } from './tableofcontents/tableofcontentscommand.js';
export { TableOfContentsEditing } from './tableofcontents/tableofcontentsediting.js';
export { TableOfContentsUI } from './tableofcontents/tableofcontentsui.js';
export { HeadingId } from './tableofcontents/headingid.js';
import './augmentation.js';
