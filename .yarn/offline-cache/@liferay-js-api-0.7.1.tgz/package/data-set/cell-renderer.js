"use strict";
/**
 * SPDX-FileCopyrightText: © 2020 Liferay, Inc. <https://liferay.com>
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */
Object.defineProperty(exports, "__esModule", { value: true });
