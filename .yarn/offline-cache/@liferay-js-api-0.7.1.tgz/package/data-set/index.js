"use strict";
/**
 * SPDX-FileCopyrightText: © 2020 Liferay, Inc. <https://liferay.com>
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.FDSConnection = void 0;
var connection_1 = require("./connection");
Object.defineProperty(exports, "FDSConnection", { enumerable: true, get: function () { return connection_1.FDSConnection; } });
