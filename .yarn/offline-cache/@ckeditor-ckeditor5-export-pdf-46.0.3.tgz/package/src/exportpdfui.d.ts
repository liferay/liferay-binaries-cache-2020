/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module export-pdf/exportpdfui
 */
import { Plugin } from 'ckeditor5/src/core.js';
/**
 * The export to PDF UI feature.
 *
 * It introduces 'Export to PDF' button in toolbar and menu bar.
 */
export declare class ExportPdfUI extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "ExportPdfUI";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    init(): void;
}
