/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module export-pdf/exportpdfcommand
 * @publicApi
 */
import { Command, type Editor } from 'ckeditor5/src/core.js';
import type { ExportPdfConfig } from './exportpdf.js';
/**
 * The export to PDF command.
 *
 * It takes the editor's HTML and CSS rules from the document and sends them to the HTML to PDF converter.
 * After processing, the converter will send back a PDF file for download.
 */
export declare class ExportPdfCommand extends Command {
    /**
     * A command state that indicates if the command is currently executing.
     *
     * @observable
     */
    isBusy: boolean;
    /**
     * @inheritDoc
     */
    constructor(editor: Editor);
    /**
     * @inheritDoc
     */
    refresh(): void;
    /**
     * Executes the command.
     *
     * @fires execute
     * @param options Options for the executed command.
     */
    execute(options?: ExportPdfConfig): Promise<void>;
}
