/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
export function getTranslation(_0x596703,_0x5a4641){const t=_0x596703['t'];switch(_0x5a4641){case'Export\x20to\x20PDF':return t('Export\x20to\x20PDF');case'An\x20error\x20occurred\x20while\x20generating\x20the\x20PDF.':return t('An\x20error\x20occurred\x20while\x20generating\x20the\x20PDF.');case'PDF\x20export\x20started':return t('PDF\x20export\x20started');case'PDF\x20export\x20failed':return t('PDF\x20export\x20failed');case'PDF\x20export\x20successful':return t('PDF\x20export\x20successful');case'Exporting\x20PDF\x20document':return t('Exporting\x20PDF\x20document');default:return _0x5a4641;}}