/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x7c6b5c=_0x23f6;(function(_0x2368a6,_0x5ad8ae){const _0x2706a2=_0x23f6,_0x1124fd=_0x2368a6();while(!![]){try{const _0x2e2e4d=parseInt(_0x2706a2(0x13a))/0x1+-parseInt(_0x2706a2(0x130))/0x2+parseInt(_0x2706a2(0x12c))/0x3+-parseInt(_0x2706a2(0x137))/0x4*(parseInt(_0x2706a2(0x12a))/0x5)+parseInt(_0x2706a2(0x131))/0x6+-parseInt(_0x2706a2(0x124))/0x7*(parseInt(_0x2706a2(0x133))/0x8)+parseInt(_0x2706a2(0x135))/0x9;if(_0x2e2e4d===_0x5ad8ae)break;else _0x1124fd['push'](_0x1124fd['shift']());}catch(_0x3e352f){_0x1124fd['push'](_0x1124fd['shift']());}}}(_0xead6,0xafe0d));import{Plugin as _0x3d99d4}from'ckeditor5/src/core.js';function _0xead6(){const _0x4294b7=['editor','772520SQoXec','commands','4806819vQoyWI','tokenUrl','716tYyiSL','CloudServices','then','1071055lRUhSN','isOfficialPlugin','pluginName','_token','init','get','70NhmgxW','exportPdf','requires','plugins','add','isPremiumPlugin','37685BXtLzb','ExportPdf','3822651JcMpCK','token','config','registerTokenUrl','2299570fzUiGl','7833552uOfWtw'];_0xead6=function(){return _0x4294b7;};return _0xead6();}import{Notification as _0x48d90d}from'ckeditor5/src/ui.js';function _0x23f6(_0x463d31,_0x34f952){const _0xead678=_0xead6();return _0x23f6=function(_0x23f648,_0x4aa6e8){_0x23f648=_0x23f648-0x122;let _0x2367d8=_0xead678[_0x23f648];return _0x2367d8;},_0x23f6(_0x463d31,_0x34f952);}import{ExportPdfCommand as _0x12d44e}from'./exportpdfcommand.js';import{ExportPdfUI as _0x1e6b07}from'./exportpdfui.js';export class ExportPdf extends _0x3d99d4{[_0x7c6b5c(0x13d)];static get[_0x7c6b5c(0x13c)](){const _0x477499=_0x7c6b5c;return _0x477499(0x12b);}static get[_0x7c6b5c(0x13b)](){return!0x0;}static get[_0x7c6b5c(0x129)](){return!0x0;}static get[_0x7c6b5c(0x126)](){const _0x3e3670=_0x7c6b5c;return[_0x3e3670(0x138),_0x48d90d,_0x1e6b07];}[_0x7c6b5c(0x122)](){const _0x2f3ae1=_0x7c6b5c,_0x164d70=this[_0x2f3ae1(0x132)],_0x5316e4=_0x164d70[_0x2f3ae1(0x12e)][_0x2f3ae1(0x123)](_0x2f3ae1(0x125))||{};_0x164d70[_0x2f3ae1(0x134)][_0x2f3ae1(0x128)](_0x2f3ae1(0x125),new _0x12d44e(_0x164d70));const _0xd22fd3=_0x164d70[_0x2f3ae1(0x127)][_0x2f3ae1(0x123)](_0x2f3ae1(0x138));!0x1===_0x5316e4[_0x2f3ae1(0x136)]?this[_0x2f3ae1(0x13d)]=null:_0x5316e4[_0x2f3ae1(0x136)]?_0xd22fd3[_0x2f3ae1(0x12f)](_0x5316e4[_0x2f3ae1(0x136)])[_0x2f3ae1(0x139)](_0x263486=>{const _0x3beb45=_0x2f3ae1;this[_0x3beb45(0x13d)]=_0x263486;}):this[_0x2f3ae1(0x13d)]=_0xd22fd3[_0x2f3ae1(0x12d)];}}