/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import type { ExportPdfConfig, ExportPdf, ExportPdfCommand } from './index.js';
declare module '@ckeditor/ckeditor5-core' {
    interface EditorConfig {
        /**
         * The configuration of the {@link module:export-pdf/exportpdf~ExportPdf export to PDF feature}.
         *
         * Read more in {@link module:export-pdf/exportpdf~ExportPdfConfig}.
         */
        exportPdf?: ExportPdfConfig;
    }
    interface PluginsMap {
        [ExportPdf.pluginName]: ExportPdf;
    }
    interface CommandsMap {
        exportPdf: ExportPdfCommand;
    }
}
