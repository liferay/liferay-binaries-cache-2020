/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module export-pdf
 */
export { ExportPdf, type ExportPdfConfig, type ExportPdfConverterOptions } from './exportpdf.js';
export { ExportPdfCommand } from './exportpdfcommand.js';
import './augmentation.js';
