/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x21f6ae,_0x5ba51d){var _0xe6d8f=_0x517f,_0x3adee0=_0x21f6ae();while(!![]){try{var _0x259b54=parseInt(_0xe6d8f(0x1bc))/0x1+-parseInt(_0xe6d8f(0x1b7))/0x2*(parseInt(_0xe6d8f(0x1b6))/0x3)+-parseInt(_0xe6d8f(0x1c3))/0x4*(parseInt(_0xe6d8f(0x1c5))/0x5)+-parseInt(_0xe6d8f(0x1bf))/0x6+-parseInt(_0xe6d8f(0x1be))/0x7*(-parseInt(_0xe6d8f(0x1ba))/0x8)+parseInt(_0xe6d8f(0x1bd))/0x9*(-parseInt(_0xe6d8f(0x1b8))/0xa)+-parseInt(_0xe6d8f(0x1c1))/0xb*(-parseInt(_0xe6d8f(0x1c0))/0xc);if(_0x259b54===_0x5ba51d)break;else _0x3adee0['push'](_0x3adee0['shift']());}catch(_0x38e0c4){_0x3adee0['push'](_0x3adee0['shift']());}}}(_0x104d,0xcdad8));function _0x104d(){var _0x5c4973=['ck-aria-description-','6414256ZxanCG','setTemplate','5JRoyfC','145023NhLdDH','48zANEkn','394610hBSwLo','span','920DwCJYp','ck-aria-description','479256HbjdsB','189gvgUSa','42378jaHrRV','4902558ZsgNec','384DCPudd','1401301nIuSCI'];_0x104d=function(){return _0x5c4973;};return _0x104d();}import{uid as _0x1bc630}from'ckeditor5/src/utils.js';import{View as _0x40a0b7}from'ckeditor5/src/ui.js';function _0x517f(_0x1b49c8,_0x38fa48){var _0x104d9a=_0x104d();return _0x517f=function(_0x517fd6,_0x382af4){_0x517fd6=_0x517fd6-0x1b6;var _0x485b96=_0x104d9a[_0x517fd6];return _0x485b96;},_0x517f(_0x1b49c8,_0x38fa48);}export class AriaDescriptionView extends _0x40a0b7{['id'];constructor(_0x35bca2,_0x5cee90){var _0x579cbf=_0x517f;super(_0x35bca2),this['id']=_0x579cbf(0x1c2)+_0x1bc630(),this[_0x579cbf(0x1c4)]({'tag':_0x579cbf(0x1b9),'attributes':{'class':['ck',_0x579cbf(0x1bb)],'id':this['id']},'children':[{'text':_0x5cee90}]});}}