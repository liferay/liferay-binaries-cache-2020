/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x1e868b=_0x2e8a;(function(_0x5ac2eb,_0xe26b8b){var _0x2cfc29=_0x2e8a,_0x1be631=_0x5ac2eb();while(!![]){try{var _0x46e3ba=parseInt(_0x2cfc29(0x161))/0x1*(-parseInt(_0x2cfc29(0x166))/0x2)+parseInt(_0x2cfc29(0x159))/0x3*(-parseInt(_0x2cfc29(0x15c))/0x4)+parseInt(_0x2cfc29(0x15e))/0x5+-parseInt(_0x2cfc29(0x162))/0x6*(-parseInt(_0x2cfc29(0x15a))/0x7)+parseInt(_0x2cfc29(0x157))/0x8*(parseInt(_0x2cfc29(0x164))/0x9)+-parseInt(_0x2cfc29(0x160))/0xa+parseInt(_0x2cfc29(0x158))/0xb;if(_0x46e3ba===_0xe26b8b)break;else _0x1be631['push'](_0x1be631['shift']());}catch(_0xac6e4e){_0x1be631['push'](_0x1be631['shift']());}}}(_0x2837,0x8352c));import{ButtonView as _0x42e117,DropdownButtonView as _0x2ab293}from'ckeditor5/src/ui.js';function _0x2e8a(_0x13d7e4,_0x4308a6){var _0x2837eb=_0x2837();return _0x2e8a=function(_0x2e8aed,_0x108992){_0x2e8aed=_0x2e8aed-0x157;var _0x2217f3=_0x2837eb[_0x2e8aed];return _0x2217f3;},_0x2e8a(_0x13d7e4,_0x4308a6);}export class LateFocusButtonView extends _0x42e117{[_0x1e868b(0x168)](){var _0xc3d63b=_0x1e868b;super[_0xc3d63b(0x168)](),F(this);}}export class LateFocusDropdownButtonView extends _0x2ab293{[_0x1e868b(0x168)](){var _0x4b37d4=_0x1e868b;super[_0x4b37d4(0x168)](),F(this);}}function _0x2837(){var _0x393cac=['1355464MrYNFA','9LudyOp','301QJNzGw','stopPropagation','1091084UhQzrq','mousedown','4014605bQJjir','mouseup','4154240AIOERM','690163TTdsAK','76518oGmvst','listenTo','783TYZMgr','focus','2dUZiVJ','element','render','preventDefault','90784sSsDkh'];_0x2837=function(){return _0x393cac;};return _0x2837();}function F(_0x184aa7){var _0x230cb7=_0x1e868b;_0x184aa7[_0x230cb7(0x163)](_0x184aa7[_0x230cb7(0x167)],_0x230cb7(0x15d),(_0x5d10f4,_0x56cbdc)=>{var _0x10ae2a=_0x230cb7;_0x56cbdc[_0x10ae2a(0x15b)](),_0x56cbdc[_0x10ae2a(0x169)]();}),_0x184aa7[_0x230cb7(0x163)](_0x184aa7[_0x230cb7(0x167)],_0x230cb7(0x15f),()=>{var _0x334634=_0x230cb7;_0x184aa7[_0x334634(0x167)][_0x334634(0x165)]();});}