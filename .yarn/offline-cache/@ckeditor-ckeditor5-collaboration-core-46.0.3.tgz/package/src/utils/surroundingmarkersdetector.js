/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x6b3a4,_0x2fe4aa){const _0x239426=_0x3614,_0x5018a7=_0x6b3a4();while(!![]){try{const _0xcc8565=-parseInt(_0x239426(0x149))/0x1+-parseInt(_0x239426(0x14a))/0x2*(parseInt(_0x239426(0x13c))/0x3)+-parseInt(_0x239426(0x147))/0x4*(-parseInt(_0x239426(0x134))/0x5)+-parseInt(_0x239426(0x144))/0x6*(parseInt(_0x239426(0x13f))/0x7)+parseInt(_0x239426(0x136))/0x8*(parseInt(_0x239426(0x146))/0x9)+-parseInt(_0x239426(0x14b))/0xa*(-parseInt(_0x239426(0x13a))/0xb)+parseInt(_0x239426(0x13e))/0xc*(-parseInt(_0x239426(0x139))/0xd);if(_0xcc8565===_0x2fe4aa)break;else _0x5018a7['push'](_0x5018a7['shift']());}catch(_0x294aec){_0x5018a7['push'](_0x5018a7['shift']());}}}(_0xc9d3,0x3a0ec));function _0xc9d3(){const _0x4bc207=['containsPosition','122427VKMLsv','2622uorZNx','4039960dENOqM','isEqual','document','50VaKDIm','end','2829416MaPQlS','selection','push','27053cYRegt','11BZFGNF','change:range','72WTClvd','focus','1032iCJwuH','14gklwYM','start','length','includes','getRange','1410666hsIYbH','markers','9aSfEwL','113284grkBbJ'];_0xc9d3=function(){return _0x4bc207;};return _0xc9d3();}function _0x3614(_0x2922e8,_0xd345d1){const _0xc9d3da=_0xc9d3();return _0x3614=function(_0x3614d4,_0x5319f9){_0x3614d4=_0x3614d4-0x132;let _0x3dba51=_0xc9d3da[_0x3614d4];return _0x3dba51;},_0x3614(_0x2922e8,_0xd345d1);}export function surroundingMarkersDetector(_0x17b7d6,_0x110dde){const _0x19374d=_0x3614,_0x6c87b=[];_0x17b7d6[_0x19374d(0x133)][_0x19374d(0x137)]['on'](_0x19374d(0x13b),()=>{const _0x3d01c7=_0x19374d,_0x1b36a6=function(_0x1b52d4,_0x18d20c){const _0x575928=_0x3614,_0x89baf1=[];for(const _0x2ea0d8 of _0x1b52d4[_0x575928(0x145)]){const _0x229d63=_0x2ea0d8[_0x575928(0x143)]();(_0x229d63[_0x575928(0x148)](_0x18d20c)||_0x229d63[_0x575928(0x140)][_0x575928(0x132)](_0x18d20c)||_0x229d63[_0x575928(0x135)][_0x575928(0x132)](_0x18d20c))&&_0x89baf1[_0x575928(0x138)](_0x2ea0d8);}return _0x89baf1;}(_0x17b7d6,_0x17b7d6[_0x3d01c7(0x133)][_0x3d01c7(0x137)][_0x3d01c7(0x13d)]),_0x48922a=[],_0x4081e5=[],_0x345fbb=[];for(const _0xb1e08f of _0x6c87b)_0x1b36a6[_0x3d01c7(0x142)](_0xb1e08f)||_0x48922a[_0x3d01c7(0x138)](_0xb1e08f);for(const _0xadad63 of _0x1b36a6)_0x6c87b[_0x3d01c7(0x142)](_0xadad63)||_0x4081e5[_0x3d01c7(0x138)](_0xadad63),_0x345fbb[_0x3d01c7(0x138)](_0xadad63);(_0x48922a[_0x3d01c7(0x141)]||_0x4081e5[_0x3d01c7(0x141)])&&_0x110dde({'left':_0x48922a,'entered':_0x4081e5}),_0x6c87b[_0x3d01c7(0x141)]=0x0,_0x6c87b[_0x3d01c7(0x138)](..._0x345fbb);});}