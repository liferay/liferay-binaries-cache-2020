/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x8871(){const _0x50a988=['462576NFAfXv','length','3573570PYprMp','view','values','2130373JBHpVH','filter','1503000IyIZzS','sort','51090igMnMX','markerNameToElements','mapViewToDom','name','domConverter','map','64kCnzaD','431496sXTGgh','from','4MUsyFE','domElement','17CoNNRm','getClientRects','mapper','push','item','191965NICxrN'];_0x8871=function(){return _0x50a988;};return _0x8871();}(function(_0x1e1b65,_0x3505fd){const _0x9c4e70=_0x200f,_0x334ebf=_0x1e1b65();while(!![]){try{const _0x1e6796=-parseInt(_0x9c4e70(0xcb))/0x1*(-parseInt(_0x9c4e70(0xc0))/0x2)+-parseInt(_0x9c4e70(0xb7))/0x3+parseInt(_0x9c4e70(0xc9))/0x4*(parseInt(_0x9c4e70(0xb6))/0x5)+-parseInt(_0x9c4e70(0xbe))/0x6+parseInt(_0x9c4e70(0xbc))/0x7+parseInt(_0x9c4e70(0xc6))/0x8*(-parseInt(_0x9c4e70(0xc7))/0x9)+parseInt(_0x9c4e70(0xb9))/0xa;if(_0x1e6796===_0x3505fd)break;else _0x334ebf['push'](_0x334ebf['shift']());}catch(_0x51331b){_0x334ebf['push'](_0x334ebf['shift']());}}}(_0x8871,0x547fe));function _0x200f(_0x4adb39,_0x25f009){const _0x887182=_0x8871();return _0x200f=function(_0x200fd7,_0x203f90){_0x200fd7=_0x200fd7-0xb3;let _0xb794af=_0x887182[_0x200fd7];return _0xb794af;},_0x200f(_0x4adb39,_0x25f009);}import{first as _0x546315}from'ckeditor5/src/utils.js';export function getMarkerDomElement(_0x2933af,_0x3bf076){const _0x43d8a2=_0x200f,_0x5c0b9e=_0x2933af[_0x43d8a2(0xb3)][_0x43d8a2(0xc1)](_0x3bf076[_0x43d8a2(0xc3)]);if(!_0x5c0b9e)return null;const _0x5a7772=_0x546315(_0x5c0b9e[_0x43d8a2(0xbb)]());return _0x2933af[_0x43d8a2(0xba)][_0x43d8a2(0xc4)][_0x43d8a2(0xc2)](_0x5a7772)||null;}export function getAllMarkersDomElementsSorted(_0x214fae,_0x2ceec6){const _0x2cd7ac=_0x200f;if(0x0===_0x2ceec6[_0x2cd7ac(0xb8)])return null;const _0x5a1e5d=[],_0x377e58=_0x214fae[_0x2cd7ac(0xba)][_0x2cd7ac(0xc4)];for(const _0x4a926c of _0x2ceec6){const _0x315b4d=_0x214fae[_0x2cd7ac(0xb3)][_0x2cd7ac(0xc1)](_0x4a926c[_0x2cd7ac(0xc3)]);if(!_0x315b4d)continue;const _0x8dc400=Array[_0x2cd7ac(0xc8)](_0x315b4d)[_0x2cd7ac(0xc5)](_0xf59397=>_0x377e58[_0x2cd7ac(0xc2)](_0xf59397))[_0x2cd7ac(0xbd)](_0x420e67=>!!_0x420e67);_0x5a1e5d[_0x2cd7ac(0xb4)](..._0x8dc400);}if(0x0===_0x5a1e5d[_0x2cd7ac(0xb8)])return null;const _0x1ac513=[];for(const _0x5adcbe of _0x5a1e5d){const _0x7989ff=_0x5adcbe[_0x2cd7ac(0xcc)]()[_0x2cd7ac(0xb5)](0x0);_0x7989ff&&_0x1ac513[_0x2cd7ac(0xb4)]({'x':_0x7989ff['x'],'y':_0x7989ff['y'],'domElement':_0x5adcbe});}return 0x0===_0x1ac513[_0x2cd7ac(0xb8)]?null:(_0x1ac513[_0x2cd7ac(0xbf)]((_0xefb18d,_0x5f2cee)=>_0xefb18d['y']-_0x5f2cee['y']||_0xefb18d['x']-_0x5f2cee['x']),_0x1ac513[_0x2cd7ac(0xc5)](_0x2c4788=>_0x2c4788[_0x2cd7ac(0xca)]));}