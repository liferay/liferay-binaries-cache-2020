/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x33ca(){var _0x5442f6=['174576taBMcY','element','120obuuIQ','showConfirm','render','deregisterChild','remove','submit','8vwqQwh','removeConfirm','cancelConfirm','destroy','873927BWneMI','set','cancel','190lwUGKG','once','message','422796LJyUaB','locale','1090047QhTiSk','370RaOZeq','326016uyRBrF','confirmView','isConfirm','registerChild','fire','appendChild','329247JgsHWF','_removeConfirm','415564yhIfxf','focus'];_0x33ca=function(){return _0x5442f6;};return _0x33ca();}(function(_0x22cbc6,_0x5511f6){var _0x437e39=_0xd52f,_0x2a18c8=_0x22cbc6();while(!![]){try{var _0x18f890=parseInt(_0x437e39(0x157))/0x1+-parseInt(_0x437e39(0x15f))/0x2+parseInt(_0x437e39(0x14d))/0x3*(parseInt(_0x437e39(0x169))/0x4)+-parseInt(_0x437e39(0x150))/0x5*(parseInt(_0x437e39(0x161))/0x6)+parseInt(_0x437e39(0x155))/0x7+parseInt(_0x437e39(0x163))/0x8*(-parseInt(_0x437e39(0x15d))/0x9)+parseInt(_0x437e39(0x156))/0xa*(parseInt(_0x437e39(0x153))/0xb);if(_0x18f890===_0x5511f6)break;else _0x2a18c8['push'](_0x2a18c8['shift']());}catch(_0x2cf9f3){_0x2a18c8['push'](_0x2a18c8['shift']());}}}(_0x33ca,0x986b8));import{ConfirmView as _0x4ff3d1}from'./confirmview.js';function _0xd52f(_0x233a4b,_0x586d5c){var _0x33cab9=_0x33ca();return _0xd52f=function(_0xd52f8d,_0x380baa){_0xd52f8d=_0xd52f8d-0x14c;var _0x5aebe7=_0x33cab9[_0xd52f8d];return _0x5aebe7;},_0xd52f(_0x233a4b,_0x586d5c);}export function ConfirmMixin(_0xf65e7){var _0x21397f=_0xd52f;return class extends _0xf65e7{[_0x21397f(0x164)](_0x3814cd,_0x4faafe){var _0x5b31cf=_0x21397f;return this[_0x5b31cf(0x158)]=new _0x4ff3d1(this[_0x5b31cf(0x154)]),this[_0x5b31cf(0x158)][_0x5b31cf(0x165)](),this[_0x5b31cf(0x158)][_0x5b31cf(0x152)]=_0x3814cd,this[_0x5b31cf(0x158)][_0x5b31cf(0x151)](_0x5b31cf(0x14f),()=>{var _0x4ca082=_0x5b31cf;this[_0x4ca082(0x15e)]();}),this[_0x5b31cf(0x158)][_0x5b31cf(0x151)](_0x5b31cf(0x168),()=>{var _0x36bd90=_0x5b31cf;this[_0x36bd90(0x15e)]();}),_0x4faafe[_0x5b31cf(0x15c)](this[_0x5b31cf(0x158)][_0x5b31cf(0x162)]),this[_0x5b31cf(0x15a)](this[_0x5b31cf(0x158)]),this[_0x5b31cf(0x158)][_0x5b31cf(0x160)](),this[_0x5b31cf(0x14e)](_0x5b31cf(0x159),!0x0),new Promise(_0x241eb8=>this[_0x5b31cf(0x158)]['on'](_0x5b31cf(0x168),_0x241eb8));}[_0x21397f(0x16b)](){var _0x2eddab=_0x21397f;this[_0x2eddab(0x159)]&&this[_0x2eddab(0x158)][_0x2eddab(0x15b)](_0x2eddab(0x14f));}[_0x21397f(0x15e)](){var _0x21ae4b=_0x21397f;this[_0x21ae4b(0x162)]&&this[_0x21ae4b(0x158)]&&this[_0x21ae4b(0x158)][_0x21ae4b(0x162)]&&(this[_0x21ae4b(0x162)][_0x21ae4b(0x160)](),this[_0x21ae4b(0x158)][_0x21ae4b(0x162)][_0x21ae4b(0x167)](),this[_0x21ae4b(0x166)](this[_0x21ae4b(0x158)]),this[_0x21ae4b(0x159)]=!0x1,this[_0x21ae4b(0x15b)](_0x21ae4b(0x16a)),this[_0x21ae4b(0x158)][_0x21ae4b(0x14c)](),this[_0x21ae4b(0x158)]=void 0x0);}};}