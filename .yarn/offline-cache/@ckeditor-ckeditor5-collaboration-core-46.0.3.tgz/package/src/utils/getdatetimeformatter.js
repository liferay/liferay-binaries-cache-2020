/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x518b(_0x2ba578,_0x2d1984){const _0x231975=_0x2319();return _0x518b=function(_0x518bf3,_0x409c86){_0x518bf3=_0x518bf3-0xa0;let _0x165d34=_0x231975[_0x518bf3];return _0x165d34;},_0x518b(_0x2ba578,_0x2d1984);}(function(_0x4646ff,_0x370fc1){const _0x3ca8e3=_0x518b,_0xcc90f0=_0x4646ff();while(!![]){try{const _0x3d5381=parseInt(_0x3ca8e3(0xbd))/0x1*(-parseInt(_0x3ca8e3(0xbf))/0x2)+parseInt(_0x3ca8e3(0xaa))/0x3*(-parseInt(_0x3ca8e3(0xac))/0x4)+parseInt(_0x3ca8e3(0xa6))/0x5+-parseInt(_0x3ca8e3(0xa9))/0x6*(parseInt(_0x3ca8e3(0xb4))/0x7)+parseInt(_0x3ca8e3(0xb6))/0x8+parseInt(_0x3ca8e3(0xa4))/0x9*(-parseInt(_0x3ca8e3(0xad))/0xa)+-parseInt(_0x3ca8e3(0xba))/0xb*(-parseInt(_0x3ca8e3(0xbe))/0xc);if(_0x3d5381===_0x370fc1)break;else _0xcc90f0['push'](_0xcc90f0['shift']());}catch(_0xf5d293){_0xcc90f0['push'](_0xcc90f0['shift']());}}}(_0x2319,0xd58d7));import{DateTime as _0x138c5c}from'luxon';import{CKEditorError as _0x5b8fc8}from'ckeditor5/src/utils.js';function _0x2319(){const _0x358387=['diff','toFormat','Yesterday','\x27Yesterday\x27\x20hh:mma','9931957pxzwTC','LL-dd-yyyy\x20hh:mma','9972816pkbLQP','Today','toJSDate','EEEE','11AwoiuI','function','\x27Today\x27\x20hh:mma','2FgYKCV','35042184SQhWvh','607118gQaoGR','now','string','dateTimeFormat','floor','fromISO','9GiAJlA','days','8155650ERBGOz','fromJSDate','hh:mma','6CTunsj','99BMUyWl','Last','160052DSmzJQ','15768050OqRNQE','\x27Last\x27\x20EEEE\x20hh:mma','invalid-date-time-format'];_0x2319=function(){return _0x358387;};return _0x2319();}import{getTranslation as _0x34ba15}from'./common-translations.js';export function getDateTimeFormatter(_0x499386={},_0x5235a9){const _0xe99a07=_0x518b;if(void 0x0!==_0x499386[_0xe99a07(0xa1)]&&_0xe99a07(0xbb)!=typeof _0x499386[_0xe99a07(0xa1)])throw new _0x5b8fc8(_0xe99a07(0xaf));return _0x1a861e=>{const _0x3afca4=_0xe99a07,_0xb71fef=_0x3afca4(0xa0)==typeof _0x1a861e?_0x138c5c[_0x3afca4(0xa3)](_0x1a861e):_0x138c5c[_0x3afca4(0xa7)](_0x1a861e),_0x174113=_0x138c5c[_0x3afca4(0xc0)](),_0x507fd0=Math[_0x3afca4(0xa2)](_0x174113[_0x3afca4(0xb0)](_0xb71fef,_0x3afca4(0xa5))[_0x3afca4(0xa5)]);return _0x499386[_0x3afca4(0xa1)]?_0x499386[_0x3afca4(0xa1)](_0xb71fef[_0x3afca4(0xb8)](),_0x5235a9&&_0x5235a9['t']?_0x5235a9['t']:void 0x0):0x0===_0x507fd0?_0x5235a9?_0x34ba15(_0x5235a9,_0x3afca4(0xb7))+'\x20'+_0xb71fef[_0x3afca4(0xb1)](_0x3afca4(0xa8)):_0xb71fef[_0x3afca4(0xb1)](_0x3afca4(0xbc)):0x1===_0x507fd0?_0x5235a9?_0x34ba15(_0x5235a9,_0x3afca4(0xb2))+'\x20'+_0xb71fef[_0x3afca4(0xb1)](_0x3afca4(0xa8)):_0xb71fef[_0x3afca4(0xb1)](_0x3afca4(0xb3)):_0x507fd0<0x7?_0x5235a9?_0x34ba15(_0x5235a9,_0x3afca4(0xab))+'\x20'+_0x34ba15(_0x5235a9,_0xb71fef[_0x3afca4(0xb1)](_0x3afca4(0xb9)))+'\x20'+_0xb71fef[_0x3afca4(0xb1)](_0x3afca4(0xa8)):_0xb71fef[_0x3afca4(0xb1)](_0x3afca4(0xae)):_0xb71fef[_0x3afca4(0xb1)](_0x3afca4(0xb5));};}