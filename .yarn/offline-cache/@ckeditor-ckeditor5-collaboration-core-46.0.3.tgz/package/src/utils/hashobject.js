/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x1352bc,_0x3ca58e){const _0x15d2c2=_0x1714,_0x4787cf=_0x1352bc();while(!![]){try{const _0x51bdb3=-parseInt(_0x15d2c2(0x19a))/0x1*(parseInt(_0x15d2c2(0x196))/0x2)+-parseInt(_0x15d2c2(0x1a2))/0x3+parseInt(_0x15d2c2(0x1a8))/0x4*(-parseInt(_0x15d2c2(0x1aa))/0x5)+parseInt(_0x15d2c2(0x1a4))/0x6*(-parseInt(_0x15d2c2(0x1a9))/0x7)+parseInt(_0x15d2c2(0x1a3))/0x8*(parseInt(_0x15d2c2(0x1a7))/0x9)+-parseInt(_0x15d2c2(0x19b))/0xa*(-parseInt(_0x15d2c2(0x198))/0xb)+parseInt(_0x15d2c2(0x1a6))/0xc;if(_0x51bdb3===_0x3ca58e)break;else _0x4787cf['push'](_0x4787cf['shift']());}catch(_0x5a5de1){_0x4787cf['push'](_0x4787cf['shift']());}}}(_0x185a,0x4cc85));function _0x185a(){const _0x654baa=['string','charCodeAt','object','sort','1106208jYWDQw','243784ylrdlL','96SpYelb','keys','13203888fKUprG','99TBZSXj','111576iUjVEk','77476HcUQTv','30OjpCVm','58Btbmde','isArray','363539mzSYjR','toString','15203GZJrgH','10DPfPGE','sign','number'];_0x185a=function(){return _0x654baa;};return _0x185a();}export function hashObject(_0x13e2dc){let _0x25ffe8=0x0,_0x2df960=0x0;for(const _0x5b62b8 of j(_0x13e2dc))_0x25ffe8=(_0x25ffe8<<0x5)-_0x25ffe8+_0x5b62b8,_0x25ffe8&=_0x25ffe8,[_0x25ffe8,_0x2df960]=[_0x2df960,_0x25ffe8];return x(_0x25ffe8)+x(_0x2df960);}function*b(_0x2036f6){const _0x2c6e23=_0x1714;null==_0x2036f6||null==_0x2036f6?yield 0x12b9b0a1:0x0===_0x2036f6||!0x1===_0x2036f6?yield 0x0:0x1===_0x2036f6||0x1==_0x2036f6?yield 0x1:Array[_0x2c6e23(0x197)](_0x2036f6)?yield*function*(_0x381959){for(const _0x5867df of _0x381959)yield*b(_0x5867df);}(_0x2036f6):_0x2c6e23(0x1a0)==typeof _0x2036f6?yield*j(_0x2036f6):_0x2c6e23(0x19e)==typeof _0x2036f6?yield*O(_0x2036f6):_0x2c6e23(0x19d)==typeof _0x2036f6&&(yield _0x2036f6);}function*j(_0x41094c){const _0x481f19=_0x1714;if(yield g('{'),_0x41094c){const _0x22db44=Object[_0x481f19(0x1a5)](_0x41094c)[_0x481f19(0x1a1)]();for(const _0xadd5b1 of _0x22db44){yield*O(_0xadd5b1),yield g(':');const _0x2de4ae=_0x41094c[_0xadd5b1];yield*b(_0x2de4ae);}}yield g('}');}function*O(_0x3a7bd8){yield g('\x22');for(const _0x27e423 of _0x3a7bd8)yield g(_0x27e423);yield g('\x22');}function _0x1714(_0x3f2623,_0x2161d7){const _0x185a58=_0x185a();return _0x1714=function(_0x1714f5,_0x577944){_0x1714f5=_0x1714f5-0x196;let _0x12eb2b=_0x185a58[_0x1714f5];return _0x12eb2b;},_0x1714(_0x3f2623,_0x2161d7);}function g(_0x963602){const _0x10fa5b=_0x1714;return _0x963602[_0x10fa5b(0x19f)](0x0);}function x(_0x3f0e9b){const _0x5b28b0=_0x1714;return(_0x3f0e9b*=Math[_0x5b28b0(0x19c)](_0x3f0e9b))[_0x5b28b0(0x199)](0x24);}