/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
export { Permissions } from './permissions.js';
export { Users, type User, type CollaborationUserColor, type CollaborationUserData } from './users.js';
export { UserView } from './users/view/userview.js';
export { AriaDescriptionView } from './suggestions/view/ariadescriptionview.js';
export { LateFocusButtonView, LateFocusDropdownButtonView } from './suggestions/view/latefocusbuttonview.js';
export { getDateTimeFormatter } from './utils/getdatetimeformatter.js';
export { getMarkerDomElement, getAllMarkersDomElementsSorted } from './utils/getmarkerdomelement.js';
export { trimHtml } from './utils/trim-html.js';
export { ConfirmMixin, type RemoveConfirmEvent } from './utils/confirmmixin.js';
export { hashObject } from './utils/hashobject.js';
export { sanitizeEditorConfig } from './utils/sanitizeEditorConfig.js';
export { surroundingMarkersDetector } from './utils/surroundingmarkersdetector.js';
export { setupThreadKeyboardNavigation, FOCUS_ANNOTATION_KEYSTROKE, type ThreadEscapeEvent, type ThreadArrowUpEvent, type ThreadArrowDownEvent } from './utils/setupthreadkeyboardnavigation.js';
export type { CollaborationOperation, InsertCollaborationOperation, SplitCollaborationOperation, MarkerCollaborationOperation, MoveCollaborationOperation, MergeCollaborationOperation, RootCollaborationOperation, RootAttributeCollaborationOperation } from './collaborationoperation.js';
export type { CollaborationHistory } from './collaborationhistory.js';
export type { LocaleConfig, RealTimeCollaborationConfig, CollaborationUsersConfig } from './config.js';
import './suggestionstyles.js';
import './augmentation.js';
