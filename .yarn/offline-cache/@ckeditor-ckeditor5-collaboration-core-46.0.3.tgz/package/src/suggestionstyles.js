/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x3a5756,_0xfef759){var _0x334777=_0xb05d,_0x3d83c6=_0x3a5756();while(!![]){try{var _0x1fed04=parseInt(_0x334777(0x166))/0x1*(-parseInt(_0x334777(0x164))/0x2)+parseInt(_0x334777(0x168))/0x3*(parseInt(_0x334777(0x163))/0x4)+-parseInt(_0x334777(0x160))/0x5+parseInt(_0x334777(0x169))/0x6+parseInt(_0x334777(0x162))/0x7*(-parseInt(_0x334777(0x16a))/0x8)+-parseInt(_0x334777(0x167))/0x9*(-parseInt(_0x334777(0x161))/0xa)+-parseInt(_0x334777(0x16b))/0xb*(-parseInt(_0x334777(0x165))/0xc);if(_0x1fed04===_0xfef759)break;else _0x3d83c6['push'](_0x3d83c6['shift']());}catch(_0x288578){_0x3d83c6['push'](_0x3d83c6['shift']());}}}(_0x3d8f,0x7f2a0));function _0xb05d(_0x137bb7,_0xaf383f){var _0x3d8f36=_0x3d8f();return _0xb05d=function(_0xb05d4,_0x47d734){_0xb05d4=_0xb05d4-0x160;var _0x41983f=_0x3d8f36[_0xb05d4];return _0x41983f;},_0xb05d(_0x137bb7,_0xaf383f);}import'../theme/suggestion.css';import'../theme/suggestionmarker.css';import'../theme/ariadescription.css';import'../theme/integrations/image.css';import'../theme/integrations/horizontalline.css';import'../theme/integrations/mediaembed.css';import'../theme/integrations/mergefields.css';function _0x3d8f(){var _0x20c859=['4KYqhdK','321982HJxAbw','204etJGtV','2ZSDbdc','253674uhnWHI','1620516aaPenw','1975062ySWnjO','710128hzFBwk','229933WjzOBy','112910IbWEcl','30IwXPIE','35mosEKS'];_0x3d8f=function(){return _0x20c859;};return _0x3d8f();}import'../theme/integrations/pagebreak.css';import'../theme/integrations/table.css';import'../theme/integrations/codeblock.css';