/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x5cb799,_0x48dc3f){var _0x33f6d9=_0x326c,_0x3e2687=_0x5cb799();while(!![]){try{var _0x293e9d=-parseInt(_0x33f6d9(0xda))/0x1+parseInt(_0x33f6d9(0xe0))/0x2*(-parseInt(_0x33f6d9(0xd7))/0x3)+-parseInt(_0x33f6d9(0xd8))/0x4+parseInt(_0x33f6d9(0xdf))/0x5*(parseInt(_0x33f6d9(0xde))/0x6)+parseInt(_0x33f6d9(0xd9))/0x7+-parseInt(_0x33f6d9(0xdc))/0x8+-parseInt(_0x33f6d9(0xdb))/0x9*(-parseInt(_0x33f6d9(0xdd))/0xa);if(_0x293e9d===_0x48dc3f)break;else _0x3e2687['push'](_0x3e2687['shift']());}catch(_0x11f10d){_0x3e2687['push'](_0x3e2687['shift']());}}}(_0x2e2d,0xaba8b));function _0x2e2d(){var _0x564ee8=['2027616MsyXwF','7711543XdEdgL','345854XrOUrA','447570WExcFd','5256600OGSVTK','430RgunSc','180kheiZd','19930fgjdxU','2293342TNgMvM','3FijOrM'];_0x2e2d=function(){return _0x564ee8;};return _0x2e2d();}export{Permissions}from'./permissions.js';export{Users}from'./users.js';export{UserView}from'./users/view/userview.js';export{AriaDescriptionView}from'./suggestions/view/ariadescriptionview.js';export{LateFocusButtonView,LateFocusDropdownButtonView}from'./suggestions/view/latefocusbuttonview.js';export{getDateTimeFormatter}from'./utils/getdatetimeformatter.js';export{getMarkerDomElement,getAllMarkersDomElementsSorted}from'./utils/getmarkerdomelement.js';export{trimHtml}from'./utils/trim-html.js';export{ConfirmMixin}from'./utils/confirmmixin.js';export{hashObject}from'./utils/hashobject.js';export{sanitizeEditorConfig}from'./utils/sanitizeEditorConfig.js';export{surroundingMarkersDetector}from'./utils/surroundingmarkersdetector.js';export{setupThreadKeyboardNavigation,FOCUS_ANNOTATION_KEYSTROKE}from'./utils/setupthreadkeyboardnavigation.js';function _0x326c(_0xd0d5aa,_0x3aad3b){var _0x2e2df9=_0x2e2d();return _0x326c=function(_0x326cd2,_0x1d86d3){_0x326cd2=_0x326cd2-0xd7;var _0xd94821=_0x2e2df9[_0x326cd2];return _0xd94821;},_0x326c(_0xd0d5aa,_0x3aad3b);}import'./suggestionstyles.js';import'./augmentation.js';