/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x2c8a5e=_0x4de7;(function(_0x2167fb,_0x93c7f6){const _0x4ef3b8=_0x4de7,_0x104995=_0x2167fb();while(!![]){try{const _0x25538c=parseInt(_0x4ef3b8(0x155))/0x1*(-parseInt(_0x4ef3b8(0x152))/0x2)+-parseInt(_0x4ef3b8(0x167))/0x3+-parseInt(_0x4ef3b8(0x164))/0x4+-parseInt(_0x4ef3b8(0x169))/0x5+-parseInt(_0x4ef3b8(0x15d))/0x6+-parseInt(_0x4ef3b8(0x15f))/0x7+parseInt(_0x4ef3b8(0x166))/0x8;if(_0x25538c===_0x93c7f6)break;else _0x104995['push'](_0x104995['shift']());}catch(_0x27324b){_0x104995['push'](_0x104995['shift']());}}}(_0x44cd,0xba73c));import{View as _0x474ed4,IconView as _0x522421}from'ckeditor5/src/ui.js';function _0x4de7(_0x16249b,_0x2415d7){const _0x44cde9=_0x44cd();return _0x4de7=function(_0x4de7ad,_0x23e86b){_0x4de7ad=_0x4de7ad-0x14e;let _0x2dbd1f=_0x44cde9[_0x4de7ad];return _0x2dbd1f;},_0x4de7(_0x16249b,_0x2415d7);}import{IconNotification as _0x5e82bb}from'ckeditor5/src/icons.js';import'../../../theme/users.css';function _0x44cd(){const _0x1e4798=['7761504jhhmHw','ck-user_me','6022149QIQQLs','ck-user__anonymous','setTemplate','content','url(\x27','4868852urbYrj','ck\x20ck-user__name','58900016QbnbDZ','4350996UdlhLn','initials','6991555MpkwfS','isMe','name','push','isAnonymous','ck-user__img','758094dFHHIn','avatar','notificationView','1ocsvFY','ck-user__avatar','div','ck-user__notification','ck\x20ck-user__name\x20ck-user__name--hidden','extendTemplate','ck-user__icon','ck-user'];_0x44cd=function(){return _0x1e4798;};return _0x44cd();}export class UserView extends _0x474ed4{[_0x2c8a5e(0x14e)];[_0x2c8a5e(0x154)];constructor(_0x216eb5,_0xc75b82,_0x2fde8b){const _0x5a64b1=_0x2c8a5e;super(_0x216eb5),this[_0x5a64b1(0x14e)]=_0xc75b82[_0x5a64b1(0x14e)],this[_0x5a64b1(0x154)]=null;const _0x3a323d=['ck',_0x5a64b1(0x15c)],_0x47da09=['ck',_0x5a64b1(0x151)];if(_0xc75b82[_0x5a64b1(0x150)]&&_0x47da09[_0x5a64b1(0x14f)](_0x5a64b1(0x160)),!_0xc75b82[_0x5a64b1(0x150)]&&_0xc75b82[_0x5a64b1(0x16a)]&&_0x3a323d[_0x5a64b1(0x14f)](_0x5a64b1(0x15e)),_0xc75b82[_0x5a64b1(0x153)]&&_0x47da09[_0x5a64b1(0x14f)](_0x5a64b1(0x156)),_0x2fde8b){const _0x2d7ef4=new _0x522421();_0x2d7ef4[_0x5a64b1(0x15a)]({'attributes':{'class':[_0x5a64b1(0x15b)]}}),_0x2d7ef4[_0x5a64b1(0x162)]=_0x5e82bb,this[_0x5a64b1(0x154)]={'tag':_0x5a64b1(0x157),'attributes':{'class':['ck',_0x5a64b1(0x158)],'data-cke-tooltip-position':'n','data-cke-tooltip-text':_0x2fde8b},'children':[_0x2d7ef4]};}const _0x7a4338=[{'tag':_0x5a64b1(0x157),'attributes':{'class':_0x47da09,'style':{'background-image':_0xc75b82[_0x5a64b1(0x153)]?_0x5a64b1(0x163)+_0xc75b82[_0x5a64b1(0x153)]+'\x27)':''}}},{'tag':_0x5a64b1(0x157),'attributes':{'class':_0xc75b82[_0x5a64b1(0x153)]?_0x5a64b1(0x159):_0x5a64b1(0x165),'aria-label':_0xc75b82[_0x5a64b1(0x14e)]},'children':[{'text':_0xc75b82[_0x5a64b1(0x168)]}]}];this[_0x5a64b1(0x154)]&&_0x7a4338[_0x5a64b1(0x14f)](this[_0x5a64b1(0x154)]),this[_0x5a64b1(0x161)]({'tag':_0x5a64b1(0x157),'attributes':{'class':_0x3a323d,'data-user-id':_0xc75b82['id']},'children':_0x7a4338});}}