/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x459765 from'./../../descriptor.js';export default class OperationMetadataDescriptor extends _0x459765{static ['DESCRIPTOR_NAME']='OperationMetadataDescriptor';static ['DESCRIPTOR']={'fields':{'userId':{'type':'string','id':0x1},'type':{'type':'string','id':0x2},'createdAt':{'type':'string','id':0x3}}};static['toJSON']({createdAt:_0x511f8a,..._0x104a75}){const _0x5d4b35={..._0x104a75};return _0x511f8a?.['toISOString']&&(_0x5d4b35['createdAt']=_0x511f8a['toISOString']()),_0x5d4b35;}static['fromJSON']({createdAt:_0x3c07fc,..._0x253d9a}){const _0x5e333d={..._0x253d9a};return _0x3c07fc&&(_0x5e333d['createdAt']=new Date(_0x3c07fc)),_0x5e333d;}}