/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
export default class OperationMetadataHelpers{static['prepareMetadataForOperations'](_0x2707c0,_0x310c4e){if(!_0x2707c0?.['length']||!_0x310c4e?.['length'])return[];const _0x1c2d60=[];let _0x400e19=0x0;for(const _0x593fd7 of _0x2707c0)if(0x0!==_0x593fd7){if(!_0x310c4e[_0x400e19])throw new Error('Missing\x20metadata\x20for\x20a\x20operation');_0x1c2d60['push'](_0x310c4e[_0x400e19]),_0x400e19++;}else _0x1c2d60['push'](_0x1c2d60[_0x1c2d60['length']-0x1]);return _0x1c2d60;}static['removeUnnecessaryMetadata'](_0x91a9e4,_0x1914a6){if(!_0x91a9e4?.['length']||!_0x1914a6?.['length'])return[];const _0x4f7109=[];for(let _0x5650bc=0x0;_0x5650bc<_0x91a9e4['length'];_0x5650bc++)if(0x0!==_0x91a9e4[_0x5650bc]){if(!_0x1914a6[_0x5650bc])throw new Error('Missing\x20metadata\x20for\x20a\x20operation');_0x4f7109['push'](_0x1914a6[_0x5650bc]);}return _0x4f7109;}}