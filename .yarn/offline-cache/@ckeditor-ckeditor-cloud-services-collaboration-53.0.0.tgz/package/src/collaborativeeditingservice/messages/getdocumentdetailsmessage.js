/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x117c93 from'../../message.js';export default class GetDocumentDetailsMessage extends _0x117c93{['documentId'];static ['TYPE']='14';static ['READABLE_TYPE_NAME']='getDocumentDetails';static ['DESCRIPTOR_NAME']='GetDocumentDetailsMessage';static ['DESCRIPTOR']={'fields':{'documentId':{'type':'string','id':0x1},'environmentId':{'type':'string','id':0x2}}};constructor(_0x253740){super(),this['documentId']=_0x253740;}get['data'](){return{'documentId':this['documentId']};}['toJSON'](){return{'documentId':this['documentId']};}static['fromJSON'](_0x25cdff){return new GetDocumentDetailsMessage(_0x25cdff['documentId']);}}