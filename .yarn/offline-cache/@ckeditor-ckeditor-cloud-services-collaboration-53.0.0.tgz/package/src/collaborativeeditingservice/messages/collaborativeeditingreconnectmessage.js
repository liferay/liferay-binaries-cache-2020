/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x493f86 from'./../../message.js';export default class CollaborativeEditingReconnectMessage extends _0x493f86{['id'];['lastKnowVersion'];['bundleVersion'];static ['TYPE']='12';static ['READABLE_TYPE_NAME']='reconnectToDocument';static ['DESCRIPTOR_NAME']='CollaborativeEditingReconnectMessage';static ['DESCRIPTOR']={'fields':{'id':{'type':'string','id':0x1},'bundleVersion':{'type':'string','id':0x2},'lastKnowVersion':{'type':'uint32','id':0x3}}};constructor(_0x113a02,_0x36c0ff,_0x5d8c70){super(),this['id']=_0x113a02,this['lastKnowVersion']=_0x36c0ff,this['bundleVersion']=_0x5d8c70;}['toJSON'](){return{'id':this['id'],'bundleVersion':this['bundleVersion'],'lastKnowVersion':this['lastKnowVersion']};}static['fromJSON'](_0x586a8a){return new CollaborativeEditingReconnectMessage(_0x586a8a['id'],_0x586a8a['lastKnowVersion'],_0x586a8a['bundleVersion']);}}