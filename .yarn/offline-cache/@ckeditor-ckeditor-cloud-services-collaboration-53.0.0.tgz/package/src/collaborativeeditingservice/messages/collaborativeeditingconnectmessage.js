/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x215b8f from'./../../message.js';export default class CollaborativeEditingConnectMessage extends _0x215b8f{['id'];['buffers'];['types'];['bundleVersion'];['lastOperationId'];static ['TYPE']='11';static ['READABLE_TYPE_NAME']='connectToDocument';static ['DESCRIPTOR_NAME']='CollaborativeEditingConnectMessage';static ['DESCRIPTOR']={'fields':{'id':{'type':'string','id':0x1},'bundleVersion':{'type':'string','id':0x2},'buffers':{'rule':'repeated','type':'bytes','id':0x3},'types':{'rule':'repeated','type':'uint32','id':0x4},'lastOperationId':{'type':'string','id':0x5}}};constructor(_0xee072b,_0x392344,_0x2d4e8c,_0x5d9a6b,_0x20b11c=''){super(),this['id']=_0xee072b,this['buffers']=_0x392344,this['types']=_0x2d4e8c,this['bundleVersion']=_0x5d9a6b,this['lastOperationId']=_0x20b11c;}['toJSON'](){return{'id':this['id'],'buffers':this['buffers'],'types':this['types'],'bundleVersion':this['bundleVersion'],'lastOperationId':this['lastOperationId']};}static['fromJSON'](_0xef211){return new CollaborativeEditingConnectMessage(_0xef211['id'],_0xef211['buffers'],_0xef211['types'],_0xef211['bundleVersion'],_0xef211['lastOperationId']);}}