/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x1fc1e8 from'./../../message.js';import _0x55f14f from'./../helpers/operationmetadatahelpers.js';import _0x4af127 from'../descriptors/operationmetadatadescriptor.js';export default class CollaborativeEditingUpdateMessage extends _0x1fc1e8{['id'];['buffers'];['types'];['baseVersion'];['metadata'];['lastOperationId'];static ['TYPE']='13';static ['READABLE_TYPE_NAME']='updateDocument';static ['DESCRIPTOR_NAME']='CollaborativeEditingUpdateMessage';static ['DESCRIPTOR']={'fields':{'id':{'type':'string','id':0x1},'baseVersion':{'type':'uint32','id':0x2},'buffers':{'rule':'repeated','type':'bytes','id':0x3},'types':{'rule':'repeated','type':'uint32','id':0x4},'metadata':{'rule':'repeated','type':'OperationMetadataDescriptor','id':0x6},'lastOperationId':{'type':'string','id':0x7}}};constructor(_0x1c40b7,_0x235f6e,_0x2f976b,_0x3445ce,_0x1cfd83=[],_0x2d8904=''){super(),this['id']=_0x1c40b7,this['buffers']=_0x235f6e,this['types']=_0x2f976b,this['baseVersion']=_0x3445ce,this['metadata']=_0x1cfd83,this['lastOperationId']=_0x2d8904;}get['data'](){return{'buffers':this['buffers'],'types':this['types'],'baseVersion':this['baseVersion'],'lastOperationId':this['lastOperationId']};}['toJSON'](){return{'id':this['id'],'buffers':this['buffers'],'types':this['types'],'baseVersion':this['baseVersion'],'metadata':_0x55f14f['removeUnnecessaryMetadata'](this['types'],this['metadata'])['map'](_0x4af127['toJSON']),'lastOperationId':this['lastOperationId']};}static['fromJSON'](_0x24f516){return new CollaborativeEditingUpdateMessage(_0x24f516['id'],_0x24f516['buffers'],_0x24f516['types'],_0x24f516['baseVersion'],_0x55f14f['prepareMetadataForOperations'](_0x24f516['types'],_0x24f516['metadata'])['map'](_0x4af127['fromJSON']),_0x24f516['lastOperationId']);}}