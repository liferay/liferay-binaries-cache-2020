/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x383701 from'./../../message.js';export default class GetDocumentDetailsResponse extends _0x383701{['lastDocumentSession'];['currentDocumentSession'];static ['DESCRIPTOR_NAME']='GetDocumentDetailsResponse';static ['DESCRIPTOR']={'fields':{'lastDocumentSessionId':{'type':'string','id':0x1},'lastDocumentSessionOperationId':{'type':'string','id':0x2},'currentDocumentSessionId':{'type':'string','id':0x3},'currentDocumentSessionVersion':{'type':'uint32','id':0x4},'currentDocumentSessionOperationId':{'type':'string','id':0x5}}};constructor(_0x5b0904,_0x3043e9){super(),this['lastDocumentSession']=_0x5b0904,this['currentDocumentSession']=_0x3043e9;}get['data'](){return{'lastDocumentSessionId':this['lastDocumentSession']?.['id'],'lastDocumentSessionOperationId':this['lastDocumentSession']?.['lastOperationId'],'currentDocumentSessionId':this['currentDocumentSession']?.['id'],'currentDocumentSessionVersion':this['currentDocumentSession']?.['version'],'currentDocumentSessionOperationId':this['currentDocumentSession']?.['lastOperationId']};}['toJSON'](){return{'lastDocumentSessionId':this['lastDocumentSession']?.['id'],'lastDocumentSessionOperationId':this['lastDocumentSession']?.['lastOperationId'],'currentDocumentSessionId':this['currentDocumentSession']?.['id'],'currentDocumentSessionVersion':this['currentDocumentSession']?.['version'],'currentDocumentSessionOperationId':this['currentDocumentSession']?.['lastOperationId']};}static['fromJSON'](_0x33b440){const _0x48c687=_0x33b440['lastDocumentSessionId']?{'id':_0x33b440['lastDocumentSessionId'],'lastOperationId':_0x33b440['lastDocumentSessionOperationId']}:void 0x0,_0x116c22=_0x33b440['currentDocumentSessionId']?{'lastOperationId':_0x33b440['currentDocumentSessionOperationId'],'version':_0x33b440['currentDocumentSessionVersion'],'id':_0x33b440['currentDocumentSessionId']}:void 0x0;return new GetDocumentDetailsResponse(_0x48c687,_0x116c22);}}