/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0xd699ca from'./../../message.js';import _0x2cfce5 from'./../helpers/operationmetadatahelpers.js';import _0x2c309d from'../descriptors/operationmetadatadescriptor.js';export default class CollaborativeEditingResponse extends _0xd699ca{['version'];['buffers'];['types'];['metadata'];['lastOperationId'];['lastOperationAcceptedAt'];static ['DESCRIPTOR_NAME']='CollaborativeEditingResponse';static ['DESCRIPTOR']={'fields':{'version':{'type':'uint32','id':0x1},'buffers':{'rule':'repeated','type':'bytes','id':0x2},'types':{'rule':'repeated','type':'uint32','id':0x3},'metadata':{'rule':'repeated','type':'OperationMetadataDescriptor','id':0x5},'lastOperationId':{'type':'string','id':0x6},'lastOperationAcceptedAt':{'type':'string','id':0x7}}};constructor(_0x41bd63,_0x977dee=[],_0x5f3195=[],_0x53117a=[],_0x2f7505='',_0x3366ab=null){super(),this['version']=_0x41bd63,this['buffers']=_0x977dee,this['types']=_0x5f3195,this['metadata']=_0x53117a,this['lastOperationId']=_0x2f7505,this['lastOperationAcceptedAt']=_0x3366ab;}get['data'](){return{'buffers':this['buffers'],'types':this['types'],'baseVersion':this['version']-this['types']['length'],'lastOperationId':this['lastOperationId'],'lastOperationAcceptedAt':this['lastOperationAcceptedAt']};}get['wereChangesApplied'](){return!this['types']?.['length'];}['toJSON'](){return{'version':this['version'],'buffers':this['buffers'],'types':this['types'],'metadata':_0x2cfce5['removeUnnecessaryMetadata'](this['types'],this['metadata'])['map'](_0x2c309d['toJSON']),'lastOperationId':this['lastOperationId'],'lastOperationAcceptedAt':this['lastOperationAcceptedAt']instanceof Date?this['lastOperationAcceptedAt']['toISOString']():this['lastOperationAcceptedAt']};}static['fromJSON'](_0x406170){return new CollaborativeEditingResponse(_0x406170['version'],_0x406170['buffers'],_0x406170['types'],_0x2cfce5['prepareMetadataForOperations'](_0x406170['types'],_0x406170['metadata'])['map'](_0x2c309d['fromJSON']),_0x406170['lastOperationId'],_0x406170['lastOperationAcceptedAt']?new Date(_0x406170['lastOperationAcceptedAt']):null);}static['create'](_0x5c27e8){return new CollaborativeEditingResponse(_0x5c27e8['version'],_0x5c27e8['buffers'],_0x5c27e8['types'],_0x5c27e8['metadata'],_0x5c27e8['lastOperationId'],_0x5c27e8['lastOperationAcceptedAt']?new Date(_0x5c27e8['lastOperationAcceptedAt']):null);}}