/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x510c0c from'./../../message.js';import _0x46597f from'../descriptors/revisiondescriptor.js';export default class RevisionHistoryUpdateRevisionsMessage extends _0x510c0c{['documentId'];['requestId'];['revisions'];static ['TYPE']='124';static ['READABLE_TYPE_NAME']='updateRevisions';static ['DESCRIPTOR_NAME']='RevisionHistoryUpdateRevisionsMessage';static ['DESCRIPTOR']={'fields':{'documentId':{'type':'string','id':0x1},'requestId':{'type':'uint32','id':0x2},'revisions':{'type':'RevisionDescriptor','id':0x3,'rule':'repeated'}}};constructor(_0xe85bc8,_0x5d7348,_0x3271e3){super(),this['documentId']=_0xe85bc8,this['requestId']=_0x5d7348,this['revisions']=_0x3271e3;}['toJSON'](){return{'documentId':this['documentId'],'requestId':this['requestId'],'revisions':this['revisions']['map'](_0x46597f['toJSON'])};}['toObject'](){return{'documentId':this['documentId'],'requestId':this['requestId'],'revisions':this['revisions']['map'](_0x46597f['toObject'])};}static['create'](_0x1d944a){return new RevisionHistoryUpdateRevisionsMessage(_0x1d944a['documentId'],_0x1d944a['requestId'],_0x1d944a['revisions']['map'](_0x46597f['create']));}static['fromJSON'](_0x295194){return new RevisionHistoryUpdateRevisionsMessage(_0x295194['documentId'],_0x295194['requestId'],_0x295194['revisions']['map'](_0x46597f['fromJSON']));}}