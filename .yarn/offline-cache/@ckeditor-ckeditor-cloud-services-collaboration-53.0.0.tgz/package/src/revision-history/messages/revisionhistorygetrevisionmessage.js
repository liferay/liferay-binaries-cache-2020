/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x56d0ce from'./../../message.js';export default class RevisionHistoryGetRevisionMessage extends _0x56d0ce{['documentId'];['revisionId'];static ['TYPE']='123';static ['READABLE_TYPE_NAME']='getRevision';static ['DESCRIPTOR_NAME']='RevisionHistoryGetRevisionMessage';static ['DESCRIPTOR']={'fields':{'documentId':{'type':'string','id':0x1},'revisionId':{'type':'string','id':0x2}}};constructor(_0x3c5d27,_0xe1e716){super(),this['documentId']=_0x3c5d27,this['revisionId']=_0xe1e716;}['toJSON'](){return{'documentId':this['documentId'],'revisionId':this['revisionId']};}static['fromJSON'](_0x4055d6){return new RevisionHistoryGetRevisionMessage(_0x4055d6['documentId'],_0x4055d6['revisionId']);}}