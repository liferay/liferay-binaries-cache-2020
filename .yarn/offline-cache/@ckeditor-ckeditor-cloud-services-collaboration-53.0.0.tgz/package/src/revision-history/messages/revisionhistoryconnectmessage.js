/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x4014fc from'./../../message.js';export default class RevisionHistoryConnectMessage extends _0x4014fc{['documentId'];static ['TYPE']='121';static ['READABLE_TYPE_NAME']='connectToRevisionHistory';static ['DESCRIPTOR_NAME']='RevisionHistoryConnectMessage';static ['DESCRIPTOR']={'fields':{'documentId':{'type':'string','id':0x1}}};constructor(_0x55473d){super(),this['documentId']=_0x55473d;}['toJSON'](){return{'documentId':this['documentId']};}static['fromJSON'](_0xfb9c61){return new RevisionHistoryConnectMessage(_0xfb9c61['documentId']);}}