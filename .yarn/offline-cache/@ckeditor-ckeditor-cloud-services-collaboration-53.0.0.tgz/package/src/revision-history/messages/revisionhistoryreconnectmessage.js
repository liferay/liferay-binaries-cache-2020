/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x38c8c8 from'./../../message.js';export default class RevisionHistoryReconnectMessage extends _0x38c8c8{['documentId'];['requestId'];static ['TYPE']='122';static ['READABLE_TYPE_NAME']='reconnectToRevisionHistory';static ['DESCRIPTOR_NAME']='RevisionHistoryReconnectMessage';static ['DESCRIPTOR']={'fields':{'documentId':{'type':'string','id':0x1},'requestId':{'type':'uint32','id':0x2}}};constructor(_0x19d978,_0x558cc2){super(),this['documentId']=_0x19d978,this['requestId']=_0x558cc2;}['toJSON'](){return{'documentId':this['documentId'],'requestId':this['requestId']};}static['fromJSON'](_0x27bcbb){return new RevisionHistoryReconnectMessage(_0x27bcbb['documentId'],_0x27bcbb['requestId']);}}