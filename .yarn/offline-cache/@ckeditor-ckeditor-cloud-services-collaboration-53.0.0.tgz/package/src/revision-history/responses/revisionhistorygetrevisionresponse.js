/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x5d2416 from'./../../message.js';import _0x33bcd7 from'../descriptors/revisiondescriptor.js';export default class RevisionHistoryGetRevisionResponse extends _0x5d2416{['revisionId'];['name'];['creatorId'];['authorsIds'];['createdAt'];['diffData'];['attributes'];['fromVersion'];['toVersion'];['isEmptyCurrent'];static ['DESCRIPTOR_NAME']='RevisionHistoryGetRevisionResponse';static ['DESCRIPTOR']=((()=>_0x33bcd7['DESCRIPTOR'])());constructor(_0x1f85c5,_0x5edb70,_0x3be736,_0x43592f,_0x2b57cb,_0x2ee3fa,_0xec761a,_0x4f52e9,_0x1b5d00,_0x595e3f){super(),this['revisionId']=_0x1f85c5,this['name']=_0x5edb70,this['creatorId']=_0x3be736,this['authorsIds']=_0x43592f,this['createdAt']=_0x2b57cb,this['diffData']=_0x2ee3fa,this['attributes']=_0xec761a,this['fromVersion']=_0x4f52e9,this['toVersion']=_0x1b5d00,this['isEmptyCurrent']=_0x595e3f;}['toJSON'](){return _0x33bcd7['toJSON'](this);}['toObject'](){return _0x33bcd7['toObject'](this);}static['create'](_0x43761b){return new RevisionHistoryGetRevisionResponse(_0x43761b['revisionId'],_0x43761b['name'],_0x43761b['creatorId'],_0x43761b['authorsIds'],_0x43761b['createdAt'],_0x43761b['diffData'],_0x43761b['attributes'],_0x43761b['fromVersion'],_0x43761b['toVersion'],_0x43761b['isEmptyCurrent']);}static['fromJSON'](_0x2cf836){return new RevisionHistoryGetRevisionResponse(_0x2cf836['revisionId'],_0x2cf836['name'],_0x2cf836['creatorId'],_0x2cf836['authorsIds']?JSON['parse'](_0x2cf836['authorsIds']):void 0x0,_0x2cf836['createdAt']?new Date(_0x2cf836['createdAt']):void 0x0,_0x2cf836['diffData'],_0x2cf836['attributes']?JSON['parse'](_0x2cf836['attributes']):void 0x0,_0x2cf836['fromVersion'],_0x2cf836['toVersion'],_0x2cf836['isEmptyCurrent']);}}