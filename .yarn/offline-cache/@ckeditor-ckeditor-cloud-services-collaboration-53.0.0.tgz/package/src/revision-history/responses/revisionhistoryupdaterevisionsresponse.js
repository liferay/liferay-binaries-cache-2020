/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0xb65f04 from'./../../message.js';export default class RevisionHistoryUpdateRevisionsResponse extends _0xb65f04{['requestId'];static ['DESCRIPTOR_NAME']='RevisionHistoryUpdateRevisionsResponse';static ['DESCRIPTOR']={'fields':{'requestId':{'type':'uint32','id':0x1}}};constructor(_0x2a8acd){super(),this['requestId']=_0x2a8acd;}['toJSON'](){return{'requestId':this['requestId']};}static['fromJSON'](_0x1d23a4){return new RevisionHistoryUpdateRevisionsResponse(_0x1d23a4['requestId']);}}