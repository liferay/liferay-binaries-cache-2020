/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x4941af from'./../../message.js';import _0x2f92f9 from'../descriptors/revisiondescriptor.js';export default class RevisionHistoryConnectResponse extends _0x4941af{['channel'];['requestId'];['revisions'];static ['DESCRIPTOR_NAME']='RevisionHistoryConnectResponse';static ['DESCRIPTOR']={'fields':{'channel':{'type':'string','id':0x1},'requestId':{'type':'uint32','id':0x2},'revisions':{'type':'RevisionDescriptor','id':0x3,'rule':'repeated'}}};constructor(_0x3c6ead,_0xacb538,_0x1a8eff){super(),this['channel']=_0x3c6ead,this['requestId']=_0xacb538,this['revisions']=_0x1a8eff;}['toJSON'](){return{'channel':this['channel'],'requestId':this['requestId'],'revisions':this['revisions']['map'](_0x2f92f9['toJSON'])};}['toObject'](){return{'channel':this['channel'],'requestId':this['requestId'],'revisions':this['revisions']['map'](_0x2f92f9['toObject'])};}static['fromJSON'](_0x212d5f){return new RevisionHistoryConnectResponse(_0x212d5f['channel'],_0x212d5f['requestId'],_0x212d5f['revisions']['map'](_0x2f92f9['fromJSON']));}}