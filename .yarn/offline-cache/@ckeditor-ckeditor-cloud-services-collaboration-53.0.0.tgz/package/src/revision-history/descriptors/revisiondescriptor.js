/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x2208e5 from'./../../descriptor.js';export default class RevisionDescriptor extends _0x2208e5{static ['DESCRIPTOR_NAME']='RevisionDescriptor';static ['DESCRIPTOR']={'fields':{'revisionId':{'type':'string','id':0x1},'name':{'type':'string','id':0x2},'creatorId':{'type':'string','id':0x3},'authorsIds':{'type':'string','id':0x4},'diffData':{'type':'string','id':0x5},'createdAt':{'type':'string','id':0x6},'attributes':{'type':'string','id':0x7},'toVersion':{'type':'uint32','id':0x8},'fromVersion':{'type':'uint32','id':0x9},'isEmptyCurrent':{'type':'bool','id':0xa}}};static['create'](_0x2848c7){return{'revisionId':_0x2848c7['id'],'name':_0x2848c7['name'],'creatorId':_0x2848c7['creatorId'],'createdAt':_0x2848c7['createdAt'],'fromVersion':_0x2848c7['fromVersion'],'toVersion':_0x2848c7['toVersion'],'isEmptyCurrent':_0x2848c7['isEmptyCurrent'],'diffData':_0x2848c7['diffData']?JSON['stringify'](_0x2848c7['diffData']):void 0x0,'attributes':_0x2848c7['attributes'],'authorsIds':_0x2848c7['authorsIds']};}static['toJSON'](_0x30e660){return{'revisionId':_0x30e660['revisionId'],'name':_0x30e660['name'],'creatorId':_0x30e660['creatorId'],'authorsIds':_0x30e660['authorsIds']?JSON['stringify'](_0x30e660['authorsIds']):void 0x0,'diffData':_0x30e660['diffData'],'createdAt':_0x30e660['createdAt']?.['toISOString'](),'attributes':_0x30e660['attributes']?JSON['stringify'](_0x30e660['attributes']):void 0x0,'toVersion':_0x30e660['toVersion'],'fromVersion':_0x30e660['fromVersion'],'isEmptyCurrent':_0x30e660['isEmptyCurrent']};}static['fromJSON'](_0x57f5b7){return{'revisionId':(_0x57f5b7={..._0x57f5b7})['revisionId'],'name':_0x57f5b7['name'],'creatorId':_0x57f5b7['creatorId'],'authorsIds':_0x57f5b7['authorsIds']?JSON['parse'](_0x57f5b7['authorsIds']):void 0x0,'diffData':_0x57f5b7['diffData'],'createdAt':_0x57f5b7['createdAt']?new Date(_0x57f5b7['createdAt']):void 0x0,'attributes':_0x57f5b7['attributes']?JSON['parse'](_0x57f5b7['attributes']):void 0x0,'toVersion':_0x57f5b7['toVersion'],'fromVersion':_0x57f5b7['fromVersion'],'isEmptyCurrent':_0x57f5b7['isEmptyCurrent']};}static['toObject'](_0x170a45){return function(_0x5ba673){for(const [_0x45c7fa,_0x5ee146]of Object['entries'](_0x5ba673))void 0x0===_0x5ee146&&delete _0x5ba673[_0x45c7fa];return _0x5ba673;}({'id':_0x170a45['revisionId'],'name':_0x170a45['name'],'creatorId':_0x170a45['creatorId'],'createdAt':_0x170a45['createdAt'],'fromVersion':_0x170a45['fromVersion'],'toVersion':_0x170a45['toVersion'],'isEmptyCurrent':_0x170a45['isEmptyCurrent'],'diffData':_0x170a45['diffData']?JSON['parse'](_0x170a45['diffData']):void 0x0,'attributes':_0x170a45['attributes'],'authorsIds':_0x170a45['authorsIds']});}}