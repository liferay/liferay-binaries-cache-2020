/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
export default class CKEditorCloudServicesServerError extends Error{['code'];['traceId'];['data'];constructor(_0x1ff876,_0xd32753){super(),this['name']='CKEditorCloudServicesServerError',this['stack']=void 0x0,this['message']=_0x1ff876,this['code']=_0xd32753['code'],this['traceId']=_0xd32753['traceId'],this['data']=_0xd32753['data'];}static['fromPublicError'](_0x40ea10){return new CKEditorCloudServicesServerError(function(_0xc66bab){let _0x2b0391='cloud-services-server-error:\x20'+_0xc66bab['message'];return _0xc66bab['explanation']&&(_0x2b0391+='\x0aExplanation:\x20'+_0xc66bab['explanation']),_0xc66bab['action']&&(_0x2b0391+='\x0aAction:\x20'+_0xc66bab['action']),_0xc66bab['traceId']&&(_0x2b0391+='\x0aTraceId:\x20'+_0xc66bab['traceId']),_0xc66bab['code']&&(_0x2b0391+='\x0aCode:\x20'+_0xc66bab['code']),_0x2b0391;}(_0x40ea10),_0x40ea10);}}