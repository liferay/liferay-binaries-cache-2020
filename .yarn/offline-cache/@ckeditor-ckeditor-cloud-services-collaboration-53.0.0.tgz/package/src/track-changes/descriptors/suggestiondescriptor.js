/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x298188 from'./../../descriptor.js';export default class SuggestionDescriptor extends _0x298188{static ['DESCRIPTOR_NAME']='SuggestionDescriptor';static ['DESCRIPTOR']={'fields':{'id':{'id':0x1,'type':'string'},'authorId':{'id':0x2,'type':'string'},'type':{'id':0x3,'type':'string'},'createdAt':{'id':0x4,'type':'string'},'data':{'id':0x5,'type':'string'},'hasComments':{'id':0x6,'type':'bool'},'state':{'id':0x7,'type':'string'},'attributes':{'id':0x8,'type':'string'}}};static['toJSON'](_0x4b3e65){return{..._0x4b3e65,'data':_0x4b3e65['data']?JSON['stringify'](_0x4b3e65['data']):_0x4b3e65['data'],'attributes':_0x4b3e65['attributes']?JSON['stringify'](_0x4b3e65['attributes']):_0x4b3e65['attributes'],'createdAt':_0x4b3e65['createdAt']?.['toISOString']()};}static['fromJSON'](_0x3afce1){return{..._0x3afce1,'data':_0x3afce1['data']?JSON['parse'](_0x3afce1['data']):_0x3afce1['data'],'attributes':_0x3afce1['attributes']?JSON['parse'](_0x3afce1['attributes']):_0x3afce1['attributes'],'createdAt':_0x3afce1['createdAt']?new Date(_0x3afce1['createdAt']):void 0x0};}}