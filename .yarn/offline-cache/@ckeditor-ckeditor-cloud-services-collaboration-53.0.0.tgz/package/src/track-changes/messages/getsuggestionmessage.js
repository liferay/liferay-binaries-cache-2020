/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x38c582 from'./../../message.js';export default class GetSuggestionMessage extends _0x38c582{['id'];['documentId'];static ['TYPE']='103';static ['READABLE_TYPE_NAME']='getSuggestion';static ['DESCRIPTOR_NAME']='TrackChangesGetSuggestionMessage';static ['DESCRIPTOR']={'fields':{'id':{'type':'string','id':0x1},'documentId':{'type':'string','id':0x2}}};constructor(_0x1057ea,_0x8e69e4){super(),this['id']=_0x1057ea,this['documentId']=_0x8e69e4;}['toJSON'](){return{'id':this['id'],'documentId':this['documentId']};}static['fromJSON'](_0x47269f){return new GetSuggestionMessage(_0x47269f['id'],_0x47269f['documentId']);}}