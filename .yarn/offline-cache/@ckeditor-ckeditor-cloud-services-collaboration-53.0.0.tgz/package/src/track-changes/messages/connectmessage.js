/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x192dea from'./../../message.js';export default class ConnectMessage extends _0x192dea{['documentId'];static ['TYPE']='105';static ['READABLE_TYPE_NAME']='connectToSuggestions';static ['DESCRIPTOR_NAME']='TrackChangesConnectMessage';static ['DESCRIPTOR']={'fields':{'documentId':{'type':'string','id':0x1}}};constructor(_0x57afec){super(),this['documentId']=_0x57afec;}['toJSON'](){return{'documentId':this['documentId']};}static['fromJSON'](_0x1ca20b){return new ConnectMessage(_0x1ca20b['documentId']);}}