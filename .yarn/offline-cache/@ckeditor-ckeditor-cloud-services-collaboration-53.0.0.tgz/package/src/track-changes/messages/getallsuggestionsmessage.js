/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x2b73cd from'./../../message.js';export default class GetAllSuggestionsMessage extends _0x2b73cd{['documentId'];static ['TYPE']='102';static ['READABLE_TYPE_NAME']='getAllSuggestions';static ['DESCRIPTOR_NAME']='TrackChangesGetAllSuggestionMessage';static ['DESCRIPTOR']={'fields':{'documentId':{'type':'string','id':0x1}}};constructor(_0x4e4e37){super(),this['documentId']=_0x4e4e37;}['toJSON'](){return{'documentId':this['documentId']};}static['fromJSON'](_0x58d5f8){return new GetAllSuggestionsMessage(_0x58d5f8['documentId']);}}