/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0xfc5389 from'./../../message.js';export default class UpdateSuggestionMessage extends _0xfc5389{['id'];['documentId'];['hasComments'];['isHasCommentsModified'];['state'];['attributes'];static ['TYPE']='104';static ['READABLE_TYPE_NAME']='updateSuggestion';static ['DESCRIPTOR_NAME']='TrackChangesUpdateSuggestionMessage';static ['DESCRIPTOR']={'fields':{'id':{'type':'string','id':0x1},'documentId':{'type':'string','id':0x2},'hasComments':{'type':'bool','id':0x3},'isHasCommentsModified':{'type':'bool','id':0x4},'state':{'type':'string','id':0x5},'attributes':{'type':'string','id':0x6}}};constructor(_0x3c07a3,_0x8822e5,_0x53690d,_0x560f91,_0x45b556,_0x3b12f7=null){super(),this['id']=_0x3c07a3,this['documentId']=_0x8822e5,this['hasComments']=_0x53690d,this['isHasCommentsModified']=_0x560f91,this['state']=_0x45b556,this['attributes']=_0x3b12f7;}['toJSON'](){return{'id':this['id'],'documentId':this['documentId'],'hasComments':this['hasComments'],'isHasCommentsModified':this['isHasCommentsModified'],'state':this['state'],'attributes':JSON['stringify'](this['attributes'])};}static['fromJSON'](_0x2f2e96){return new UpdateSuggestionMessage(_0x2f2e96['id'],_0x2f2e96['documentId'],_0x2f2e96['hasComments'],_0x2f2e96['isHasCommentsModified'],_0x2f2e96['state'],_0x2f2e96['attributes']?JSON['parse'](_0x2f2e96['attributes']):null);}}