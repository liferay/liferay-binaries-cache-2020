/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x29141d from'./../../message.js';export default class BatchUpdateSuggestionsStateMessage extends _0x29141d{['ids'];['documentId'];['state'];static ['TYPE']='106';static ['READABLE_TYPE_NAME']='batchUpdateSuggestionsState';static ['DESCRIPTOR_NAME']='TrackChangesBatchUpdateSuggestionsStateMessage';static ['DESCRIPTOR']={'fields':{'ids':{'type':'string','rule':'repeated','id':0x1},'documentId':{'type':'string','id':0x2},'state':{'type':'string','id':0x3}}};constructor(_0x43bb3c,_0x1ffe12,_0x5d63d0){super(),this['ids']=_0x43bb3c,this['documentId']=_0x1ffe12,this['state']=_0x5d63d0;}['toJSON'](){return{'ids':this['ids'],'documentId':this['documentId'],'state':this['state']};}static['fromJSON'](_0x56e2cb){return new BatchUpdateSuggestionsStateMessage(_0x56e2cb['ids'],_0x56e2cb['documentId'],_0x56e2cb['state']);}}