/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x1a501d from'./../../message.js';export default class AddSuggestionMessage extends _0x1a501d{['id'];['documentId'];['type'];['data'];['originalSuggestionId'];['attributes'];static ['TYPE']='101';static ['READABLE_TYPE_NAME']='addSuggestion';static ['DESCRIPTOR_NAME']='TrackChangesAddSuggestionMessage';static ['DESCRIPTOR']={'fields':{'id':{'type':'string','id':0x1},'documentId':{'type':'string','id':0x2},'type':{'type':'string','id':0x3},'data':{'type':'string','id':0x4},'originalSuggestionId':{'type':'string','id':0x5},'attributes':{'type':'string','id':0x6}}};constructor(_0x4f03a3,_0x30aa35,_0x55a3c7,_0x3c2301={},_0x5ec584=null,_0x9443f2=null){super(),this['id']=_0x4f03a3,this['documentId']=_0x30aa35,this['type']=_0x55a3c7,this['data']=_0x3c2301,this['originalSuggestionId']=_0x5ec584,this['attributes']=_0x9443f2;}['toJSON'](){return{'id':this['id'],'documentId':this['documentId'],'type':this['type'],'data':JSON['stringify'](this['data']),'originalSuggestionId':this['originalSuggestionId'],'attributes':JSON['stringify'](this['attributes'])};}static['fromJSON'](_0x28e3d5){return new AddSuggestionMessage(_0x28e3d5['id'],_0x28e3d5['documentId'],_0x28e3d5['type'],JSON['parse'](_0x28e3d5['data']),_0x28e3d5['originalSuggestionId']??null,_0x28e3d5['attributes']?JSON['parse'](_0x28e3d5['attributes']):null);}}