/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x23f6a0 from'./../../message.js';import _0x502f5a from'../descriptors/suggestiondescriptor.js';export default class GetAllSuggestionResponse extends _0x23f6a0{['_suggestions'];['_suggestionsV2'];['suggestions'];static ['DESCRIPTOR_NAME']='TrackChangesGetAllSuggestionsResponse';static ['DESCRIPTOR']={'fields':{'suggestions':{'type':'string','rule':'repeated','id':0x1},'suggestionsV2':{'type':'SuggestionDescriptor','rule':'repeated','id':0x2}}};constructor(_0x5184d0,_0x3601b9){super(),this['_suggestions']=_0x5184d0,this['_suggestionsV2']=_0x3601b9,this['suggestions']=_0x3601b9?.['length']?_0x3601b9:_0x5184d0;}['toJSON'](){return{'suggestions':this['_suggestions']?.['map'](_0x2df77b=>JSON['stringify'](_0x2df77b)),'suggestionsV2':this['_suggestionsV2']?.['map'](_0x502f5a['toJSON'])};}static['fromJSON'](_0xb9f0b4){return new GetAllSuggestionResponse(_0xb9f0b4['suggestions']?.['map'](_suggestionFromString),_0xb9f0b4['suggestionsV2']?.['map'](_0x502f5a['fromJSON']));}}function _suggestionFromString(_0x33205d){const _0x21ba81=JSON['parse'](_0x33205d);return _0x21ba81['createdAt']=_0x21ba81['createdAt']?new Date(_0x21ba81['createdAt']):void 0x0,_0x21ba81;}