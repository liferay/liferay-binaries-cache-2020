/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x27a11a from'./../../message.js';export default class GetSuggestionResponse extends _0x27a11a{['id'];['authorId'];['type'];['hasComments'];['state'];['data'];['attributes'];['createdAt'];static ['DESCRIPTOR_NAME']='TrackChangesGetSuggestionResponse';static ['DESCRIPTOR']={'fields':{'id':{'type':'string','id':0x1},'authorId':{'type':'string','id':0x2},'type':{'type':'string','id':0x3},'createdAt':{'type':'string','id':0x4},'data':{'type':'string','id':0x5},'hasComments':{'type':'bool','id':0x6},'state':{'type':'string','id':0x7},'attributes':{'type':'string','id':0x8}}};constructor(_0x3de1ed,_0x96b3f8,_0x29f74c,_0x2aed32,_0x568f34,_0xb2ca43,_0x3722b6={},_0x4f64c3=null){super(),this['id']=_0x3de1ed,this['authorId']=_0x96b3f8,this['type']=_0x29f74c,this['hasComments']=_0x568f34,this['state']=_0xb2ca43,this['data']=_0x3722b6,this['attributes']=_0x4f64c3,this['createdAt']=new Date(_0x2aed32);}['toJSON'](){return{'id':this['id'],'authorId':this['authorId'],'type':this['type'],'createdAt':this['createdAt']['toISOString'](),'data':JSON['stringify'](this['data']),'hasComments':this['hasComments'],'state':this['state'],'attributes':JSON['stringify'](this['attributes'])};}static['fromJSON'](_0x1a14f6){return new GetSuggestionResponse(_0x1a14f6['id'],_0x1a14f6['authorId'],_0x1a14f6['type'],_0x1a14f6['createdAt'],_0x1a14f6['hasComments'],_0x1a14f6['state'],JSON['parse'](_0x1a14f6['data']),_0x1a14f6['attributes']?JSON['parse'](_0x1a14f6['attributes']):null);}}