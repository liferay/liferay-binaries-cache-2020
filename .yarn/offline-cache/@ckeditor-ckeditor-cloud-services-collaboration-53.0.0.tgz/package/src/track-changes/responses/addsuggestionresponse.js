/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0xd47eda from'./../../message.js';export default class AddSuggestionResponse extends _0xd47eda{['id'];['authorId'];['type'];['hasComments'];['state'];['data'];['attributes'];['createdAt'];static ['DESCRIPTOR_NAME']='TrackChangesAddSuggestionResponse';static ['DESCRIPTOR']={'fields':{'id':{'type':'string','id':0x1},'authorId':{'type':'string','id':0x2},'type':{'type':'string','id':0x3},'createdAt':{'type':'string','id':0x4},'data':{'type':'string','id':0x5},'hasComments':{'type':'bool','id':0x6},'state':{'type':'string','id':0x7},'attributes':{'type':'string','id':0x8}}};constructor(_0x135eb7,_0x36cd2e,_0x299282,_0x156b4a,_0x15fcdb,_0x4c5563,_0x366887={},_0x49459e=null){super(),this['id']=_0x135eb7,this['authorId']=_0x36cd2e,this['type']=_0x299282,this['hasComments']=_0x15fcdb,this['state']=_0x4c5563,this['data']=_0x366887,this['attributes']=_0x49459e,this['createdAt']=_0x156b4a?new Date(_0x156b4a):void 0x0;}['toJSON'](){return{'id':this['id'],'authorId':this['authorId'],'type':this['type'],'createdAt':this['createdAt']?.['toISOString'](),'data':JSON['stringify'](this['data']),'hasComments':this['hasComments'],'state':this['state'],'attributes':JSON['stringify'](this['attributes'])};}static['fromJSON'](_0x12e050){return new AddSuggestionResponse(_0x12e050['id'],_0x12e050['authorId'],_0x12e050['type'],_0x12e050['createdAt'],_0x12e050['hasComments'],_0x12e050['state'],JSON['parse'](_0x12e050['data']),_0x12e050['attributes']?JSON['parse'](_0x12e050['attributes']):null);}}