/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x559a0f from'./../../message.js';import _0x2970d1 from'../descriptors/suggestiondescriptor.js';export default class ConnectResponse extends _0x559a0f{['channel'];['_suggestions'];['_suggestionsV2'];['suggestions'];static ['DESCRIPTOR_NAME']='TrackChangesConnectResponse';static ['DESCRIPTOR']={'fields':{'channel':{'type':'string','id':0x1},'suggestions':{'type':'string','rule':'repeated','id':0x2},'suggestionsV2':{'type':'SuggestionDescriptor','rule':'repeated','id':0x3}}};constructor(_0x4e925d,_0x53274d,_0x250b84){super(),this['channel']=_0x4e925d,this['_suggestions']=_0x53274d,this['_suggestionsV2']=_0x250b84,this['suggestions']=_0x250b84?.['length']?_0x250b84:_0x53274d;}['toJSON'](){return{'channel':this['channel'],'suggestions':this['_suggestions']?.['map'](_0x19bf5a=>JSON['stringify'](_0x19bf5a)),'suggestionsV2':this['_suggestionsV2']?.['map'](_0x2970d1['toJSON'])};}static['fromJSON'](_0x31abca){return new ConnectResponse(_0x31abca['channel'],_0x31abca['suggestions']?.['map'](_0x5eea31=>JSON['parse'](_0x5eea31)),_0x31abca['suggestionsV2']?.['map'](_0x2970d1['fromJSON']));}}