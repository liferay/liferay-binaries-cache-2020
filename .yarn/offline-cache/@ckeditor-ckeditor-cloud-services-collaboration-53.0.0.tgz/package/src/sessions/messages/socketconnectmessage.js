/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x1c7290 from'./../../message.js';export default class SocketConnectMessage extends _0x1c7290{['id'];['userId'];['role'];['permissions'];static ['TYPE']='32';static ['READABLE_TYPE_NAME']='connectSocket';static ['DESCRIPTOR_NAME']='SocketConnectMessage';static ['DESCRIPTOR']={'fields':{'id':{'type':'string','id':0x1},'userId':{'type':'string','id':0x2},'role':{'type':'string','id':0x3},'permissions':{'rule':'repeated','type':'string','id':0x4}}};constructor(_0x24b763,_0x416cdf,_0x4f8460,_0x101342){super(),this['id']=_0x24b763,this['userId']=_0x416cdf,this['role']=_0x4f8460,this['permissions']=_0x101342;}['toJSON'](){return{'id':this['id'],'userId':this['userId']??void 0x0,'role':this['role']??void 0x0,'permissions':this['permissions']??void 0x0};}static['fromJSON'](_0x50510d){return new SocketConnectMessage(_0x50510d['id'],_0x50510d['userId'],_0x50510d['role'],_0x50510d['permissions']);}}