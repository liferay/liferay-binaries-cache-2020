/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x4caed4 from'./sessioncollection.js';export default class Sessions{static async['getConnectedSessions'](_0x50614c,_0x3e3a33,_0x4df28e){const _0x3c9bc6=new _0x4caed4(_0x3e3a33,_0x4df28e);return await _0x3c9bc6['connect'](_0x50614c),_0x3c9bc6;}}