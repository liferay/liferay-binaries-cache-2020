/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x5f122d from'./../../message.js';export default class SessionsConnectResponse extends _0x5f122d{['channel'];['sockets'];static ['DESCRIPTOR_NAME']='SessionsConnectResponse';static ['DESCRIPTOR']={'fields':{'channel':{'type':'string','id':0x1},'sockets':{'rule':'repeated','type':'SessionsSocketDescriptor','id':0x2}}};constructor(_0x136612,_0x52aef4=[]){super(),this['channel']=_0x136612,this['sockets']=_0x52aef4;}['toJSON'](){return{'channel':this['channel'],'sockets':this['sockets']['map'](_0x1a5552=>({'user':_0x1a5552['userId'],'session':_0x1a5552['id'],'role':_0x1a5552['role'],'permissions':_0x1a5552['permissions']}))};}static['fromJSON'](_0x3f4f54){return new SessionsConnectResponse(_0x3f4f54['channel'],_0x3f4f54['sockets']['map'](_0x196af3=>({'id':_0x196af3['session'],'userId':_0x196af3['user'],'role':_0x196af3['role'],'permissions':_0x196af3['permissions']})));}}