/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
export default class CKEditorCloudServicesError extends Error{['context'];['code'];['data'];constructor(_0x224dd1,_0x2b0c9c,_0x19b391=null,_0x5e4ff4={}){super('cloud-services-internal-error:\x20'+_0x224dd1),this['context']=_0x2b0c9c,this['code']=_0x19b391,this['data']=_0x5e4ff4,this['name']='CKEditorError';}static['fromPublicError'](_0x147ba9){return new CKEditorCloudServicesError(function(_0x4450de){let _0x2d839c='cloud-services-error:\x20'+_0x4450de['message'];return _0x4450de['data']&&(_0x2d839c+='\x0aError\x20data:\x20'+JSON['stringify'](_0x4450de['data'])),_0x4450de['explanation']&&(_0x2d839c+='\x0aExplanation:\x20'+_0x4450de['explanation']),_0x4450de['action']&&(_0x2d839c+='\x0aAction:\x20'+_0x4450de['action']),_0x4450de['traceId']&&(_0x2d839c+='\x0aTraceId:\x20'+_0x4450de['traceId']),_0x4450de['code']&&(_0x2d839c+='\x0aCode:\x20'+_0x4450de['code']),_0x2d839c;}(_0x147ba9),_0x147ba9);}}