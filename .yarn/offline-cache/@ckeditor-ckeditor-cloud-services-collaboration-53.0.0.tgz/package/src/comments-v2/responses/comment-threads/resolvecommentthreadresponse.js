/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x560910 from'./../../../message.js';export default class ResolveCommentThreadResponse extends _0x560910{['commentThreadId'];['documentId'];['resolvedBy'];['resolvedAt'];static ['DESCRIPTOR_NAME']='CommentsV2ResolveCommentThreadResponse';static ['DESCRIPTOR']={'fields':{'commentThreadId':{'type':'string','id':0x1},'documentId':{'type':'string','id':0x2},'resolvedAt':{'type':'string','id':0x3},'resolvedBy':{'type':'string','id':0x4}}};constructor(_0x281cc1,_0x38670b,_0x2d50ec,_0x39e07e){super(),this['commentThreadId']=_0x281cc1,this['documentId']=_0x38670b,this['resolvedBy']=_0x2d50ec,this['resolvedAt']=new Date(_0x39e07e);}['toJSON'](){return{'commentThreadId':this['commentThreadId'],'documentId':this['documentId'],'resolvedBy':this['resolvedBy'],'resolvedAt':this['resolvedAt']['toISOString']()};}static['fromJSON'](_0x16c036){return new ResolveCommentThreadResponse(_0x16c036['commentThreadId'],_0x16c036['documentId'],_0x16c036['resolvedBy'],_0x16c036['resolvedAt']);}}