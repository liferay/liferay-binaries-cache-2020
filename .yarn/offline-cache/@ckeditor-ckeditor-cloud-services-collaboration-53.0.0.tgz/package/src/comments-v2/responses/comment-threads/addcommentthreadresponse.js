/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x48daec from'./../../../message.js';import _0x5ecc25 from'../../descriptors/commentthreadaddedcomment.js';export default class AddCommentThreadResponse extends _0x48daec{['commentThreadId'];['comments'];['createdAt'];static ['DESCRIPTOR_NAME']='CommentsV2AddCommentThreadResponse';static ['DESCRIPTOR']={'fields':{'commentThreadId':{'type':'string','id':0x1},'createdAt':{'type':'string','id':0x2},'comments':{'type':'CommentThreadAddedCommentDescriptor','rule':'repeated','id':0x3}}};constructor(_0x5c4721,_0x5db865,_0x5f0b09=[]){super(),this['commentThreadId']=_0x5c4721,this['comments']=_0x5f0b09,this['createdAt']=new Date(_0x5db865);}['toJSON'](){return{'commentThreadId':this['commentThreadId'],'createdAt':this['createdAt']['toISOString'](),'comments':this['comments']['map'](_0x51292b=>_0x5ecc25['toJSON'](_0x51292b))};}static['fromJSON'](_0x585e45){return new AddCommentThreadResponse(_0x585e45['commentThreadId'],_0x585e45['createdAt'],_0x585e45['comments']['map'](_0x401b55=>_0x5ecc25['fromJSON'](_0x401b55)));}}