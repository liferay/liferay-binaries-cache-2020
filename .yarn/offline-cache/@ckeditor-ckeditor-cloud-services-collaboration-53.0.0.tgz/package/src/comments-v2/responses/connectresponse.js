/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x135514 from'./../../message.js';import _0x2c0d83 from'../descriptors/commentsthreaddescriptor.js';export default class ConnectResponse extends _0x135514{['channel'];['_threads'];['_threadsV2'];['threads'];static ['DESCRIPTOR_NAME']='CommentsV2ConnectResponse';static ['DESCRIPTOR']={'fields':{'channel':{'type':'string','id':0x1},'threads':{'type':'string','rule':'repeated','id':0x2},'threadsV2':{'type':'CommentsThreadDescriptor','rule':'repeated','id':0x3}}};constructor(_0x24450f,_0x51f8e7,_0x85fb34){super(),this['channel']=_0x24450f,this['_threads']=_0x51f8e7,this['_threadsV2']=_0x85fb34,this['threads']=_0x85fb34?.['length']?_0x85fb34:_0x51f8e7;}['toJSON'](){return{'channel':this['channel'],'threads':this['_threads']?.['map'](_0x58c278=>JSON['stringify'](_0x58c278)),'threadsV2':this['_threadsV2']?.['map'](_0x2c0d83['toJSON'])};}static['fromJSON'](_0x57b361){return new ConnectResponse(_0x57b361['channel'],_0x57b361['threads']?.['map'](_0x4ff9e9=>JSON['parse'](_0x4ff9e9)),_0x57b361['threadsV2']?.['map'](_0x2c0d83['fromJSON']));}}