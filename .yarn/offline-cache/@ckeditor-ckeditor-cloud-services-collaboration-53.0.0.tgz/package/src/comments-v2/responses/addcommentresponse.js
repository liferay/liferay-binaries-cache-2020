/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0xfd5cda from'./../../message.js';export default class AddCommentResponse extends _0xfd5cda{['commentThreadId'];['commentId'];['createdAt'];static ['DESCRIPTOR_NAME']='CommentsV2AddCommentResponse';static ['DESCRIPTOR']={'fields':{'commentThreadId':{'type':'string','id':0x1},'commentId':{'type':'string','id':0x2},'createdAt':{'type':'string','id':0x3}}};constructor(_0x2edcb2,_0x4cf441,_0x108370){super(),this['commentThreadId']=_0x2edcb2,this['commentId']=_0x4cf441,this['createdAt']=new Date(_0x108370);}['toJSON'](){return{'commentThreadId':this['commentThreadId'],'commentId':this['commentId'],'createdAt':this['createdAt']['toISOString']()};}static['fromJSON'](_0x2d286a){return new AddCommentResponse(_0x2d286a['commentThreadId'],_0x2d286a['commentId'],_0x2d286a['createdAt']);}}