/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0xa08a55 from'./../../message.js';import _0x465b05 from'../descriptors/commentdescriptor.js';export default class GetCommentThreadResponse extends _0xa08a55{['commentThreadId'];['_comments'];['_commentsV2'];['resolvedBy'];['comments'];['createdAt'];['deletedAt'];['resolvedAt'];['attributes'];['context'];['unlinkedAt'];static ['DESCRIPTOR_NAME']='CommentsV2GetCommentThreadResponse';static ['DESCRIPTOR']={'fields':{'commentThreadId':{'type':'string','id':0x1},'comments':{'type':'string','rule':'repeated','id':0x2},'commentsV2':{'type':'CommentDescriptor','rule':'repeated','id':0x3},'resolvedAt':{'type':'string','id':0x4},'resolvedBy':{'type':'string','id':0x5},'context':{'type':'string','id':0x6},'createdAt':{'type':'string','id':0x7},'deletedAt':{'type':'string','id':0x8},'attributes':{'type':'string','id':0x9},'unlinkedAt':{'type':'string','id':0xa}}};constructor(_0x475118,_0x4a91f0,_0x42e300,_0x1484fe,_0x523feb,_0x107621,_0xd19ec3,_0x587652,_0x103445,_0x40f845){super(),this['commentThreadId']=_0x475118,this['_comments']=_0x4a91f0,this['_commentsV2']=_0x42e300,this['resolvedBy']=_0x523feb,this['comments']=_0x42e300?.['length']?_0x42e300:_0x4a91f0,this['createdAt']=_0xd19ec3?new Date(_0xd19ec3):void 0x0,this['deletedAt']='string'==typeof _0x587652?new Date(_0x587652):_0x587652,this['resolvedAt']='string'==typeof _0x103445?new Date(_0x103445):_0x103445,this['unlinkedAt']='string'==typeof _0x40f845?new Date(_0x40f845):_0x40f845,this['attributes']='string'==typeof _0x1484fe?JSON['parse'](_0x1484fe):_0x1484fe,this['context']='string'==typeof _0x107621?JSON['parse'](_0x107621):_0x107621;}['toJSON'](){return{'commentThreadId':this['commentThreadId'],'comments':this['_comments']?.['map'](_0x4343dc=>JSON['stringify'](_0x4343dc)),'commentsV2':this['_commentsV2']?.['map'](_0x465b05['toJSON']),'attributes':this['attributes']?JSON['stringify'](this['attributes']):this['attributes'],'context':this['context']?JSON['stringify'](this['context']):this['context'],'resolvedBy':this['resolvedBy'],'createdAt':this['createdAt']?.['toISOString'](),'deletedAt':this['deletedAt']?.['toISOString'](),'resolvedAt':this['resolvedAt']?.['toISOString'](),'unlinkedAt':this['unlinkedAt']?.['toISOString']()};}static['fromJSON'](_0x2a0f83){return new GetCommentThreadResponse(_0x2a0f83['commentThreadId'],_0x2a0f83['comments']?.['map'](_0x40c79d=>function(_0xc8e3e1){const _0x4b6ab5=JSON['parse'](_0xc8e3e1);return{..._0x4b6ab5,'createdAt':new Date(_0x4b6ab5['createdAt'])};}(_0x40c79d)),_0x2a0f83['commentsV2']?.['map'](_0x465b05['fromJSON']),_0x2a0f83['attributes']?JSON['parse'](_0x2a0f83['attributes']):_0x2a0f83['attributes'],_0x2a0f83['resolvedBy'],_0x2a0f83['context']?JSON['parse'](_0x2a0f83['context']):_0x2a0f83['context'],_0x2a0f83['createdAt'],_0x2a0f83['deletedAt'],_0x2a0f83['resolvedAt'],_0x2a0f83['unlinkedAt']);}}