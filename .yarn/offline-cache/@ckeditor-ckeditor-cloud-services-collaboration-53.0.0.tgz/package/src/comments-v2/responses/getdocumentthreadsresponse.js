/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x20aa65 from'./../../message.js';import _0x4e4e00 from'../descriptors/commentsthreaddescriptor.js';export default class GetDocumentThreadsResponse extends _0x20aa65{['_threads'];['_threadsV2'];['threads'];static ['DESCRIPTOR_NAME']='CommentsV2GetDocumentThreadsResponse';static ['DESCRIPTOR']={'fields':{'threads':{'type':'string','rule':'repeated','id':0x1},'threadsV2':{'type':'CommentsThreadDescriptor','rule':'repeated','id':0x2}}};constructor(_0x2e07fd,_0x34622a){super(),this['_threads']=_0x2e07fd,this['_threadsV2']=_0x34622a,this['threads']=_0x34622a?.['length']?_0x34622a:_0x2e07fd;}['toJSON'](){return{'threads':this['_threads']?.['map'](_0x121a19=>JSON['stringify'](_0x121a19)),'threadsV2':this['_threadsV2']?.['map'](_0x4e4e00['toJSON'])};}static['fromJSON'](_0x43efae){return new GetDocumentThreadsResponse(_0x43efae['threads']?.['map'](_0x494abd=>function(_0x48b57c){const _0x1146ca=JSON['parse'](_0x48b57c),_0x45a870={..._0x1146ca};return _0x1146ca['comments']&&(_0x45a870['comments']=_0x1146ca['comments']?.['map'](_0x552e4f=>({..._0x552e4f,'createdAt':new Date(_0x552e4f['createdAt'])}))),_0x45a870;}(_0x494abd)),_0x43efae['threadsV2']?.['map'](_0x4e4e00['fromJSON']));}}