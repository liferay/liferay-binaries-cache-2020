/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x41fedb from'./../../descriptor.js';export default class CommentDescriptor extends _0x41fedb{static ['DESCRIPTOR_NAME']='CommentDescriptor';static ['DESCRIPTOR']={'fields':{'commentId':{'id':0x1,'type':'string'},'commentThreadId':{'id':0x2,'type':'string'},'userId':{'id':0x3,'type':'string'},'content':{'id':0x4,'type':'string'},'documentId':{'id':0x5,'type':'string'},'createdAt':{'id':0x6,'type':'string'},'attributes':{'id':0x7,'type':'string'}}};static['toJSON'](_0x3637e0){return{..._0x3637e0,'createdAt':_0x3637e0['createdAt']?.['toISOString'](),'attributes':_0x3637e0['attributes']?JSON['stringify'](_0x3637e0['attributes']):null};}static['fromJSON'](_0x282d65){return{..._0x282d65,'createdAt':new Date(_0x282d65['createdAt']),'attributes':_0x282d65['attributes']?JSON['parse'](_0x282d65['attributes']):null};}}