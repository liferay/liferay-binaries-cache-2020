/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x40b441 from'../../descriptor.js';export default class CommentThreadAddedCommentDescriptor extends _0x40b441{static ['DESCRIPTOR_NAME']='CommentThreadAddedCommentDescriptor';static ['DESCRIPTOR']={'fields':{'commentId':{'id':0x1,'type':'string'},'createdAt':{'id':0x2,'type':'string'}}};static['toJSON'](_0x362c5d){return{'commentId':_0x362c5d['commentId'],'createdAt':_0x362c5d['createdAt']?.['toISOString']()};}static['fromJSON'](_0x135660){return{'commentId':_0x135660['commentId'],'createdAt':new Date(_0x135660['createdAt'])};}}