/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x3b49e6 from'./../../descriptor.js';import _0x1f830b from'./commentdescriptor.js';export default class CommentsThreadDescriptor extends _0x3b49e6{static ['DESCRIPTOR_NAME']='CommentsThreadDescriptor';static ['DESCRIPTOR']={'fields':{'commentThreadId':{'type':'string','id':0x1},'comments':{'type':'CommentDescriptor','rule':'repeated','id':0x2},'resolvedAt':{'type':'string','id':0x3},'resolvedBy':{'type':'string','id':0x4},'context':{'type':'string','id':0x5},'createdAt':{'type':'string','id':0x6},'deletedAt':{'type':'string','id':0x7},'attributes':{'type':'string','id':0x8},'unlinkedAt':{'type':'string','id':0x9}}};static['toJSON'](_0x115242){return{..._0x115242,'createdAt':_0x115242['createdAt']?.['toISOString'](),'deletedAt':_0x115242['deletedAt']?.['toISOString'](),'resolvedAt':_0x115242['resolvedAt']?.['toISOString'](),'attributes':_0x115242['attributes']?JSON['stringify'](_0x115242['attributes']):null,'context':_0x115242['context']?JSON['stringify'](_0x115242['context']):_0x115242['context'],'comments':_0x115242['comments']?.['map'](_0x1f830b['toJSON']),'unlinkedAt':_0x115242['unlinkedAt']?.['toISOString']()};}static['fromJSON'](_0x37ccb7){return{..._0x37ccb7,'createdAt':_0x37ccb7['createdAt']?new Date(_0x37ccb7['createdAt']):void 0x0,'deletedAt':_0x37ccb7['deletedAt']?new Date(_0x37ccb7['deletedAt']):void 0x0,'resolvedAt':_0x37ccb7['resolvedAt']?new Date(_0x37ccb7['resolvedAt']):void 0x0,'attributes':_0x37ccb7['attributes']?JSON['parse'](_0x37ccb7['attributes']):null,'context':_0x37ccb7['context']?JSON['parse'](_0x37ccb7['context']):void 0x0,'comments':_0x37ccb7['comments']?.['map'](_0x1f830b['fromJSON']),'unlinkedAt':_0x37ccb7['unlinkedAt']?new Date(_0x37ccb7['unlinkedAt']):void 0x0};}}