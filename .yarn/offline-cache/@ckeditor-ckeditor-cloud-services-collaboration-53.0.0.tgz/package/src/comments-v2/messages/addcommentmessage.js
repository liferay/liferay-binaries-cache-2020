/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x923b12 from'./../../message.js';import _0x2d461f from'../descriptors/commentsthreaddescriptor.js';export default class AddCommentMessage extends _0x923b12{['documentId'];['commentThreadId'];['content'];['commentId'];['userId'];['attributes'];['commentThread'];['createdAt'];static ['TYPE']='91';static ['READABLE_TYPE_NAME']='addComment';static ['DESCRIPTOR_NAME']='CommentsV2AddCommentMessage';static ['DESCRIPTOR']={'fields':{'commentThreadId':{'type':'string','id':0x1},'content':{'type':'string','id':0x2},'documentId':{'type':'string','id':0x3},'commentId':{'type':'string','id':0x4},'createdAt':{'type':'string','id':0x5},'userId':{'type':'string','id':0x6},'attributes':{'type':'string','id':0x7},'commentThread':{'type':'CommentsThreadDescriptor','id':0x8}}};constructor(_0x39acc4,_0x39a856,_0x443ed4,_0x36f3b7='',_0x46dc7a,_0x22cfe7='',_0x17af8a=null,_0x5a7cdb){super(),this['documentId']=_0x39acc4,this['commentThreadId']=_0x39a856,this['content']=_0x443ed4,this['commentId']=_0x36f3b7,this['userId']=_0x22cfe7,this['attributes']=_0x17af8a,this['commentThread']=_0x5a7cdb,this['createdAt']=_0x46dc7a?new Date(_0x46dc7a):'';}['toJSON'](){return{'commentThreadId':this['commentThreadId'],'content':this['content'],'documentId':this['documentId'],'commentId':this['commentId'],'createdAt':this['createdAt']instanceof Date?this['createdAt']['toISOString']():this['createdAt'],'userId':this['userId'],'attributes':JSON['stringify'](this['attributes']),'commentThread':this['commentThread']?_0x2d461f['toJSON'](this['commentThread']):void 0x0};}static['fromJSON'](_0x13c7df){return new AddCommentMessage(_0x13c7df['documentId'],_0x13c7df['commentThreadId'],_0x13c7df['content'],_0x13c7df['commentId']?_0x13c7df['commentId']:void 0x0,_0x13c7df['createdAt']?new Date(_0x13c7df['createdAt']):void 0x0,_0x13c7df['userId']?_0x13c7df['userId']:void 0x0,_0x13c7df['attributes']?JSON['parse'](_0x13c7df['attributes']):{},_0x13c7df['commentThread']?_0x2d461f['fromJSON'](_0x13c7df['commentThread']):void 0x0);}}