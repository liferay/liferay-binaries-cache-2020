/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x23a8a9 from'./../../message.js';export default class GetDocumentThreadsMessage extends _0x23a8a9{['documentId'];static ['TYPE']='94';static ['READABLE_TYPE_NAME']='getDocumentThreads';static ['DESCRIPTOR_NAME']='CommentsV2GetDocumentThreadsMessage';static ['DESCRIPTOR']={'fields':{'documentId':{'type':'string','id':0x1}}};constructor(_0x2ea60c){super(),this['documentId']=_0x2ea60c;}['toJSON'](){return{'documentId':this['documentId']};}static['fromJSON'](_0x1a18d7){return new GetDocumentThreadsMessage(_0x1a18d7['documentId']);}}