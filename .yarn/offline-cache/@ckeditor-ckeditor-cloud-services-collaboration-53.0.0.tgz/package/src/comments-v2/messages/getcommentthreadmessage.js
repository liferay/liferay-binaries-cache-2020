/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x38acfd from'./../../message.js';export default class GetCommentThreadMessage extends _0x38acfd{['commentThreadId'];['documentId'];static ['TYPE']='93';static ['READABLE_TYPE_NAME']='getComment';static ['DESCRIPTOR_NAME']='CommentsV2GetCommentThreadMessage';static ['DESCRIPTOR']={'fields':{'commentThreadId':{'type':'string','id':0x1},'documentId':{'type':'string','id':0x2}}};constructor(_0x586675,_0x58d165){super(),this['commentThreadId']=_0x586675,this['documentId']=_0x58d165;}['toJSON'](){return{'commentThreadId':this['commentThreadId'],'documentId':this['documentId']};}static['fromJSON'](_0x19aeff){return new GetCommentThreadMessage(_0x19aeff['commentThreadId'],_0x19aeff['documentId']);}}