/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x28a340 from'./../../message.js';export default class RemoveCommentMessage extends _0x28a340{['documentId'];['commentThreadId'];['commentId'];static ['TYPE']='95';static ['READABLE_TYPE_NAME']='removeComment';static ['DESCRIPTOR_NAME']='CommentsV2RemoveCommentMessage';static ['DESCRIPTOR']={'fields':{'commentThreadId':{'type':'string','id':0x1},'commentId':{'type':'string','id':0x2},'documentId':{'type':'string','id':0x3}}};constructor(_0x228c1a,_0x50253f,_0x10c584){super(),this['documentId']=_0x228c1a,this['commentThreadId']=_0x50253f,this['commentId']=_0x10c584;}['toJSON'](){return{'documentId':this['documentId'],'commentThreadId':this['commentThreadId'],'commentId':this['commentId']};}static['fromJSON'](_0x2eccaa){return new RemoveCommentMessage(_0x2eccaa['documentId'],_0x2eccaa['commentThreadId'],_0x2eccaa['commentId']);}}