/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x3ee6b3 from'./../../message.js';export default class RemoveCommentThreadMessage extends _0x3ee6b3{['documentId'];['commentThreadId'];static ['TYPE']='97';static ['READABLE_TYPE_NAME']='removeCommentThread';static ['DESCRIPTOR_NAME']='CommentsV2RemoveCommentThreadMessage';static ['DESCRIPTOR']={'fields':{'commentThreadId':{'type':'string','id':0x1},'documentId':{'type':'string','id':0x2}}};constructor(_0x428737,_0x204735){super(),this['documentId']=_0x428737,this['commentThreadId']=_0x204735;}['toJSON'](){return{'documentId':this['documentId'],'commentThreadId':this['commentThreadId']};}static['fromJSON'](_0x5af9b6){return new RemoveCommentThreadMessage(_0x5af9b6['documentId'],_0x5af9b6['commentThreadId']);}}