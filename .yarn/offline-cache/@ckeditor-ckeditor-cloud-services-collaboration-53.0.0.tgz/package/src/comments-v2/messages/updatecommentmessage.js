/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x3cacd6 from'./../../message.js';import _0x8404da from'../descriptors/commentsthreaddescriptor.js';export default class UpdateCommentMessage extends _0x3cacd6{['documentId'];['commentThreadId'];['commentId'];['content'];['attributes'];['isAttributesUpdated'];['commentThread'];static ['TYPE']='96';static ['READABLE_TYPE_NAME']='updateComment';static ['DESCRIPTOR_NAME']='CommentsV2UpdateCommentMessage';static ['DESCRIPTOR']={'fields':{'commentThreadId':{'type':'string','id':0x1},'commentId':{'type':'string','id':0x2},'content':{'type':'string','id':0x3},'documentId':{'type':'string','id':0x4},'attributes':{'type':'string','id':0x5},'isAttributesUpdated':{'type':'bool','id':0x6},'commentThread':{'type':'CommentsThreadDescriptor','id':0x7}}};constructor(_0x25d4f2,_0x52a709,_0x197d81,_0x25017a,_0x3e1595=null,_0x41bb58=!0x1,_0xe8183d){super(),this['documentId']=_0x25d4f2,this['commentThreadId']=_0x52a709,this['commentId']=_0x197d81,this['content']=_0x25017a,this['attributes']=_0x3e1595,this['isAttributesUpdated']=_0x41bb58,this['commentThread']=_0xe8183d;}['toJSON'](){return{'documentId':this['documentId'],'commentThreadId':this['commentThreadId'],'commentId':this['commentId'],'content':this['content'],'attributes':this['attributes']?JSON['stringify'](this['attributes']):null,'isAttributesUpdated':this['isAttributesUpdated'],'commentThread':this['commentThread']?_0x8404da['toJSON'](this['commentThread']):void 0x0};}static['fromJSON'](_0x22c9c6){return new UpdateCommentMessage(_0x22c9c6['documentId'],_0x22c9c6['commentThreadId'],_0x22c9c6['commentId'],_0x22c9c6['content'],_0x22c9c6['attributes']?JSON['parse'](_0x22c9c6['attributes']):null,_0x22c9c6['isAttributesUpdated'],_0x22c9c6['commentThread']?_0x8404da['fromJSON'](_0x22c9c6['commentThread']):void 0x0);}}