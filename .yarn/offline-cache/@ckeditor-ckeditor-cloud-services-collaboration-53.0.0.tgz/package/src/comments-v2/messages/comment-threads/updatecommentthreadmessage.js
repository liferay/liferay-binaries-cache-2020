/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x1a503e from'../../../message.js';export default class UpdateCommentThreadMessage extends _0x1a503e{['commentThreadId'];['documentId'];['context'];['attributes'];['unlinkedAt'];static ['TYPE']='143';static ['READABLE_TYPE_NAME']='updateCommentThread';static ['DESCRIPTOR_NAME']='CommentsV2UpdateCommentThreadMessage';static ['DESCRIPTOR']={'fields':{'commentThreadId':{'type':'string','id':0x1},'documentId':{'type':'string','id':0x2},'context':{'type':'string','id':0x3},'attributes':{'type':'string','id':0x4},'unlinkedAt':{'type':'string','id':0x5}}};constructor(_0x14ea94,_0x3b8879,_0x43c045,_0x146ee5=null,_0x88d07d=null){super(),this['commentThreadId']=_0x14ea94,this['documentId']=_0x3b8879,this['context']=_0x43c045,this['attributes']=_0x146ee5,this['unlinkedAt']=_0x88d07d?new Date(_0x88d07d):'';}['toJSON'](){return{'documentId':this['documentId'],'commentThreadId':this['commentThreadId'],'context':this['context']?JSON['stringify'](this['context']):this['context'],'attributes':this['attributes']?JSON['stringify'](this['attributes']):null,'unlinkedAt':this['unlinkedAt']instanceof Date?this['unlinkedAt']['toISOString']():this['unlinkedAt']};}static['fromJSON'](_0x558c1d){return new UpdateCommentThreadMessage(_0x558c1d['commentThreadId'],_0x558c1d['documentId'],_0x558c1d['context']?JSON['parse'](_0x558c1d['context']):_0x558c1d['context'],_0x558c1d['attributes']?JSON['parse'](_0x558c1d['attributes']):null,_0x558c1d['unlinkedAt']?new Date(_0x558c1d['unlinkedAt']):null);}}