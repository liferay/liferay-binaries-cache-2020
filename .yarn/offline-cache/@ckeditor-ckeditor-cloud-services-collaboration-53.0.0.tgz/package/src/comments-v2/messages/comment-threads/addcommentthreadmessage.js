/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x300751 from'../../../message.js';import _0x27fe36 from'../../descriptors/commentdescriptor.js';export default class AddCommentThreadMessage extends _0x300751{['documentId'];['commentThreadId'];['comments'];['context'];['resolvedBy'];['attributes'];['createdAt'];['resolvedAt'];['deletedAt'];static ['TYPE']='140';static ['READABLE_TYPE_NAME']='addCommentThread';static ['DESCRIPTOR_NAME']='CommentsV2AddCommentThreadMessage';static ['DESCRIPTOR']={'fields':{'documentId':{'type':'string','id':0x1},'commentThreadId':{'type':'string','id':0x2},'context':{'type':'string','id':0x3},'createdAt':{'type':'string','id':0x4},'resolvedAt':{'type':'string','id':0x5},'resolvedBy':{'type':'string','id':0x6},'attributes':{'type':'string','id':0x7},'deletedAt':{'type':'string','id':0x8},'comments':{'type':'CommentDescriptor','rule':'repeated','id':0x9}}};constructor(_0x4d2501,_0xa4d11d,_0x43c4e0=[],_0x16db2f,_0x4165c3=null,_0x19f586=null,_0x12b29a=null,_0x254f01=null,_0x24e354=null){super(),this['documentId']=_0x4d2501,this['commentThreadId']=_0xa4d11d,this['comments']=_0x43c4e0,this['context']=_0x16db2f,this['resolvedBy']=_0x4165c3,this['attributes']=_0x24e354,this['createdAt']=_0x19f586?new Date(_0x19f586):'',this['resolvedAt']=_0x12b29a?new Date(_0x12b29a):'',this['deletedAt']=_0x254f01?new Date(_0x254f01):'';}['toJSON'](){return{'commentThreadId':this['commentThreadId'],'context':this['context']?JSON['stringify'](this['context']):this['context'],'documentId':this['documentId'],'resolvedBy':this['resolvedBy'],'resolvedAt':this['resolvedAt']instanceof Date?this['resolvedAt']['toISOString']():this['resolvedAt'],'deletedAt':this['deletedAt']instanceof Date?this['deletedAt']['toISOString']():this['deletedAt'],'createdAt':this['createdAt']instanceof Date?this['createdAt']['toISOString']():this['createdAt'],'attributes':this['attributes']?JSON['stringify'](this['attributes']):this['attributes'],'comments':this['comments']?.['map'](_0x33ce20=>_0x27fe36['toJSON'](_0x33ce20))};}static['fromJSON'](_0x57ed06){return new AddCommentThreadMessage(_0x57ed06['documentId'],_0x57ed06['commentThreadId'],_0x57ed06['comments']?.['map'](_0x3ec3c5=>_0x27fe36['fromJSON']({..._0x3ec3c5,'documentId':_0x57ed06['documentId'],'commentThreadId':_0x57ed06['commentThreadId']})),_0x57ed06['context']?JSON['parse'](_0x57ed06['context']):_0x57ed06['context'],_0x57ed06['resolvedBy'],_0x57ed06['createdAt']?new Date(_0x57ed06['createdAt']):void 0x0,_0x57ed06['resolvedAt']?new Date(_0x57ed06['resolvedAt']):void 0x0,_0x57ed06['deletedAt']?new Date(_0x57ed06['deletedAt']):void 0x0,_0x57ed06['attributes']?JSON['parse'](_0x57ed06['attributes']):_0x57ed06['attributes']);}}