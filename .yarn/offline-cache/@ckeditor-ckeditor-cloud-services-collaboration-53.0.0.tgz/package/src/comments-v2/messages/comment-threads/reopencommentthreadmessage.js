/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0xc6a4b5 from'../../../message.js';export default class ReopenCommentThreadMessage extends _0xc6a4b5{['commentThreadId'];['documentId'];static ['TYPE']='141';static ['READABLE_TYPE_NAME']='reopenCommentThread';static ['DESCRIPTOR_NAME']='CommentsV2ReopenCommentThreadMessage';static ['DESCRIPTOR']={'fields':{'commentThreadId':{'type':'string','id':0x1},'documentId':{'type':'string','id':0x2}}};constructor(_0x160a4d,_0x5cc224){super(),this['commentThreadId']=_0x160a4d,this['documentId']=_0x5cc224;}['toJSON'](){return{'documentId':this['documentId'],'commentThreadId':this['commentThreadId']};}static['fromJSON'](_0x182a39){return new ReopenCommentThreadMessage(_0x182a39['commentThreadId'],_0x182a39['documentId']);}}