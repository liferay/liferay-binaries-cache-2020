/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x444309 from'../../../message.js';export default class ResolveCommentThreadMessage extends _0x444309{['commentThreadId'];['documentId'];['resolvedBy'];['resolvedAt'];static ['TYPE']='142';static ['READABLE_TYPE_NAME']='resolveCommentThread';static ['DESCRIPTOR_NAME']='CommentsV2ResolveCommentThreadMessage';static ['DESCRIPTOR']={'fields':{'commentThreadId':{'type':'string','id':0x1},'documentId':{'type':'string','id':0x2},'resolvedBy':{'type':'string','id':0x3},'resolvedAt':{'type':'string','id':0x4}}};constructor(_0x1681f4,_0x3c163e,_0x1acde7,_0xf97a04){super(),this['commentThreadId']=_0x1681f4,this['documentId']=_0x3c163e,this['resolvedBy']=_0x1acde7,this['resolvedAt']=_0xf97a04?new Date(_0xf97a04):void 0x0;}['toJSON'](){return{'documentId':this['documentId'],'commentThreadId':this['commentThreadId'],'resolvedBy':this['resolvedBy'],'resolvedAt':this['resolvedAt']?.['toISOString']()};}static['fromJSON'](_0x11c28f){return new ResolveCommentThreadMessage(_0x11c28f['commentThreadId'],_0x11c28f['documentId'],_0x11c28f['resolvedBy'],_0x11c28f['resolvedAt']);}}