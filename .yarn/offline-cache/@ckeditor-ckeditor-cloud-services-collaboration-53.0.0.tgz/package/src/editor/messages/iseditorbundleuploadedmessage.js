/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x126667 from'./../../message.js';export default class IsEditorBundleUploadedMessage extends _0x126667{['bundleVersion'];static ['TYPE']='131';static ['READABLE_TYPE_NAME']='isEditorBundleUploaded';static ['DESCRIPTOR_NAME']='IsEditorBundleUploadedMessage';static ['DESCRIPTOR']={'fields':{'bundleVersion':{'type':'string','id':0x1}}};constructor(_0x1d97ae){super(),this['bundleVersion']=_0x1d97ae;}['toJSON'](){return{'bundleVersion':this['bundleVersion']};}static['fromJSON'](_0x25d1a1){return new IsEditorBundleUploadedMessage(_0x25d1a1['bundleVersion']);}}