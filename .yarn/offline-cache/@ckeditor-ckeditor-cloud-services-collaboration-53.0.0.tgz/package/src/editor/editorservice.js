/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import{EmitterMixin}from'ckeditor5/src/utils.js';import _0x47a2cb from'./../messagescompressor.js';import{WEB_SOCKET_GATEWAY_STATES}from'../websocketgateway/websocketgateway.js';import _0x55d0b5 from'./messages/iseditorbundleuploadedmessage.js';import _0x366313 from'./responses/iseditorbundleuploadedresponse.js';import _0x291034 from'../ckeditorcloudserviceserror.js';export const _SERVICE=0xd;class EditorService extends/* #__PURE__ -- @preserve */
EmitterMixin(){static ['_SERVICE']=0xd;static async['isBundleUploaded'](_0x50852d,_0x10100f){const _0x5be26c=new _0x55d0b5(_0x10100f);if(_0x50852d['state']!==WEB_SOCKET_GATEWAY_STATES['CONNECTED'])throw new _0x291034('WebSocket\x20Gateway\x20is\x20not\x20connected.',_0x50852d);const _0x52b0bb=await _0x50852d['_sendRequest'](EditorService['_SERVICE'],_0x55d0b5['TYPE'],_0x47a2cb['encode'](_0x5be26c));return _0x47a2cb['decode'](_0x52b0bb,_0x366313)['isUploaded'];}}export default EditorService;