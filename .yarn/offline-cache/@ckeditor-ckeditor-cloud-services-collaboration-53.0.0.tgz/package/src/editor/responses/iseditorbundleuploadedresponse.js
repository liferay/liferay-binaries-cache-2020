/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x514f62 from'./../../message.js';export default class IsEditorBundleUploadedResponse extends _0x514f62{['isUploaded'];static ['DESCRIPTOR_NAME']='IsEditorBundleUploadedResponse';static ['DESCRIPTOR']={'fields':{'isUploaded':{'type':'bool','id':0x1}}};constructor(_0x144c5a){super(),this['isUploaded']=_0x144c5a;}['toJSON'](){return{'isUploaded':this['isUploaded']};}static['fromJSON'](_0x4e9877){return new IsEditorBundleUploadedResponse(_0x4e9877['isUploaded']);}}