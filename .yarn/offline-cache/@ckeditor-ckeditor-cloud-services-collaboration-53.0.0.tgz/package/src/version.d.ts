declare const _default: "53.0.0";
export default _default;
