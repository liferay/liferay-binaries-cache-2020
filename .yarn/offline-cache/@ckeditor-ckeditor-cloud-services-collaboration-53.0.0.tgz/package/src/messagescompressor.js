/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x1bb827 from'./compiledmessages.js';export default class MessagesCompressor{static['decode'](_0xec2c90,_0x1f68d9){const _0x104a6f=_getType(_0x1f68d9)['decode']('undefined'==typeof window?_0xec2c90:new Uint8Array(_0xec2c90));return _0x1f68d9['fromJSON']({..._0x104a6f});}static['encode'](_0x406585){const _0x1d3f62=_getType(_0x406585['constructor']),_0xd0bca8=_0x406585['toJSON'](),_0x2aaf08=_0x1d3f62['verify'](_0xd0bca8);if(_0x2aaf08)throw Error(_0x2aaf08);return _0x1d3f62['encode'](_0x1d3f62['create'](_0xd0bca8))['finish']();}}function _getType(_0xe305a2){return _0x1bb827[_0xe305a2['DESCRIPTOR_NAME']];}