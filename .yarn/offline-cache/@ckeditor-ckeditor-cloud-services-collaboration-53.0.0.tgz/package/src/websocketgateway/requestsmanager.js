/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x187be9 from'../ckeditorcloudserviceserror.js';class WebSocketRequest{['_context'];['_deferredPromise']=(function(){let resolve,reject;const promise=new Promise((promiseResolve,promiseReject)=>{resolve=promiseResolve,reject=promiseReject;});return{'resolve':resolve,'reject':reject,'promise':promise};}());['timeout'];constructor(_0x2bbe0a,_0x466398){this['_context']=_0x2bbe0a,this['timeout']=setTimeout(()=>this['error'](new _0x187be9('Request\x20timeout.',this['_context'])),_0x466398);}get['promise'](){return this['_deferredPromise']['promise'];}['response'](_0xdfeb2f){this['_deferredPromise']['resolve'](_0xdfeb2f);}['error'](_0x3fbe33){this['_deferredPromise']['reject'](_0x3fbe33);}}export default class WebSocketGatewayRequestsManager{['_context'];['_requests']=new Set();constructor(_0x50ceb5){this['_context']=_0x50ceb5;}async['send'](_0x3d060c,_0x25542e=0xafc8){const _0x3198dd=this['_createRequest'](_0x25542e);try{return _0x3d060c(_0x3198dd),await _0x3198dd['promise'];}finally{this['_finishRequest'](_0x3198dd);}}['errorAll'](_0xb86b09){for(const _0x1fbe47 of this['_requests'])_0x1fbe47['error'](_0xb86b09);}['waitForAllRequests'](_0x1b6741=0xafc8){return this['_waitForRequests'](_0x1b6741);}['_createRequest'](_0x363c9a){const _0x2e04e4=new WebSocketRequest(this['_context'],_0x363c9a);return this['_requests']['add'](_0x2e04e4),_0x2e04e4;}['_finishRequest'](_0xb9294d){this['_requests']['delete'](_0xb9294d),clearTimeout(_0xb9294d['timeout']);}async['_waitForRequests'](_0x48fc24=0x1388,_0x37302a=0x0){return!this['_requests']['size']||_0x37302a>=_0x48fc24/0x1f4?Promise['resolve']():(await new Promise(_0x36426d=>{setTimeout(_0x36426d,0x1f4);}),this['_waitForRequests'](_0x48fc24,_0x37302a++));}}