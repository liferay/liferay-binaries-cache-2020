/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const IS_NODE=/* #__PURE__ -- @preserve */
((()=>!('undefined'==typeof process||!process['versions']?.['node']))());export const MessageDataTypes={'BUFFER':0x1,'STRING':0x2,'NUMBER':0x3,'OBJECT':0x4};export default class ParserUtils{static['getPacketType'](..._0x1c507f){let _0x79460d=0x0;for(let _0x233ba5=0x0;_0x233ba5<_0x1c507f['length'];_0x233ba5++){_0x79460d+=_0x1c507f[_0x233ba5]*Math['pow'](0xa,_0x1c507f['length']-_0x233ba5-0x1);}return _0x79460d;}static['getType'](_0x5dbf2b){if(ParserUtils['isBuffer'](_0x5dbf2b))return MessageDataTypes['BUFFER'];const _0x38a926=typeof _0x5dbf2b;return'string'===_0x38a926?MessageDataTypes['STRING']:'number'===_0x38a926?MessageDataTypes['NUMBER']:MessageDataTypes['OBJECT'];}static['isBuffer'](_0x2537e9){return IS_NODE&&Buffer['isBuffer'](_0x2537e9)||_0x2537e9 instanceof ArrayBuffer||_0x2537e9 instanceof Uint8Array||this['_isBufferView'](_0x2537e9);}static['_isBufferView'](_0x20be17){return'function'==typeof ArrayBuffer['isView']?ArrayBuffer['isView'](_0x20be17):_0x20be17['buffer']instanceof ArrayBuffer;}}