/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x27dd38 from'./packagedatamessage.js';import _0x1ee918,{MessageDataTypes}from'./../parserutils.js';export default class StringStringPacketDataMessage extends _0x27dd38{['data'];['data1'];static ['TYPE']=/* #__PURE__ -- @preserve */
((()=>_0x1ee918['getPacketType'](MessageDataTypes['STRING'],MessageDataTypes['STRING']))());static ['DESCRIPTOR_NAME']='StringStringPacketDataMessage';static ['DESCRIPTOR']={'fields':{'data':{'type':'string','id':0x1},'data1':{'type':'string','id':0x2}}};constructor(_0x21f24d,_0x2de5ca){super(),this['data']=_0x21f24d,this['data1']=_0x2de5ca;}['toJSON'](){return{'data':this['data'],'data1':this['data1']};}static['fromJSON'](_0x2a8d31){return new StringStringPacketDataMessage(_0x2a8d31['data'],_0x2a8d31['data1']);}static['create'](_0x2cbd3f,_0x330be2){return new StringStringPacketDataMessage(_0x2cbd3f,_0x330be2);}}