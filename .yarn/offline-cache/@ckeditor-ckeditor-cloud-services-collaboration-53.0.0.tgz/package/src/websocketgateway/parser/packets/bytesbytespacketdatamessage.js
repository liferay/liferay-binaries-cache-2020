/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x34817a from'./packagedatamessage.js';import _0x312939,{MessageDataTypes}from'./../parserutils.js';export default class BytesBytesPacketDataMessage extends _0x34817a{['data'];['data1'];static ['TYPE']=/* #__PURE__ -- @preserve */
((()=>_0x312939['getPacketType'](MessageDataTypes['BUFFER'],MessageDataTypes['BUFFER']))());static ['DESCRIPTOR_NAME']='BytesBytesPacketDataMessage';static ['DESCRIPTOR']={'fields':{'data':{'type':'bytes','id':0x1},'data1':{'type':'bytes','id':0x2}}};constructor(_0x3256a3,_0x13185b){super(),this['data']=_0x3256a3,this['data1']=_0x13185b;}['toJSON'](){return{'data':this['data'],'data1':this['data1']};}static['fromJSON'](_0x171f0c){return new BytesBytesPacketDataMessage(_0x171f0c['data'],_0x171f0c['data1']);}static['create'](_0x20db8a,_0x308b7b){return new BytesBytesPacketDataMessage(_0x20db8a,_0x308b7b);}}