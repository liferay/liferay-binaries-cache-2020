/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x10dc1c from'./packagedatamessage.js';import _0x52997b,{MessageDataTypes}from'./../parserutils.js';export default class NumberBytesPacketDataMessage extends _0x10dc1c{['data'];['data1'];static ['TYPE']=/* #__PURE__ -- @preserve */
((()=>_0x52997b['getPacketType'](MessageDataTypes['NUMBER'],MessageDataTypes['BUFFER']))());static ['DESCRIPTOR_NAME']='NumberBytesPacketDataMessage';static ['DESCRIPTOR']={'fields':{'data':{'type':'uint32','id':0x1},'data1':{'type':'bytes','id':0x2}}};constructor(_0x3b6ca3,_0x155365){super(),this['data']=_0x3b6ca3,this['data1']=_0x155365;}['toJSON'](){return{'data':this['data'],'data1':this['data1']};}static['fromJSON'](_0x1ce2be){return new NumberBytesPacketDataMessage(_0x1ce2be['data'],_0x1ce2be['data1']);}static['create'](_0x5b8b82,_0x3692b9){return new NumberBytesPacketDataMessage(_0x5b8b82,_0x3692b9);}}