/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x57d14a from'./packagedatamessage.js';import _0x186647,{MessageDataTypes}from'./../parserutils.js';export default class StringBytesPacketDataMessage extends _0x57d14a{['data'];['data1'];static ['TYPE']=/* #__PURE__ -- @preserve */
((()=>_0x186647['getPacketType'](MessageDataTypes['STRING'],MessageDataTypes['BUFFER']))());static ['DESCRIPTOR_NAME']='StringBytesPacketDataMessage';static ['DESCRIPTOR']={'fields':{'data':{'type':'string','id':0x1},'data1':{'type':'bytes','id':0x2}}};constructor(_0x48dfdf,_0x5a03a7){super(),this['data']=_0x48dfdf,this['data1']=_0x5a03a7;}['toJSON'](){return{'data':this['data'],'data1':this['data1']};}static['fromJSON'](_0x4ab5ea){return new StringBytesPacketDataMessage(_0x4ab5ea['data'],_0x4ab5ea['data1']);}static['create'](_0x39513d,_0x486f9e){return new StringBytesPacketDataMessage(_0x39513d,_0x486f9e);}}