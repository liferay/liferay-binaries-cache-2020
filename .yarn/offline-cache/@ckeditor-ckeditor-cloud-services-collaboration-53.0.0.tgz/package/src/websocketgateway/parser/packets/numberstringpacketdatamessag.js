/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x465676 from'./packagedatamessage.js';import _0x329904,{MessageDataTypes}from'./../parserutils.js';export default class NumberStringPacketDataMessage extends _0x465676{['data'];['data1'];static ['TYPE']=/* #__PURE__ -- @preserve */
((()=>_0x329904['getPacketType'](MessageDataTypes['NUMBER'],MessageDataTypes['STRING']))());static ['DESCRIPTOR_NAME']='NumberStringPacketDataMessage';static ['DESCRIPTOR']={'fields':{'data':{'type':'uint32','id':0x1},'data1':{'type':'string','id':0x2}}};constructor(_0x2a42ff,_0x101c5f){super(),this['data']=_0x2a42ff,this['data1']=_0x101c5f;}['toJSON'](){return{'data':this['data'],'data1':this['data1']};}static['fromJSON'](_0x52486f){return new NumberStringPacketDataMessage(_0x52486f['data'],_0x52486f['data1']);}static['create'](_0x2c7f35,_0x302653){return new NumberStringPacketDataMessage(_0x2c7f35,_0x302653);}}