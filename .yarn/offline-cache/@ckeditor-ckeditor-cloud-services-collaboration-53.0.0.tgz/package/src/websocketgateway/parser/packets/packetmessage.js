/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x31bd94 from'./../../../messagescompressor.js';import _0x25b9c0 from'./../../../message.js';import _0x22098c from'./packetoptionsmessage.js';import _0x259b62 from'./../parserutils.js';import _0x490fe4 from'./numberbytespacketdatamessage.js';import _0x2b299e from'./stringbytespacketdatamessage.js';import _0x361ea3 from'./bytesbytespacketdatamessage.js';import _0x14e66b from'./stringobjectpacketdatamessage.js';import _0x42cbd9 from'./numberobjectpacketdatamessage.js';import _0xd1fdc4 from'./objectobjectpacketdatamessage.js';import _0x1114e1 from'./objectbufferpacketdatamessage.js';import _0xcd186c from'./stringstringpacketdatamessage.js';import _0x2db721 from'./stringnumberpacketdatamessage.js';import _0x309755 from'./numbernumberpacketdatamessag.js';import _0x411115 from'./numberstringpacketdatamessag.js';const PACKET_DATA_MESSAGES=/* #__PURE__ -- @preserve */
((()=>[_0x490fe4,_0x2b299e,_0x361ea3,_0x14e66b,_0x42cbd9,_0xd1fdc4,_0x1114e1,_0xcd186c,_0x2db721,_0x309755,_0x411115]['reduce']((_0x1f7093,_0x2e1b23)=>(_0x1f7093[_0x2e1b23['TYPE']]=_0x2e1b23,_0x1f7093),{}))());export default class PacketMessage extends _0x25b9c0{['type'];['data'];['id'];['nsp'];['options'];static ['TYPE']=0xa;static ['DESCRIPTOR_NAME']='PacketMessage';static ['DESCRIPTOR']={'fields':{'type':{'type':'uint32','id':0x1},'id':{'type':'uint32','id':0x2},'nsp':{'type':'string','id':0x3},'data':{'type':'bytes','id':0x4},'options':{'type':'bytes','id':0x5}}};constructor(_0x1c9994,_0x695bca,_0x213150,_0x3e969a='/',_0x5383c4){super(),this['type']=_0x1c9994,this['data']=_0x695bca,this['id']=_0x213150,this['nsp']=_0x3e969a,this['options']=_0x5383c4??new _0x22098c();}get['packetData'](){return void 0x0===this['data']['data']&&void 0x0===this['data']['data1']?[]:this['data']['data']&&void 0x0===this['data']['data1']?[this['data']['data']]:[this['data']['data'],this['data']['data1']];}['toJSON'](){const _0x5c5023=_0x31bd94['encode'](this['options']),_0x1d697b=_0x31bd94['encode'](this['data']);return{'type':this['type']+0xa*this['data']['constructor']['TYPE'],'id':this['id'],'nsp':'/'===this['nsp']?void 0x0:this['nsp'],'data':_0x1d697b,'options':_0x5c5023};}static['fromJSON'](_0x423082){const _0x1eccb6=Math['floor'](_0x423082['type']/0xa);return new PacketMessage(_0x423082['type']-0xa*_0x1eccb6,_0x31bd94['decode'](_0x423082['data'],PACKET_DATA_MESSAGES[_0x1eccb6]),_0x423082['id'],_0x423082['nsp'],_0x423082['options']?_0x31bd94['decode'](_0x423082['options'],_0x22098c):new _0x22098c());}static['create'](_0x2c77ab,_0xe83319={}){const _0x35bf29=_0x259b62['getPacketType'](_0x259b62['getType'](_0x2c77ab['data'][0x0]),_0x259b62['getType'](_0x2c77ab['data'][0x1]??_0x2c77ab['data'][0x0]));return new PacketMessage(_0x2c77ab['type'],PACKET_DATA_MESSAGES[_0x35bf29]['create'](_0x2c77ab['data'][0x0],_0x2c77ab['data'][0x1]),_0x2c77ab['id'],_0x2c77ab['nsp'],new _0x22098c(_0xe83319['flags'],_0xe83319['rooms'],_0xe83319['except']));}}