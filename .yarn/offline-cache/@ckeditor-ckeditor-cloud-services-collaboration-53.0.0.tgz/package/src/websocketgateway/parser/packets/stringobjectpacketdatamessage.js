/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x2581cc from'./packagedatamessage.js';import _0x41c863,{MessageDataTypes}from'./../parserutils.js';export default class StringObjectPacketDataMessage extends _0x2581cc{['data'];['data1'];static ['TYPE']=/* #__PURE__ -- @preserve */
((()=>_0x41c863['getPacketType'](MessageDataTypes['STRING'],MessageDataTypes['OBJECT']))());static ['DESCRIPTOR_NAME']='StringObjectPacketDataMessage';static ['DESCRIPTOR']={'fields':{'data':{'type':'string','id':0x1},'data1':{'type':'string','id':0x2}}};constructor(_0x360fb7,_0x36fe80){super(),this['data']=_0x360fb7,this['data1']=_0x36fe80;}['toJSON'](){return{'data':this['data'],'data1':this['data1']?JSON['stringify'](this['data1']):void 0x0};}static['fromJSON'](_0x317a17){return new StringObjectPacketDataMessage(_0x317a17['data'],_0x317a17['data1']&&JSON['parse'](_0x317a17['data1']));}static['create'](_0x264c17,_0x5a286){return new StringObjectPacketDataMessage(_0x264c17,_0x5a286);}}