/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0xf118ae from'./../../../message.js';export default class PacketOptionsMessage extends _0xf118ae{['flags'];['rooms'];['except'];static ['TYPE']=0xb;static ['DESCRIPTOR_NAME']='PacketOptionsMessage';static ['DESCRIPTOR']={'fields':{'flags':{'type':'string','id':0x1},'rooms':{'type':'string','id':0x2,'rule':'repeated'},'except':{'type':'string','id':0x3,'rule':'repeated'}}};constructor(_0x299fee,_0x2df78d=[],_0x4b8796=[]){super(),this['flags']=_0x299fee,this['rooms']=_0x2df78d,this['except']=_0x4b8796;}['toJSON'](){return{'flags':this['flags']?JSON['stringify'](this['flags']):void 0x0,'rooms':this['rooms']?.['length']?this['rooms']:void 0x0,'except':this['except']?.['length']?this['except']:void 0x0};}static['fromJSON'](_0x2e4ffd){return new PacketOptionsMessage(_0x2e4ffd['flags']&&JSON['parse'](_0x2e4ffd['flags']),_0x2e4ffd['rooms'],_0x2e4ffd['except']);}}