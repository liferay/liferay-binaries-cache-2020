/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x480bbd from'./packagedatamessage.js';import _0x6f5177,{MessageDataTypes}from'./../parserutils.js';export default class NumberNumberPacketDataMessage extends _0x480bbd{['data'];['data1'];static ['TYPE']=/* #__PURE__ -- @preserve */
((()=>_0x6f5177['getPacketType'](MessageDataTypes['NUMBER'],MessageDataTypes['NUMBER']))());static ['DESCRIPTOR_NAME']='NumberNumberPacketDataMessage';static ['DESCRIPTOR']={'fields':{'data':{'type':'uint32','id':0x1},'data1':{'type':'uint32','id':0x2}}};constructor(_0x4eca76,_0x2b393d){super(),this['data']=_0x4eca76,this['data1']=_0x2b393d;}['toJSON'](){return{'data':this['data'],'data1':this['data1']};}static['fromJSON'](_0x6a3ce2){return new NumberNumberPacketDataMessage(_0x6a3ce2['data'],_0x6a3ce2['data1']);}static['create'](_0x18e5fb,_0x18f8d5){return new NumberNumberPacketDataMessage(_0x18e5fb,_0x18f8d5);}}