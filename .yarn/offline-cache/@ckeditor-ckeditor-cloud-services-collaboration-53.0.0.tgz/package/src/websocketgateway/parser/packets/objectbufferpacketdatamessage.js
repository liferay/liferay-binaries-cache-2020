/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0xb5397e from'./packagedatamessage.js';import _0x2f7828,{MessageDataTypes}from'./../parserutils.js';export default class ObjectBufferPacketDataMessage extends _0xb5397e{['data'];['data1'];static ['TYPE']=/* #__PURE__ -- @preserve */
((()=>_0x2f7828['getPacketType'](MessageDataTypes['OBJECT'],MessageDataTypes['BUFFER']))());static ['DESCRIPTOR_NAME']='ObjectBufferPacketDataMessage';static ['DESCRIPTOR']={'fields':{'data':{'type':'string','id':0x1},'data1':{'type':'bytes','id':0x2}}};constructor(_0x4e0d10,_0x1a8df8){super(),this['data']=_0x4e0d10,this['data1']=_0x1a8df8;}['toJSON'](){return{'data':this['data']?JSON['stringify'](this['data']):void 0x0,'data1':this['data1']};}static['fromJSON'](_0x45791c){return new ObjectBufferPacketDataMessage(_0x45791c['data']&&JSON['parse'](_0x45791c['data']),_0x45791c['data1']);}static['create'](_0x13c2a4,_0x45f89f){return new ObjectBufferPacketDataMessage(_0x13c2a4,_0x45f89f);}}