/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0xf0279d from'./packagedatamessage.js';import _0x57f3f0,{MessageDataTypes}from'./../parserutils.js';export default class NumberObjectPacketDataMessage extends _0xf0279d{['data'];['data1'];static ['TYPE']=/* #__PURE__ -- @preserve */
((()=>_0x57f3f0['getPacketType'](MessageDataTypes['NUMBER'],MessageDataTypes['OBJECT']))());static ['DESCRIPTOR_NAME']='NumberObjectPacketDataMessage';static ['DESCRIPTOR']={'fields':{'data':{'type':'uint32','id':0x1},'data1':{'type':'string','id':0x2}}};constructor(_0xdad90d,_0x23b878){super(),this['data']=_0xdad90d,this['data1']=_0x23b878;}['toJSON'](){return{'data':this['data'],'data1':this['data1']?JSON['stringify'](this['data1']):void 0x0};}static['fromJSON'](_0xe97835){return new NumberObjectPacketDataMessage(_0xe97835['data'],_0xe97835['data1']&&JSON['parse'](_0xe97835['data1']));}static['create'](_0x50504c,_0x5da768){return new NumberObjectPacketDataMessage(_0x50504c,_0x5da768);}}