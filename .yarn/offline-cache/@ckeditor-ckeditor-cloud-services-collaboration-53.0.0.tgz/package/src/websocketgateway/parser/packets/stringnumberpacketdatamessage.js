/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x5b0939 from'./packagedatamessage.js';import _0x4ffcba,{MessageDataTypes}from'./../parserutils.js';export default class StringNumberPacketDataMessage extends _0x5b0939{['data'];['data1'];static ['TYPE']=/* #__PURE__ -- @preserve */
((()=>_0x4ffcba['getPacketType'](MessageDataTypes['STRING'],MessageDataTypes['NUMBER']))());static ['DESCRIPTOR_NAME']='StringNumberPacketDataMessage';static ['DESCRIPTOR']={'fields':{'data':{'type':'string','id':0x1},'data1':{'type':'uint32','id':0x2}}};constructor(_0x1cd569,_0x4cbef4){super(),this['data']=_0x1cd569,this['data1']=_0x4cbef4;}['toJSON'](){return{'data':this['data'],'data1':this['data1']};}static['fromJSON'](_0x5e19c9){return new StringNumberPacketDataMessage(_0x5e19c9['data'],_0x5e19c9['data1']);}static['create'](_0xa0c34f,_0x18cc57){return new StringNumberPacketDataMessage(_0xa0c34f,_0x18cc57);}}