/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x4037aa from'./packagedatamessage.js';import _0x228ef8,{MessageDataTypes}from'./../parserutils.js';export default class ObjectObjectPacketDataMessage extends _0x4037aa{['data'];['data1'];static ['TYPE']=/* #__PURE__ -- @preserve */
((()=>_0x228ef8['getPacketType'](MessageDataTypes['OBJECT'],MessageDataTypes['OBJECT']))());static ['DESCRIPTOR_NAME']='ObjectObjectPacketDataMessage';static ['DESCRIPTOR']={'fields':{'data':{'type':'string','id':0x1},'data1':{'type':'string','id':0x2}}};constructor(_0x3855d2,_0x34715b){super(),this['data']=_0x3855d2,this['data1']=_0x34715b;}['toJSON'](){return{'data':this['data']?JSON['stringify'](this['data']):void 0x0,'data1':this['data1']?JSON['stringify'](this['data1']):void 0x0};}static['fromJSON'](_0xe0a751){return new ObjectObjectPacketDataMessage(_0xe0a751['data']&&JSON['parse'](_0xe0a751['data']),_0xe0a751['data1']&&JSON['parse'](_0xe0a751['data1']));}static['create'](_0x157489,_0x463e55){return new ObjectObjectPacketDataMessage(_0x157489,_0x463e55);}}