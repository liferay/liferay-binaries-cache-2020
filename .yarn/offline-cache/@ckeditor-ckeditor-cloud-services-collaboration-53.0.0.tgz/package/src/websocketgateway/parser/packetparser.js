/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x3b428b from'./packets/packetmessage.js';import _0x5a3be9 from'./../../messagescompressor.js';export default class PacketParser{['encode'](_0x5f3222,_0x41a485,_0xfd1d68,_0x574088='/',_0x27ca63={}){if(_0x41a485['length']>0x2)throw new Error('PacketParser\x20supports\x20only\x202\x20elements\x20in\x20data');const _0x140754={'type':_0x5f3222,'data':_0x41a485,'id':_0xfd1d68,'nsp':_0x574088};return _0x5a3be9['encode'](_0x3b428b['create'](_0x140754,_0x27ca63));}['decode'](_0x1e264c){const _0x419adb=_0x5a3be9['decode'](_0x1e264c,_0x3b428b);return{'packet':{'id':_0x419adb['id'],'type':_0x419adb['type'],'data':_0x419adb['packetData'],'nsp':_0x419adb['nsp']},'options':{'flags':_0x419adb['options']['flags'],'rooms':_0x419adb['options']['rooms'],'except':_0x419adb['options']['except']}};}}