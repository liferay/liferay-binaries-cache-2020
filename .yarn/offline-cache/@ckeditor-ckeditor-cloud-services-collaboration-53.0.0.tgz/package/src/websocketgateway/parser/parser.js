/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import{Decoder as _0x1006cf,Encoder as _0x285dc5,PacketType}from'socket.io-parser';import _0x364c7d from'./packetparser.js';import _0x3fdcea from'./parserutils.js';export const ENCODED_TYPES=/* #__PURE__ -- @preserve */
((()=>[PacketType['EVENT'],PacketType['ACK'],PacketType['BINARY_ACK'],PacketType['BINARY_EVENT']])());export class Encoder extends _0x285dc5{['_packetParser'];constructor(_0xed46da){super(),this['_packetParser']=_0xed46da??new _0x364c7d();}['encode'](_0x8a62eb){if(ENCODED_TYPES['includes'](_0x8a62eb['type']))try{return[this['_packetParser']['encode'](_0x8a62eb['type'],_0x8a62eb['data'],_0x8a62eb['id'],_0x8a62eb['nsp'])];}catch(_0x130c64){console['error']('Can\x20not\x20properly\x20serialize\x20or\x20deserialize\x20messages.\x20Check\x20the\x20original\x20error.',{'originalError':{'message':_0x130c64['message']}});}return super['encode'](_0x8a62eb);}}export class Decoder extends _0x1006cf{['_packetParser'];constructor(_0x27782c){super(),this['_packetParser']=_0x27782c??new _0x364c7d();}['add'](_0x37b9ff){if(!_0x3fdcea['isBuffer'](_0x37b9ff))return super['add'](_0x37b9ff);let _0x3dc35c;try{_0x3dc35c=this['_packetParser']['decode'](_0x37b9ff)['packet'];}catch(_0x5ad5a0){return super['add'](_0x37b9ff);}super['emitReserved']('decoded',_0x3dc35c);}}