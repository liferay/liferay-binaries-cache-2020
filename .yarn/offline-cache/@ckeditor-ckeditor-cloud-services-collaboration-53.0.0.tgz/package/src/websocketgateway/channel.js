/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import{EmitterMixin}from'ckeditor5/src/utils.js';import _0x12095c from'./../websocketgateway/messages/channelmessage.js';import _0xc90d55 from'./../messagescompressor.js';export default class extends/* #__PURE__ -- @preserve */
EmitterMixin(){['_channelName'];['_wsGateway'];['_socket'];constructor(_0x14d6e6,_0x2aa4dc,_0x1f8c7b){super(),this['_channelName']=_0x14d6e6,this['_wsGateway']=_0x2aa4dc,this['_socket']=_0x1f8c7b,this['_subscribeToChannel']();}['remove'](){this['_socket']['off'](this['_channelName']);}['getEventName'](_0x8187b0,_0x430359=!0x1){let _0x1b83af='';return _0x430359&&(_0x1b83af+='all:'),_0x1b83af+='event',_0x8187b0&&(_0x1b83af+=':'+_0x8187b0),_0x1b83af;}['_subscribeToChannel'](){this['_socket']['on'](this['_channelName'],_0x2801ef=>{const _0x56501b=_0xc90d55['decode'](_0x2801ef,_0x12095c);this['fire'](this['getEventName'](_0x56501b['type'],!0x0),_0x56501b['data'],_0x56501b['socketId']),_0x56501b['socketId']!==this['_wsGateway']['socketId']&&this['fire'](this['getEventName'](_0x56501b['type']),_0x56501b['data'],_0x56501b['socketId']);});}}