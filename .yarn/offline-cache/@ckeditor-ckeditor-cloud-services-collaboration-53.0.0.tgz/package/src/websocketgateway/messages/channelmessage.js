/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x5d2505 from'./../../message.js';export default class ChannelMessage extends _0x5d2505{['type'];['socketId'];['data'];static ['DESCRIPTOR_NAME']='ChannelMessage';static ['DESCRIPTOR']={'fields':{'type':{'type':'uint32','id':0x1},'socketId':{'type':'string','id':0x2},'data':{'type':'bytes','id':0x3}}};constructor(_0x33f7f9,_0x3e3dd2,_0x43901a){super(),this['type']=_0x33f7f9,this['socketId']=_0x3e3dd2,this['data']=_0x43901a;}['toJSON'](){return{'type':this['type'],'socketId':this['socketId'],'data':this['data']};}static['fromJSON'](_0x3c3379){return new ChannelMessage(_0x3c3379['type'],_0x3c3379['socketId'],_0x3c3379['data']);}}