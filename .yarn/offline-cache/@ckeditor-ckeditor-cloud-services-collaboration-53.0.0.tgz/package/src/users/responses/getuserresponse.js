/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x9bcda3 from'./../../message.js';export default class GetUserResponse extends _0x9bcda3{['attributes'];static ['DESCRIPTOR_NAME']='GetUserResponse';static ['DESCRIPTOR']={'fields':{'attributes':{'rule':'repeated','type':'KeyValueDescriptor','id':0x1}}};constructor(_0x1d789d){super(),this['attributes']=_0x1d789d;}['toJSON'](){return{'attributes':Object['keys'](this['attributes'])['map'](_0x377205=>({'key':_0x377205,'value':JSON['stringify'](this['attributes'][_0x377205])}))};}static['fromJSON'](_0x49fd92){const _0x7ea6b9=_0x49fd92['attributes']['reduce']((_0x3c35b4,_0x51154b)=>(_0x3c35b4[_0x51154b['key']]=_0x51154b['value']?JSON['parse'](_0x51154b['value']):null,_0x3c35b4),{});return new GetUserResponse(_0x7ea6b9);}}