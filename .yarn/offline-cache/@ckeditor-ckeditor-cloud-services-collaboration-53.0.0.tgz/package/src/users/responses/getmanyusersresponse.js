/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x1922bf from'./../../message.js';export default class GetManyUsersResponse extends _0x1922bf{['users'];static ['DESCRIPTOR_NAME']='GetManyUsersResponse';static ['DESCRIPTOR']={'fields':{'users':{'rule':'repeated','type':'UserDescriptor','id':0x1}}};constructor(_0x37dd05){super(),this['users']=_0x37dd05;}['toJSON'](){return{'users':this['users']['map'](_userToJson)};}static['fromJSON'](_0x1786dc){return new GetManyUsersResponse(_0x1786dc['users']['map'](_userFromJson));}}function _userToJson(_0x2309c5){return{'attributes':Object['keys'](_0x2309c5)['map'](_0x1c2f6b=>({'key':_0x1c2f6b,'value':JSON['stringify'](_0x2309c5[_0x1c2f6b])}))};}function _userFromJson(_0x7b0ccf){return _0x7b0ccf['attributes']['reduce']((_0x3a7b38,_0x3689ec)=>(_0x3a7b38[_0x3689ec['key']]=_0x3689ec['value']?JSON['parse'](_0x3689ec['value']):null,_0x3a7b38),{});}