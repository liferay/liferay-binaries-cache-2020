/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x561ee3 from'./../../descriptor.js';export default class UserDescriptor extends _0x561ee3{static ['DESCRIPTOR_NAME']='UserDescriptor';static ['DESCRIPTOR']={'fields':{'attributes':{'rule':'repeated','type':'KeyValueDescriptor','id':0x1}}};}