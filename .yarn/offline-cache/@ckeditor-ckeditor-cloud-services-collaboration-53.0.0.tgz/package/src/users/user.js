/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x5c4b8d from'./messages/getusermessage.js';import _0x79af5c from'./responses/getuserresponse.js';import _0x458aa0 from'./../messagescompressor.js';import _0x23f0aa from'./messages/getmanyusersmessage.js';import _0x472831 from'./responses/getmanyusersresponse.js';class User{static ['_SERVICE']=0x2;constructor(_0x1840d0={}){this['_attributes']=new Map();for(const _0x208a37 of Object['keys'](_0x1840d0))'id'!==_0x208a37?(this['_attributes']['set'](_0x208a37,_0x1840d0[_0x208a37]),Object['defineProperty'](this,_0x208a37,{'enumerable':!0x0,'configurable':!0x1,'get':()=>this['_attributes']['get'](_0x208a37)})):this['id']=_0x1840d0['id'];}static['fromData'](_0x2ff6a9){return new User(_0x2ff6a9);}static async['get'](_0x49ae55,_0x66a035){const _0x28ecb6=new _0x5c4b8d(_0x66a035);try{const _0x524707=await _0x49ae55['_sendRequest'](User['_SERVICE'],_0x5c4b8d['TYPE'],_0x458aa0['encode'](_0x28ecb6)),_0xe25b0a=_0x458aa0['decode'](_0x524707,_0x79af5c);return new User(_0xe25b0a['attributes']);}catch(_0x156df7){return new User({'id':_0x66a035});}}static async['getMany'](_0x8dce78,_0x448eb3){const _0x5876f5=new _0x23f0aa(_0x448eb3);try{const _0x40baa1=await _0x8dce78['_sendRequest'](User['_SERVICE'],_0x23f0aa['TYPE'],_0x458aa0['encode'](_0x5876f5));return _0x458aa0['decode'](_0x40baa1,_0x472831)['users']['map'](_0xaafab2=>new User(_0xaafab2));}catch(_0x9635d2){return _0x448eb3['map'](_0x256fdb=>new User({'id':_0x256fdb}));}}}export default User;