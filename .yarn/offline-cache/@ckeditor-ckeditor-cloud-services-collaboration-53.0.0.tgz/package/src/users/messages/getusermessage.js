/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import _0x457d78 from'./../../message.js';export default class GetUserMessage extends _0x457d78{['id'];static ['TYPE']='21';static ['READABLE_TYPE_NAME']='getUser';static ['DESCRIPTOR_NAME']='GetUserMessage';static ['DESCRIPTOR']={'fields':{'id':{'type':'string','id':0x1}}};constructor(_0x4c2a69){super(),this['id']=_0x4c2a69;}['toJSON'](){return{'id':this['id']};}static['fromJSON'](_0x4ce690){return new GetUserMessage(_0x4ce690['id']);}}