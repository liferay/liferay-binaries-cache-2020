/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module line-height/lineheightui
 */
import { Plugin } from 'ckeditor5/src/core.js';
import '../theme/lineheight.css';
/**
 * The line height UI plugin. It introduces the `'lineHeight'` dropdown.
 */
export declare class LineHeightUI extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "LineHeightUI";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    init(): void;
    /**
     * @inheritDoc
     */
    destroy(): void;
}
