/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module line-height/lineheightediting
 */
import { Plugin, type Editor } from 'ckeditor5/src/core.js';
/**
 * The line height editing feature.
 *
 * It introduces the {@link module:line-height/lineheightcommand~LineHeightCommand command} and the `lineHeight`
 * attribute in the {@link module:engine/model/model~Model model} which renders in the {@link module:engine/view/view view}
 * as a `style="line-height: ..."` style.
 */
export declare class LineHeightEditing extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "LineHeightEditing";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    constructor(editor: Editor);
    /**
     * @inheritDoc
     */
    init(): void;
    /**
     * @inheritDoc
     */
    afterInit(): void;
}
