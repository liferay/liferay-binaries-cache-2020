/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module line-height/lineheightconfig
 * @publicApi
 */
import type { DowncastAttributeDescriptor } from 'ckeditor5/src/engine.js';
/**
 * The configuration of the {@link module:line-height/lineheight~LineHeight} feature.
 *
 * Read more in {@link module:line-height/lineheightconfig~LineHeightConfig}.
 */
export interface LineHeightConfig {
    /**
     * Available line height options. The default value is:
     *
     * ```ts
     * const lineHeightConfig = {
     * 	options: [ 0.5, 1, 1.5, 2, 2.5 ]
     * };
     * ```
     *
     * **Note**: Line height values have to be provided in a format without units.
     * The available values are always multipliers of the default line height applied to the edited content.
     */
    options?: Array<string | number | LineHeightOption>;
    /**
     * By default, the plugin removes any `line-height` value that does not match the plugin's configuration.
     * It means that if you paste content with line heights that the editor does not understand, the `line-height` attribute
     * will be removed and the content will be displayed with the default line height.
     *
     * You can preserve pasted line heights values by switching the `supportAllValues` option to `true`:
     *
     * ```ts
     * const lineHeightConfig = {
     * 	supportAllValues: true
     * };
     * ```
     *
     * With this configuration line heights not specified in the editor configuration will not be removed when pasting the content.
     */
    supportAllValues?: boolean;
    /**
     * Default value of line height attribute. Defaults to `1.5`.
     */
    defaultValue?: number;
}
/**
 * Configuration for one of the dropdown options.
 */
export interface LineHeightOption {
    /**
     * The user-readable title of the option.
     */
    title: string;
    /**
     * The line height value (CSS line-height property value, string).
     */
    model: string;
    /**
     * View element configuration.
     */
    view?: DowncastAttributeDescriptor;
}
