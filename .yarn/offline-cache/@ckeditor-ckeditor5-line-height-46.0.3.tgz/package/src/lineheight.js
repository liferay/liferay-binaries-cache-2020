/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x3715fa=_0x2b12;(function(_0x14b5b2,_0x54b474){var _0x155568=_0x2b12,_0x2f71e7=_0x14b5b2();while(!![]){try{var _0x5ddb09=-parseInt(_0x155568(0xd5))/0x1+-parseInt(_0x155568(0xdc))/0x2+parseInt(_0x155568(0xd9))/0x3+-parseInt(_0x155568(0xe0))/0x4+-parseInt(_0x155568(0xda))/0x5+-parseInt(_0x155568(0xd8))/0x6*(-parseInt(_0x155568(0xdd))/0x7)+parseInt(_0x155568(0xdf))/0x8;if(_0x5ddb09===_0x54b474)break;else _0x2f71e7['push'](_0x2f71e7['shift']());}catch(_0x2013b6){_0x2f71e7['push'](_0x2f71e7['shift']());}}}(_0x44b5,0x2a483));import{Plugin as _0x1fc77b}from'ckeditor5/src/core.js';function _0x2b12(_0x32fa03,_0x47f6e1){var _0x44b581=_0x44b5();return _0x2b12=function(_0x2b123d,_0x135621){_0x2b123d=_0x2b123d-0xd5;var _0x1fa4a6=_0x44b581[_0x2b123d];return _0x1fa4a6;},_0x2b12(_0x32fa03,_0x47f6e1);}function _0x44b5(){var _0x117134=['LineHeight','1164NlsprC','396621DUEzsV','1561530QefrLG','isOfficialPlugin','416912NIRfds','1148BNFkZn','isPremiumPlugin','7664344IiBMyU','715092IfbSIV','requires','249344PnHOtP','pluginName'];_0x44b5=function(){return _0x117134;};return _0x44b5();}import{LineHeightEditing as _0x5c114d}from'./lineheightediting.js';import{LineHeightUI as _0x2f8787}from'./lineheightui.js';export class LineHeight extends _0x1fc77b{static get[_0x3715fa(0xe1)](){return[_0x5c114d,_0x2f8787];}static get[_0x3715fa(0xd6)](){var _0x41a3fb=_0x3715fa;return _0x41a3fb(0xd7);}static get[_0x3715fa(0xdb)](){return!0x0;}static get[_0x3715fa(0xde)](){return!0x0;}}