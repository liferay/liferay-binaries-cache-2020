/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x251a(_0x2675bc,_0x555370){const _0x539589=_0x5395();return _0x251a=function(_0x251af,_0x1bd7b7){_0x251af=_0x251af-0x1bf;let _0x45ebed=_0x539589[_0x251af];return _0x45ebed;},_0x251a(_0x2675bc,_0x555370);}const _0x392dd4=_0x251a;(function(_0x2d286c,_0x4d97e2){const _0x132270=_0x251a,_0x488089=_0x2d286c();while(!![]){try{const _0x18d0cd=parseInt(_0x132270(0x1cb))/0x1+-parseInt(_0x132270(0x1cd))/0x2*(parseInt(_0x132270(0x1d8))/0x3)+parseInt(_0x132270(0x1cc))/0x4+parseInt(_0x132270(0x1d7))/0x5*(-parseInt(_0x132270(0x1c1))/0x6)+parseInt(_0x132270(0x1d4))/0x7*(parseInt(_0x132270(0x1bf))/0x8)+parseInt(_0x132270(0x1d6))/0x9+parseInt(_0x132270(0x1d9))/0xa;if(_0x18d0cd===_0x4d97e2)break;else _0x488089['push'](_0x488089['shift']());}catch(_0xc9333d){_0x488089['push'](_0x488089['shift']());}}}(_0x5395,0xeea43));import{Command as _0x70040d}from'ckeditor5/src/core.js';import{first as _0x1d085a}from'ckeditor5/src/utils.js';export class LineHeightCommand extends _0x70040d{[_0x392dd4(0x1d1)](){const _0x228e5a=_0x392dd4,_0x165bd0=this[_0x228e5a(0x1da)][_0x228e5a(0x1c2)][_0x228e5a(0x1ce)],_0x1c1b5b=_0x1d085a(_0x165bd0[_0x228e5a(0x1d2)][_0x228e5a(0x1d0)]());this[_0x228e5a(0x1c6)]=Boolean(_0x1c1b5b)&&this[_0x228e5a(0x1c4)](_0x1c1b5b),this[_0x228e5a(0x1db)]=this[_0x228e5a(0x1c6)]&&_0x1c1b5b[_0x228e5a(0x1c7)](_0x228e5a(0x1c0));}[_0x392dd4(0x1c8)](_0x31450b={}){const _0x2a2919=_0x392dd4,_0x4994e9=this[_0x2a2919(0x1da)][_0x2a2919(0x1c2)],_0x4a09c8=_0x4994e9[_0x2a2919(0x1ce)][_0x2a2919(0x1d2)],_0x2ca1fa=_0x31450b[_0x2a2919(0x1db)];_0x4994e9[_0x2a2919(0x1d3)](_0x3bfc7d=>{const _0x5c9710=_0x2a2919,_0x21b2b3=Array[_0x5c9710(0x1c9)](_0x4a09c8[_0x5c9710(0x1d0)]())[_0x5c9710(0x1c5)](_0xb018c2=>this[_0x5c9710(0x1c4)](_0xb018c2));for(const _0x3d4016 of _0x21b2b3)_0x2ca1fa?_0x3bfc7d[_0x5c9710(0x1ca)](_0x5c9710(0x1c0),_0x2ca1fa,_0x3d4016):_0x3bfc7d[_0x5c9710(0x1cf)](_0x5c9710(0x1c0),_0x3d4016);});}[_0x392dd4(0x1c4)](_0x54336d){const _0x39c598=_0x392dd4;return this[_0x39c598(0x1da)][_0x39c598(0x1c2)][_0x39c598(0x1d5)][_0x39c598(0x1c3)](_0x54336d,_0x39c598(0x1c0));}}function _0x5395(){const _0x9bcb13=['execute','from','setAttribute','69771CCkgnF','4675904sOtuUU','170622fceJAb','document','removeAttribute','getSelectedBlocks','refresh','selection','change','42taPQiz','schema','5019363FSUIGh','446375yWTaSK','63bFWFeR','4334550PhVxAc','editor','value','2504296WzxATO','lineHeight','90oMWOkq','model','checkAttribute','_canHaveLineHeight','filter','isEnabled','getAttribute'];_0x5395=function(){return _0x9bcb13;};return _0x5395();}