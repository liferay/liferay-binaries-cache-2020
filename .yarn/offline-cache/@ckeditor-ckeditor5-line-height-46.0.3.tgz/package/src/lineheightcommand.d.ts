/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module line-height/lineheightcommand
 * @publicApi
 */
import { Command } from 'ckeditor5/src/core.js';
/**
 * The line height command. It applies the line height on block elements.
 */
export declare class LineHeightCommand extends Command {
    /**
     * @inheritDoc
     */
    refresh(): void;
    /**
     * Executes the command.
     *
     * @param options.value The value to apply. When `undefined`, the command will remove the attribute.
     */
    execute(options?: {
        value?: string;
    }): void;
}
