/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module line-height
 */
export { LineHeight } from './lineheight.js';
export { LineHeightEditing } from './lineheightediting.js';
export { LineHeightUI } from './lineheightui.js';
export { LineHeightCommand } from './lineheightcommand.js';
export type { LineHeightConfig, LineHeightOption } from './lineheightconfig.js';
import './augmentation.js';
