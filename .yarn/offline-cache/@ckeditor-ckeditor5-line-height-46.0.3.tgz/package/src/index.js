/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x148ee8,_0x374dd6){var _0x4c9581=_0x1837,_0x2cc056=_0x148ee8();while(!![]){try{var _0x2fae9a=parseInt(_0x4c9581(0x11f))/0x1+parseInt(_0x4c9581(0x11d))/0x2*(-parseInt(_0x4c9581(0x11c))/0x3)+parseInt(_0x4c9581(0x124))/0x4*(parseInt(_0x4c9581(0x127))/0x5)+parseInt(_0x4c9581(0x11e))/0x6*(parseInt(_0x4c9581(0x121))/0x7)+-parseInt(_0x4c9581(0x122))/0x8*(parseInt(_0x4c9581(0x125))/0x9)+-parseInt(_0x4c9581(0x120))/0xa*(-parseInt(_0x4c9581(0x126))/0xb)+parseInt(_0x4c9581(0x123))/0xc;if(_0x2fae9a===_0x374dd6)break;else _0x2cc056['push'](_0x2cc056['shift']());}catch(_0x1d097c){_0x2cc056['push'](_0x2cc056['shift']());}}}(_0x5ddc,0x6d060));function _0x5ddc(){var _0x3299fa=['685734xLXfjX','84335IQFEFY','119220VJqMKS','28jjqQJC','8vBqGSj','10302264BPTczz','52iaEarM','4256667xCBZJf','110DZNEpY','33285TbieqW','69wJqPKe','59674FiMiNy'];_0x5ddc=function(){return _0x3299fa;};return _0x5ddc();}export{LineHeight}from'./lineheight.js';export{LineHeightEditing}from'./lineheightediting.js';export{LineHeightUI}from'./lineheightui.js';export{LineHeightCommand}from'./lineheightcommand.js';function _0x1837(_0x13b716,_0x3ea35b){var _0x5ddc8d=_0x5ddc();return _0x1837=function(_0x1837a6,_0x5d86e9){_0x1837a6=_0x1837a6-0x11c;var _0x343e59=_0x5ddc8d[_0x1837a6];return _0x343e59;},_0x1837(_0x13b716,_0x3ea35b);}import'./augmentation.js';