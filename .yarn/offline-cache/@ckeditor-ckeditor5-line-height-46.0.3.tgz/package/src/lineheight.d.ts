/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module line-height/lineheight
 * @publicApi
 */
import { Plugin } from 'ckeditor5/src/core.js';
import { LineHeightEditing } from './lineheightediting.js';
import { LineHeightUI } from './lineheightui.js';
/**
 * The line height plugin.
 *
 * For a detailed overview, check the {@glink features/line-height Line height feature documentation}.
 */
export declare class LineHeight extends Plugin {
    /**
     * @inheritDoc
     */
    static get requires(): readonly [typeof LineHeightEditing, typeof LineHeightUI];
    /**
     * @inheritDoc
     */
    static get pluginName(): "LineHeight";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
}
