/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x228f(){const _0x10de68=['insertContent','51455SzDRVK','htmlProcessor','1890668EKZHqc','change','editor','toView','12379536kmONzQ','function','31209YneZrv','string','data','237mLhYed','execute','270zIbFmm','4214245CvWQOZ','toModel','5636ZSvTsW','3868952LpKRZX'];_0x228f=function(){return _0x10de68;};return _0x228f();}const _0x4e95f1=_0xb11a;(function(_0x5a0231,_0x419ab6){const _0x387b17=_0xb11a,_0xdf25bc=_0x5a0231();while(!![]){try{const _0x1555f7=-parseInt(_0x387b17(0x17f))/0x1+-parseInt(_0x387b17(0x174))/0x2*(parseInt(_0x387b17(0x182))/0x3)+-parseInt(_0x387b17(0x179))/0x4+-parseInt(_0x387b17(0x177))/0x5*(parseInt(_0x387b17(0x184))/0x6)+parseInt(_0x387b17(0x185))/0x7+-parseInt(_0x387b17(0x175))/0x8+parseInt(_0x387b17(0x17d))/0x9;if(_0x1555f7===_0x419ab6)break;else _0xdf25bc['push'](_0xdf25bc['shift']());}catch(_0x362fca){_0xdf25bc['push'](_0xdf25bc['shift']());}}}(_0x228f,0x4a4c7));import{Command as _0x406348}from'ckeditor5/src/core.js';function _0xb11a(_0x3f3827,_0x589b05){const _0x228f97=_0x228f();return _0xb11a=function(_0xb11acc,_0x499fee){_0xb11acc=_0xb11acc-0x174;let _0x430079=_0x228f97[_0xb11acc];return _0x430079;},_0xb11a(_0x3f3827,_0x589b05);}export class TemplateCommand extends _0x406348{[_0x4e95f1(0x183)](_0x3b01cf){const _0x4c1f86=_0x4e95f1,{model:_0x535c9c}=this[_0x4c1f86(0x17b)];let _0x26c3e7;switch(typeof _0x3b01cf){case _0x4c1f86(0x180):_0x26c3e7=_0x3b01cf;break;case _0x4c1f86(0x17e):_0x26c3e7=_0x3b01cf();}_0x4c1f86(0x180)==typeof _0x26c3e7&&_0x535c9c[_0x4c1f86(0x17a)](()=>{const _0xd39a12=_0x4c1f86,_0x33f273=this[_0xd39a12(0x17b)][_0xd39a12(0x181)][_0xd39a12(0x178)][_0xd39a12(0x17c)](_0x26c3e7),_0x300d11=this[_0xd39a12(0x17b)][_0xd39a12(0x181)][_0xd39a12(0x186)](_0x33f273);_0x535c9c[_0xd39a12(0x176)](_0x300d11);});}}