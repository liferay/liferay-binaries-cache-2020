/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module template/templateui
 */
import { Plugin } from 'ckeditor5/src/core.js';
import '../theme/template.css';
/**
 * The UI plugin of the template feature.
 *
 * It registers the `'insertTemplate'` UI dropdown in the editor's {@link module:ui/componentfactory~ComponentFactory component factory}
 * that displays a list of templates and allows to insert them into the editor content.
 */
export declare class TemplateUI extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "TemplateUI";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    init(): void;
    /**
     * @inheritDoc
     */
    afterInit(): void;
}
