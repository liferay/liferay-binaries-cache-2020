/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module template
 */
export { Template } from './template.js';
export { TemplateCommand } from './templatecommand.js';
export { TemplateEditing } from './templateediting.js';
export { TemplateUI } from './templateui.js';
export type { TemplateConfig, TemplateDefinition } from './template.js';
import './augmentation.js';
