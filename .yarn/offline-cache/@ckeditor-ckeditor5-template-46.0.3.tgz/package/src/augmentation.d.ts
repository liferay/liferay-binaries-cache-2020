/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import type { Template, TemplateCommand, TemplateEditing, TemplateUI, TemplateConfig } from './index.js';
declare module '@ckeditor/ckeditor5-core' {
    interface PluginsMap {
        [Template.pluginName]: Template;
        [TemplateEditing.pluginName]: TemplateEditing;
        [TemplateUI.pluginName]: TemplateUI;
    }
    interface CommandsMap {
        insertTemplate: TemplateCommand;
    }
    interface EditorConfig {
        /**
         * The configuration of the {@link module:template/template~Template} feature.
         *
         * Read more in {@link module:template/template~TemplateConfig}.
         */
        template?: TemplateConfig;
    }
}
