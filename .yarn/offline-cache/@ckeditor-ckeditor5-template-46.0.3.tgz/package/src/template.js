/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x955f5f=_0x3420;(function(_0x2fc915,_0xc71fbb){var _0xc28863=_0x3420,_0x6a29e0=_0x2fc915();while(!![]){try{var _0x99e9a9=parseInt(_0xc28863(0x70))/0x1+parseInt(_0xc28863(0x69))/0x2*(-parseInt(_0xc28863(0x71))/0x3)+-parseInt(_0xc28863(0x6c))/0x4+-parseInt(_0xc28863(0x73))/0x5*(-parseInt(_0xc28863(0x6f))/0x6)+-parseInt(_0xc28863(0x6e))/0x7+parseInt(_0xc28863(0x6b))/0x8+parseInt(_0xc28863(0x75))/0x9;if(_0x99e9a9===_0xc71fbb)break;else _0x6a29e0['push'](_0x6a29e0['shift']());}catch(_0x1248b7){_0x6a29e0['push'](_0x6a29e0['shift']());}}}(_0x9a7e,0xc8c41));import{Plugin as _0x5b6cc7}from'ckeditor5/src/core.js';function _0x9a7e(){var _0x22b2db=['560823NuwRhP','21QOfXnK','isOfficialPlugin','180kBRjgg','isPremiumPlugin','26523432lvfAHC','pluginName','255166sjjCDH','Template','5184384AHEeEi','5864004CAELGR','requires','10236352pKxRmw','81306DOduEr'];_0x9a7e=function(){return _0x22b2db;};return _0x9a7e();}import{TemplateEditing as _0x379aad}from'./templateediting.js';function _0x3420(_0x4ef9b1,_0x58741b){var _0x9a7e44=_0x9a7e();return _0x3420=function(_0x3420f2,_0x5e9c30){_0x3420f2=_0x3420f2-0x68;var _0x23cfbb=_0x9a7e44[_0x3420f2];return _0x23cfbb;},_0x3420(_0x4ef9b1,_0x58741b);}import{TemplateUI as _0xd4efe2}from'./templateui.js';export class Template extends _0x5b6cc7{static get[_0x955f5f(0x6d)](){return[_0x379aad,_0xd4efe2];}static get[_0x955f5f(0x68)](){var _0x322df2=_0x955f5f;return _0x322df2(0x6a);}static get[_0x955f5f(0x72)](){return!0x0;}static get[_0x955f5f(0x74)](){return!0x0;}}