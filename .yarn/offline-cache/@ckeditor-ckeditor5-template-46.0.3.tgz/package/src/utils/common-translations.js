/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
export function getTranslation(_0x398a54,_0x3e28ba,..._0x21d11d){const t=_0x398a54['t'];switch(_0x3e28ba){case'No\x20templates\x20were\x20found\x20matching\x20\x22%0\x22.':return t('No\x20templates\x20were\x20found\x20matching\x20\x22%0\x22.',..._0x21d11d);case'Please\x20try\x20a\x20different\x20phrase\x20or\x20check\x20the\x20spelling.':return t('Please\x20try\x20a\x20different\x20phrase\x20or\x20check\x20the\x20spelling.');case'No\x20templates\x20available.':return t('No\x20templates\x20available.');case'%0\x20templates\x20found':return t('%0\x20templates\x20found',..._0x21d11d);case'Search\x20template':return t('Search\x20template');case'Template':return t('Template');case'Insert\x20template':return t('Insert\x20template');default:return _0x3e28ba;}}