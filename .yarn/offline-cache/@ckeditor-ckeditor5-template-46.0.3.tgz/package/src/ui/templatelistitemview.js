/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x57240c=_0x2c70;function _0x33f3(){var _0x310f48=['9sQnRau','buttonView','130760RnCuFC','2zpAkbt','7395976gkMVAI','2162316JlpdXJ','originalIndex','142368nIlVtD','838160YJSDIL','610404RCDqfN','285556NWwQOF'];_0x33f3=function(){return _0x310f48;};return _0x33f3();}(function(_0x448dd2,_0x35d446){var _0x395795=_0x2c70,_0x41b0d7=_0x448dd2();while(!![]){try{var _0x5d9244=parseInt(_0x395795(0x1c4))/0x1+-parseInt(_0x395795(0x1c0))/0x2*(parseInt(_0x395795(0x1c6))/0x3)+-parseInt(_0x395795(0x1c7))/0x4+-parseInt(_0x395795(0x1c5))/0x5+-parseInt(_0x395795(0x1c2))/0x6+-parseInt(_0x395795(0x1bf))/0x7+-parseInt(_0x395795(0x1c1))/0x8*(-parseInt(_0x395795(0x1c8))/0x9);if(_0x5d9244===_0x35d446)break;else _0x41b0d7['push'](_0x41b0d7['shift']());}catch(_0x2b4929){_0x41b0d7['push'](_0x41b0d7['shift']());}}}(_0x33f3,0x3be3e));function _0x2c70(_0x3a0b5f,_0x348413){var _0x33f3c6=_0x33f3();return _0x2c70=function(_0x2c70a7,_0x17c185){_0x2c70a7=_0x2c70a7-0x1bf;var _0x223664=_0x33f3c6[_0x2c70a7];return _0x223664;},_0x2c70(_0x3a0b5f,_0x348413);}import{ListItemView as _0xb24d68}from'ckeditor5/src/ui.js';export class TemplateListItemView extends _0xb24d68{[_0x57240c(0x1c3)];[_0x57240c(0x1c9)];constructor(_0x5c5578,_0x512f0a){var _0x11e2e7=_0x57240c;super(_0x5c5578),this[_0x11e2e7(0x1c3)]=_0x512f0a,this[_0x11e2e7(0x1c9)]=null;}}