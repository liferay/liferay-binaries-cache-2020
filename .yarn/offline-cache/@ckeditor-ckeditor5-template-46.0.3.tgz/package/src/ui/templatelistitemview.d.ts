/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module template/ui/templatelistitemview
 */
import type { Locale } from 'ckeditor5/src/utils.js';
import { ListItemView } from 'ckeditor5/src/ui.js';
import { type TemplateListButtonView } from './templatelistbuttonview.js';
/**
 * A view representing an item in the list of tempaltes.
 *
 * @protected
 */
export declare class TemplateListItemView extends ListItemView {
    /**
     * The initial index of the item in the list of templates.
     * Useful while searching and sorting to reverse the list to the same order.
     */
    readonly originalIndex: number;
    /**
     * The instance of the template button view containing the title,
     * icon, and description of the template.
     */
    buttonView: TemplateListButtonView | null;
    /**
     * Creates an instance of the {@link module:template/ui/templatelistitemview~TemplateListItemView} class.
     *
     * @param locale The localization services instance.
     * @param originalIndex The initial index of the item in the list of templates.
     */
    constructor(locale: Locale, originalIndex: number);
}
