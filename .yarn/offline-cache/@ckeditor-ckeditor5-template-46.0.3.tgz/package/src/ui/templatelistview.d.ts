/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module template/ui/templatelistview
 */
import { ListView, type FilteredView } from 'ckeditor5/src/ui.js';
/**
 * The template list view class with filtering and sorting.
 *
 * @private
 */
export declare class TemplateListView extends ListView implements FilteredView {
    /**
     * Filters the list of templates according to a specified regular expression. The filtered list is sorted so that items that
     * match the regular expression in their titles are displayed first.
     *
     * Matching items highlight the regular expression (query) in their titles and/or descriptions.
     *
     * **Note**: The `Collection` (also `ViewCollection`) class does not provide sorting functionality. Thus, the functionality
     * implemented in this method is **extremely inefficient** because it clones the entire collection, sorts it as an array,
     * then purges the original collection and sets it from scratch with the sorted array. Purging and resetting the
     * collection triggers an avalanche of `add` and `remove` events synchronously handled by the `Template` (UI bindings)
     * and **rendered in the DOM**. As long as sorting takes shorter than rendering of the DOM this should not be noticeable
     * but the moment it does not, the UI will start glitching. A proper `Collection#sort` is needed to work around
     * this overhead (see https://github.com/ckeditor/ckeditor5/issues/2065).
     *
     * **Note**: Passing `null` to this method resets the list to its original state.
     *
     * @param regExp A regular expression used to match the list title and description.
     * @returns True if some list items matched the regular expression. False otherwise.
     */
    filter(regExp: RegExp | null): {
        resultsCount: number;
        totalItemsCount: number;
    };
}
