/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module template/templateediting
 */
import { Plugin } from 'ckeditor5/src/core.js';
/**
 * The template editing plugin.
 */
export declare class TemplateEditing extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "TemplateEditing";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    init(): void;
    /**
     * @inheritDoc
     */
    destroy(): void;
}
