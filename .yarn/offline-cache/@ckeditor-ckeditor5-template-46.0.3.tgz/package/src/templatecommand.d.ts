/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module template/templatecommand
 * @publicApi
 */
import { Command } from 'ckeditor5/src/core.js';
/**
 * The template command.
 *
 * Inserts a template into the editor content.
 */
export declare class TemplateCommand extends Command {
    /**
     * Inserts the template data at the position of the selection.
     *
     * @fires execute
     * @param templateData Template data should be a raw HTML string or a function that returns one.
     */
    execute(templateData: string | Function): void;
}
