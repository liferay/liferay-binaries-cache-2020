/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x450d50,_0x8843d1){var _0x226b53=_0x38d3,_0x29c523=_0x450d50();while(!![]){try{var _0x59a075=-parseInt(_0x226b53(0x1ee))/0x1+parseInt(_0x226b53(0x1ec))/0x2*(parseInt(_0x226b53(0x1e7))/0x3)+-parseInt(_0x226b53(0x1e8))/0x4*(-parseInt(_0x226b53(0x1eb))/0x5)+-parseInt(_0x226b53(0x1e9))/0x6*(parseInt(_0x226b53(0x1ea))/0x7)+-parseInt(_0x226b53(0x1ed))/0x8*(parseInt(_0x226b53(0x1e3))/0x9)+parseInt(_0x226b53(0x1e6))/0xa+parseInt(_0x226b53(0x1e4))/0xb*(parseInt(_0x226b53(0x1e5))/0xc);if(_0x59a075===_0x8843d1)break;else _0x29c523['push'](_0x29c523['shift']());}catch(_0x46f5b4){_0x29c523['push'](_0x29c523['shift']());}}}(_0x2e97,0xe6b6f));export{Template}from'./template.js';export{TemplateCommand}from'./templatecommand.js';export{TemplateEditing}from'./templateediting.js';export{TemplateUI}from'./templateui.js';import'./augmentation.js';function _0x38d3(_0x32da21,_0x3a2160){var _0x2e9723=_0x2e97();return _0x38d3=function(_0x38d3ae,_0x4e4152){_0x38d3ae=_0x38d3ae-0x1e3;var _0x14fc92=_0x2e9723[_0x38d3ae];return _0x14fc92;},_0x38d3(_0x32da21,_0x3a2160);}function _0x2e97(){var _0x447454=['11lCugPU','10077924WgUuMm','5097500JVYNZb','38904pjMFUv','50812etVoVz','41094aoxrPN','1337VIglYs','25ciTYDF','268bstyrI','88uykKiU','696261eHQSMa','164763uBlOOK'];_0x2e97=function(){return _0x447454;};return _0x2e97();}