/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x4a1821,_0x45e39b){var _0x2cb1d9=_0x389a,_0x50d7ec=_0x4a1821();while(!![]){try{var _0x55b62e=-parseInt(_0x2cb1d9(0x7e))/0x1*(-parseInt(_0x2cb1d9(0x82))/0x2)+-parseInt(_0x2cb1d9(0x81))/0x3*(parseInt(_0x2cb1d9(0x84))/0x4)+-parseInt(_0x2cb1d9(0x7f))/0x5+-parseInt(_0x2cb1d9(0x7d))/0x6*(-parseInt(_0x2cb1d9(0x80))/0x7)+parseInt(_0x2cb1d9(0x83))/0x8+parseInt(_0x2cb1d9(0x7b))/0x9+-parseInt(_0x2cb1d9(0x7c))/0xa;if(_0x55b62e===_0x45e39b)break;else _0x50d7ec['push'](_0x50d7ec['shift']());}catch(_0x3c491b){_0x50d7ec['push'](_0x50d7ec['shift']());}}}(_0x3e8e,0xe51e8));export{Compressor}from'./compressor.js';function _0x389a(_0x5ab503,_0x117865){var _0x3e8e7a=_0x3e8e();return _0x389a=function(_0x389aae,_0x4ebe46){_0x389aae=_0x389aae-0x7b;var _0x4af811=_0x3e8e7a[_0x389aae];return _0x4af811;},_0x389a(_0x5ab503,_0x117865);}function _0x3e8e(){var _0x2d16c4=['4222fOloyE','11887136qMpBAp','4KfyqEw','13706406tWaiIZ','5634090evkuDy','287220uXefxG','272raazLK','5690730nXPWGJ','91Jqfcmi','4695903UYGHqj'];_0x3e8e=function(){return _0x2d16c4;};return _0x3e8e();}