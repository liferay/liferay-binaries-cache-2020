/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x4179(_0x25eb76,_0xda58fa){const _0x2a7040=_0x2a70();return _0x4179=function(_0x4179d3,_0x44f512){_0x4179d3=_0x4179d3-0x15b;let _0x150d8c=_0x2a7040[_0x4179d3];return _0x150d8c;},_0x4179(_0x25eb76,_0xda58fa);}const _0x20903c=_0x4179;function _0x2a70(){const _0x581c06=['toObject','encode','1845918iAOpBK','14624PtARpi','_protobufRoot','2134272PNzcpw','951620bjPsYH','1359KRMFKb','decompress','decode','_protobuf','getDescriptor','create','17810808VHmlJI','1367744eaGNhY','verify','1527852vrNBSh','finish','compress'];_0x2a70=function(){return _0x581c06;};return _0x2a70();}(function(_0x5b224c,_0xf8e9d6){const _0x1f498b=_0x4179,_0x1a0568=_0x5b224c();while(!![]){try{const _0x49ecf6=-parseInt(_0x1f498b(0x163))/0x1+-parseInt(_0x1f498b(0x16a))/0x2+-parseInt(_0x1f498b(0x15c))/0x3*(-parseInt(_0x1f498b(0x16b))/0x4)+-parseInt(_0x1f498b(0x15b))/0x5+-parseInt(_0x1f498b(0x165))/0x6+-parseInt(_0x1f498b(0x16d))/0x7+parseInt(_0x1f498b(0x162))/0x8;if(_0x49ecf6===_0xf8e9d6)break;else _0x1a0568['push'](_0x1a0568['shift']());}catch(_0x4bb249){_0x1a0568['push'](_0x1a0568['shift']());}}}(_0x2a70,0xcd8e2));import{messages as _0x1e43ee}from'./lib/compiledmessages.js';export class ProtobufFactory{[_0x20903c(0x16c)];constructor(){const _0xebefc6=_0x20903c;this[_0xebefc6(0x16c)]=_0x1e43ee;}[_0x20903c(0x160)](_0x695419){const _0x1c5541=_0x20903c;return new ProtobufDescriptor(this[_0x1c5541(0x16c)][_0x695419]);}}export class ProtobufDescriptor{[_0x20903c(0x15f)];constructor(_0x4a02e4){const _0x21e8c3=_0x20903c;this[_0x21e8c3(0x15f)]=_0x4a02e4;}[_0x20903c(0x167)](_0x5cc8b4){const _0x37d5c3=_0x20903c,_0x405565=this[_0x37d5c3(0x15f)][_0x37d5c3(0x164)](_0x5cc8b4);if(_0x405565)throw Error(_0x405565);return this[_0x37d5c3(0x15f)][_0x37d5c3(0x169)](this[_0x37d5c3(0x15f)][_0x37d5c3(0x161)](_0x5cc8b4))[_0x37d5c3(0x166)]();}[_0x20903c(0x15d)](_0x4098a4){const _0xc07c57=_0x20903c;return this[_0xc07c57(0x15f)][_0xc07c57(0x168)](this[_0xc07c57(0x15f)][_0xc07c57(0x15e)](_0x4098a4),{'oneofs':!0x0});}}