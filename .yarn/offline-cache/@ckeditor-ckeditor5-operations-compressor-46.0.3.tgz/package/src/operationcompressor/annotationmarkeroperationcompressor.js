/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0xbc482e=_0x1cc5;(function(_0x19339d,_0x73d463){const _0x10f2ca=_0x1cc5,_0x8996b4=_0x19339d();while(!![]){try{const _0x591cab=parseInt(_0x10f2ca(0x196))/0x1*(parseInt(_0x10f2ca(0x191))/0x2)+-parseInt(_0x10f2ca(0x1a1))/0x3+-parseInt(_0x10f2ca(0x190))/0x4+-parseInt(_0x10f2ca(0x19c))/0x5+-parseInt(_0x10f2ca(0x192))/0x6*(-parseInt(_0x10f2ca(0x19b))/0x7)+parseInt(_0x10f2ca(0x197))/0x8+parseInt(_0x10f2ca(0x195))/0x9*(parseInt(_0x10f2ca(0x1a2))/0xa);if(_0x591cab===_0x73d463)break;else _0x8996b4['push'](_0x8996b4['shift']());}catch(_0x2df587){_0x8996b4['push'](_0x8996b4['shift']());}}}(_0x4dde,0x47cc3));function _0x1cc5(_0x4aa91e,_0x20eb0d){const _0x4ddeb8=_0x4dde();return _0x1cc5=function(_0x1cc5b9,_0x5f33ec){_0x1cc5b9=_0x1cc5b9-0x190;let _0x4f2e86=_0x4ddeb8[_0x1cc5b9];return _0x4f2e86;},_0x1cc5(_0x4aa91e,_0x20eb0d);}function _0x4dde(){const _0x555e75=['__className','_omittedNamespace','compress','42sukZNA','2747345VhnOrJ','decompress','startsWith','MarkerOperation','length','1081479pHiWDa','7408180eIBNCP','239512qijDeM','264518NChvxJ','385698geXkHK','replace','name','9WoBsPk','1efbSbg','41184bSRYsA'];_0x4dde=function(){return _0x555e75;};return _0x4dde();}import{MarkerOperationCompressor as _0x5c5944}from'./markeroperationcompressor.js';export class AnnotationMarkerOperationCompressor extends _0x5c5944{[_0xbc482e(0x199)];constructor(_0x463df5,_0x5baada,_0x257613,_0x1edb7e){const _0x369c3b=_0xbc482e;super(_0x463df5,_0x5baada,_0x257613),this[_0x369c3b(0x199)]=_0x1edb7e+':';}[_0xbc482e(0x19a)](_0x52ba1f,_0x262e2b){const _0x382bd0=_0xbc482e;return!(_0x382bd0(0x19f)!=_0x262e2b[0x0][_0x382bd0(0x198)]||!_0x262e2b[0x0][_0x382bd0(0x194)][_0x382bd0(0x19e)](this[_0x382bd0(0x199)]))&&(_0x262e2b[0x0][_0x382bd0(0x194)]=_0x262e2b[0x0][_0x382bd0(0x194)][_0x382bd0(0x193)](new RegExp('^'+this[_0x382bd0(0x199)]),''),super[_0x382bd0(0x19a)](_0x52ba1f,_0x262e2b),!0x0);}[_0xbc482e(0x19d)](_0xfe5558,_0xdf07d){const _0x582674=_0xbc482e;super[_0x582674(0x19d)](_0xfe5558,_0xdf07d);const _0x139238=_0xfe5558[_0xfe5558[_0x582674(0x1a0)]-0x1];_0x139238[_0x582674(0x194)]=this[_0x582674(0x199)]+_0x139238[_0x582674(0x194)];}}