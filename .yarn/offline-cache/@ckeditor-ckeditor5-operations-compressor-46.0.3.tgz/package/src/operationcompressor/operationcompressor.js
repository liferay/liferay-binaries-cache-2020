/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x4af031=_0x311c;function _0x311c(_0x58f43e,_0x52b0d5){const _0x4b180e=_0x4b18();return _0x311c=function(_0x311c4d,_0x51dc53){_0x311c4d=_0x311c4d-0x172;let _0x3b2b6d=_0x4b180e[_0x311c4d];return _0x3b2b6d;},_0x311c(_0x58f43e,_0x52b0d5);}function _0x4b18(){const _0x3f5610=['4EfNTPh','__className','8hYaQCH','3052705fRneGF','8530004ekCMPc','_operationName','types','1923612ZlNkzY','buffers','shift','17977330SAEZQJ','decompress','push','8355876qrADOQ','944577dXIxak','compress','48MHEpnb','_id','_protobufDescriptor','18027CIdPSA'];_0x4b18=function(){return _0x3f5610;};return _0x4b18();}(function(_0x418d58,_0x290557){const _0x280e60=_0x311c,_0x19b9a5=_0x418d58();while(!![]){try{const _0x95653=-parseInt(_0x280e60(0x17b))/0x1*(-parseInt(_0x280e60(0x178))/0x2)+parseInt(_0x280e60(0x183))/0x3+-parseInt(_0x280e60(0x17c))/0x4*(-parseInt(_0x280e60(0x17f))/0x5)+-parseInt(_0x280e60(0x175))/0x6+parseInt(_0x280e60(0x180))/0x7*(-parseInt(_0x280e60(0x17e))/0x8)+-parseInt(_0x280e60(0x176))/0x9+parseInt(_0x280e60(0x172))/0xa;if(_0x95653===_0x290557)break;else _0x19b9a5['push'](_0x19b9a5['shift']());}catch(_0xefdf82){_0x19b9a5['push'](_0x19b9a5['shift']());}}}(_0x4b18,0xbb003));import{parsePositionBeforeCompression as _0x49739f,parsePositionAfterCompression as _0x598563}from'../utils.js';export class OperationCompressor{[_0x4af031(0x179)];[_0x4af031(0x181)];[_0x4af031(0x17a)];constructor(_0x1550ee,_0x1a6b7b,_0x4b1d6b){const _0x515baa=_0x4af031;this[_0x515baa(0x179)]=_0x1550ee,this[_0x515baa(0x181)]=_0x1a6b7b,this[_0x515baa(0x17a)]=_0x4b1d6b;}[_0x4af031(0x177)](_0x1fb9f0,_0x2abe14){const _0x485421=_0x4af031,_0x42e3d0=_0x2abe14[_0x485421(0x185)]();return _0x49739f(_0x42e3d0),_0x1fb9f0[_0x485421(0x184)][_0x485421(0x174)](this[_0x485421(0x17a)][_0x485421(0x177)](_0x42e3d0)),_0x1fb9f0[_0x485421(0x182)][_0x485421(0x174)](this[_0x485421(0x179)]),!0x0;}[_0x4af031(0x173)](_0x2f0267,_0x226648){const _0x24ac75=_0x4af031;_0x226648[_0x24ac75(0x182)][_0x24ac75(0x185)]();const _0x370e9b=this[_0x24ac75(0x17a)][_0x24ac75(0x173)](_0x226648[_0x24ac75(0x184)][_0x24ac75(0x185)]());_0x598563(_0x370e9b),_0x370e9b[_0x24ac75(0x17d)]=this[_0x24ac75(0x181)],_0x2f0267[_0x24ac75(0x174)](_0x370e9b);}}