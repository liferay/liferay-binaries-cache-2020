/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x386689=_0x48bd;function _0xdc49(){const _0xcc2f99=['6303920yPBtrP','8100bBlTTH','6834544QyXhGG','604aKIVKk','4cQSpGo','6930780aPlITL','newRange','3492546mwrnDz','1951200YhJEHg','oldRange','3379MPFuDO','decompress','11JvLoUo','length','234vQxfBF'];_0xdc49=function(){return _0xcc2f99;};return _0xdc49();}(function(_0x4161c5,_0x30d5b9){const _0x1db16f=_0x48bd,_0x13e623=_0x4161c5();while(!![]){try{const _0x498b12=-parseInt(_0x1db16f(0x14b))/0x1*(-parseInt(_0x1db16f(0x153))/0x2)+parseInt(_0x1db16f(0x148))/0x3*(-parseInt(_0x1db16f(0x154))/0x4)+parseInt(_0x1db16f(0x151))/0x5*(parseInt(_0x1db16f(0x14f))/0x6)+parseInt(_0x1db16f(0x150))/0x7+parseInt(_0x1db16f(0x152))/0x8+-parseInt(_0x1db16f(0x149))/0x9+parseInt(_0x1db16f(0x146))/0xa*(-parseInt(_0x1db16f(0x14d))/0xb);if(_0x498b12===_0x30d5b9)break;else _0x13e623['push'](_0x13e623['shift']());}catch(_0x5a13a9){_0x13e623['push'](_0x13e623['shift']());}}}(_0xdc49,0xbaa28));function _0x48bd(_0x2345d4,_0x2cb0b2){const _0xdc49d9=_0xdc49();return _0x48bd=function(_0x48bd08,_0xfc36a3){_0x48bd08=_0x48bd08-0x146;let _0x1fd9db=_0xdc49d9[_0x48bd08];return _0x1fd9db;},_0x48bd(_0x2345d4,_0x2cb0b2);}import{OperationCompressor as _0x498225}from'./operationcompressor.js';export class MarkerOperationCompressor extends _0x498225{[_0x386689(0x14c)](_0x2b0281,_0x44f319){const _0x4277d7=_0x386689;super[_0x4277d7(0x14c)](_0x2b0281,_0x44f319);const _0x3b2353=_0x2b0281[_0x2b0281[_0x4277d7(0x14e)]-0x1];_0x3b2353[_0x4277d7(0x14a)]||(_0x3b2353[_0x4277d7(0x14a)]=null),_0x3b2353[_0x4277d7(0x147)]||(_0x3b2353[_0x4277d7(0x147)]=null);}}