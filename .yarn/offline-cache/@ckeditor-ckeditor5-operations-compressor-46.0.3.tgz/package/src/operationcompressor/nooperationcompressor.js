/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0xe27e32=_0x3bd0;function _0x3353(){var _0x4faa1c=['8055MlGQlE','decompress','6KpNBFE','_operationName','4709523UdmUnT','_id','64579BhhXEn','3337660MrLRoM','compress','21197040hPPGbr','shift','types','push','10aAtZfM','1200480qIOtmw','107058CBcFPc','4848uWPXKN'];_0x3353=function(){return _0x4faa1c;};return _0x3353();}(function(_0x5b5f4a,_0x513289){var _0xb76b1a=_0x3bd0,_0x260477=_0x5b5f4a();while(!![]){try{var _0x58d85a=-parseInt(_0xb76b1a(0x140))/0x1*(parseInt(_0xb76b1a(0x147))/0x2)+parseInt(_0xb76b1a(0x138))/0x3+-parseInt(_0xb76b1a(0x141))/0x4+-parseInt(_0xb76b1a(0x137))/0x5*(parseInt(_0xb76b1a(0x13c))/0x6)+-parseInt(_0xb76b1a(0x13e))/0x7+parseInt(_0xb76b1a(0x139))/0x8*(parseInt(_0xb76b1a(0x13a))/0x9)+parseInt(_0xb76b1a(0x143))/0xa;if(_0x58d85a===_0x513289)break;else _0x260477['push'](_0x260477['shift']());}catch(_0xd020c8){_0x260477['push'](_0x260477['shift']());}}}(_0x3353,0x9936d));function _0x3bd0(_0x1e381f,_0x369f53){var _0x335390=_0x3353();return _0x3bd0=function(_0x3bd0bf,_0x5e64f5){_0x3bd0bf=_0x3bd0bf-0x137;var _0x6a84f7=_0x335390[_0x3bd0bf];return _0x6a84f7;},_0x3bd0(_0x1e381f,_0x369f53);}import{OperationCompressor as _0x57abce}from'./operationcompressor.js';export class NoOperationCompressor extends _0x57abce{[_0xe27e32(0x142)](_0x241fdd,_0x5a82f7){var _0x172e29=_0xe27e32;return _0x5a82f7[_0x172e29(0x144)](),_0x241fdd[_0x172e29(0x145)][_0x172e29(0x146)](this[_0x172e29(0x13f)]),!0x0;}[_0xe27e32(0x13b)](_0x4dbd3f,_0x1e6756){var _0x940271=_0xe27e32;_0x1e6756[_0x940271(0x145)][_0x940271(0x144)](),_0x4dbd3f[_0x940271(0x146)]({'__className':this[_0x940271(0x13d)]});}}