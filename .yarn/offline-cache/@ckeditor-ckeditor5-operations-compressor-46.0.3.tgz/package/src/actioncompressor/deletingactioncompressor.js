/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x36a3f6=_0x56ec;(function(_0x1f6157,_0x582dfc){const _0x452506=_0x56ec,_0x54adcc=_0x1f6157();while(!![]){try{const _0x4c6387=parseInt(_0x452506(0x1dc))/0x1*(parseInt(_0x452506(0x1e5))/0x2)+parseInt(_0x452506(0x1e6))/0x3+parseInt(_0x452506(0x1db))/0x4*(-parseInt(_0x452506(0x1d1))/0x5)+-parseInt(_0x452506(0x1e9))/0x6*(parseInt(_0x452506(0x1e8))/0x7)+-parseInt(_0x452506(0x1e4))/0x8+parseInt(_0x452506(0x1cf))/0x9+parseInt(_0x452506(0x1e3))/0xa*(parseInt(_0x452506(0x1eb))/0xb);if(_0x4c6387===_0x582dfc)break;else _0x54adcc['push'](_0x54adcc['shift']());}catch(_0x1dd799){_0x54adcc['push'](_0x54adcc['shift']());}}}(_0x45c9,0x7f16b));import{ActionCompressor as _0x2b780c}from'./actioncompressor.js';function _0x45c9(){const _0x79b269=['3138947GynEGL','6zUbcbC','_compareOperations','209jorhDz','_compressSingleOperation','2135691DwowUY','buffers','15jmXezI','root','_checkOperation','targetPosition','_combineNext','_getCompressorByName','compress','MoveOperation','$graveyard','wasUndone','1199476GTlqRl','317032jnHgaG','sourcePosition','_splitCurrent','_decompressSingleOperation','howMany','_context','__className','619580fGHdlJ','3760272ClBPsK','4MKtpKp','870156WIOGpb','decompress'];_0x45c9=function(){return _0x79b269;};return _0x45c9();}import{arePositionsEqual as _0x2f2954,getPositionShiftedBy as _0x2cae0d}from'../utils.js';function _0x56ec(_0x4b5542,_0xfea6eb){const _0x45c922=_0x45c9();return _0x56ec=function(_0x56ecd3,_0x34eb5b){_0x56ecd3=_0x56ecd3-0x1cf;let _0x50a78c=_0x45c922[_0x56ecd3];return _0x50a78c;},_0x56ec(_0x4b5542,_0xfea6eb);}import{cloneDeep as _0x30b73f}from'es-toolkit/compat';export class DeletingActionCompressor extends _0x2b780c{[_0x36a3f6(0x1d5)](_0x5214a7,_0xf1a30d){const _0x4b0c50=_0x36a3f6;return _0xf1a30d[_0x4b0c50(0x1e0)]++,_0xf1a30d[_0x4b0c50(0x1dd)]=_0x30b73f(_0x5214a7[_0x4b0c50(0x1dd)]),_0xf1a30d;}[_0x36a3f6(0x1de)](_0x4f7dcf){const _0xfaca00=_0x36a3f6,_0x4a7cf6=_0x30b73f(_0x4f7dcf);return _0x4f7dcf[_0xfaca00(0x1e0)]--,_0x4a7cf6[_0xfaca00(0x1e0)]=0x1,_0x4a7cf6[_0xfaca00(0x1dd)]=_0x2cae0d(_0x4a7cf6[_0xfaca00(0x1dd)],_0x4f7dcf[_0xfaca00(0x1e0)]),_0x4a7cf6;}[_0x36a3f6(0x1ea)](_0x5c1079,_0x28d0fe){const _0x4b5c1c=_0x36a3f6;return!(!this[_0x4b5c1c(0x1d3)](_0x5c1079)||!this[_0x4b5c1c(0x1d3)](_0x28d0fe))&&(_0x2f2954(_0x2cae0d(_0x5c1079[_0x4b5c1c(0x1dd)],-0x1),_0x28d0fe[_0x4b5c1c(0x1dd)])&&_0x2f2954(_0x5c1079[_0x4b5c1c(0x1d4)],_0x28d0fe[_0x4b5c1c(0x1d4)]));}[_0x36a3f6(0x1ec)](_0x2e3672){const _0xd25f35=_0x36a3f6,_0x21ee2c={'types':[],'buffers':[],'baseVersion':0x0};return this[_0xd25f35(0x1e1)][_0xd25f35(0x1d6)](_0xd25f35(0x1d8))[_0xd25f35(0x1d7)](_0x21ee2c,[_0x2e3672]),_0x21ee2c[_0xd25f35(0x1d0)][0x0];}[_0x36a3f6(0x1df)](_0x322fb8){const _0x20396d=_0x36a3f6,_0x53f0ad=[];return this[_0x20396d(0x1e1)][_0x20396d(0x1d6)](_0x20396d(0x1d8))[_0x20396d(0x1e7)](_0x53f0ad,_0x322fb8),_0x53f0ad[0x0];}[_0x36a3f6(0x1d3)](_0xb9665a){const _0x413015=_0x36a3f6;return _0x413015(0x1d8)==_0xb9665a[_0x413015(0x1e2)]&&_0x413015(0x1d9)==_0xb9665a[_0x413015(0x1d4)][_0x413015(0x1d2)]&&0x1==_0xb9665a[_0x413015(0x1e0)]&&!_0xb9665a[_0x413015(0x1da)];}}