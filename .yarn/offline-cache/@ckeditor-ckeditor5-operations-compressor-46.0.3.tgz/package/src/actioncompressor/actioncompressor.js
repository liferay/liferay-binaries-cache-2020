/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x5562f2=_0x3e2f;(function(_0x23a845,_0xb3af){const _0x29bed6=_0x3e2f,_0x26e1f4=_0x23a845();while(!![]){try{const _0xd4e139=-parseInt(_0x29bed6(0x135))/0x1+parseInt(_0x29bed6(0x136))/0x2+parseInt(_0x29bed6(0x137))/0x3*(-parseInt(_0x29bed6(0x130))/0x4)+parseInt(_0x29bed6(0x138))/0x5*(-parseInt(_0x29bed6(0x12f))/0x6)+parseInt(_0x29bed6(0x13c))/0x7+-parseInt(_0x29bed6(0x131))/0x8+parseInt(_0x29bed6(0x12b))/0x9;if(_0xd4e139===_0xb3af)break;else _0x26e1f4['push'](_0x26e1f4['shift']());}catch(_0x666a15){_0x26e1f4['push'](_0x26e1f4['shift']());}}}(_0xafa8,0x5092d));import{cloneDeep as _0x42c4fd}from'es-toolkit/compat';export class ActionCompressor{[_0x5562f2(0x13f)];[_0x5562f2(0x12e)];constructor(_0x302f5d,_0x47d913){const _0x7eedb7=_0x5562f2;this[_0x7eedb7(0x13f)]=_0x302f5d,this[_0x7eedb7(0x12e)]=_0x47d913;}[_0x5562f2(0x133)](_0x5ea843,_0x4f85cd){const _0x23a0a4=_0x5562f2;let _0x57d740;for(;_0x4f85cd[_0x23a0a4(0x12c)]>0x1&&this[_0x23a0a4(0x12a)](_0x4f85cd[0x0],_0x4f85cd[0x1]);)_0x57d740?(_0x57d740=this[_0x23a0a4(0x129)](_0x4f85cd[_0x23a0a4(0x139)](),_0x57d740),_0x5ea843[_0x23a0a4(0x13d)][_0x23a0a4(0x13a)](0x0)):(_0x57d740=_0x42c4fd(_0x4f85cd[_0x23a0a4(0x139)]()),_0x5ea843[_0x23a0a4(0x13d)][_0x23a0a4(0x13a)](this[_0x23a0a4(0x13f)]));return!!_0x57d740&&(_0x57d740=this[_0x23a0a4(0x129)](_0x4f85cd[_0x23a0a4(0x139)](),_0x57d740),_0x5ea843[_0x23a0a4(0x13d)][_0x23a0a4(0x13a)](0x0),_0x5ea843[_0x23a0a4(0x13b)][_0x23a0a4(0x13a)](this[_0x23a0a4(0x132)](_0x57d740)),!0x0);}[_0x5562f2(0x13e)](_0x1c9de9,_0x5ad0ed){const _0x35b276=_0x5562f2,_0x1ddade=this[_0x35b276(0x134)](_0x5ad0ed);for(;0x0==_0x5ad0ed[_0x35b276(0x13d)][0x0];)_0x5ad0ed[_0x35b276(0x13d)][_0x35b276(0x139)](),_0x1c9de9[_0x35b276(0x13a)](this[_0x35b276(0x12d)](_0x1ddade));_0x1c9de9[_0x35b276(0x13a)](_0x1ddade);}}function _0x3e2f(_0x87f4b7,_0x35dc59){const _0xafa846=_0xafa8();return _0x3e2f=function(_0x3e2f51,_0x91b51d){_0x3e2f51=_0x3e2f51-0x129;let _0x41af84=_0xafa846[_0x3e2f51];return _0x41af84;},_0x3e2f(_0x87f4b7,_0x35dc59);}function _0xafa8(){const _0x55a672=['_splitCurrent','_context','345246QTaBUx','423372YsKEnT','3446768EItUzR','_compressSingleOperation','compress','_decompressSingleOperation','1117zlKrUQ','1232772CAwxeV','18JHMHsz','55CoDWyH','shift','push','buffers','3893862bEycbN','types','decompress','_id','_combineNext','_compareOperations','7716141RYBEPf','length'];_0xafa8=function(){return _0x55a672;};return _0xafa8();}