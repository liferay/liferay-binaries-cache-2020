/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x26a8ae=_0x2466;(function(_0x4f7157,_0xc88081){const _0x4b12d2=_0x2466,_0x5be962=_0x4f7157();while(!![]){try{const _0x2fbaf7=parseInt(_0x4b12d2(0xe7))/0x1*(parseInt(_0x4b12d2(0xd8))/0x2)+-parseInt(_0x4b12d2(0xdb))/0x3*(parseInt(_0x4b12d2(0xed))/0x4)+parseInt(_0x4b12d2(0xf2))/0x5+-parseInt(_0x4b12d2(0xd9))/0x6+-parseInt(_0x4b12d2(0xda))/0x7+parseInt(_0x4b12d2(0xee))/0x8*(parseInt(_0x4b12d2(0xe4))/0x9)+-parseInt(_0x4b12d2(0xeb))/0xa*(parseInt(_0x4b12d2(0xe5))/0xb);if(_0x2fbaf7===_0xc88081)break;else _0x5be962['push'](_0x5be962['shift']());}catch(_0x2fcc73){_0x5be962['push'](_0x5be962['shift']());}}}(_0x2ab6,0x38424));function _0x2466(_0x1e6896,_0x5c8444){const _0x2ab649=_0x2ab6();return _0x2466=function(_0x2466bd,_0x19cb27){_0x2466bd=_0x2466bd-0xd7;let _0x561158=_0x2ab649[_0x2466bd];return _0x561158;},_0x2466(_0x1e6896,_0x5c8444);}import{ActionCompressor as _0x19d545}from'./actioncompressor.js';import{arePositionsEqual as _0x73288d}from'../utils.js';function _0x2ab6(){const _0x27c496=['root','wasUndone','142nEQaaO','856152qYWfVr','255486DUnVzV','6HixSKE','compress','$graveyard','_splitCurrent','buffers','_decompressSingleOperation','_checkOperation','_context','_getCompressorByName','232182PKNeQW','11DPtclq','targetPosition','396MnZmdQ','MoveOperation','decompress','howMany','1358680OTrBso','_compareOperations','243332nQVtJm','136RzRZeY','_compressSingleOperation','_combineNext','sourcePosition','1002390jAvOnc','__className'];_0x2ab6=function(){return _0x27c496;};return _0x2ab6();}import{cloneDeep as _0x47507f}from'es-toolkit/compat';export class ForwardDeletingActionCompressor extends _0x19d545{[_0x26a8ae(0xf0)](_0x350fb3,_0x260dc0){const _0x18bb77=_0x26a8ae;return _0x260dc0[_0x18bb77(0xea)]++,_0x260dc0;}[_0x26a8ae(0xde)](_0x337525){const _0x2f9fdd=_0x26a8ae,_0x276669=_0x47507f(_0x337525);return _0x276669[_0x2f9fdd(0xea)]=0x1,_0x337525[_0x2f9fdd(0xea)]--,_0x276669;}[_0x26a8ae(0xec)](_0x49234c,_0x4c5661){const _0x34ebf0=_0x26a8ae;return!(!this[_0x34ebf0(0xe1)](_0x49234c)||!this[_0x34ebf0(0xe1)](_0x4c5661))&&(_0x73288d(_0x49234c[_0x34ebf0(0xf1)],_0x4c5661[_0x34ebf0(0xf1)])&&_0x73288d(_0x49234c[_0x34ebf0(0xe6)],_0x4c5661[_0x34ebf0(0xe6)]));}[_0x26a8ae(0xef)](_0x3d2049){const _0x5bc26a=_0x26a8ae,_0x11b3e4={'types':[],'buffers':[],'baseVersion':0x0};return this[_0x5bc26a(0xe2)][_0x5bc26a(0xe3)](_0x5bc26a(0xe8))[_0x5bc26a(0xdc)](_0x11b3e4,[_0x3d2049]),_0x11b3e4[_0x5bc26a(0xdf)][0x0];}[_0x26a8ae(0xe0)](_0x5be9e0){const _0x40a263=_0x26a8ae,_0x991794=[];return this[_0x40a263(0xe2)][_0x40a263(0xe3)](_0x40a263(0xe8))[_0x40a263(0xe9)](_0x991794,_0x5be9e0),_0x991794[0x0];}[_0x26a8ae(0xe1)](_0x3e462c){const _0x42ed6c=_0x26a8ae;return _0x42ed6c(0xe8)==_0x3e462c[_0x42ed6c(0xf3)]&&_0x42ed6c(0xdd)==_0x3e462c[_0x42ed6c(0xe6)][_0x42ed6c(0xf4)]&&0x1==_0x3e462c[_0x42ed6c(0xea)]&&!_0x3e462c[_0x42ed6c(0xd7)];}}