/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module export-inline-styles/exportinlinestylesediting
 * @publicApi
 */
import { Plugin } from 'ckeditor5/src/core.js';
/**
 * The editing part of the plugin responsible for converting external CSS styles to inline styles.
 */
export declare class ExportInlineStylesEditing extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "ExportInlineStylesEditing";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    init(): void;
    /**
     * @inheritDoc
     */
    afterInit(): void;
}
