/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0xc7d18d,_0x17be8){var _0x5285e7=_0x1e25,_0x5b81e7=_0xc7d18d();while(!![]){try{var _0x420587=parseInt(_0x5285e7(0xbe))/0x1*(parseInt(_0x5285e7(0xc0))/0x2)+-parseInt(_0x5285e7(0xbc))/0x3*(parseInt(_0x5285e7(0xc1))/0x4)+-parseInt(_0x5285e7(0xbd))/0x5*(parseInt(_0x5285e7(0xc4))/0x6)+parseInt(_0x5285e7(0xbb))/0x7+parseInt(_0x5285e7(0xbf))/0x8+parseInt(_0x5285e7(0xc3))/0x9+-parseInt(_0x5285e7(0xc2))/0xa*(parseInt(_0x5285e7(0xc5))/0xb);if(_0x420587===_0x17be8)break;else _0x5b81e7['push'](_0x5b81e7['shift']());}catch(_0x503469){_0x5b81e7['push'](_0x5b81e7['shift']());}}}(_0x4fff,0x3986d));export{ExportInlineStyles}from'./exportinlinestyles.js';export{ExportInlineStylesCommand}from'./exportinlinestylescommand.js';export{ExportInlineStylesEditing}from'./exportinlinestylesediting.js';export{dropImportantStyleSuffix}from'./exportinlinestylesutils.js';function _0x4fff(){var _0x2009c5=['160200ssncyK','54UHmHWX','340dPaYkz','110LcwIQG','345771rbUilt','6OTQtKR','84953uCvPYW','1601397TDURRJ','5709gLVrHs','494810lyCAUW','10892CDqTtw'];_0x4fff=function(){return _0x2009c5;};return _0x4fff();}function _0x1e25(_0x59b372,_0x47bca3){var _0x4ffffb=_0x4fff();return _0x1e25=function(_0x1e25f6,_0x64c5c1){_0x1e25f6=_0x1e25f6-0xbb;var _0x368113=_0x4ffffb[_0x1e25f6];return _0x368113;},_0x1e25(_0x59b372,_0x47bca3);}import'./augmentation.js';