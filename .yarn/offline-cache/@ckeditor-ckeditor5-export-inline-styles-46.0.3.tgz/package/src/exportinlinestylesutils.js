/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x5bbf(){const _0x730d96=['replace','length','596648ImhiJP','filter','24rCmkOM','1477494NBMblb','72lFsQPY','1861867NqtitB','push','672012xoPIBB','1038495DseKhK','6701fLpiLR','trim','endsWith','1628324HRmkde','slice'];_0x5bbf=function(){return _0x730d96;};return _0x5bbf();}function _0x172a(_0x125095,_0x58b0ee){const _0x5bbf06=_0x5bbf();return _0x172a=function(_0x172aab,_0x342200){_0x172aab=_0x172aab-0x98;let _0x2fdf37=_0x5bbf06[_0x172aab];return _0x2fdf37;},_0x172a(_0x125095,_0x58b0ee);}(function(_0xe8c808,_0xee6d58){const _0x46cacc=_0x172a,_0x1f1be1=_0xe8c808();while(!![]){try{const _0x3bcbc5=-parseInt(_0x46cacc(0xa1))/0x1*(-parseInt(_0x46cacc(0x9a))/0x2)+-parseInt(_0x46cacc(0x9f))/0x3+-parseInt(_0x46cacc(0xa4))/0x4+parseInt(_0x46cacc(0xa0))/0x5+parseInt(_0x46cacc(0x9b))/0x6+-parseInt(_0x46cacc(0x9d))/0x7+-parseInt(_0x46cacc(0x98))/0x8*(-parseInt(_0x46cacc(0x9c))/0x9);if(_0x3bcbc5===_0xee6d58)break;else _0x1f1be1['push'](_0x1f1be1['shift']());}catch(_0x142074){_0x1f1be1['push'](_0x1f1be1['shift']());}}}(_0x5bbf,0x391d6));export function splitByTopLevelComma(_0x83425a){const _0x4ba2aa=_0x172a,_0x10f7a0=[];let _0xf9cbae='',_0x3eeaab=0x0;for(;_0x3eeaab<_0x83425a[_0x4ba2aa(0xa7)];){const _0x18089c=_0x83425a[_0x3eeaab];if('('===_0x18089c){const _0x209e7e=findMatchingParenthesis(_0x83425a,_0x3eeaab+0x1);if(-0x1===_0x209e7e)return[];_0xf9cbae+=_0x83425a[_0x4ba2aa(0xa5)](_0x3eeaab,_0x209e7e+0x1),_0x3eeaab=_0x209e7e+0x1;}else','!==_0x18089c||_0xf9cbae[_0x4ba2aa(0xa3)]('\x5c')?(_0xf9cbae+=_0x18089c,_0x3eeaab++):(_0x10f7a0[_0x4ba2aa(0x9e)](_0xf9cbae[_0x4ba2aa(0xa2)]()),_0xf9cbae='',_0x3eeaab++);}return _0xf9cbae[_0x4ba2aa(0xa2)]()&&_0x10f7a0[_0x4ba2aa(0x9e)](_0xf9cbae[_0x4ba2aa(0xa2)]()),_0x10f7a0[_0x4ba2aa(0x99)](Boolean);}export function findMatchingParenthesis(_0x1a2387,_0x4d5cc8){const _0x12d679=_0x172a;let _0x20715c=0x1;for(let _0x1e7654=_0x4d5cc8;_0x1e7654<_0x1a2387[_0x12d679(0xa7)];_0x1e7654++){const _0x5d881b=_0x1a2387[_0x1e7654];if('('===_0x5d881b)_0x20715c++;else{if(')'===_0x5d881b&&(_0x20715c--,0x0===_0x20715c))return _0x1e7654;}}return-0x1;}export function dropImportantStyleSuffix(_0x4d5f14){const _0x432936=_0x172a;return _0x4d5f14[_0x432936(0xa6)](/!\s*important/i,'')[_0x432936(0xa2)]();}