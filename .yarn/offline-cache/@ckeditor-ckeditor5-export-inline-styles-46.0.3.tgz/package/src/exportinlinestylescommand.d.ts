/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module export-inline-styles/exportinlinestylescommand
 * @publicApi
 */
import { Command, type Editor } from 'ckeditor5/src/core.js';
import type { ExportInlineStylesTransformation } from './exportinlinestyles.js';
/**
 * The export to inline styles command.
 */
export declare class ExportInlineStylesCommand extends Command {
    /**
     * A command status that indicates whether the command is currently being executed.
     *
     * @observable
     */
    isBusy: boolean;
    /**
     * @inheritDoc
     */
    constructor(editor: Editor);
    /**
     * @inheritDoc
     */
    refresh(): void;
    /**
     * Executes a command that converts the editor's content to a string HTML representation.
     *
     * @fires execute
     * @param options Additional configuration for the retrieved data.
     * @param options.rootName The name of the root element to get. Defaults to `'main'`.
     * @param options.dataControllerDowncastOptions Additional configuration that will be available through the
     * {@link module:engine/conversion/downcastdispatcher~DowncastConversionApi#options} during the conversion process.
     * @param options.transformations An array of transformation callbacks. For more detailed information about the format see
     * {@link module:export-inline-styles/exportinlinestyles~ExportInlineStylesConfig}.
     * @returns A promise resolved with the processed string HTML content.
     */
    execute(options: {
        rootName?: string;
        dataControllerDowncastOptions?: Record<string, unknown>;
        transformations?: Array<ExportInlineStylesTransformation>;
    }): Promise<string>;
}
