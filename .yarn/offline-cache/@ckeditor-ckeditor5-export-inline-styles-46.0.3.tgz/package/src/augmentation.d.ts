/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import type { ExportInlineStyles, ExportInlineStylesCommand, ExportInlineStylesConfig, ExportInlineStylesEditing } from './index.js';
declare module '@ckeditor/ckeditor5-core' {
    interface PluginsMap {
        [ExportInlineStyles.pluginName]: ExportInlineStyles;
        [ExportInlineStylesEditing.pluginName]: ExportInlineStylesEditing;
    }
    interface CommandsMap {
        exportInlineStyles: ExportInlineStylesCommand;
    }
    interface EditorConfig {
        /**
         * The configuration of the {@link module:export-inline-styles/exportinlinestyles~ExportInlineStyles export inline styles feature}.
         *
         * Read more in {@link module:export-inline-styles/exportinlinestyles~ExportInlineStylesConfig}.
         */
        exportInlineStyles?: ExportInlineStylesConfig;
    }
}
