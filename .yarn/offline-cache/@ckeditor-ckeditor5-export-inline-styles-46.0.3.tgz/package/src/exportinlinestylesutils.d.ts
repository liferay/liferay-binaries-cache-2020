/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module export-inline-styles/exportinlinestylesutils
 */
/**
 * Splits a string by top-level separators while preserving nested structures in parentheses.
 * Useful for parsing CSS-like syntax where nested structures should be kept intact.
 *
 * @param text The text to split.
 * @returns An array of individual segments.
 *
 * ```ts
 * // CSS selectors with nested pseudo-functions
 * splitByTopLevelComma( ':is(h1, h2, h3).title' );
 * // → [ ':is(h1, h2, h3).title' ]
 *
 * splitByTopLevelComma( '.foo:is(.bar, .baz), .qux' );
 * // → [ '.foo:is(.bar, .baz)', '.qux' ]
 *
 * // CSS values with color functions
 * splitByTopLevelComma( 'rgb(255, 0, 0), blue' );
 * // → [ 'rgb(255, 0, 0)', 'blue' ]
 *
 * // Generic nested structures
 * splitByTopLevelComma( 'foo(1, 2), bar(3, fn(4, 5)), baz' );
 * // → [ 'foo(1, 2)', 'bar(3, fn(4, 5))', 'baz' ]
 * ```
 */
export declare function splitByTopLevelComma(text: string): Array<string>;
/**
 * Finds the position of matching closing parenthesis, handling nested parentheses.
 * Used for CSS-like syntax parsing where functions can be nested (like in `var(--color, var(--fallback))`).
 *
 * @param text The text to search in.
 * @param startPosition Position after the opening parenthesis.
 * @returns Position of the matching closing parenthesis or -1 if not found.
 *
 * @example
 * ```ts
 * findMatchingParenthesis( 'var(--color, var(--fallback))', 4 ); // returns 28
 * findMatchingParenthesis( 'rgb(255, 0, 0)', 4 ); // returns 13
 * ```
 */
export declare function findMatchingParenthesis(text: string, startPosition: number): number;
/**
 * Removes the `!important` suffix from a CSS property value.
 *
 * @param value The CSS property value which might contain `!important`.
 * @returns The cleaned value without `!important`.
 *
 * @example
 * // returns "color: red" from "color: red !important"
 */
export declare function dropImportantStyleSuffix(value: string): string;
