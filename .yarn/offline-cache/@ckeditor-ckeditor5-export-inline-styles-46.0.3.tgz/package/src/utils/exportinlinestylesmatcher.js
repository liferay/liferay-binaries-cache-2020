/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x54e05c,_0x23b861){const _0x2dba32=_0x487c,_0xe50612=_0x54e05c();while(!![]){try{const _0x3a2ca0=parseInt(_0x2dba32(0x17a))/0x1*(-parseInt(_0x2dba32(0x17c))/0x2)+-parseInt(_0x2dba32(0x165))/0x3*(parseInt(_0x2dba32(0x17b))/0x4)+parseInt(_0x2dba32(0x16c))/0x5*(parseInt(_0x2dba32(0x174))/0x6)+-parseInt(_0x2dba32(0x178))/0x7*(-parseInt(_0x2dba32(0x171))/0x8)+parseInt(_0x2dba32(0x16e))/0x9+-parseInt(_0x2dba32(0x16b))/0xa*(parseInt(_0x2dba32(0x163))/0xb)+parseInt(_0x2dba32(0x16a))/0xc;if(_0x3a2ca0===_0x23b861)break;else _0xe50612['push'](_0xe50612['shift']());}catch(_0x280b08){_0xe50612['push'](_0xe50612['shift']());}}}(_0x29b4,0xe2302));function _0x487c(_0x25eb11,_0x3654f4){const _0x29b417=_0x29b4();return _0x487c=function(_0x487c34,_0x5e8b10){_0x487c34=_0x487c34-0x162;let _0x143c3d=_0x29b417[_0x487c34];return _0x143c3d;},_0x487c(_0x25eb11,_0x3654f4);}import{StylesMap as _0xda98b5}from'ckeditor5/src/engine.js';import{inlineStylesMapCSSVariables as _0x2f5995}from'./exportinlinestylescssvariables.js';function _0x29b4(){const _0x4b9a0e=['6891psZHch','map','element','stylesMap','setTo','16965996oaVRQX','490HFMniV','3005GcDIoq','flatSelector','12195270XQqHVQ','string','fallbackCSSVariablesLookup','4442664JnmClV','parsedCssRules','set','474WTFSCd','matches','style','stylesProcessor','21clYQIb','getStylesEntries','1740107JOjIPC','964agcIqo','2gVVWgw','getAttribute','283349Rnyiuy','filter'];_0x29b4=function(){return _0x4b9a0e;};return _0x29b4();}export function getElementInlineStyles(_0x541bff){const _0x3ad86d=_0x487c,_0x432d9c=_0x541bff[_0x3ad86d(0x167)][_0x3ad86d(0x162)](_0x3ad86d(0x176))||'',_0x5e73a1=_0x541bff[_0x3ad86d(0x172)][_0x3ad86d(0x164)](_0x5ee03c=>_0x541bff[_0x3ad86d(0x167)][_0x3ad86d(0x175)](_0x5ee03c[_0x3ad86d(0x16d)]))[_0x3ad86d(0x166)](_0x4a2920=>_0x4a2920[_0x3ad86d(0x168)]),_0x1e8c86=concatStylesMaps(_0x541bff[_0x3ad86d(0x177)],[..._0x5e73a1,_0x432d9c]);return{'localCSSVariables':_0x2f5995(_0x541bff[_0x3ad86d(0x170)],_0x1e8c86),'stylesMap':_0x1e8c86};}export function concatStylesMaps(_0x439b9b,_0x2c2ea4){const _0x92efae=_0x487c,_0x2b69b9=new _0xda98b5(_0x439b9b);for(const _0x1bc670 of _0x2c2ea4){let _0x970aa6=null;if(_0x970aa6=_0x92efae(0x16f)==typeof _0x1bc670?new _0xda98b5(_0x439b9b)[_0x92efae(0x169)](_0x1bc670):_0x1bc670,_0x970aa6){for(const [_0x297875,_0x3572d3]of _0x970aa6[_0x92efae(0x179)]())_0x2b69b9[_0x92efae(0x173)](_0x297875,_0x3572d3);}}return _0x2b69b9;}