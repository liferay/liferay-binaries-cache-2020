/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import { StylesMap, type StylesProcessor } from 'ckeditor5/src/engine.js';
import { type CSSVariablesMap } from './exportinlinestylescssvariables.js';
/**
 * Processes raw stylesheets from various sources and converts them into parsed CSS rules.
 * This function combines stylesheets from external files and inline CSS, filters out empty entries,
 * and converts the raw CSS text into parsed CSS rules.
 *
 * **NOTE:**
 *
 * 	1. The order of the stylesheets matters.
 * 	2. The rules from the last stylesheet have the highest priority.
 *
 * @param options Configuration options containing stylesheet paths and inline CSS.
 * @returns A promise that resolves to an array of parsed CSS rules and a map of root CSS variables.
 */
export declare function collectAndProcessStylesheets(options: {
    stylesProcessor: StylesProcessor;
    stylesheets?: Array<string>;
    inlineCss?: string;
}): Promise<{
    parsedCssRules: Array<ParsedCSSRule>;
    rootCssVariables: CSSVariablesMap;
}>;
/**
 * Represents a flattened CSS rule with its selector and style information.
 */
export type ParsedCSSRule = {
    /**
     * A single CSS selector extracted from potentially comma-separated selectors.
     * For example, for `h1, h2 { color: red }`, there would be two separate rules with `h1` and `h2` as flatSelector.
     */
    flatSelector: string;
    /**
     * A map of styles extracted from the CSS rule.
     */
    stylesMap: StylesMap;
};
