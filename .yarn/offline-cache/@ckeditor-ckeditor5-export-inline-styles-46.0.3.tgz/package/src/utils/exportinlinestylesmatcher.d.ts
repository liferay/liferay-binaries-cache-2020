/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module export-inline-styles/utils/exportinlinestylesmatcher
 */
import { StylesMap, type StylesProcessor } from 'ckeditor5/src/engine.js';
import type { ParsedCSSRule } from './exportinlinestylescollector.js';
import { type CSSVariableLookupCallback, type CSSVariablesMap } from './exportinlinestylescssvariables.js';
/**
 * Returns inline styles that should be applied to the given element based on matched CSS rules.
 *
 * @param options.stylesProcessor A StylesProcessor instance.
 * @param options.fallbackCSSVariablesLookup A function that returns a CSS variable value for a given variable name.
 * @param options.parsedCssRules An array of parsed CSS rules.
 * @param options.element The HTML element to get inline styles for.
 * @returns A string containing inline styles.
 *
 * ```ts
 * const rules = [
 *   { flatSelector: 'p.important', stylesMap: new StylesMap( 'color: red;' ) },
 *   { flatSelector: 'p', stylesMap: new StylesMap( 'font-size: 12px;' ) }
 * ];
 * const element = document.createElement( 'p' );
 * element.className = 'important';
 *
 * const { stylesMap } = getElementInlineStyles( rules, element );
 * // Returns styles map with: "color: red; font-size: 12px"
 * ```
 */
export declare function getElementInlineStyles(options: {
    stylesProcessor: StylesProcessor;
    fallbackCSSVariablesLookup: CSSVariableLookupCallback;
    parsedCssRules: Array<ParsedCSSRule>;
    element: HTMLElement;
}): {
    localCSSVariables: CSSVariablesMap;
    stylesMap: StylesMap;
};
/**
 * Combines multiple StylesMap or String objects into a single StylesMap object.
 *
 * @param stylesProcessor A StylesProcessor instance.
 * @param stylesMaps An array of StylesMap objects to combine.
 * @returns A StylesMap object containing all combined styles.
 */
export declare function concatStylesMaps(stylesProcessor: StylesProcessor, stylesMaps: Array<StylesMap | string | null>): StylesMap;
