/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x5199(){const _0x542938=['requires','isOfficialPlugin','pluginName','editor','bind','ready','3280448ySgglx','9FzApji','192628tSmyWY','get','scrollToPage','forceDisabled','Pagination','1482732VXLkvX','set','pageNumber','isEnabled','browserCheck','1krYwIn','isPremiumPlugin','219646ravrBN','totalPages','2469131HiaxpW','70mJnlYo','config','1677375unGeck','isBlink','pagination.enableOnUnsupportedBrowsers','plugins','848682ZNbKaf','init'];_0x5199=function(){return _0x542938;};return _0x5199();}const _0x162ab0=_0x2282;(function(_0x2db44f,_0x1ce03b){const _0x2b80a6=_0x2282,_0x362c3=_0x2db44f();while(!![]){try{const _0x3d8c53=parseInt(_0x2b80a6(0x185))/0x1*(-parseInt(_0x2b80a6(0x187))/0x2)+-parseInt(_0x2b80a6(0x17a))/0x3*(-parseInt(_0x2b80a6(0x17b))/0x4)+parseInt(_0x2b80a6(0x18c))/0x5+-parseInt(_0x2b80a6(0x180))/0x6+parseInt(_0x2b80a6(0x189))/0x7+parseInt(_0x2b80a6(0x179))/0x8+-parseInt(_0x2b80a6(0x171))/0x9*(parseInt(_0x2b80a6(0x18a))/0xa);if(_0x3d8c53===_0x1ce03b)break;else _0x362c3['push'](_0x362c3['shift']());}catch(_0x1cf2b3){_0x362c3['push'](_0x362c3['shift']());}}}(_0x5199,0x371a8));function _0x2282(_0x484b6d,_0x570702){const _0x519939=_0x5199();return _0x2282=function(_0x228206,_0x11c068){_0x228206=_0x228206-0x170;let _0x356844=_0x519939[_0x228206];return _0x356844;},_0x2282(_0x484b6d,_0x570702);}import{Plugin as _0x167360}from'ckeditor5/src/core.js';import{PaginationEditing as _0x331701}from'./paginationediting.js';import{PaginationUI as _0x482c80}from'./paginationui.js';import{env as _0x247056}from'ckeditor5/src/utils.js';export class Pagination extends _0x167360{static get[_0x162ab0(0x175)](){const _0x4799fb=_0x162ab0;return _0x4799fb(0x17f);}static get[_0x162ab0(0x174)](){return!0x0;}static get[_0x162ab0(0x186)](){return!0x0;}static get[_0x162ab0(0x173)](){return[_0x331701,_0x482c80];}constructor(_0x57523d){const _0x1d24d5=_0x162ab0;super(_0x57523d),this[_0x1d24d5(0x183)]=!0x1;}[_0x162ab0(0x172)](){const _0x4b18c7=_0x162ab0;this[_0x4b18c7(0x181)]({'pageNumber':0x1,'totalPages':0x1});const _0x222467=this[_0x4b18c7(0x176)][_0x4b18c7(0x170)][_0x4b18c7(0x17c)](_0x331701);this[_0x4b18c7(0x177)](_0x4b18c7(0x182))['to'](_0x222467),this[_0x4b18c7(0x177)](_0x4b18c7(0x188))['to'](_0x222467),_0x247056[_0x4b18c7(0x18d)]||this[_0x4b18c7(0x176)][_0x4b18c7(0x18b)][_0x4b18c7(0x17c)](_0x4b18c7(0x18e))?this[_0x4b18c7(0x176)]['on'](_0x4b18c7(0x178),()=>{const _0x1bae3c=_0x4b18c7;this[_0x1bae3c(0x183)]=!0x0;}):this[_0x4b18c7(0x17e)](_0x4b18c7(0x184));}[_0x162ab0(0x17d)](_0x3e6b9e){const _0x25f0e2=_0x162ab0;this[_0x25f0e2(0x176)][_0x25f0e2(0x170)][_0x25f0e2(0x17c)](_0x331701)[_0x25f0e2(0x17d)](_0x3e6b9e);}}