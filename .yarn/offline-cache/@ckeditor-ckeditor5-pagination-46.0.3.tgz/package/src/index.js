/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x8fb0ec,_0x3f2d9e){var _0x4a0a11=_0x3e07,_0x5c2635=_0x8fb0ec();while(!![]){try{var _0x3bdefa=parseInt(_0x4a0a11(0xa3))/0x1*(parseInt(_0x4a0a11(0xa7))/0x2)+-parseInt(_0x4a0a11(0xa8))/0x3+-parseInt(_0x4a0a11(0xa4))/0x4+parseInt(_0x4a0a11(0xa0))/0x5+parseInt(_0x4a0a11(0xa2))/0x6+-parseInt(_0x4a0a11(0xa5))/0x7*(-parseInt(_0x4a0a11(0xa6))/0x8)+parseInt(_0x4a0a11(0x9f))/0x9*(-parseInt(_0x4a0a11(0xa1))/0xa);if(_0x3bdefa===_0x3f2d9e)break;else _0x5c2635['push'](_0x5c2635['shift']());}catch(_0xe34f96){_0x5c2635['push'](_0x5c2635['shift']());}}}(_0x2983,0x860ef));export{Pagination}from'./pagination.js';function _0x3e07(_0x5a56ed,_0x1a3e38){var _0x2983a6=_0x2983();return _0x3e07=function(_0x3e07b8,_0x488187){_0x3e07b8=_0x3e07b8-0x9f;var _0x52c0fb=_0x2983a6[_0x3e07b8];return _0x52c0fb;},_0x3e07(_0x5a56ed,_0x1a3e38);}export{PaginationRenderer}from'./paginationrenderer.js';function _0x2983(){var _0x22338f=['2383820uMXmVW','7654759MNzhpw','8DZAjgc','2074jzwhqP','3236499SEndpr','27trwXSv','2464240WIJCde','1075770iSCgVd','5624538LBikJU','22uRyrLM'];_0x2983=function(){return _0x22338f;};return _0x2983();}import'./augmentation.js';