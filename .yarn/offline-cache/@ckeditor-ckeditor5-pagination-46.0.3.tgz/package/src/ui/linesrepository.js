/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x39a0a0=_0x5b4d;(function(_0x2f8cfe,_0x361f8e){const _0x1815fd=_0x5b4d,_0x35f135=_0x2f8cfe();while(!![]){try{const _0x985b07=-parseInt(_0x1815fd(0x1bb))/0x1*(-parseInt(_0x1815fd(0x1b5))/0x2)+parseInt(_0x1815fd(0x1bd))/0x3+parseInt(_0x1815fd(0x1ad))/0x4*(-parseInt(_0x1815fd(0x1ac))/0x5)+-parseInt(_0x1815fd(0x1a6))/0x6+-parseInt(_0x1815fd(0x1ba))/0x7+-parseInt(_0x1815fd(0x1b2))/0x8+parseInt(_0x1815fd(0x1af))/0x9;if(_0x985b07===_0x361f8e)break;else _0x35f135['push'](_0x35f135['shift']());}catch(_0x402ccd){_0x35f135['push'](_0x35f135['shift']());}}}(_0x53c4,0x288d0));function _0x5b4d(_0x126b7e,_0x2bb0f7){const _0x53c464=_0x53c4();return _0x5b4d=function(_0x5b4d9c,_0x3b1870){_0x5b4d9c=_0x5b4d9c-0x1a4;let _0x55a966=_0x53c464[_0x5b4d9c];return _0x55a966;},_0x5b4d(_0x126b7e,_0x2bb0f7);}import{first as _0x32f356}from'ckeditor5/src/utils.js';import{LineView as _0x5729f0}from'./lineview.js';function _0x53c4(){const _0x539fa7=['20yTxerW','has','4629024vRgZaj','_viewCollection','view','2288360FnwPLV','size','set','10QFOQKl','clear','isVisible','_visibleLines','delete','791987hEZPIU','63052AXDkIT','body','564858HDaObS','showLine','values','destroy','1183500pnQbHR','cleanLines','_hiddenLines','setViewCollection','remove','add','255350pqLnfR'];_0x53c4=function(){return _0x539fa7;};return _0x53c4();}export class LinesRepository{[_0x39a0a0(0x1b0)];[_0x39a0a0(0x1b8)]=new Set();[_0x39a0a0(0x1a8)]=new Set();constructor(_0x238167){const _0x5dbfca=_0x39a0a0;this[_0x5dbfca(0x1b0)]=_0x238167['ui'][_0x5dbfca(0x1b1)][_0x5dbfca(0x1bc)];}[_0x39a0a0(0x1a5)](){const _0x1675fb=_0x39a0a0;for(const _0x4efc5b of this[_0x1675fb(0x1a8)])_0x4efc5b[_0x1675fb(0x1a5)]();}[_0x39a0a0(0x1a7)](){const _0xff8be9=_0x39a0a0;for(const _0x5d5024 of this[_0xff8be9(0x1b8)])_0x5d5024[_0xff8be9(0x1b7)]=!0x1,this[_0xff8be9(0x1a8)][_0xff8be9(0x1ab)](_0x5d5024);this[_0xff8be9(0x1b8)][_0xff8be9(0x1b6)]();}[_0x39a0a0(0x1be)](_0x3a03de,_0x2c5dfa,_0x1483ee,_0x1e1d0a){const _0x287d6d=_0x39a0a0;let _0x4262e0;this[_0x287d6d(0x1a8)][_0x287d6d(0x1b3)]?(_0x4262e0=_0x32f356(this[_0x287d6d(0x1a8)][_0x287d6d(0x1a4)]()),this[_0x287d6d(0x1a8)][_0x287d6d(0x1b9)](_0x4262e0)):_0x4262e0=new _0x5729f0(),_0x4262e0[_0x287d6d(0x1b4)]({'pageNumber':_0x1e1d0a,'left':_0x3a03de,'top':_0x2c5dfa,'width':_0x1483ee}),_0x4262e0[_0x287d6d(0x1b7)]=!0x0,this[_0x287d6d(0x1b0)][_0x287d6d(0x1ae)](_0x4262e0)||this[_0x287d6d(0x1b0)][_0x287d6d(0x1ab)](_0x4262e0),this[_0x287d6d(0x1b8)][_0x287d6d(0x1ab)](_0x4262e0);}[_0x39a0a0(0x1a9)](_0x325fe1){const _0x1ffb6c=_0x39a0a0;for(const _0x2bde89 of[...this[_0x1ffb6c(0x1b8)],...this[_0x1ffb6c(0x1a8)]])this[_0x1ffb6c(0x1b0)][_0x1ffb6c(0x1ae)](_0x2bde89)&&this[_0x1ffb6c(0x1b0)][_0x1ffb6c(0x1aa)](_0x2bde89);this[_0x1ffb6c(0x1b0)]=_0x325fe1;}}