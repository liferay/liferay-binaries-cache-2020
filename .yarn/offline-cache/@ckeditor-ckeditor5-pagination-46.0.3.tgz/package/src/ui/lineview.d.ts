/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module pagination/ui/lineview
 */
import { View } from 'ckeditor5/src/ui.js';
import '../../theme/line.css';
/**
 * The page break line view.
 */
export declare class LineView extends View {
    /**
     * Controls whether the line is visible.
     *
     * @observable
     * @default false
     */
    isVisible: boolean;
    /**
     * Controls the line position x coordinate.
     *
     * @observable
     * @default null
     */
    left: number | null;
    /**
     * Controls the line width.
     *
     * @observable
     * @default null
     */
    width: number | null;
    /**
     * Controls the line label.
     *
     * @observable
     * @default null
     */
    pageNumber: number | null;
    /**
     * Controls the line position y coordinate.
     *
     * @observable
     * @default null
     */
    top: number | null;
    /**
     * @inheritDoc
     */
    constructor();
}
