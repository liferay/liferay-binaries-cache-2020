/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x24490a,_0x48fc1b){const _0x72d1ef=_0x4d61,_0x14c1ef=_0x24490a();while(!![]){try{const _0xb449e5=parseInt(_0x72d1ef(0xe0))/0x1*(-parseInt(_0x72d1ef(0xd9))/0x2)+-parseInt(_0x72d1ef(0xdb))/0x3+parseInt(_0x72d1ef(0xe5))/0x4+-parseInt(_0x72d1ef(0xe3))/0x5+parseInt(_0x72d1ef(0xea))/0x6+parseInt(_0x72d1ef(0xdc))/0x7+parseInt(_0x72d1ef(0xeb))/0x8;if(_0xb449e5===_0x48fc1b)break;else _0x14c1ef['push'](_0x14c1ef['shift']());}catch(_0x4bf343){_0x14c1ef['push'](_0x14c1ef['shift']());}}}(_0xb4a5,0x39485));import{View as _0x588ddf}from'ckeditor5/src/ui.js';function _0x4d61(_0x12a754,_0x13e2b6){const _0xb4a5ba=_0xb4a5();return _0x4d61=function(_0x4d6155,_0x31dcb5){_0x4d6155=_0x4d6155-0xd9;let _0x3dd0a9=_0xb4a5ba[_0x4d6155];return _0x3dd0a9;},_0x4d61(_0x12a754,_0x13e2b6);}import{toUnit as _0x2e6a7b}from'ckeditor5/src/utils.js';import'../../theme/line.css';function _0xb4a5(){const _0x3cbe56=['2725904oFSKdN','4gkAQQG','div','525711sIOmFM','1140951jfWvOp','bindTemplate','ck-pagination-view-line','setTemplate','86948ZUmNlX','top','isVisible','946745xqLzbN','pageNumber','1020832hQDGRy','ck-hidden','width','set','left','85032hmvHKQ'];_0xb4a5=function(){return _0x3cbe56;};return _0xb4a5();}const z=/* #__PURE__ -- @preserve */
_0x2e6a7b('px');export class LineView extends _0x588ddf{constructor(){const _0x484894=_0x4d61;super();const _0x5427ef=this[_0x484894(0xdd)];this[_0x484894(0xe8)]({'isVisible':!0x1,'left':null,'top':null,'width':null,'pageNumber':null}),this[_0x484894(0xdf)]({'tag':_0x484894(0xda),'attributes':{'data-page-number':_0x5427ef['to'](_0x484894(0xe4)),'class':['ck',_0x484894(0xde),_0x5427ef['if'](_0x484894(0xe2),_0x484894(0xe6),_0x5cfe6f=>!_0x5cfe6f)],'style':{'left':_0x5427ef['to'](_0x484894(0xe9),_0x486577=>z(_0x486577)),'top':_0x5427ef['to'](_0x484894(0xe1),_0x423e5c=>z(_0x423e5c)),'width':_0x5427ef['to'](_0x484894(0xe7),_0x10299f=>z(_0x10299f))}}});}}