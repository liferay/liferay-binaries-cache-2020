/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x4970(){var _0x589be0=['pluginName','SlashCommand','278466FdXVLu','2806062fybzIR','643517vUREAk','Mention','180bTdXqA','133672KRnZxD','isPremiumPlugin','4qDbiDO','1883380kRsTBo','160183BNIMmz','requires','isOfficialPlugin','1699472PmBVwB'];_0x4970=function(){return _0x589be0;};return _0x4970();}var _0x30d573=_0x474b;(function(_0x29086f,_0x2dee95){var _0x14ce1f=_0x474b,_0x16345f=_0x29086f();while(!![]){try{var _0x5b64e8=-parseInt(_0x14ce1f(0x176))/0x1*(-parseInt(_0x14ce1f(0x174))/0x2)+parseInt(_0x14ce1f(0x17c))/0x3+parseInt(_0x14ce1f(0x179))/0x4+parseInt(_0x14ce1f(0x175))/0x5+-parseInt(_0x14ce1f(0x17d))/0x6+-parseInt(_0x14ce1f(0x17e))/0x7+-parseInt(_0x14ce1f(0x172))/0x8*(parseInt(_0x14ce1f(0x171))/0x9);if(_0x5b64e8===_0x2dee95)break;else _0x16345f['push'](_0x16345f['shift']());}catch(_0x28a0e5){_0x16345f['push'](_0x16345f['shift']());}}}(_0x4970,0x4e5b0));import{Plugin as _0x252c5e}from'ckeditor5/src/core.js';function _0x474b(_0x534d75,_0x3b2a5e){var _0x497077=_0x4970();return _0x474b=function(_0x474bc6,_0x764322){_0x474bc6=_0x474bc6-0x171;var _0x4cd939=_0x497077[_0x474bc6];return _0x4cd939;},_0x474b(_0x534d75,_0x3b2a5e);}import{SlashCommandEditing as _0x792c2c}from'./slashcommandediting.js';import{SlashCommandUI as _0x30a06a}from'./slashcommandui.js';export class SlashCommand extends _0x252c5e{static get[_0x30d573(0x177)](){var _0x18d4c6=_0x30d573;return[_0x18d4c6(0x17f),_0x792c2c,_0x30a06a];}static get[_0x30d573(0x17a)](){var _0x4459b7=_0x30d573;return _0x4459b7(0x17b);}static get[_0x30d573(0x178)](){return!0x0;}static get[_0x30d573(0x173)](){return!0x0;}}