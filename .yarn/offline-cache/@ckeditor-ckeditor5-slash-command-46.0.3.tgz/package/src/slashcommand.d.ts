/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module slash-command/slashcommand
 * @publicApi
 */
import { Plugin } from 'ckeditor5/src/core.js';
import { SlashCommandEditing } from './slashcommandediting.js';
import { SlashCommandUI } from './slashcommandui.js';
/**
 * The slash command feature.
 * It allows for an easy access to a predefined list of editor commands by typing `/` inside the editor.
 *
 * For a detailed overview, check the {@glink features/slash-commands Slash command} feature guide.
 *
 * @extends module:core/plugin~Plugin
 */
export declare class SlashCommand extends Plugin {
    /**
     * @inheritDoc
     */
    static get requires(): readonly ["Mention", typeof SlashCommandEditing, typeof SlashCommandUI];
    /**
     * @inheritDoc
     */
    static get pluginName(): "SlashCommand";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
}
