/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import type { SlashCommand, SlashCommandConfig, SlashCommandEditing, SlashCommandUI, SlashCommandEditorConfig } from './index.js';
declare module '@ckeditor/ckeditor5-core' {
    interface EditorConfig {
        /**
         * The configuration of the {@link module:slash-command/slashcommand~SlashCommand} feature.
         *
         * Read more in {@link module:slash-command/slashcommandeditorconfig~SlashCommandEditorConfig}.
         */
        slashCommand?: SlashCommandEditorConfig;
    }
    interface PluginsMap {
        [SlashCommand.pluginName]: SlashCommand;
        [SlashCommandConfig.pluginName]: SlashCommandConfig;
        [SlashCommandEditing.pluginName]: SlashCommandEditing;
        [SlashCommandUI.pluginName]: SlashCommandUI;
    }
}
