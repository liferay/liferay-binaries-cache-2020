/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module slash-command
 */
export { SlashCommand } from './slashcommand.js';
export { SlashCommandConfig } from './slashcommandconfig.js';
export { SlashCommandEditing } from './slashcommandediting.js';
export { SlashCommandUI } from './slashcommandui.js';
export type { SlashCommandEditorConfig } from './slashcommandeditorconfig.js';
export type { SlashCommandDefinition } from './slashcommandconfig.js';
import './augmentation.js';
