/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x93c769=_0x5608;(function(_0x1be5db,_0x3dc8ee){const _0x2dd5c5=_0x5608,_0x5eebc6=_0x1be5db();while(!![]){try{const _0x10777a=parseInt(_0x2dd5c5(0x195))/0x1+parseInt(_0x2dd5c5(0x199))/0x2+parseInt(_0x2dd5c5(0x1a5))/0x3+parseInt(_0x2dd5c5(0x189))/0x4+-parseInt(_0x2dd5c5(0x1a1))/0x5*(parseInt(_0x2dd5c5(0x18f))/0x6)+parseInt(_0x2dd5c5(0x191))/0x7+-parseInt(_0x2dd5c5(0x192))/0x8;if(_0x10777a===_0x3dc8ee)break;else _0x5eebc6['push'](_0x5eebc6['shift']());}catch(_0xc2c685){_0x5eebc6['push'](_0x5eebc6['shift']());}}}(_0x5684,0x51890));import{Plugin as _0x5a5f0a}from'ckeditor5/src/core.js';function _0x5608(_0x2d8926,_0x5568f1){const _0x5684bb=_0x5684();return _0x5608=function(_0x560805,_0x107304){_0x560805=_0x560805-0x189;let _0x5b8c9e=_0x5684bb[_0x560805];return _0x5b8c9e;},_0x5608(_0x2d8926,_0x5568f1);}import{SlashCommandConfig as _0x2362c8}from'./slashcommandconfig.js';function _0x5684(){const _0x468aa2=['pluginName','738549QWGBsc','1697488xLLQNa','push','SlashCommandEditing','isEnabled','requires','toLowerCase','2220CHmmWt','editor','2251291GMYHRI','9766696sWdSjn','getAllowedCommands','aliases','130651ezLuJO','SlashCommandConfig','includes','plugins','880992QylYDg','description','getMatchingCommands','isPremiumPlugin','get','isOfficialPlugin','concat','filter','115typLls','title','some'];_0x5684=function(){return _0x468aa2;};return _0x5684();}export class SlashCommandEditing extends _0x5a5f0a{static get[_0x93c769(0x1a4)](){const _0x4caefe=_0x93c769;return _0x4caefe(0x18b);}static get[_0x93c769(0x19e)](){return!0x0;}static get[_0x93c769(0x19c)](){return!0x0;}static get[_0x93c769(0x18d)](){return[_0x2362c8];}[_0x93c769(0x19b)](_0x55cc96){const _0x447ab7=_0x93c769,_0x2cab11=_0x55cc96&&_0x55cc96[_0x447ab7(0x18e)]();let _0xd6cfa1=this[_0x447ab7(0x190)][_0x447ab7(0x198)][_0x447ab7(0x19d)](_0x447ab7(0x196))[_0x447ab7(0x193)]();if(_0xd6cfa1=_0xd6cfa1[_0x447ab7(0x1a0)](_0x5f1c93=>_0x5f1c93[_0x447ab7(0x18c)]()),_0x2cab11){const _0x41ef66=[],_0x1382ca=[],_0x4fa5f9=[],_0x5671f6=[];for(const _0x2c0fa4 of _0xd6cfa1)_0x2c0fa4['id'][_0x447ab7(0x18e)]()[_0x447ab7(0x197)](_0x2cab11)?_0x41ef66[_0x447ab7(0x18a)](_0x2c0fa4):_0x2c0fa4[_0x447ab7(0x1a2)][_0x447ab7(0x18e)]()[_0x447ab7(0x197)](_0x2cab11)?_0x1382ca[_0x447ab7(0x18a)](_0x2c0fa4):_0x2c0fa4[_0x447ab7(0x194)]&&_0x2c0fa4[_0x447ab7(0x194)][_0x447ab7(0x1a3)](_0x9f8f07=>_0x9f8f07[_0x447ab7(0x18e)]()[_0x447ab7(0x197)](_0x2cab11))?_0x4fa5f9[_0x447ab7(0x18a)](_0x2c0fa4):_0x2c0fa4[_0x447ab7(0x19a)]&&_0x2c0fa4[_0x447ab7(0x19a)][_0x447ab7(0x18e)]()[_0x447ab7(0x197)](_0x2cab11)&&_0x5671f6[_0x447ab7(0x18a)](_0x2c0fa4);_0xd6cfa1=_0x41ef66[_0x447ab7(0x19f)](_0x1382ca,_0x4fa5f9,_0x5671f6);}return _0xd6cfa1;}}