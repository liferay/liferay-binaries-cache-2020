/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module slash-command/slashcommandui
 */
import { Plugin, type Editor } from 'ckeditor5/src/core.js';
import './slashcommandeditorconfig.js';
import '../theme/slashcommand.css';
/**
 * Provides the UI functionality of the {@link module:slash-command/slashcommand~SlashCommand} feature.
 *
 * @extends module:core/plugin~Plugin
 */
export declare class SlashCommandUI extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "SlashCommandUI";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    constructor(editor: Editor);
    /**
     * @inheritDoc
     */
    init(): void;
    /**
     * @inheritDoc
     */
    destroy(): void;
}
