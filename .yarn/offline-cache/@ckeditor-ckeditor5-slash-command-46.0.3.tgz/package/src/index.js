/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x4726ae,_0xa7244e){var _0x45403c=_0x4c41,_0x1d52d7=_0x4726ae();while(!![]){try{var _0x3e63d3=-parseInt(_0x45403c(0x99))/0x1+-parseInt(_0x45403c(0x98))/0x2*(-parseInt(_0x45403c(0x90))/0x3)+parseInt(_0x45403c(0x95))/0x4*(-parseInt(_0x45403c(0x93))/0x5)+-parseInt(_0x45403c(0x97))/0x6+parseInt(_0x45403c(0x94))/0x7*(parseInt(_0x45403c(0x96))/0x8)+parseInt(_0x45403c(0x91))/0x9*(-parseInt(_0x45403c(0x8f))/0xa)+parseInt(_0x45403c(0x92))/0xb;if(_0x3e63d3===_0xa7244e)break;else _0x1d52d7['push'](_0x1d52d7['shift']());}catch(_0x264f45){_0x1d52d7['push'](_0x1d52d7['shift']());}}}(_0x18ec,0x3ff4e));function _0x18ec(){var _0x458e05=['7654922SlqGRT','10yTJglU','7jCITWG','1028336Imndal','2549992VQjqTl','1193898ZfxmFl','68770nMxPyn','125581EVDiue','3770GbUzvJ','18RPPIZk','2871TuFNtg'];_0x18ec=function(){return _0x458e05;};return _0x18ec();}export{SlashCommand}from'./slashcommand.js';function _0x4c41(_0x22d1aa,_0x299b98){var _0x18ec99=_0x18ec();return _0x4c41=function(_0x4c4121,_0x3a4b6f){_0x4c4121=_0x4c4121-0x8f;var _0x5438b1=_0x18ec99[_0x4c4121];return _0x5438b1;},_0x4c41(_0x22d1aa,_0x299b98);}export{SlashCommandConfig}from'./slashcommandconfig.js';export{SlashCommandEditing}from'./slashcommandediting.js';export{SlashCommandUI}from'./slashcommandui.js';import'./augmentation.js';