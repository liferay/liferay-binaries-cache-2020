/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module slash-command/slashcommandediting
 */
import { Plugin } from 'ckeditor5/src/core.js';
import { SlashCommandConfig, type SlashCommandDefinition } from './slashcommandconfig.js';
/**
 * Provides the editing functionality of the {@link module:slash-command/slashcommand~SlashCommand} feature.
 *
 * @extends module:core/plugin~Plugin
 */
export declare class SlashCommandEditing extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "SlashCommandEditing";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    static get requires(): readonly [typeof SlashCommandConfig];
    /**
     * Returns the list of matching enabled command definitions for the specific query text case-insensitively.
     */
    getMatchingCommands(queryString: string): Array<SlashCommandDefinition>;
}
