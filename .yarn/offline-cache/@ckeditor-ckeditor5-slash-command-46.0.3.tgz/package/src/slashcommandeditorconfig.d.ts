/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module slash-command/slashcommandeditorconfig
 * @publicApi
 */
import type { SlashCommandDefinition } from './slashcommandconfig.js';
/**
 * The configuration of the slash command feature.
 *
 * Read more about {@glink features/slash-commands#configuration configuring the slash command feature}.
 *
 * ```ts
 *		ClassicEditor
 *			.create( editorElement, {
 *				slashCommand: ... // Slash command feature options.
 *			} )
 *			.then( ... )
 *			.catch( ... );
 * ```
 *
 * See {@link module:core/editor/editorconfig~EditorConfig all editor options}.
 */
export interface SlashCommandEditorConfig {
    /**
     * The list of commands to be removed from the default command list. Commands specified by this configuration will not
     * appear in the user interface upon writing the slash ("/") character.
     *
     * * Each entry must be a unique name of a command registered in the
     * {@link module:core/editor/editor~Editor#commands editor's command collection}.
     * * Check out the list of the {@link module:slash-command/slashcommandconfig~SlashCommandConfig#getDefaultCommands default commands}
     * supported by the slash command feature to learn which commands can be removed.
     *
     * ```ts
     *		ClassicEditor
     *			.create( editorElement, {
     *				plugins: [ SlashCommand, ... ],
     *				slashCommand: {
     *					removeCommands: [ 'heading', 'paragraph', ... ]
     *					// ...
     * 				}
     *			} )
     *			.then( ... )
     *			.catch( ... );
     * ```
     */
    removeCommands: Array<string>;
    /**
     * Additional commands to be added to the
     * {@link module:slash-command/slashcommandconfig~SlashCommandConfig#getDefaultCommands list of defaults} supported
     * by the slash command feature. It allows the feature to work with third-party commands and make them appear in the user interface
     * upon writing the slash ("/") character.
     *
     * ```ts
     *		ClassicEditor
     *			.create( editorElement, {
     *				plugins: [ SlashCommand, ... ],
     *				slashCommand: {
     *					extraCommands: [
     *						{
     *							id: 'bold',
     *							commandName: 'bold',
     *							title: 'Bold',
     *							// ...
     *						},
     *						// ...
     *					]
     *					// ...
     *				}
     *			} )
     *			.then( ... )
     *			.catch( ... );
     * ```
     */
    extraCommands: Array<SlashCommandDefinition>;
    /**
     * The maximum number of commands displayed in the dropdown list of slash commands.
     *
     * ```ts
     *		ClassicEditor
     *			.create( editorElement, {
     *				plugins: [ SlashCommand, ... ],
     *				slashCommand: {
     *					dropdownLimit: 4
     *					// More of editor configuration.
     * 					// ...
     * 				}
     *			} )
     *			.then( ... )
     *			.catch( ... );
     * ```
     */
    dropdownLimit: number;
}
