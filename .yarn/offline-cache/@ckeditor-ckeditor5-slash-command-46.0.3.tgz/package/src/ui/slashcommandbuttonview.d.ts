/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module slash-command/ui/slashcommandbuttonview
 */
import type { Locale } from 'ckeditor5/src/utils.js';
import { View, ButtonView } from 'ckeditor5/src/ui.js';
import type { SlashCommandDefinition } from '../slashcommandconfig.js';
/**
 * A class representing an individual button (slash command) in the list.
 *
 * @extends module:ui/button/buttonview~ButtonView
 */
export declare class SlashCommandButtonView extends ButtonView {
    /**
     * The view rendering the text part of the slash command button consisting of a title and an optional description.
     *
     * @protected
     */
    textPartView: View;
    /**
     * Creates an instance of the {@link module:slash-command/ui/slashcommandbuttonview~SlashCommandButtonView} class.
     */
    constructor(locale: Locale, commandDefinition: SlashCommandDefinition);
    /**
     * @inheritDoc
     */
    render(): void;
}
