/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x2e67(_0x9d85f8,_0xb7be7e){const _0x10988a=_0x1098();return _0x2e67=function(_0x2e6723,_0x3e2a40){_0x2e6723=_0x2e6723-0x14e;let _0x20542d=_0x10988a[_0x2e6723];return _0x20542d;},_0x2e67(_0x9d85f8,_0xb7be7e);}const _0x3a0617=_0x2e67;(function(_0x53266f,_0xce4dd4){const _0x56df49=_0x2e67,_0x34f95d=_0x53266f();while(!![]){try{const _0x18b7b5=-parseInt(_0x56df49(0x150))/0x1+-parseInt(_0x56df49(0x167))/0x2*(-parseInt(_0x56df49(0x15d))/0x3)+-parseInt(_0x56df49(0x158))/0x4+parseInt(_0x56df49(0x163))/0x5+parseInt(_0x56df49(0x15a))/0x6*(parseInt(_0x56df49(0x151))/0x7)+parseInt(_0x56df49(0x15c))/0x8*(parseInt(_0x56df49(0x14f))/0x9)+-parseInt(_0x56df49(0x14e))/0xa;if(_0x18b7b5===_0xce4dd4)break;else _0x34f95d['push'](_0x34f95d['shift']());}catch(_0x5c3daa){_0x34f95d['push'](_0x34f95d['shift']());}}}(_0x1098,0xb493d));import{IconPlay as _0x1536f3}from'ckeditor5/src/icons.js';import{View as _0x1d9c94,ButtonView as _0x4e950f}from'ckeditor5/src/ui.js';function _0x1098(){const _0x22bfbf=['render','ck-slash-command-button__text-part','486mGHhTS','set','span','title','12089260vZftfi','6042609AUtdce','1098197KaWtie','7HulCYV','setTemplate','children','_createTextPartView','ck-slash-command-button__description','icon','description','1036572DIggXJ','textPartView','8211954datcRQ','isIconColorInherited','8KbvoGY','7449AXJIoM','ck-slash-command-button','add','isColorInherited','iconView','labelView','3312410vMBVFG','div'];_0x1098=function(){return _0x22bfbf;};return _0x1098();}export class SlashCommandButtonView extends _0x4e950f{constructor(_0x4812cc,_0x56a478){const _0x1446c9=_0x2e67;super(_0x4812cc),this[_0x1446c9(0x159)]=this[_0x1446c9(0x154)](_0x4812cc,_0x56a478),void 0x0!==_0x56a478[_0x1446c9(0x15b)]&&(this[_0x1446c9(0x161)][_0x1446c9(0x160)]=_0x56a478[_0x1446c9(0x15b)]),this[_0x1446c9(0x168)]({'icon':_0x56a478[_0x1446c9(0x156)]||_0x1536f3,'withText':!0x0,'label':_0x56a478[_0x1446c9(0x16a)],'class':_0x1446c9(0x15e)});}[_0x3a0617(0x165)](){const _0x5d80c=_0x3a0617;super[_0x5d80c(0x165)](),this[_0x5d80c(0x153)][_0x5d80c(0x15f)](this[_0x5d80c(0x159)]);}[_0x3a0617(0x154)](_0xb01333,_0x12ea80){const _0x1d99eb=_0x3a0617,_0x42aa20=new _0x1d9c94(_0xb01333);return _0x42aa20[_0x1d99eb(0x152)]({'tag':_0x1d99eb(0x164),'attributes':{'class':['ck',_0x1d99eb(0x166)]},'children':_0x12ea80[_0x1d99eb(0x157)]?[this[_0x1d99eb(0x162)],{'tag':_0x1d99eb(0x169),'attributes':{'class':['ck',_0x1d99eb(0x155)]},'children':[{'text':_0x12ea80[_0x1d99eb(0x157)]}]}]:[this[_0x1d99eb(0x162)]]}),_0x42aa20;}}