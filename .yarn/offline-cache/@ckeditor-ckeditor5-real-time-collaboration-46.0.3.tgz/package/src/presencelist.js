/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x3989(_0x57d68c,_0x46d8e5){var _0x1e734a=_0x1e73();return _0x3989=function(_0x3989c6,_0x5e8ba6){_0x3989c6=_0x3989c6-0x13a;var _0x2b10c4=_0x1e734a[_0x3989c6];return _0x2b10c4;},_0x3989(_0x57d68c,_0x46d8e5);}var _0x26a4a8=_0x3989;(function(_0x282649,_0x488c46){var _0x40a173=_0x3989,_0x3a1916=_0x282649();while(!![]){try{var _0x1c7aef=parseInt(_0x40a173(0x13e))/0x1*(parseInt(_0x40a173(0x13a))/0x2)+parseInt(_0x40a173(0x13c))/0x3+-parseInt(_0x40a173(0x142))/0x4*(parseInt(_0x40a173(0x149))/0x5)+parseInt(_0x40a173(0x140))/0x6*(-parseInt(_0x40a173(0x147))/0x7)+-parseInt(_0x40a173(0x143))/0x8*(-parseInt(_0x40a173(0x145))/0x9)+parseInt(_0x40a173(0x13f))/0xa*(parseInt(_0x40a173(0x144))/0xb)+-parseInt(_0x40a173(0x141))/0xc;if(_0x1c7aef===_0x488c46)break;else _0x3a1916['push'](_0x3a1916['shift']());}catch(_0x15e3cb){_0x3a1916['push'](_0x3a1916['shift']());}}}(_0x1e73,0x2baa2));import{ContextPlugin as _0x419782}from'ckeditor5/src/core.js';function _0x1e73(){var _0x42f278=['27OGaSrb','PresenceList','441889IqFjzO','pluginName','32090asPWNY','isPremiumPlugin','109734CcfySh','requires','850839gTZcym','isOfficialPlugin','3ShlGzO','3288590NMPnjV','6wMyfKc','5582328UBKYON','44OgdvZo','1856cYdsBM','11XXJWGK'];_0x1e73=function(){return _0x42f278;};return _0x1e73();}import{Sessions as _0x3b50fd}from'./realtimecollaborativeediting/sessions.js';import{PresenceListUI as _0x2021d6}from'./presencelist/presencelistui.js';export class PresenceList extends _0x419782{static get[_0x26a4a8(0x13b)](){return[_0x3b50fd,_0x2021d6];}static get[_0x26a4a8(0x148)](){var _0xc79488=_0x26a4a8;return _0xc79488(0x146);}static get[_0x26a4a8(0x13d)](){return!0x0;}static get[_0x26a4a8(0x14a)](){return!0x0;}}