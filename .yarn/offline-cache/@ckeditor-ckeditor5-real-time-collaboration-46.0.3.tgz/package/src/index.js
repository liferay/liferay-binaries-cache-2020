/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x4e87f9,_0x330644){var _0x14be31=_0x43cd,_0x1954b7=_0x4e87f9();while(!![]){try{var _0x3ea408=parseInt(_0x14be31(0x17b))/0x1*(-parseInt(_0x14be31(0x175))/0x2)+parseInt(_0x14be31(0x174))/0x3*(-parseInt(_0x14be31(0x178))/0x4)+parseInt(_0x14be31(0x17a))/0x5+parseInt(_0x14be31(0x173))/0x6*(parseInt(_0x14be31(0x176))/0x7)+-parseInt(_0x14be31(0x179))/0x8*(-parseInt(_0x14be31(0x17f))/0x9)+-parseInt(_0x14be31(0x17c))/0xa*(parseInt(_0x14be31(0x177))/0xb)+parseInt(_0x14be31(0x17e))/0xc*(parseInt(_0x14be31(0x17d))/0xd);if(_0x3ea408===_0x330644)break;else _0x1954b7['push'](_0x1954b7['shift']());}catch(_0x1bc6e2){_0x1954b7['push'](_0x1954b7['shift']());}}}(_0x495e,0x43a1b));export{RealTimeCollaborativeEditing}from'./realtimecollaborativeediting.js';export{RealTimeCollaborativeTrackChanges}from'./realtimecollaborativetrackchanges.js';export{RealTimeCollaborativeComments}from'./realtimecollaborativecomments.js';function _0x495e(){var _0x26b9f4=['11715RQpcQK','860TvCrGK','7976qpNiWb','38695PUyxoV','1poIQSo','2670VRtRqf','13UWPrzB','5451444iyTTIV','2835aPzche','24114KUbWIx','687UCpQgY','580122QadDsI','217XfLtMl'];_0x495e=function(){return _0x26b9f4;};return _0x495e();}export{RealTimeCollaborativeRevisionHistory}from'./realtimecollaborativerevisionhistory.js';export{CloudServicesCommentsAdapter}from'./realtimecollaborativecomments/cloudservicescommentsadapter.js';export{CloudServicesTrackChangesAdapter}from'./realtimecollaborativetrackchanges/cloudservicestrackchangesadapter.js';export{CloudServicesRevisionHistoryAdapter}from'./realtimecollaborativerevisionhistory/cloudservicesrevisionhistoryadapter.js';export{RealTimeCollaborationClient}from'./realtimecollaborativeediting/realtimecollaborationclient.js';export{PresenceListUI}from'./presencelist/presencelistui.js';export{PresenceList}from'./presencelist.js';function _0x43cd(_0x8fcd27,_0x466c68){var _0x495ec9=_0x495e();return _0x43cd=function(_0x43cdea,_0x24e852){_0x43cdea=_0x43cdea-0x173;var _0x1df0f5=_0x495ec9[_0x43cdea];return _0x1df0f5;},_0x43cd(_0x8fcd27,_0x466c68);}export{Sessions}from'./realtimecollaborativeediting/sessions.js';export{WebSocketGateway}from'./realtimecollaborativeediting/websocketgateway.js';import'./augmentation.js';