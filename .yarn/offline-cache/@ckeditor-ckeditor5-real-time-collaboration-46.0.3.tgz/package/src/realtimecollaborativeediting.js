/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x1d09(){var _0x57ba6e=['1022724yvrRCQ','1815903FIogpo','8904880YYUxDW','pluginName','isOfficialPlugin','13871272zWjPad','8148NgLEOT','7okChTr','4297220xsTefU','148196aScPBb','isPremiumPlugin','RealTimeCollaborativeEditing','requires','20QlXWEU'];_0x1d09=function(){return _0x57ba6e;};return _0x1d09();}var _0x2cd517=_0x44c8;(function(_0x4825c5,_0x1cd5ef){var _0x4db4f5=_0x44c8,_0x1c96bf=_0x4825c5();while(!![]){try{var _0x42daf7=-parseInt(_0x4db4f5(0x99))/0x1*(parseInt(_0x4db4f5(0x95))/0x2)+-parseInt(_0x4db4f5(0x92))/0x3+-parseInt(_0x4db4f5(0x94))/0x4+parseInt(_0x4db4f5(0x9c))/0x5+parseInt(_0x4db4f5(0x9a))/0x6+-parseInt(_0x4db4f5(0x93))/0x7*(-parseInt(_0x4db4f5(0x91))/0x8)+-parseInt(_0x4db4f5(0x9b))/0x9;if(_0x42daf7===_0x1cd5ef)break;else _0x1c96bf['push'](_0x1c96bf['shift']());}catch(_0x48e23a){_0x1c96bf['push'](_0x1c96bf['shift']());}}}(_0x1d09,0xe1baf));function _0x44c8(_0x28d597,_0x5d5761){var _0x1d091b=_0x1d09();return _0x44c8=function(_0x44c8dd,_0x443ab1){_0x44c8dd=_0x44c8dd-0x8f;var _0x1bf854=_0x1d091b[_0x44c8dd];return _0x1bf854;},_0x44c8(_0x28d597,_0x5d5761);}import{Plugin as _0x477121}from'ckeditor5/src/core.js';import{RealTimeCollaborationClient as _0x1cf202}from'./realtimecollaborativeediting/realtimecollaborationclient.js';export class RealTimeCollaborativeEditing extends _0x477121{static get[_0x2cd517(0x98)](){return[_0x1cf202];}static get[_0x2cd517(0x8f)](){var _0x2696b0=_0x2cd517;return _0x2696b0(0x97);}static get[_0x2cd517(0x90)](){return!0x0;}static get[_0x2cd517(0x96)](){return!0x0;}}