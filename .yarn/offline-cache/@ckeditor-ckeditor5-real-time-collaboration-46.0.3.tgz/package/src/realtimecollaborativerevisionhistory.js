/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x23793f=_0x3f0b;(function(_0x295c1c,_0x34642d){var _0x5639cb=_0x3f0b,_0x3512cb=_0x295c1c();while(!![]){try{var _0x2ca200=parseInt(_0x5639cb(0x165))/0x1*(parseInt(_0x5639cb(0x166))/0x2)+parseInt(_0x5639cb(0x167))/0x3*(parseInt(_0x5639cb(0x158))/0x4)+parseInt(_0x5639cb(0x159))/0x5+parseInt(_0x5639cb(0x163))/0x6*(-parseInt(_0x5639cb(0x162))/0x7)+parseInt(_0x5639cb(0x156))/0x8+parseInt(_0x5639cb(0x15a))/0x9*(-parseInt(_0x5639cb(0x15e))/0xa)+-parseInt(_0x5639cb(0x15b))/0xb*(parseInt(_0x5639cb(0x160))/0xc);if(_0x2ca200===_0x34642d)break;else _0x3512cb['push'](_0x3512cb['shift']());}catch(_0x1b5028){_0x3512cb['push'](_0x3512cb['shift']());}}}(_0xba20,0xf38d5));function _0xba20(){var _0x33de9f=['4880920cSHyjo','isPremiumPlugin','36jzqKIF','isOfficialPlugin','385511kTbYhE','132pXQGfz','pluginName','648174qjLLtM','6fplqQK','9tExvkC','6955304yrCLKO','RevisionHistory','1441188GUMJrH','6595840aOpOmo','18WUkgJD','7438255FFDfMI','RealTimeCollaborativeRevisionHistory','requires'];_0xba20=function(){return _0x33de9f;};return _0xba20();}import{Plugin as _0x285ac2}from'ckeditor5/src/core.js';function _0x3f0b(_0x3fe007,_0x20a166){var _0xba203d=_0xba20();return _0x3f0b=function(_0x3f0b99,_0x39efc8){_0x3f0b99=_0x3f0b99-0x156;var _0x2d4b8c=_0xba203d[_0x3f0b99];return _0x2d4b8c;},_0x3f0b(_0x3fe007,_0x20a166);}import{CloudServicesRevisionHistoryAdapter as _0x22cba1}from'./realtimecollaborativerevisionhistory/cloudservicesrevisionhistoryadapter.js';import{RealTimeCollaborativeEditing as _0x4fd5b8}from'./realtimecollaborativeediting.js';export class RealTimeCollaborativeRevisionHistory extends _0x285ac2{static get[_0x23793f(0x15d)](){var _0x1bd420=_0x23793f;return[_0x1bd420(0x157),_0x22cba1,_0x4fd5b8];}static get[_0x23793f(0x164)](){var _0x17d455=_0x23793f;return _0x17d455(0x15c);}static get[_0x23793f(0x161)](){return!0x0;}static get[_0x23793f(0x15f)](){return!0x0;}}