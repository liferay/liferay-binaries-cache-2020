/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x26964b=_0x3f51;function _0x3f51(_0x4a0177,_0x1f1aee){const _0x3a7ec8=_0x3a7e();return _0x3f51=function(_0x3f51ea,_0x3aaee0){_0x3f51ea=_0x3f51ea-0x152;let _0x11baff=_0x3a7ec8[_0x3f51ea];return _0x11baff;},_0x3f51(_0x4a0177,_0x1f1aee);}(function(_0x5df725,_0xc12e79){const _0x21dbda=_0x3f51,_0x789dcf=_0x5df725();while(!![]){try{const _0x9360cd=parseInt(_0x21dbda(0x152))/0x1+parseInt(_0x21dbda(0x156))/0x2*(parseInt(_0x21dbda(0x153))/0x3)+parseInt(_0x21dbda(0x163))/0x4*(parseInt(_0x21dbda(0x15f))/0x5)+parseInt(_0x21dbda(0x165))/0x6+parseInt(_0x21dbda(0x160))/0x7*(-parseInt(_0x21dbda(0x155))/0x8)+-parseInt(_0x21dbda(0x167))/0x9+parseInt(_0x21dbda(0x162))/0xa*(parseInt(_0x21dbda(0x16b))/0xb);if(_0x9360cd===_0xc12e79)break;else _0x789dcf['push'](_0x789dcf['shift']());}catch(_0x4307f4){_0x789dcf['push'](_0x789dcf['shift']());}}}(_0x3a7e,0x99b9b));function _0x3a7e(){const _0x1c608d=['4LStONd','bindTemplate','7430322leRgei','color','6464817BahXfr','ck-presence-list__dropdown-list-item','span','focus','803hyznyC','ck-presence-list__marker','true','setTemplate','352253LLsICp','3iKOqjk','button','7449592BRrPUS','320578WyiQyr','presentation','tag','fire','execute','userView','ck-user__full-name','name','getBackgroundColorClass','34380OdPqsp','7GJCoGQ','element','71420RdTkZO'];_0x3a7e=function(){return _0x1c608d;};return _0x3a7e();}import{ListItemView as _0x1be2bd}from'ckeditor5/src/ui.js';import{UserView as _0x681f41}from'ckeditor5-collaboration/src/collaboration-core.js';export class PresenceDropdownListItemView extends _0x1be2bd{[_0x26964b(0x15b)];constructor(_0x2d9643,_0x12ace4,_0x217d9a){const _0x3cc32a=_0x26964b;super(_0x2d9643);const _0x114591=this[_0x3cc32a(0x164)];this[_0x3cc32a(0x15b)]=new _0x681f41(_0x2d9643,_0x12ace4);const _0x344015={'tag':'li','attributes':{'class':['ck',_0x3cc32a(0x168)],'tabindex':-0x1,'role':_0x3cc32a(0x157),'aria-label':_0x12ace4[_0x3cc32a(0x15d)]},'children':[this[_0x3cc32a(0x15b)],{'tag':_0x3cc32a(0x169),'attributes':{'class':['ck',_0x3cc32a(0x15c)]},'children':[{'text':_0x12ace4[_0x3cc32a(0x15d)]}]},{'tag':_0x3cc32a(0x169),'attributes':{'class':['ck',_0x3cc32a(0x16c),_0x12ace4[_0x3cc32a(0x166)][_0x3cc32a(0x15e)]()],'aria-hidden':_0x3cc32a(0x16d)}}]};_0x217d9a&&(_0x344015[_0x3cc32a(0x158)]=_0x3cc32a(0x154),_0x344015['on']={'click':_0x114591['to'](()=>this[_0x3cc32a(0x159)](_0x3cc32a(0x15a)))}),this[_0x3cc32a(0x16e)](_0x344015);}[_0x26964b(0x16a)](){const _0x327534=_0x26964b;this[_0x327534(0x161)][_0x327534(0x16a)]();}}