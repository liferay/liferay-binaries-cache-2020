/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x5920af=_0x2240;function _0x2240(_0x20a303,_0x190efb){const _0x2ea837=_0x2ea8();return _0x2240=function(_0x22401a,_0x257707){_0x22401a=_0x22401a-0xff;let _0x149886=_0x2ea837[_0x22401a];return _0x149886;},_0x2240(_0x20a303,_0x190efb);}(function(_0x41a4fe,_0x3b5bde){const _0x2ef6c1=_0x2240,_0x1dab3d=_0x41a4fe();while(!![]){try{const _0x38cc05=parseInt(_0x2ef6c1(0x102))/0x1*(-parseInt(_0x2ef6c1(0x10b))/0x2)+parseInt(_0x2ef6c1(0x116))/0x3+-parseInt(_0x2ef6c1(0x115))/0x4+-parseInt(_0x2ef6c1(0x105))/0x5*(-parseInt(_0x2ef6c1(0x10a))/0x6)+-parseInt(_0x2ef6c1(0x10d))/0x7*(-parseInt(_0x2ef6c1(0x110))/0x8)+parseInt(_0x2ef6c1(0x10e))/0x9+-parseInt(_0x2ef6c1(0x103))/0xa*(parseInt(_0x2ef6c1(0x108))/0xb);if(_0x38cc05===_0x3b5bde)break;else _0x1dab3d['push'](_0x1dab3d['shift']());}catch(_0x5cd2b6){_0x1dab3d['push'](_0x1dab3d['shift']());}}}(_0x2ea8,0xeedff));import{View as _0x5b9820}from'ckeditor5/src/ui.js';export class PresenceCounterView extends _0x5b9820{[_0x5920af(0x117)];constructor(_0x4e8d6e,_0x3a6f3c=0x6){const _0x199207=_0x5920af;super(_0x4e8d6e);const _0x47d223=this[_0x199207(0x106)];this[_0x199207(0xff)](_0x199207(0x114),!0x0),this[_0x199207(0xff)](_0x199207(0x10f),0x0),this[_0x199207(0x117)]=_0x3a6f3c,this[_0x199207(0x113)](_0x199207(0x114))['to'](this,_0x199207(0x10f),_0x21f8f3=>_0x21f8f3<_0x3a6f3c),this[_0x199207(0x112)]({'tag':_0x199207(0x107),'attributes':{'class':['ck',_0x199207(0x109),_0x47d223['if'](_0x199207(0x114),_0x199207(0x101))],'role':_0x199207(0x10c)},'children':[{'tag':_0x199207(0x107),'attributes':{'class':['ck',_0x199207(0x111)]},'children':[{'tag':_0x199207(0x107),'attributes':{'class':['ck',_0x199207(0x100)]},'children':[{'text':_0x47d223['to'](_0x199207(0x10f),_0x42420b=>'+'+(_0x42420b-this[_0x199207(0x117)]+0x2)[_0x199207(0x104)]())}]}]}]});}}function _0x2ea8(){const _0x22649f=['set','ck-presence-list__users-counter__text','ck-presence-list__counter--hidden','5KxFRlZ','1439830HSbBzy','toString','485fdHRrt','bindTemplate','div','154chIPqj','ck-presence-list__list-item','100722RUHtYd','563916cpYfSL','listitem','462AcLufP','12503763LhvIYw','usersCount','189984dKIgav','ck-presence-list__users-counter','setTemplate','bind','isHidden','7227168WUAslT','4877283XIwchl','_collapseAt'];_0x2ea8=function(){return _0x22649f;};return _0x2ea8();}