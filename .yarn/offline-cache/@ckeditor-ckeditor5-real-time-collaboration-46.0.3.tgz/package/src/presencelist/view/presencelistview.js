/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0xed8c6b=_0x3e51;function _0x28ce(){const _0x53e43f=['tooltipPosition','192MxjowD','4SxnevM','change','10609902NoKudi','inlineListView','1178222IcvRwF','3437457OMmFzt','locale','6182245bPUCbG','ck-rounded-corners','2UsUYIZ','div','items','setTemplate','first','705470jEMSxZ','7795888NdNpXa','hasPopup','listenTo','isCollapsed','bind','77rlLPTL','ck-presence-list--collapsed','ck-presence-list','set','counterView','bindTemplate','186382rpxCUg','ck-reset'];_0x28ce=function(){return _0x53e43f;};return _0x28ce();}(function(_0x311ac4,_0x2d5375){const _0x4d0aaa=_0x3e51,_0x2975a9=_0x311ac4();while(!![]){try{const _0x444026=parseInt(_0x4d0aaa(0x1e7))/0x1*(-parseInt(_0x4d0aaa(0x1ec))/0x2)+parseInt(_0x4d0aaa(0x1e8))/0x3+-parseInt(_0x4d0aaa(0x1e3))/0x4*(-parseInt(_0x4d0aaa(0x1ea))/0x5)+parseInt(_0x4d0aaa(0x1e2))/0x6*(-parseInt(_0x4d0aaa(0x1df))/0x7)+parseInt(_0x4d0aaa(0x1f2))/0x8+-parseInt(_0x4d0aaa(0x1e5))/0x9+parseInt(_0x4d0aaa(0x1f1))/0xa*(parseInt(_0x4d0aaa(0x1d9))/0xb);if(_0x444026===_0x2d5375)break;else _0x2975a9['push'](_0x2975a9['shift']());}catch(_0x5d5961){_0x2975a9['push'](_0x2975a9['shift']());}}}(_0x28ce,0x9c9ab));import{View as _0x1d1af0}from'ckeditor5/src/ui.js';import{PresenceCounterView as _0x5549be}from'./presencecounterview.js';import{PresenceInlineListView as _0x3956a5}from'./presenceinlinelistview.js';function _0x3e51(_0x1a47ff,_0x53894a){const _0x28ce2f=_0x28ce();return _0x3e51=function(_0x3e515f,_0x3d95f2){_0x3e515f=_0x3e515f-0x1d8;let _0x337e9d=_0x28ce2f[_0x3e515f];return _0x337e9d;},_0x3e51(_0x1a47ff,_0x53894a);}import'../../../theme/presencelist.css';export class PresenceListView extends _0x1d1af0{[_0xed8c6b(0x1dd)];[_0xed8c6b(0x1e6)];constructor(_0x332e60,_0x3eecf1=0x6){const _0x303c16=_0xed8c6b;super(_0x332e60);const _0x1a272d=this[_0x303c16(0x1de)];this[_0x303c16(0x1dc)](_0x303c16(0x1f5),!0x0),this[_0x303c16(0x1dd)]=new _0x5549be(this[_0x303c16(0x1e9)],_0x3eecf1),this[_0x303c16(0x1e6)]=new _0x3956a5(_0x332e60),this[_0x303c16(0x1e6)][_0x303c16(0x1d8)](_0x303c16(0x1f3))['to'](this,_0x303c16(0x1f5)),this[_0x303c16(0x1f4)](this[_0x303c16(0x1e6)][_0x303c16(0x1ee)],_0x303c16(0x1e4),()=>{const _0x5a23d9=_0x303c16;for(const _0x89e19a of this[_0x5a23d9(0x1e6)][_0x5a23d9(0x1ee)])_0x89e19a[_0x5a23d9(0x1e1)]='s';this[_0x5a23d9(0x1e6)][_0x5a23d9(0x1ee)][_0x5a23d9(0x1f0)]&&(this[_0x5a23d9(0x1e6)][_0x5a23d9(0x1ee)][_0x5a23d9(0x1f0)][_0x5a23d9(0x1e1)]='se');}),this[_0x303c16(0x1ef)]({'tag':_0x303c16(0x1ed),'attributes':{'class':['ck',_0x303c16(0x1db),_0x303c16(0x1e0),_0x303c16(0x1eb),_0x1a272d['if'](_0x303c16(0x1f5),_0x303c16(0x1da))]},'children':[this[_0x303c16(0x1e6)]]});}}