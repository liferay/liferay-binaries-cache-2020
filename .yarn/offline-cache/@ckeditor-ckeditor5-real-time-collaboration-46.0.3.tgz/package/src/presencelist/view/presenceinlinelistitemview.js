/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x470a68=_0x420a;function _0x420a(_0xc40460,_0x1fdfdb){const _0x2499cc=_0x2499();return _0x420a=function(_0x420a1d,_0x3a0073){_0x420a1d=_0x420a1d-0x193;let _0x25ff4d=_0x2499cc[_0x420a1d];return _0x25ff4d;},_0x420a(_0xc40460,_0x1fdfdb);}(function(_0x4bebc0,_0x3e3043){const _0x1d2662=_0x420a,_0x1e1a5c=_0x4bebc0();while(!![]){try{const _0x2574de=-parseInt(_0x1d2662(0x1a9))/0x1*(parseInt(_0x1d2662(0x1a5))/0x2)+-parseInt(_0x1d2662(0x19b))/0x3*(parseInt(_0x1d2662(0x19d))/0x4)+-parseInt(_0x1d2662(0x196))/0x5*(parseInt(_0x1d2662(0x195))/0x6)+parseInt(_0x1d2662(0x194))/0x7+parseInt(_0x1d2662(0x1b1))/0x8*(parseInt(_0x1d2662(0x199))/0x9)+parseInt(_0x1d2662(0x1a8))/0xa+parseInt(_0x1d2662(0x1a0))/0xb;if(_0x2574de===_0x3e3043)break;else _0x1e1a5c['push'](_0x1e1a5c['shift']());}catch(_0x5f1492){_0x1e1a5c['push'](_0x1e1a5c['shift']());}}}(_0x2499,0x3e25f));import{LabelView as _0x296734,View as _0x3a5fe0}from'ckeditor5/src/ui.js';import{UserView as _0x528fc1}from'ckeditor5-collaboration/src/collaboration-core.js';export class PresenceInlineListItemView extends _0x3a5fe0{[_0x470a68(0x1b2)];[_0x470a68(0x1a3)];constructor(_0x59cace,_0x42fad9,_0x142b46){const _0x3f7a6c=_0x470a68;super(_0x59cace);const _0x41b928=this[_0x3f7a6c(0x1a4)];this[_0x3f7a6c(0x1b4)](_0x3f7a6c(0x197),!0x1),this[_0x3f7a6c(0x1b4)](_0x3f7a6c(0x1af),!0x0),this[_0x3f7a6c(0x1b4)](_0x3f7a6c(0x1aa),''),this[_0x3f7a6c(0x1b2)]=new _0x528fc1(_0x59cace,_0x42fad9),this[_0x3f7a6c(0x1a3)]=new ot(_0x59cace,_0x42fad9);const _0x54bfea=new _0x296734(_0x59cace);_0x54bfea[_0x3f7a6c(0x1a6)][_0x3f7a6c(0x19e)]=_0x3f7a6c(0x1b5),_0x54bfea[_0x3f7a6c(0x193)]=_0x42fad9[_0x3f7a6c(0x19c)];const _0x36c132={'tag':_0x3f7a6c(0x19f),'attributes':{'class':['ck',_0x3f7a6c(0x198)],'role':_0x3f7a6c(0x19a),'tabindex':_0x41b928['to'](_0x3f7a6c(0x197),_0x2df92a=>!!_0x2df92a&&0x0),'aria-labelledby':_0x54bfea['id'],'data-cke-tooltip-text':this[_0x3f7a6c(0x1b2)][_0x3f7a6c(0x19c)],'data-cke-tooltip-position':_0x41b928['to'](_0x3f7a6c(0x1aa)),'data-cke-tooltip-disabled':_0x41b928['to'](_0x3f7a6c(0x1af),_0x597fa4=>!_0x597fa4),'data-cke-tooltip-class':_0x3f7a6c(0x1ad)},'children':[this[_0x3f7a6c(0x1b2)],this[_0x3f7a6c(0x1a3)],_0x54bfea]};_0x142b46&&(_0x36c132[_0x3f7a6c(0x19e)]=_0x3f7a6c(0x1a1),_0x36c132['on']={'click':_0x41b928['to'](()=>this[_0x3f7a6c(0x1a2)](_0x3f7a6c(0x1ac)))}),this[_0x3f7a6c(0x1a7)](_0x36c132);}}class ot extends _0x3a5fe0{constructor(_0x341303,_0x4640b1){const _0x1e144b=_0x470a68;super(_0x341303),this[_0x1e144b(0x1a7)]({'tag':_0x1e144b(0x1b5),'attributes':{'class':['ck',_0x1e144b(0x1b3),_0x4640b1[_0x1e144b(0x1b0)][_0x1e144b(0x1ae)]()],'aria-hidden':_0x1e144b(0x1ab)}});}}function _0x2499(){const _0x269ab2=['7366425IYcECW','button','fire','markerView','bindTemplate','8rIjAsq','template','setTemplate','2347370qWxHWp','13875RYWGkK','tooltipPosition','true','execute','ck-presence-list__list-item__tooltip','getBackgroundColorClass','hasTooltip','color','456lINFNK','userView','ck-presence-list__marker','set','span','text','2161348VzYism','6YAZdQq','2122595xBPPJL','isFocusable','ck-presence-list__list-item','3411ZhsimU','listitem','327lXafOl','name','18356VULQuX','tag','div'];_0x2499=function(){return _0x269ab2;};return _0x2499();}