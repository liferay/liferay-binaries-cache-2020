/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x210450=_0x2b25;function _0x843f(){var _0x963478=['4263690EPYjQZ','13852zzFlUS','5967640fMVIWx','TrackChanges','isPremiumPlugin','834593aDBGYf','4982528QTvNkp','27ipYApw','5094468VSPxoS','RealTimeCollaborativeTrackChanges','isOfficialPlugin','590wBGFAg','460538frGqBe','requires','pluginName','3LzNzUm'];_0x843f=function(){return _0x963478;};return _0x843f();}(function(_0x3d4c96,_0x172890){var _0x46eed9=_0x2b25,_0x31f639=_0x3d4c96();while(!![]){try{var _0x13c9e8=parseInt(_0x46eed9(0x1ef))/0x1+parseInt(_0x46eed9(0x1e6))/0x2*(parseInt(_0x46eed9(0x1e9))/0x3)+-parseInt(_0x46eed9(0x1eb))/0x4*(parseInt(_0x46eed9(0x1e5))/0x5)+parseInt(_0x46eed9(0x1e2))/0x6+parseInt(_0x46eed9(0x1ec))/0x7+-parseInt(_0x46eed9(0x1e0))/0x8+-parseInt(_0x46eed9(0x1e1))/0x9*(parseInt(_0x46eed9(0x1ea))/0xa);if(_0x13c9e8===_0x172890)break;else _0x31f639['push'](_0x31f639['shift']());}catch(_0x5d3b47){_0x31f639['push'](_0x31f639['shift']());}}}(_0x843f,0x6f4df));import{Plugin as _0x2bd8cd}from'ckeditor5/src/core.js';import{CloudServicesTrackChangesAdapter as _0x1e18b7}from'./realtimecollaborativetrackchanges/cloudservicestrackchangesadapter.js';import{RealTimeCollaborativeComments as _0x12f2c9}from'./realtimecollaborativecomments.js';function _0x2b25(_0x22d558,_0x53e0d5){var _0x843fb5=_0x843f();return _0x2b25=function(_0x2b2528,_0x43ef8f){_0x2b2528=_0x2b2528-0x1e0;var _0x109294=_0x843fb5[_0x2b2528];return _0x109294;},_0x2b25(_0x22d558,_0x53e0d5);}export class RealTimeCollaborativeTrackChanges extends _0x2bd8cd{static get[_0x210450(0x1e7)](){var _0x3c3c4a=_0x210450;return[_0x12f2c9,_0x1e18b7,_0x3c3c4a(0x1ed)];}static get[_0x210450(0x1e8)](){var _0x511a8f=_0x210450;return _0x511a8f(0x1e3);}static get[_0x210450(0x1e4)](){return!0x0;}static get[_0x210450(0x1ee)](){return!0x0;}}