/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x483149=_0x5ab0;function _0x2baa(){var _0x427114=['704814nZWWvb','createdAt','94GcbPay','3139680OZADgp','data','1102098qGEKwZ','8MofEUU','4050620SchpTn','author','19018dEAAVH','type','set','2934632eIsYSl','toJSON','rootName','28mNQbZq','4050261eimZwD'];_0x2baa=function(){return _0x427114;};return _0x2baa();}(function(_0x58d9d7,_0x10e2d0){var _0x2b572b=_0x5ab0,_0x44bf71=_0x58d9d7();while(!![]){try{var _0x30fc61=-parseInt(_0x2b572b(0x1e7))/0x1*(parseInt(_0x2b572b(0x1ee))/0x2)+-parseInt(_0x2b572b(0x1ea))/0x3+parseInt(_0x2b572b(0x1f1))/0x4+parseInt(_0x2b572b(0x1e8))/0x5+parseInt(_0x2b572b(0x1e5))/0x6*(-parseInt(_0x2b572b(0x1e3))/0x7)+parseInt(_0x2b572b(0x1eb))/0x8*(parseInt(_0x2b572b(0x1e4))/0x9)+parseInt(_0x2b572b(0x1ec))/0xa;if(_0x30fc61===_0x10e2d0)break;else _0x44bf71['push'](_0x44bf71['shift']());}catch(_0x45e00b){_0x44bf71['push'](_0x44bf71['shift']());}}}(_0x2baa,0x768dd));function _0x5ab0(_0x2cf065,_0x3f700d){var _0x2baacb=_0x2baa();return _0x5ab0=function(_0x5ab073,_0x1db0dd){_0x5ab073=_0x5ab073-0x1e3;var _0xea9901=_0x2baacb[_0x5ab073];return _0xea9901;},_0x5ab0(_0x2cf065,_0x3f700d);}import{ObservableMixin as _0x226954,uid as _0x1f445f}from'ckeditor5/src/utils.js';export class ChangeItem extends/* #__PURE__ -- @preserve */
_0x226954(){['id'];[_0x483149(0x1ed)];[_0x483149(0x1ef)];[_0x483149(0x1e9)];[_0x483149(0x1f3)];constructor(_0x1244c0){var _0x2fe49c=_0x483149;super(),this['id']=_0x1244c0['id']||_0x1f445f(),this[_0x2fe49c(0x1ed)]=_0x1244c0[_0x2fe49c(0x1ed)],this[_0x2fe49c(0x1ef)]=_0x1244c0[_0x2fe49c(0x1ef)],this[_0x2fe49c(0x1e9)]=_0x1244c0[_0x2fe49c(0x1e9)]||{},this[_0x2fe49c(0x1f3)]=_0x1244c0[_0x2fe49c(0x1f3)],this[_0x2fe49c(0x1f0)](_0x2fe49c(0x1e6),_0x1244c0[_0x2fe49c(0x1e6)]);}[_0x483149(0x1f2)](){var _0xbd3da8=_0x483149;return{'id':this['id'],'authorId':this[_0xbd3da8(0x1ed)]['id'],'type':this[_0xbd3da8(0x1ef)],'data':this[_0xbd3da8(0x1e9)],'createdAt':this[_0xbd3da8(0x1e6)]};}}