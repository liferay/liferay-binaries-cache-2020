/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
export { Revision, type RevisionUpdateEvent, type RevisionJSON } from './revision.js';
export { RevisionHistory, RevisionViewerIntegration } from './revisionhistory.js';
export { RevisionsRepository } from './revisionsrepository.js';
export { RevisionHistoryUtils } from './revisionhistoryutils.js';
export { RevisionViewerLoadingOverlay } from './ui/revisionviewer/revisionviewerloadingoverlay.js';
export { RevisionHistoryUI } from './ui/revisionhistory/revisionhistoryui.js';
export { RevisionTracker } from './revisiontracker.js';
export { RevisionViewer, RestoreRevisionCommand, ShowChangeCommand } from './revisionviewer.js';
export { RevisionsSidebar } from './ui/revisionssidebar/revisionssidebar.js';
export { RevisionViewerUI } from './ui/revisionviewer/revisionviewerui.js';
export { RevisionViewerEditor } from './editor/revisionviewereditor.js';
export type { RevisionData } from './revision.js';
export type { RevisionHistoryConfig } from './revisionhistoryconfig.js';
export type { RevisionHistoryAdapter } from './revisionhistoryadapter.js';
import './augmentation.js';
