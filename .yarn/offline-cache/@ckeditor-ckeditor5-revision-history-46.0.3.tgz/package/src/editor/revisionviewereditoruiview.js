/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x5ec8(){var _0x59cd25=['8246pGhwHH','shouldToolbarGroupWhenFull','content','stickyPanel','11249359QpYPLT','add','render','358jlFlZE','2580369jlBfrv','342666gSodMI','4SNhmFE','_editable','9idIXEc','editable','toolbar','11748392kxNsRO','4060370USOmLj','top','175aqVxvk','4010980Dkccbd','main'];_0x5ec8=function(){return _0x59cd25;};return _0x5ec8();}function _0xa347(_0x51b269,_0x4acc8e){var _0x5ec8e5=_0x5ec8();return _0xa347=function(_0xa34777,_0xd4ded6){_0xa34777=_0xa34777-0x146;var _0x188741=_0x5ec8e5[_0xa34777];return _0x188741;},_0xa347(_0x51b269,_0x4acc8e);}var _0x2b1a3c=_0xa347;(function(_0x293ec7,_0x54f9ee){var _0x258efc=_0xa347,_0x20d14d=_0x293ec7();while(!![]){try{var _0x252a29=-parseInt(_0x258efc(0x151))/0x1*(-parseInt(_0x258efc(0x158))/0x2)+parseInt(_0x258efc(0x159))/0x3*(parseInt(_0x258efc(0x146))/0x4)+parseInt(_0x258efc(0x14f))/0x5+parseInt(_0x258efc(0x15a))/0x6*(-parseInt(_0x258efc(0x14e))/0x7)+parseInt(_0x258efc(0x14b))/0x8*(-parseInt(_0x258efc(0x148))/0x9)+-parseInt(_0x258efc(0x14c))/0xa+parseInt(_0x258efc(0x155))/0xb;if(_0x252a29===_0x54f9ee)break;else _0x20d14d['push'](_0x20d14d['shift']());}catch(_0x16a013){_0x20d14d['push'](_0x20d14d['shift']());}}}(_0x5ec8,0xd1a25));import{BoxedEditorUIView as _0x4c01bf,InlineEditableUIView as _0x5df86d,StickyPanelView as _0x4e8cf8,ToolbarView as _0x27e24c}from'ckeditor5/src/ui.js';import'@ckeditor/ckeditor5-editor-classic/theme/classiceditor.css';export class RevisionViewerEditorUIView extends _0x4c01bf{[_0x2b1a3c(0x147)];[_0x2b1a3c(0x154)];[_0x2b1a3c(0x14a)];get[_0x2b1a3c(0x149)](){var _0x3835a4=_0x2b1a3c;return this[_0x3835a4(0x147)];}constructor(_0x153e93,_0x49dfe4,_0x584f9e={}){var _0x1ab455=_0x2b1a3c;super(_0x153e93),this[_0x1ab455(0x154)]=new _0x4e8cf8(_0x153e93),this[_0x1ab455(0x14a)]=new _0x27e24c(_0x153e93,{'shouldGroupWhenFull':_0x584f9e[_0x1ab455(0x152)]}),this[_0x1ab455(0x147)]=new _0x5df86d(_0x153e93,_0x49dfe4);}[_0x2b1a3c(0x157)](){var _0x5642b7=_0x2b1a3c;super[_0x5642b7(0x157)](),this[_0x5642b7(0x154)][_0x5642b7(0x153)][_0x5642b7(0x156)](this[_0x5642b7(0x14a)]),this[_0x5642b7(0x14d)][_0x5642b7(0x156)](this[_0x5642b7(0x154)]),this[_0x5642b7(0x150)][_0x5642b7(0x156)](this[_0x5642b7(0x149)]);}}