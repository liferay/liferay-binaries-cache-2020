/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x5b7a24=_0x5c9c;(function(_0x2c2984,_0x5c2b61){const _0x178b69=_0x5c9c,_0x4ac248=_0x2c2984();while(!![]){try{const _0x311ed1=-parseInt(_0x178b69(0x10f))/0x1*(-parseInt(_0x178b69(0x107))/0x2)+parseInt(_0x178b69(0x11b))/0x3+parseInt(_0x178b69(0x10e))/0x4*(-parseInt(_0x178b69(0x10b))/0x5)+-parseInt(_0x178b69(0x118))/0x6+parseInt(_0x178b69(0x119))/0x7*(parseInt(_0x178b69(0x106))/0x8)+parseInt(_0x178b69(0x11f))/0x9+-parseInt(_0x178b69(0x111))/0xa;if(_0x311ed1===_0x5c2b61)break;else _0x4ac248['push'](_0x4ac248['shift']());}catch(_0x5a025e){_0x4ac248['push'](_0x4ac248['shift']());}}}(_0x4e24,0x18e9c));import{Editor as _0x487848,ElementApiMixin as _0x4fab86}from'ckeditor5/src/core.js';import{RevisionViewerEditorUI as _0x27518c}from'./revisionviewereditorui.js';function _0x4e24(){const _0xb3954a=['view','432168fVOOKr','createRoot','model','config','405702sYkbDY','get','fire','initialData','280OSDkGm','8438toPyjX','document','sourceElement','destroy','23275wchhiM','ready','data','148Nidcye','29GvhDiB','locale','1235690ixIrqV','create','editing','updateSourceElement','_ui','initPlugins','init','166212kFWJqF','22813rIbSCh'];_0x4e24=function(){return _0xb3954a;};return _0x4e24();}import{RevisionViewerEditorUIView as _0x262fc1}from'./revisionviewereditoruiview.js';function _0x5c9c(_0x49fe07,_0x2103bb){const _0x4e24a9=_0x4e24();return _0x5c9c=function(_0x5c9c3a,_0x3b8922){_0x5c9c3a=_0x5c9c3a-0x106;let _0x2d76aa=_0x4e24a9[_0x5c9c3a];return _0x2d76aa;},_0x5c9c(_0x49fe07,_0x2103bb);}export class RevisionViewerEditor extends/* #__PURE__ -- @preserve */
_0x4fab86(_0x487848){[_0x5b7a24(0x115)];get['ui'](){const _0xa021a1=_0x5b7a24;return this[_0xa021a1(0x115)];}constructor(_0x419281,_0x3536b3){const _0x33518a=_0x5b7a24;super(_0x3536b3),this[_0x33518a(0x109)]=_0x419281,this[_0x33518a(0x11d)][_0x33518a(0x108)][_0x33518a(0x11c)]();const _0x33f386=new _0x262fc1(this[_0x33518a(0x110)],this[_0x33518a(0x113)][_0x33518a(0x11a)],{'shouldToolbarGroupWhenFull':!0x0});this[_0x33518a(0x115)]=new _0x27518c(this,_0x33f386);}[_0x5b7a24(0x10a)](){const _0x38b468=_0x5b7a24;return this[_0x38b468(0x114)](),this['ui'][_0x38b468(0x10a)](),super[_0x38b468(0x10a)]();}static async[_0x5b7a24(0x112)](_0x39eb12,_0x1e8bfe){const _0x1db8e4=_0x5b7a24,_0x41cd8f=new this(_0x39eb12,_0x1e8bfe);return await _0x41cd8f[_0x1db8e4(0x116)](),await _0x41cd8f['ui'][_0x1db8e4(0x117)](_0x39eb12),await _0x41cd8f[_0x1db8e4(0x10d)][_0x1db8e4(0x117)](_0x41cd8f[_0x1db8e4(0x11e)][_0x1db8e4(0x120)](_0x1db8e4(0x122))||''),_0x41cd8f[_0x1db8e4(0x121)](_0x1db8e4(0x10c)),_0x41cd8f;}}