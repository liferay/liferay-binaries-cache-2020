/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x52a7b2=_0x3a7c;(function(_0x5b1013,_0x51d778){const _0x56172c=_0x3a7c,_0x5d51ef=_0x5b1013();while(!![]){try{const _0x4908f3=parseInt(_0x56172c(0x1b3))/0x1+-parseInt(_0x56172c(0x1b2))/0x2+parseInt(_0x56172c(0x1b6))/0x3*(parseInt(_0x56172c(0x1a9))/0x4)+parseInt(_0x56172c(0x1a6))/0x5+-parseInt(_0x56172c(0x1b4))/0x6*(parseInt(_0x56172c(0x1a2))/0x7)+parseInt(_0x56172c(0x1b7))/0x8*(-parseInt(_0x56172c(0x1a3))/0x9)+parseInt(_0x56172c(0x19f))/0xa*(parseInt(_0x56172c(0x1b5))/0xb);if(_0x4908f3===_0x51d778)break;else _0x5d51ef['push'](_0x5d51ef['shift']());}catch(_0xf3260){_0x5d51ef['push'](_0x5d51ef['shift']());}}}(_0x3c83,0x4ad23));function _0x3a7c(_0x12c438,_0x9a9d40){const _0x3c8322=_0x3c83();return _0x3a7c=function(_0x3a7c1d,_0x1837c2){_0x3a7c1d=_0x3a7c1d-0x19f;let _0x25d02e=_0x3c8322[_0x3a7c1d];return _0x25d02e;},_0x3a7c(_0x12c438,_0x9a9d40);}function _0x3c83(){const _0x457405=['36459uvSJVZ','8OMFCOY','isPremiumPlugin','340zfyphM','roots','editing','399BQhEoS','2203209qOLZQN','addClass','RevisionViewerLoadingOverlay','2443650hjwJBR','view','ck-editor__editable__loading-overlay','124WSHQIR','document','editor','isOfficialPlugin','pluginName','show','change','hide','removeClass','235650ZOZpoC','179329DFUbMk','57690gVomsH','55759phHvDS'];_0x3c83=function(){return _0x457405;};return _0x3c83();}import{Plugin as _0x1ea691}from'ckeditor5/src/core.js';const ge=_0x52a7b2(0x1a8);import'../../../theme/revisionviewerloadingoverlay.css';export class RevisionViewerLoadingOverlay extends _0x1ea691{static get[_0x52a7b2(0x1ad)](){const _0x42d0c1=_0x52a7b2;return _0x42d0c1(0x1a5);}static get[_0x52a7b2(0x1ac)](){return!0x0;}static get[_0x52a7b2(0x1b8)](){return!0x0;}[_0x52a7b2(0x1ae)](){const _0x4cbf96=_0x52a7b2,_0xa2e977=this[_0x4cbf96(0x1ab)][_0x4cbf96(0x1a1)][_0x4cbf96(0x1a7)];_0xa2e977[_0x4cbf96(0x1af)](_0x334d59=>{const _0x6baae5=_0x4cbf96;for(const _0xe2d074 of _0xa2e977[_0x6baae5(0x1aa)][_0x6baae5(0x1a0)])_0x334d59[_0x6baae5(0x1a4)](ge,_0xe2d074);});}[_0x52a7b2(0x1b0)](){const _0x190bb4=_0x52a7b2,_0xeed08b=this[_0x190bb4(0x1ab)][_0x190bb4(0x1a1)][_0x190bb4(0x1a7)];_0xeed08b[_0x190bb4(0x1af)](_0x20c9cb=>{const _0x2c0fdf=_0x190bb4;for(const _0x6c298a of _0xeed08b[_0x2c0fdf(0x1aa)][_0x2c0fdf(0x1a0)])_0x20c9cb[_0x2c0fdf(0x1b1)](ge,_0x6c298a);});}}