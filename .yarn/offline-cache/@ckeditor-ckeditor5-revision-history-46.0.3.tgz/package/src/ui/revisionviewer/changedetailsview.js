/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x5e3cb8=_0x5af3;function _0x5af3(_0x3fe3b0,_0x5dc45d){const _0x53aee5=_0x53ae();return _0x5af3=function(_0x5af328,_0x500eec){_0x5af328=_0x5af328-0x99;let _0x4bec35=_0x53aee5[_0x5af328];return _0x4bec35;},_0x5af3(_0x3fe3b0,_0x5dc45d);}(function(_0x575f96,_0xa0f920){const _0x532a66=_0x5af3,_0x570806=_0x575f96();while(!![]){try{const _0x5e3ffc=parseInt(_0x532a66(0x9a))/0x1*(parseInt(_0x532a66(0x99))/0x2)+parseInt(_0x532a66(0xb1))/0x3+parseInt(_0x532a66(0xb4))/0x4+-parseInt(_0x532a66(0xa3))/0x5+parseInt(_0x532a66(0xa2))/0x6*(-parseInt(_0x532a66(0xb3))/0x7)+parseInt(_0x532a66(0xaa))/0x8+-parseInt(_0x532a66(0xa6))/0x9;if(_0x5e3ffc===_0xa0f920)break;else _0x570806['push'](_0x570806['shift']());}catch(_0x5c217e){_0x570806['push'](_0x570806['shift']());}}}(_0x53ae,0x8b466));function _0x53ae(){const _0x348d44=['ck-revision-change__','data','focus','bindTemplate','element','Added\x20by','6bbqeiR','3870205cAXcRu','isSuggestion','ck-annotation','1399788gMZYuu','set','_model','name','3183240VQVKFA','Suggested\x20by','author','type','div','changeId','ck-revision-change','577977fabkEB','span','3448319CZcHQA','2249672fbkzJu','add','setTemplate','Removed\x20by','1036dcPERd','1621Orjiux','ck-revision-change__label'];_0x53ae=function(){return _0x348d44;};return _0x53ae();}import{View as _0x589081}from'ckeditor5/src/ui.js';import{getTranslation as _0x387298}from'../../utils/common-translations.js';export class ChangeDetailsView extends _0x589081{[_0x5e3cb8(0xaf)];[_0x5e3cb8(0xa8)];constructor(_0x1ceae0,_0x2d692b){const _0x388d1d=_0x5e3cb8;super(_0x1ceae0),this[_0x388d1d(0xa8)]=_0x2d692b,this[_0x388d1d(0xaf)]=_0x2d692b['id'];const _0x52f32f=this[_0x388d1d(0x9f)],_0xc8f51e=_0x387298(_0x1ceae0,_0x2d692b[_0x388d1d(0x9d)][_0x388d1d(0xa4)]?_0x388d1d(0xab):_0x388d1d(0xb5)==_0x2d692b[_0x388d1d(0xad)]?_0x388d1d(0xa1):_0x388d1d(0xb7));this[_0x388d1d(0xa7)](_0x388d1d(0xad),_0x2d692b[_0x388d1d(0xad)]),this[_0x388d1d(0xb6)]({'tag':_0x388d1d(0xae),'attributes':{'class':[_0x388d1d(0xa5),_0x388d1d(0xb0),_0x52f32f['to'](_0x388d1d(0xad),_0x59fafc=>_0x388d1d(0x9c)+_0x59fafc)],'tabindex':-0x1},'children':[{'tag':_0x388d1d(0xb2),'children':[{'tag':_0x388d1d(0xb2),'attributes':{'class':[_0x388d1d(0x9b)]},'children':[{'text':_0xc8f51e}]},{'text':'\x20'+_0x2d692b[_0x388d1d(0xac)][_0x388d1d(0xa9)]}]}]});}[_0x5e3cb8(0x9e)](){const _0x1f3317=_0x5e3cb8;this[_0x1f3317(0xa0)][_0x1f3317(0x9e)]();}}