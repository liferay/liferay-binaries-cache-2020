/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x25fb2,_0x5d5784){const _0x14df92=_0x4528,_0x1b8eec=_0x25fb2();while(!![]){try{const _0x4e51c0=-parseInt(_0x14df92(0x8a))/0x1*(parseInt(_0x14df92(0x7b))/0x2)+parseInt(_0x14df92(0x88))/0x3*(-parseInt(_0x14df92(0x86))/0x4)+parseInt(_0x14df92(0x83))/0x5+parseInt(_0x14df92(0x7a))/0x6+parseInt(_0x14df92(0x85))/0x7+-parseInt(_0x14df92(0x84))/0x8*(parseInt(_0x14df92(0x7c))/0x9)+-parseInt(_0x14df92(0x89))/0xa*(parseInt(_0x14df92(0x7f))/0xb);if(_0x4e51c0===_0x5d5784)break;else _0x1b8eec['push'](_0x1b8eec['shift']());}catch(_0x3ddde5){_0x1b8eec['push'](_0x1b8eec['shift']());}}}(_0x8283,0xb7078));import{View as _0x52d10f,IconView as _0x516d51}from'ckeditor5/src/ui.js';import{getTranslation as _0x46b8ee}from'../../utils/common-translations.js';import{IconHistory as _0x1afe1c}from'ckeditor5/src/icons.js';function _0x8283(){const _0x44cd5a=['ck-revision-history-sidebar__header__label','setTemplate','ck-revision-history-sidebar__header','5387735OdYKEd','8xUeEgB','1409961ZtQSfg','20PTtrvj','Revision\x20history','156081gBQXJc','120JhswgW','1THRHYm','ck-reset_all','span','7348752jBmeJZ','780844gergMU','1234629vxvvMw','content','div','885808jdjbvF'];_0x8283=function(){return _0x44cd5a;};return _0x8283();}function _0x4528(_0x30e75f,_0x4b429d){const _0x82836=_0x8283();return _0x4528=function(_0x452856,_0x5597b2){_0x452856=_0x452856-0x7a;let _0x1c00f8=_0x82836[_0x452856];return _0x1c00f8;},_0x4528(_0x30e75f,_0x4b429d);}import'../../../theme/revisionssidebar/revisionssidebarheader.css';export class RevisionsSidebarHeaderView extends _0x52d10f{constructor(_0x59ac13){const _0x25f13c=_0x4528;super(_0x59ac13);const _0x6990a1=new _0x516d51();_0x6990a1[_0x25f13c(0x7d)]=_0x1afe1c,this[_0x25f13c(0x81)]({'tag':_0x25f13c(0x7e),'attributes':{'class':['ck',_0x25f13c(0x8b),_0x25f13c(0x82)]},'children':[_0x6990a1,{'tag':_0x25f13c(0x8c),'attributes':{'class':['ck',_0x25f13c(0x80)]},'children':[_0x46b8ee(_0x59ac13,_0x25f13c(0x87))]}]});}}