/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0xad14(_0x448336,_0x3a8545){const _0x1d19ee=_0x1d19();return _0xad14=function(_0xad14d,_0x168252){_0xad14d=_0xad14d-0x15c;let _0x38172e=_0x1d19ee[_0xad14d];return _0x38172e;},_0xad14(_0x448336,_0x3a8545);}const _0x4bfd28=_0xad14;(function(_0x47d923,_0x8ee352){const _0x98b99c=_0xad14,_0x5b0054=_0x47d923();while(!![]){try{const _0x34a8ac=parseInt(_0x98b99c(0x15e))/0x1+-parseInt(_0x98b99c(0x163))/0x2+parseInt(_0x98b99c(0x16f))/0x3*(-parseInt(_0x98b99c(0x165))/0x4)+-parseInt(_0x98b99c(0x15c))/0x5*(-parseInt(_0x98b99c(0x170))/0x6)+parseInt(_0x98b99c(0x174))/0x7*(-parseInt(_0x98b99c(0x161))/0x8)+parseInt(_0x98b99c(0x16b))/0x9*(-parseInt(_0x98b99c(0x162))/0xa)+parseInt(_0x98b99c(0x164))/0xb;if(_0x34a8ac===_0x8ee352)break;else _0x5b0054['push'](_0x5b0054['shift']());}catch(_0x280404){_0x5b0054['push'](_0x5b0054['shift']());}}}(_0x1d19,0x49509));import{View as _0x1fc44d}from'ckeditor5/src/ui.js';import{RevisionView as _0x38b0a2}from'../revision/revisionview.js';import{getDateTimePeriodInfo as _0x26d9c9}from'./utils.js';import'../../../theme/revisionssidebar/revisionssidebartimeperiod.css';function _0x1d19(){const _0x257e82=['8mhAviY','1910DEILjU','899622GsraFu','15022799vLIgVn','168zCQRBl','select','startDate','uiLanguage','removeRevision','delegate','21033YAzVtU','ck-revision-history-sidebar__time-period__revisions','remove','addRevision','33099oeKhSH','412194sikvXD','ck-revision-history-sidebar__time-period__label','revisionViews','createCollection','3677093yvgGiR','add','locale','_requireRevisionName','find','div','setName','setTemplate','span','40vsQAKH','localizedPeriodName','269859jgMIZF','_revisionActions','ck-revision-history-sidebar__time-period'];_0x1d19=function(){return _0x257e82;};return _0x1d19();}export class RevisionsSidebarTimePeriodView extends _0x1fc44d{[_0x4bfd28(0x167)];[_0x4bfd28(0x172)];[_0x4bfd28(0x15f)];[_0x4bfd28(0x177)];constructor(_0x2d705b,_0x201bfd,_0x54df8f,_0x111551){const _0x3eb2bd=_0x4bfd28;super(_0x2d705b);const _0x3837ed=_0x26d9c9(_0x201bfd,this[_0x3eb2bd(0x176)][_0x3eb2bd(0x168)])[_0x3eb2bd(0x15d)];this[_0x3eb2bd(0x167)]=_0x201bfd,this[_0x3eb2bd(0x172)]=this[_0x3eb2bd(0x173)](),this[_0x3eb2bd(0x15f)]=_0x54df8f,this[_0x3eb2bd(0x177)]=_0x111551,this[_0x3eb2bd(0x172)][_0x3eb2bd(0x16a)](_0x3eb2bd(0x166))['to'](this),this[_0x3eb2bd(0x172)][_0x3eb2bd(0x16a)](_0x3eb2bd(0x17a))['to'](this),this[_0x3eb2bd(0x17b)]({'tag':_0x3eb2bd(0x179),'attributes':{'class':['ck',_0x3eb2bd(0x160)]},'children':[{'tag':_0x3eb2bd(0x17c),'attributes':{'class':['ck',_0x3eb2bd(0x171)]},'children':[{'text':_0x3837ed}]},{'tag':_0x3eb2bd(0x179),'attributes':{'class':['ck',_0x3eb2bd(0x16c)]},'children':this[_0x3eb2bd(0x172)]}]});}[_0x4bfd28(0x16e)](_0x37d750){const _0x596e2b=_0x4bfd28,_0x255cea=new _0x38b0a2(this[_0x596e2b(0x176)],_0x37d750,this[_0x596e2b(0x15f)],this[_0x596e2b(0x177)]);this[_0x596e2b(0x172)][_0x596e2b(0x175)](_0x255cea);}[_0x4bfd28(0x169)](_0x46c749){const _0x4ef5d1=_0x4bfd28,_0x57b2bc=this[_0x4ef5d1(0x172)][_0x4ef5d1(0x178)](_0xd3f921=>_0xd3f921['id']===_0x46c749['id']);this[_0x4ef5d1(0x172)][_0x4ef5d1(0x16d)](_0x57b2bc);}}