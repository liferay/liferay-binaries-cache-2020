/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x43d072=_0x576b;(function(_0x348cf0,_0x103966){const _0x521d13=_0x576b,_0x2d28bd=_0x348cf0();while(!![]){try{const _0x2cb84b=-parseInt(_0x521d13(0x182))/0x1+-parseInt(_0x521d13(0x173))/0x2+-parseInt(_0x521d13(0x16f))/0x3+-parseInt(_0x521d13(0x17f))/0x4+-parseInt(_0x521d13(0x181))/0x5+-parseInt(_0x521d13(0x183))/0x6+parseInt(_0x521d13(0x17c))/0x7;if(_0x2cb84b===_0x103966)break;else _0x2d28bd['push'](_0x2d28bd['shift']());}catch(_0x532a92){_0x2d28bd['push'](_0x2d28bd['shift']());}}}(_0x46e6,0xad806));function _0x576b(_0x220cd9,_0x4f1ebb){const _0x46e6ba=_0x46e6();return _0x576b=function(_0x576bec,_0x2e4d46){_0x576bec=_0x576bec-0x169;let _0x253456=_0x46e6ba[_0x576bec];return _0x253456;},_0x576b(_0x220cd9,_0x4f1ebb);}import{LabeledFieldView as _0xd8f87b}from'ckeditor5/src/ui.js';function _0x46e6(){const _0x6c0e22=['4161760VkDkuc','164927UsLoqB','5532402RLvkSv','clientWidth','listenTo','_updateTooltipText','element','ck-revision-history-sidebar__revision-name','scrollWidth','render','1874496gKwavG','extendTemplate','set','value','392956ogvxnz','destroy','fieldView','_tooltipString','input','bindTemplate','ck-tooltip_multi-line','Revision\x20name','_resizeObserver','28204477LyDCFE','Enter\x20the\x20revision\x20name','span','2311572zfKgui','placeholder'];_0x46e6=function(){return _0x6c0e22;};return _0x46e6();}import{ResizeObserver as _0x1b3b86}from'ckeditor5/src/utils.js';import{getTranslation as _0x3f798f}from'../../utils/common-translations.js';import'../../../theme/revision/revisionname.css';export class RevisionNameView extends _0xd8f87b{[_0x43d072(0x17b)]=null;constructor(_0x22ce3f,_0x4f499e){const _0x5f205f=_0x43d072;super(_0x22ce3f,_0x4f499e);const _0x3ee403=this[_0x5f205f(0x178)];this[_0x5f205f(0x171)]({'label':_0x3f798f(_0x22ce3f,_0x5f205f(0x17a)),'_tooltipString':''}),this[_0x5f205f(0x175)][_0x5f205f(0x180)]=_0x3f798f(_0x22ce3f,_0x5f205f(0x17d)),this[_0x5f205f(0x170)]({'tag':_0x5f205f(0x17e),'attributes':{'class':[_0x5f205f(0x16c)],'data-cke-tooltip-text':_0x3ee403['to'](_0x5f205f(0x176)),'data-cke-tooltip-position':'s','data-cke-tooltip-class':_0x5f205f(0x179)}});}[_0x43d072(0x16e)](){const _0x55571f=_0x43d072;super[_0x55571f(0x16e)](),this[_0x55571f(0x17b)]=new _0x1b3b86(this[_0x55571f(0x175)][_0x55571f(0x16b)],()=>this[_0x55571f(0x16a)]()),this[_0x55571f(0x169)](this[_0x55571f(0x175)],_0x55571f(0x177),()=>this[_0x55571f(0x16a)]());}[_0x43d072(0x174)](){const _0x29183d=_0x43d072;super[_0x29183d(0x174)](),this[_0x29183d(0x17b)]&&this[_0x29183d(0x17b)][_0x29183d(0x174)]();}[_0x43d072(0x16a)](){const _0x3df7c1=_0x43d072,_0x373b77=this[_0x3df7c1(0x175)][_0x3df7c1(0x16b)];this[_0x3df7c1(0x176)]=_0x373b77[_0x3df7c1(0x16d)]>_0x373b77[_0x3df7c1(0x184)]&&_0x373b77[_0x3df7c1(0x172)]||'';}}