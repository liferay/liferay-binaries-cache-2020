/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x503b39=_0x309c;function _0x309c(_0x3cc386,_0x1bbacd){const _0x2cf6f1=_0x2cf6();return _0x309c=function(_0x309c3e,_0x3a2b6b){_0x309c3e=_0x309c3e-0x175;let _0x1ecf8f=_0x2cf6f1[_0x309c3e];return _0x1ecf8f;},_0x309c(_0x3cc386,_0x1bbacd);}(function(_0x21075c,_0x490bd7){const _0x253a5a=_0x309c,_0x3ba17b=_0x21075c();while(!![]){try{const _0x22b59e=-parseInt(_0x253a5a(0x181))/0x1*(parseInt(_0x253a5a(0x18a))/0x2)+-parseInt(_0x253a5a(0x18b))/0x3*(parseInt(_0x253a5a(0x18e))/0x4)+parseInt(_0x253a5a(0x189))/0x5+parseInt(_0x253a5a(0x17d))/0x6+-parseInt(_0x253a5a(0x178))/0x7*(parseInt(_0x253a5a(0x183))/0x8)+-parseInt(_0x253a5a(0x17b))/0x9+parseInt(_0x253a5a(0x187))/0xa*(parseInt(_0x253a5a(0x17f))/0xb);if(_0x22b59e===_0x490bd7)break;else _0x3ba17b['push'](_0x3ba17b['shift']());}catch(_0x2d8564){_0x3ba17b['push'](_0x3ba17b['shift']());}}}(_0x2cf6,0x2e953));import{View as _0x2d359f}from'ckeditor5/src/ui.js';import'../../../theme/revision/subrevisioncollapser.css';function _0x2cf6(){const _0x231c64=['button','18796kqzOiI','_isCollapsed','ck-revision-history-sidebar__subrevision-collapser__inner','toggle','1307593NJRbMp','ck-revision-history-sidebar__subrevision-collapser','true','1056879CjtgsN','ck-hidden','2041302sZCHzL','set','1529hqrRvu','ck-revision-history-sidebar__subrevision-collapser_collapsed','5708UbcUyP','span','8BsBfiu','false','isVisible','bindTemplate','23990sUraAA','click','1695120wJwINB','104SyxoPM','141oxDFSj','setTemplate'];_0x2cf6=function(){return _0x231c64;};return _0x2cf6();}export class SubrevisionCollapserView extends _0x2d359f{constructor(_0x1e9b11){const _0xb847f3=_0x309c;super(_0x1e9b11);const _0x21f52b=this[_0xb847f3(0x186)];this[_0xb847f3(0x17e)]({'isVisible':!0x0,'_isCollapsed':!0x0}),this[_0xb847f3(0x18c)]({'tag':_0xb847f3(0x182),'attributes':{'class':['ck',_0xb847f3(0x179),_0x21f52b['if'](_0xb847f3(0x185),_0xb847f3(0x17c),_0x128e86=>!_0x128e86),_0x21f52b['if'](_0xb847f3(0x175),_0xb847f3(0x180))],'role':_0xb847f3(0x18d),'aria-pressed':_0x21f52b['to'](_0xb847f3(0x175),_0x3df631=>_0x3df631?_0xb847f3(0x184):_0xb847f3(0x17a))},'children':[{'tag':_0xb847f3(0x182),'attributes':{'class':['ck',_0xb847f3(0x176)]}}],'on':{'click':_0x21f52b['to'](_0xb847f3(0x188))}});}[_0x503b39(0x177)](){const _0x136007=_0x503b39;this[_0x136007(0x175)]=!this[_0x136007(0x175)];}}