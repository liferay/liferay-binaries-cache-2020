/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x4d43(){var _0x30e4b3=['long','3252VzbmDO','999815qYCtXi','numeric','toLocaleDateString','15162uQOAvW','790gYBXoQ','1134609BJxQue','45vwQnEv','2177xmWAKS','1615384TJfGQo','469560PbDPgA','toLocaleTimeString','135mYDKYN','264693Hoqreh'];_0x4d43=function(){return _0x30e4b3;};return _0x4d43();}(function(_0x107aeb,_0xcf1aad){var _0x574b16=_0x2a80,_0x3c7493=_0x107aeb();while(!![]){try{var _0xdd07db=-parseInt(_0x574b16(0xd1))/0x1+parseInt(_0x574b16(0xda))/0x2+-parseInt(_0x574b16(0xd6))/0x3+parseInt(_0x574b16(0xd0))/0x4*(-parseInt(_0x574b16(0xdc))/0x5)+-parseInt(_0x574b16(0xd4))/0x6*(-parseInt(_0x574b16(0xd8))/0x7)+-parseInt(_0x574b16(0xd9))/0x8*(parseInt(_0x574b16(0xd7))/0x9)+-parseInt(_0x574b16(0xd5))/0xa*(-parseInt(_0x574b16(0xdd))/0xb);if(_0xdd07db===_0xcf1aad)break;else _0x3c7493['push'](_0x3c7493['shift']());}catch(_0x39180b){_0x3c7493['push'](_0x3c7493['shift']());}}}(_0x4d43,0x7d046));function _0x2a80(_0x41c9b7,_0x17c2dc){var _0x4d43b0=_0x4d43();return _0x2a80=function(_0x2a80b4,_0x4d25){_0x2a80b4=_0x2a80b4-0xd0;var _0x550dc6=_0x4d43b0[_0x2a80b4];return _0x550dc6;},_0x2a80(_0x41c9b7,_0x17c2dc);}export function dateToPrettyFormat(_0x431dad,_0x5b9357){var _0x3d9411=_0x2a80;return _0x5b9357[_0x3d9411(0xd3)](_0x431dad,{'month':_0x3d9411(0xde),'day':_0x3d9411(0xd2)})+',\x20'+_0x5b9357[_0x3d9411(0xdb)](_0x431dad,{'hour':_0x3d9411(0xd2),'minute':_0x3d9411(0xd2)});}