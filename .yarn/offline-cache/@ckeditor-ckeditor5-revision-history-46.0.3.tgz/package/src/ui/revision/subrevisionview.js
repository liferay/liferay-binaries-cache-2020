/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0xa7bf9b=_0x3510;(function(_0x3924e6,_0x32ec5f){const _0x44bafd=_0x3510,_0x1e4853=_0x3924e6();while(!![]){try{const _0x1ca9d3=parseInt(_0x44bafd(0x167))/0x1*(parseInt(_0x44bafd(0x161))/0x2)+-parseInt(_0x44bafd(0x16b))/0x3*(-parseInt(_0x44bafd(0x164))/0x4)+parseInt(_0x44bafd(0x17b))/0x5*(parseInt(_0x44bafd(0x163))/0x6)+-parseInt(_0x44bafd(0x179))/0x7+-parseInt(_0x44bafd(0x175))/0x8*(-parseInt(_0x44bafd(0x162))/0x9)+parseInt(_0x44bafd(0x17a))/0xa*(-parseInt(_0x44bafd(0x165))/0xb)+parseInt(_0x44bafd(0x16a))/0xc*(-parseInt(_0x44bafd(0x174))/0xd);if(_0x1ca9d3===_0x32ec5f)break;else _0x1e4853['push'](_0x1e4853['shift']());}catch(_0x2657f2){_0x1e4853['push'](_0x1e4853['shift']());}}}(_0x4c19,0x55c6f));function _0x3510(_0x7bc0b2,_0x20f117){const _0x4c195d=_0x4c19();return _0x3510=function(_0x351032,_0x562287){_0x351032=_0x351032-0x160;let _0x640687=_0x4c195d[_0x351032];return _0x640687;},_0x3510(_0x7bc0b2,_0x20f117);}function _0x4c19(){const _0x45b9ff=['ck-revision-history-sidebar__revision_selected','isSelected','ck-revision-history-sidebar__revision__date','_createdAtFormatted','bindTemplate','span','ck-reset','fire','13rpSfKr','17840VlJTmp','set','ck-revision-history-sidebar__subrevision','creator','3600478qqmfLO','816190xOJRpx','3204020PoQimk','bind','createdAt','select','ck-revision-history-sidebar__revision','setTemplate','_parentRevisionId','deselect','14LsKvlY','2421zgLZQa','6DHKdqv','232248xYIrHm','66rJteOl','div','68168ckXUUB','uiLanguage','ck-revision-history-sidebar__revision-authors','9226476icyZuy','21NHRbPr'];_0x4c19=function(){return _0x45b9ff;};return _0x4c19();}import{View as _0xfbbacc}from'ckeditor5/src/ui.js';import{RevisionAuthorView as _0x1ef9c5}from'./revisionauthorview.js';import{dateToPrettyFormat as _0x8bcaef}from'./utils.js';import'../../../theme/revision/subrevision.css';export class SubrevisionView extends _0xfbbacc{['id'];[_0xa7bf9b(0x181)];constructor(_0x58a83b,_0x510e42,_0x4b8ab9){const _0x41bd7c=_0xa7bf9b;super(_0x58a83b);const _0x43d1f5=this[_0x41bd7c(0x170)];this['id']=_0x510e42['id'],this[_0x41bd7c(0x17c)](_0x41bd7c(0x17d))['to'](_0x510e42),this[_0x41bd7c(0x176)](_0x41bd7c(0x16d),!0x1),this[_0x41bd7c(0x17c)](_0x41bd7c(0x16f))['to'](this,_0x41bd7c(0x17d),_0x1963f6=>_0x1963f6?_0x8bcaef(_0x58a83b[_0x41bd7c(0x168)],_0x1963f6):void 0x0),this[_0x41bd7c(0x181)]=_0x4b8ab9,this[_0x41bd7c(0x180)]({'tag':_0x41bd7c(0x166),'attributes':{'class':['ck',_0x41bd7c(0x172),_0x41bd7c(0x17f),_0x41bd7c(0x177),_0x43d1f5['if'](_0x41bd7c(0x16d),_0x41bd7c(0x16c))]},'children':[{'tag':_0x41bd7c(0x171),'attributes':{'class':['ck',_0x41bd7c(0x16e)]},'children':[{'text':_0x43d1f5['to'](_0x41bd7c(0x16f))}]},{'tag':'ul','attributes':{'class':['ck',_0x41bd7c(0x169)]},'children':[new _0x1ef9c5(_0x58a83b,_0x510e42[_0x41bd7c(0x178)],!0x0)]}],'on':{'click':_0x43d1f5['to'](this[_0x41bd7c(0x17e)][_0x41bd7c(0x17c)](this))}});}[_0xa7bf9b(0x17e)](){const _0xd2f8d7=_0xa7bf9b;this[_0xd2f8d7(0x16d)]=!0x0,this[_0xd2f8d7(0x173)](_0xd2f8d7(0x17e),{'parentId':this[_0xd2f8d7(0x181)]});}[_0xa7bf9b(0x160)](){const _0x32c34d=_0xa7bf9b;this[_0x32c34d(0x16d)]=!0x1;}}