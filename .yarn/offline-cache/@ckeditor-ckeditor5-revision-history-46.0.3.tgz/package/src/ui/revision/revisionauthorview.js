/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x1bc9a5,_0x3560c8){const _0x43a5de=_0x3486,_0x2865eb=_0x1bc9a5();while(!![]){try{const _0x41cebf=parseInt(_0x43a5de(0x181))/0x1*(-parseInt(_0x43a5de(0x186))/0x2)+-parseInt(_0x43a5de(0x184))/0x3+-parseInt(_0x43a5de(0x18e))/0x4+parseInt(_0x43a5de(0x18d))/0x5*(-parseInt(_0x43a5de(0x187))/0x6)+-parseInt(_0x43a5de(0x194))/0x7*(parseInt(_0x43a5de(0x190))/0x8)+-parseInt(_0x43a5de(0x180))/0x9+parseInt(_0x43a5de(0x182))/0xa*(parseInt(_0x43a5de(0x18c))/0xb);if(_0x41cebf===_0x3560c8)break;else _0x2865eb['push'](_0x2865eb['shift']());}catch(_0x50e216){_0x2865eb['push'](_0x2865eb['shift']());}}}(_0x5475,0x61ae5));import{View as _0x13c801,IconView as _0x2b4912}from'ckeditor5/src/ui.js';import{IconUser as _0x2561d0}from'ckeditor5/src/icons.js';function _0x3486(_0x114749,_0x1f3911){const _0x5475f5=_0x5475();return _0x3486=function(_0x3486f2,_0x896d9b){_0x3486f2=_0x3486f2-0x180;let _0x2ca449=_0x5475f5[_0x3486f2];return _0x2ca449;},_0x3486(_0x114749,_0x1f3911);}import{getTranslation as _0x55895d}from'../../utils/common-translations.js';import'../../../theme/revision/revisionauthor.css';export class RevisionAuthorView extends _0x13c801{constructor(_0x477d5b,_0x1bfa5d,_0x47c503){const _0x5c51ba=_0x3486;super(_0x477d5b);const _0x52201a=new _0x2b4912();_0x52201a[_0x5c51ba(0x18a)]({'content':_0x2561d0,'viewBox':_0x5c51ba(0x185)});const _0xa08c07=['ck',_0x5c51ba(0x18b)];_0x47c503&&_0xa08c07[_0x5c51ba(0x18f)](_0x5c51ba(0x193));const _0x111ff6=[{'tag':_0x5c51ba(0x191),'attributes':{'class':['ck',_0x5c51ba(0x189)],'title':_0x55895d(_0x477d5b,_0x47c503?_0x5c51ba(0x188):_0x5c51ba(0x195))},'children':[_0x52201a,_0x1bfa5d[_0x5c51ba(0x192)]]}];this[_0x5c51ba(0x183)]({'tag':'li','attributes':{'class':_0xa08c07},'children':_0x111ff6});}}function _0x5475(){const _0x43c00b=['ck-revision-history-sidebar__revision-author__name','set','ck-revision-history-sidebar__revision-author','6523LoGgsb','1817595nHokMF','775208GVbgUt','push','8Exmtur','span','name','ck-revision-history-sidebar__revision-author_creator','4782442OGFrDN','Revision\x20author','5713326colbzt','6lJptfN','54020KWRiBm','setTemplate','1498344dOonbH','0\x200\x2011\x2010','142832KwSAJZ','6ngRELr','Revision\x20creator'];_0x5475=function(){return _0x43c00b;};return _0x5475();}