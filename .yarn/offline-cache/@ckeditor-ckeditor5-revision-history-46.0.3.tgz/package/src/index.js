/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x48f3cb,_0x662cf0){var _0x6b9850=_0x5bf3,_0x3de568=_0x48f3cb();while(!![]){try{var _0x457446=-parseInt(_0x6b9850(0x137))/0x1+parseInt(_0x6b9850(0x13d))/0x2*(-parseInt(_0x6b9850(0x135))/0x3)+parseInt(_0x6b9850(0x133))/0x4*(-parseInt(_0x6b9850(0x13b))/0x5)+-parseInt(_0x6b9850(0x136))/0x6+parseInt(_0x6b9850(0x139))/0x7*(parseInt(_0x6b9850(0x134))/0x8)+parseInt(_0x6b9850(0x138))/0x9+-parseInt(_0x6b9850(0x13c))/0xa*(-parseInt(_0x6b9850(0x13a))/0xb);if(_0x457446===_0x662cf0)break;else _0x3de568['push'](_0x3de568['shift']());}catch(_0x135d0b){_0x3de568['push'](_0x3de568['shift']());}}}(_0x32e3,0x5d68c));function _0x32e3(){var _0x51b68a=['4034272bPKfuT','15vvGKIE','2471256mEOSgp','172302HFQVhb','5685102yQViBF','7Nxahlu','3443AQttnd','221270dgWOpC','15430DdVwql','243154sMdxJN','4qHwNAR'];_0x32e3=function(){return _0x51b68a;};return _0x32e3();}export{Revision}from'./revision.js';export{RevisionHistory,RevisionViewerIntegration}from'./revisionhistory.js';export{RevisionsRepository}from'./revisionsrepository.js';function _0x5bf3(_0x380006,_0x84f9b2){var _0x32e3cc=_0x32e3();return _0x5bf3=function(_0x5bf30c,_0x3179e7){_0x5bf30c=_0x5bf30c-0x133;var _0x4d9e1b=_0x32e3cc[_0x5bf30c];return _0x4d9e1b;},_0x5bf3(_0x380006,_0x84f9b2);}export{RevisionHistoryUtils}from'./revisionhistoryutils.js';export{RevisionViewerLoadingOverlay}from'./ui/revisionviewer/revisionviewerloadingoverlay.js';export{RevisionHistoryUI}from'./ui/revisionhistory/revisionhistoryui.js';export{RevisionTracker}from'./revisiontracker.js';export{RevisionViewer,RestoreRevisionCommand,ShowChangeCommand}from'./revisionviewer.js';export{RevisionsSidebar}from'./ui/revisionssidebar/revisionssidebar.js';export{RevisionViewerUI}from'./ui/revisionviewer/revisionviewerui.js';export{RevisionViewerEditor}from'./editor/revisionviewereditor.js';import'./augmentation.js';