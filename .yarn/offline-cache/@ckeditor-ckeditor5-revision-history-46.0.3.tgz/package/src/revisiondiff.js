/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x48e317=_0x530a;function _0x58fc(){const _0x43a9d1=['2211010fCljhI','add','896080bhtONA','10SaNlxe','10012coxlwj','27PyQkBs','5Xjecfh','changes','1583461qMYOqo','2607624MCpbpj','oldRevisionId','7xELAlA','4038032oRYVXg','_setChanges','2083389WBvvwZ','newRevisionId'];_0x58fc=function(){return _0x43a9d1;};return _0x58fc();}function _0x530a(_0x21eebe,_0x2d4093){const _0x58fc89=_0x58fc();return _0x530a=function(_0x530a86,_0x5245d4){_0x530a86=_0x530a86-0x17f;let _0x5a62f4=_0x58fc89[_0x530a86];return _0x5a62f4;},_0x530a(_0x21eebe,_0x2d4093);}(function(_0x38da63,_0x2ff670){const _0x4d24db=_0x530a,_0x518ba9=_0x38da63();while(!![]){try{const _0x2ecf4b=-parseInt(_0x4d24db(0x18c))/0x1*(parseInt(_0x4d24db(0x18d))/0x2)+parseInt(_0x4d24db(0x187))/0x3+-parseInt(_0x4d24db(0x18b))/0x4*(-parseInt(_0x4d24db(0x17f))/0x5)+-parseInt(_0x4d24db(0x182))/0x6*(parseInt(_0x4d24db(0x184))/0x7)+-parseInt(_0x4d24db(0x185))/0x8+-parseInt(_0x4d24db(0x18e))/0x9*(-parseInt(_0x4d24db(0x189))/0xa)+-parseInt(_0x4d24db(0x181))/0xb;if(_0x2ecf4b===_0x2ff670)break;else _0x518ba9['push'](_0x518ba9['shift']());}catch(_0x10467d){_0x518ba9['push'](_0x518ba9['shift']());}}}(_0x58fc,0x6d7a1));import{Collection as _0x4fce38}from'ckeditor5/src/utils.js';export class RevisionDiff{[_0x48e317(0x188)];[_0x48e317(0x183)];[_0x48e317(0x180)];constructor(_0x3da887,_0x14b354){const _0x51563d=_0x48e317;this[_0x51563d(0x188)]=_0x3da887,this[_0x51563d(0x183)]=_0x14b354,this[_0x51563d(0x180)]=new _0x4fce38();}[_0x48e317(0x186)](_0x594bdb){const _0xa5f741=_0x48e317;for(const _0x3f4fdd of _0x594bdb)this[_0xa5f741(0x180)][_0xa5f741(0x18a)](_0x3f4fdd);}}