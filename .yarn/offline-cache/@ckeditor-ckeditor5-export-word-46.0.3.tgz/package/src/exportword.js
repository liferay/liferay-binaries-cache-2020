/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x1cf9fe=_0x1311;function _0xb298(){const _0x295f63=['4112xPhpTu','add','12999822pLxUCs','CloudServices','init','exportWord','tokenUrl','config','ExportWord','pluginName','registerTokenUrl','6lRhlTC','_token','then','4wyuOVC','requires','47106jMfihx','173351bOEBuq','3147732xFxKsI','isOfficialPlugin','2013765RUIJRC','plugins','4046rDgcFP','commands','token','230tuqeMQ','286755MbztkZ','editor','get','isPremiumPlugin'];_0xb298=function(){return _0x295f63;};return _0xb298();}(function(_0x12ba8d,_0xa75301){const _0x584768=_0x1311,_0x2db46b=_0x12ba8d();while(!![]){try{const _0x46db85=parseInt(_0x584768(0x133))/0x1*(parseInt(_0x584768(0x12d))/0x2)+parseInt(_0x584768(0x13c))/0x3*(-parseInt(_0x584768(0x130))/0x4)+parseInt(_0x584768(0x136))/0x5+parseInt(_0x584768(0x134))/0x6+parseInt(_0x584768(0x138))/0x7*(parseInt(_0x584768(0x140))/0x8)+-parseInt(_0x584768(0x132))/0x9*(parseInt(_0x584768(0x13b))/0xa)+-parseInt(_0x584768(0x142))/0xb;if(_0x46db85===_0xa75301)break;else _0x2db46b['push'](_0x2db46b['shift']());}catch(_0x5a0b52){_0x2db46b['push'](_0x2db46b['shift']());}}}(_0xb298,0x54a7f));import{Plugin as _0x55ebf6}from'ckeditor5/src/core.js';import{Notification as _0x315048}from'ckeditor5/src/ui.js';import{ExportWordCommand as _0x3bb142}from'./exportwordcommand.js';function _0x1311(_0x19f516,_0x5b148a){const _0xb298da=_0xb298();return _0x1311=function(_0x13111b,_0x294bd0){_0x13111b=_0x13111b-0x12c;let _0x25582b=_0xb298da[_0x13111b];return _0x25582b;},_0x1311(_0x19f516,_0x5b148a);}import{ExportWordUI as _0x123f8a}from'./exportwordui.js';export class ExportWord extends _0x55ebf6{[_0x1cf9fe(0x12e)];static get[_0x1cf9fe(0x149)](){const _0x41fbe8=_0x1cf9fe;return _0x41fbe8(0x148);}static get[_0x1cf9fe(0x135)](){return!0x0;}static get[_0x1cf9fe(0x13f)](){return!0x0;}static get[_0x1cf9fe(0x131)](){const _0x25701e=_0x1cf9fe;return[_0x25701e(0x143),_0x315048,_0x123f8a];}[_0x1cf9fe(0x144)](){const _0xa012bf=_0x1cf9fe,_0x41c1a4=this[_0xa012bf(0x13d)],_0x3ab73c=_0x41c1a4[_0xa012bf(0x147)][_0xa012bf(0x13e)](_0xa012bf(0x145))||{};_0x41c1a4[_0xa012bf(0x139)][_0xa012bf(0x141)](_0xa012bf(0x145),new _0x3bb142(_0x41c1a4));const _0x2106b2=_0x41c1a4[_0xa012bf(0x137)][_0xa012bf(0x13e)](_0xa012bf(0x143));!0x1===_0x3ab73c[_0xa012bf(0x146)]?this[_0xa012bf(0x12e)]=null:_0x3ab73c[_0xa012bf(0x146)]?_0x2106b2[_0xa012bf(0x12c)](_0x3ab73c[_0xa012bf(0x146)])[_0xa012bf(0x12f)](_0x145b78=>{const _0x255eaa=_0xa012bf;this[_0x255eaa(0x12e)]=_0x145b78;}):this[_0xa012bf(0x12e)]=_0x2106b2[_0xa012bf(0x13a)];}}