/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module export-word/exportwordcommand
 * @publicApi
 */
import { Command, type Editor } from 'ckeditor5/src/core.js';
import type { ExportWordConfig } from './exportword.js';
/**
 * The export to Word command.
 *
 * It takes the editor's HTML and CSS rules from the document and sends them to the HTML to Word converter.
 * After processing, the converter will send back a Word file for download.
 */
export declare class ExportWordCommand extends Command {
    /**
     * A command state that indicates if the command is currently executing.
     *
     * @observable
     */
    isBusy: boolean;
    /**
     * @inheritDoc
     */
    constructor(editor: Editor);
    /**
     * @inheritDoc
     */
    refresh(): void;
    /**
     * @inheritDoc
     */
    execute(options?: ExportWordConfig): Promise<void>;
}
