/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module export-word/exportwordui
 */
import { Plugin } from 'ckeditor5/src/core.js';
/**
 * The export to Word UI feature.
 *
 * It introduces 'Export to Word' button in toolbar and menu bar.
 */
export declare class ExportWordUI extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "ExportWordUI";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    init(): void;
}
