/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module export-word
 */
export { ExportWord, type ExportWordConfig, type ExportWordConverterOptions, type ExportWordConverterFormatOption, type ExportWordConverterOrientationOption, type ExportWordConverterHeaderFooterOption, type ExportWordConverterCommentsOption, type ExportWordConverterSuggestionsOption, type ExportWordConverterOptionsV2, type ExportWordConverterDocumentOptionsV2, type ExportWordConverterMarginsOptionsV2, type ExportWordConverterHeaderFooterOptionsV2, type ExportWordConverterWatermarkV2, type ExportWordConverterExtraHttpHeaders, type ExportWordConverterExtraHttpHeadersHeader, type ExportWordConverterHeaderFooterItemOptionsV2, type ExportWordConverterOrientationOptionsV2, type ExportWordConverterFormatOptionsV2, type ExportWordConverterPredifinedFormatOptionsV2, type ExportWordConverterCustomFormatOptionsV2 } from './exportword.js';
export { ExportWordCommand } from './exportwordcommand.js';
import './augmentation.js';
