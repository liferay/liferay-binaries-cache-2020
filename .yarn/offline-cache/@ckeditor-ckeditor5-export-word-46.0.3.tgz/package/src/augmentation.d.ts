/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import type { ExportWordConfig, ExportWord, ExportWordCommand } from './index.js';
declare module '@ckeditor/ckeditor5-core' {
    interface EditorConfig {
        /**
         * The configuration of the {@link module:export-word/exportword~ExportWord export to Word feature}.
         *
         * Read more in {@link module:export-word/exportword~ExportWordConfig}.
         */
        exportWord?: ExportWordConfig;
    }
    interface PluginsMap {
        [ExportWord.pluginName]: ExportWord;
    }
    interface CommandsMap {
        exportWord: ExportWordCommand;
    }
}
