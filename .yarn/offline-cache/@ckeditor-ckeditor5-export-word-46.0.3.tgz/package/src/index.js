/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x4b79a6,_0x4c5372){var _0xe70391=_0x34da,_0x185eee=_0x4b79a6();while(!![]){try{var _0x5d3fad=parseInt(_0xe70391(0x19d))/0x1*(parseInt(_0xe70391(0x1a2))/0x2)+-parseInt(_0xe70391(0x1a4))/0x3*(-parseInt(_0xe70391(0x19e))/0x4)+parseInt(_0xe70391(0x19f))/0x5+parseInt(_0xe70391(0x1a1))/0x6+-parseInt(_0xe70391(0x1a0))/0x7+-parseInt(_0xe70391(0x1a3))/0x8*(-parseInt(_0xe70391(0x19c))/0x9)+-parseInt(_0xe70391(0x19b))/0xa;if(_0x5d3fad===_0x4c5372)break;else _0x185eee['push'](_0x185eee['shift']());}catch(_0x5a122f){_0x185eee['push'](_0x185eee['shift']());}}}(_0x2535,0xb63e5));function _0x34da(_0x13d0c0,_0x6cf700){var _0x25353f=_0x2535();return _0x34da=function(_0x34daf3,_0x5654ee){_0x34daf3=_0x34daf3-0x19b;var _0x249de4=_0x25353f[_0x34daf3];return _0x249de4;},_0x34da(_0x13d0c0,_0x6cf700);}export{ExportWord}from'./exportword.js';export{ExportWordCommand}from'./exportwordcommand.js';import'./augmentation.js';function _0x2535(){var _0x4ed5dd=['5794104nMNozm','2sveqwj','102440dwuILc','951blntAf','13719750qRlvLI','36daGJKj','1014583ELOMuh','7904hCyWAe','1455850IPiAUO','5814235DYOMgB'];_0x2535=function(){return _0x4ed5dd;};return _0x2535();}