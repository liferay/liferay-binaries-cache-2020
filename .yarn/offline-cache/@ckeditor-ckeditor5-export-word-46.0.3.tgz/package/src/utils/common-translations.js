/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
export function getTranslation(_0x2bf379,_0x343bf2){const t=_0x2bf379['t'];switch(_0x343bf2){case'Export\x20to\x20Word':return t('Export\x20to\x20Word');case'An\x20error\x20occurred\x20while\x20generating\x20the\x20Word\x20file.':return t('An\x20error\x20occurred\x20while\x20generating\x20the\x20Word\x20file.');case'Word\x20document\x20export\x20started':return t('Word\x20document\x20export\x20started');case'Word\x20document\x20export\x20failed':return t('Word\x20document\x20export\x20failed');case'Word\x20document\x20export\x20successful':return t('Word\x20document\x20export\x20successful');case'Exporting\x20Word\x20document':return t('Exporting\x20Word\x20document');default:return _0x343bf2;}}