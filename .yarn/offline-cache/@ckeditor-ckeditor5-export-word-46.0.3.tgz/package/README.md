CKEditor&nbsp;5 Export to Word feature
======================================

[![npm version](https://badge.fury.io/js/%40ckeditor%2Fckeditor5-export-word.svg)](https://www.npmjs.com/package/@ckeditor/ckeditor5-export-word)

This package contains an export to Word feature for CKEditor&nbsp;5. It allows you to generate a `.docx` file directly from the CKEditor&nbsp;5 WYSIWYG editor content.

When enabled, this feature sends the content of your editor together with the styles that are used to display it to the CKEditor Cloud Services HTML to Word converter service. The service then generates a `.docx` document that can be downloaded by the user. This allows you to print your content to the `.docx` format.

![A screencast showing generating a `.docx` file from CKEditor&nbsp;5 content thanks to the Word export feature](https://c.cksource.com/a/1/img/npm/ckeditor-5-word-export.gif)

This is a premium feature. Sign up for a [free non-commitment 14-day trial](https://portal.ckeditor.com/checkout?plan=free), or see: [https://ckeditor.com/pricing](https://ckeditor.com/pricing) for more information.

## Installation

This plugin is part of the `ckeditor5-premium-features` package. Install the whole package to use it.

```bash
npm install ckeditor5-premium-features
```

## Create free account

If you want to check full CKEditor&nbsp;5 capabilities, sign up for a [free non-commitment 14-day trial](https://portal.ckeditor.com/checkout?plan=free).

## Demo

Check out the [demo in the Export to Word feature](https://ckeditor.com/docs/ckeditor5/latest/features/converters/export-word.html#demo) guide.

## Documentation

See the [`@ckeditor/ckeditor5-export-word` package](https://ckeditor.com/docs/ckeditor5/latest/api/export-word.html) page in [CKEditor&nbsp;5 documentation](https://ckeditor.com/docs/ckeditor5/latest/) as well as the [Export to Word](https://ckeditor.com/docs/ckeditor5/latest/features/converters/export-word.html) feature guide.

## Getting support

CKEditor&nbsp;5 Export to Word feature comes with outstanding support from a dedicated team of customer care specialists, QA engineers and CKEditor&nbsp;5 developers. The team will gladly assist you in all aspects from setting up your account to integrating CKEditor&nbsp;5 Word export feature with your application.

As a licensed CKEditor&nbsp;5 Export to Word feature user you can report bugs and request features directly through the CKEditor Ecosystem customer dashboard.


## License

**CKEditor&nbsp;5 Export to Word** (https://ckeditor.com/ckeditor-5/)<br>
Copyright (c) 2003–2025, [CKSource Holding sp. z o.o.](https://cksource.com)  All rights reserved.

CKEditor&nbsp;5 Export to Word feature is licensed under a commercial license and is protected by copyright law. For more information, see: [https://ckeditor.com/pricing](https://ckeditor.com/pricing).

### Trademarks

**CKEditor** is a trademark of [CKSource Holding sp. z o.o.](https://cksource.com)  All other brand and product names are trademarks, registered trademarks or service marks of their respective holders.
