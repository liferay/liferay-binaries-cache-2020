/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x35e937=_0x4dd2;(function(_0x4777f7,_0x1af38f){const _0x28d0ca=_0x4dd2,_0x3041bf=_0x4777f7();while(!![]){try{const _0x138f04=-parseInt(_0x28d0ca(0x19c))/0x1+-parseInt(_0x28d0ca(0x1ac))/0x2+-parseInt(_0x28d0ca(0x18c))/0x3+-parseInt(_0x28d0ca(0x18b))/0x4+-parseInt(_0x28d0ca(0x1a1))/0x5*(-parseInt(_0x28d0ca(0x19a))/0x6)+parseInt(_0x28d0ca(0x1ab))/0x7+parseInt(_0x28d0ca(0x18d))/0x8*(parseInt(_0x28d0ca(0x1a0))/0x9);if(_0x138f04===_0x1af38f)break;else _0x3041bf['push'](_0x3041bf['shift']());}catch(_0xdf06b1){_0x3041bf['push'](_0x3041bf['shift']());}}}(_0x1bab,0xee558));import{View as _0x1f74fa}from'ckeditor5/src/ui.js';import{toUnit as _0x1063ad}from'ckeditor5/src/utils.js';function _0x4dd2(_0x288a95,_0x3dc712){const _0x1bab23=_0x1bab();return _0x4dd2=function(_0x4dd26c,_0x2f3705){_0x4dd26c=_0x4dd26c-0x188;let _0x4fa279=_0x1bab23[_0x4dd26c];return _0x4fa279;},_0x4dd2(_0x288a95,_0x3dc712);}import{createMutationObserver as _0x17f08a}from'../../utils/createmutationobserver.js';const Ot=/* #__PURE__ -- @preserve */
_0x1063ad('px');function _0x1bab(){const _0x2cec9f=['arrowup','detach','render','div','content','focus','presentation','bottom','_mutationObserver','clientHeight','attach','6sVZYcy','bindTemplate','1321831nQrCwf','_targetTop','isAnimationDisabled','element','37996623bXWYfI','2825995dffuEU','height','arrowdown','set','first','bind','ck-sidebar-item--no-animation','ck-sidebar-item','setTemplate','top','2706970sqvMPl','779526LFaDup','createCollection','clear','delegate','destroy','3226248DTGTUq','5038152OyiJDm','8sKSICm','updateHeight'];_0x1bab=function(){return _0x2cec9f;};return _0x1bab();}export class AnnotationsSidebarItemView extends _0x1f74fa{[_0x35e937(0x193)];[_0x35e937(0x19d)];[_0x35e937(0x197)];constructor(_0x5ad61a){const _0x419a77=_0x35e937;super(_0x5ad61a),this[_0x419a77(0x1a4)](_0x419a77(0x1aa),0x0),this[_0x419a77(0x1a4)](_0x419a77(0x1a2),0x0),this[_0x419a77(0x1a6)](_0x419a77(0x196))['to'](this,_0x419a77(0x1aa),this,_0x419a77(0x1a2),(_0x17af7b,_0x5f57c1)=>_0x17af7b+_0x5f57c1),this[_0x419a77(0x1a4)](_0x419a77(0x19e),!0x1),this[_0x419a77(0x197)]=_0x17f08a(()=>this[_0x419a77(0x18e)]()),this[_0x419a77(0x19d)]=null,this[_0x419a77(0x193)]=this[_0x419a77(0x1ad)](),this[_0x419a77(0x193)][_0x419a77(0x189)](_0x419a77(0x18f),_0x419a77(0x1a3))['to'](this);const _0x2e44ca=this[_0x419a77(0x19b)];this[_0x419a77(0x1a9)]({'tag':_0x419a77(0x192),'attributes':{'class':[_0x419a77(0x1a8),_0x2e44ca['to'](_0x419a77(0x19e),_0x145472=>_0x145472?_0x419a77(0x1a7):'')],'style':{'top':_0x2e44ca['to'](_0x419a77(0x1aa),_0x251d19=>Ot(_0x251d19))},'role':_0x419a77(0x195)},'children':this[_0x419a77(0x193)]});}[_0x35e937(0x191)](){const _0x190369=_0x35e937;super[_0x190369(0x191)](),this[_0x190369(0x197)][_0x190369(0x199)](this[_0x190369(0x19f)]);}[_0x35e937(0x194)](){const _0xcb91f6=_0x35e937;this[_0xcb91f6(0x193)][_0xcb91f6(0x1a5)]&&this[_0xcb91f6(0x193)][_0xcb91f6(0x1a5)][_0xcb91f6(0x194)]();}[_0x35e937(0x18e)](){const _0x5a8a2e=_0x35e937,_0x1b59f1=this[_0x5a8a2e(0x19f)][_0x5a8a2e(0x198)];_0x1b59f1&&(this[_0x5a8a2e(0x1a2)]=_0x1b59f1);}[_0x35e937(0x18a)](){const _0x7c3fbe=_0x35e937;this[_0x7c3fbe(0x193)][_0x7c3fbe(0x188)](),this[_0x7c3fbe(0x197)][_0x7c3fbe(0x190)](),super[_0x7c3fbe(0x18a)]();}}