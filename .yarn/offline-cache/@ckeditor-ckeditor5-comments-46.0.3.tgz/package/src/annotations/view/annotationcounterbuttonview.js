/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x1cc5(){const _0x3cd426=['_badge','setTemplate','1530700bJRRIR','add','extendTemplate','ck-annotation-counter','ck-annotation-counter__badge','set','bindTemplate','995373qPTmTn','isDirty','ck-annotation-counter__badge--edit-mode','ck-annotation-counter__badge--','656654RDZMCN','span','3cNmeOV','1868805vvZzEz','icon','children','toString','...','bind','1017527ZlXIsv','annotationType','1104528cpudUP','counterView','32sfzSny','number','550913EgUQXb'];_0x1cc5=function(){return _0x3cd426;};return _0x1cc5();}const _0x18fe60=_0x2073;function _0x2073(_0x141d50,_0x408e37){const _0x1cc56b=_0x1cc5();return _0x2073=function(_0x207389,_0x47a47e){_0x207389=_0x207389-0x1d6;let _0x3f4dd6=_0x1cc56b[_0x207389];return _0x3f4dd6;},_0x2073(_0x141d50,_0x408e37);}(function(_0x32708b,_0x3ec138){const _0x58455b=_0x2073,_0x27278c=_0x32708b();while(!![]){try{const _0x410f2e=parseInt(_0x58455b(0x1f2))/0x1+-parseInt(_0x58455b(0x1e3))/0x2+parseInt(_0x58455b(0x1e5))/0x3*(parseInt(_0x58455b(0x1d8))/0x4)+-parseInt(_0x58455b(0x1e6))/0x5+parseInt(_0x58455b(0x1ee))/0x6+-parseInt(_0x58455b(0x1ec))/0x7+parseInt(_0x58455b(0x1f0))/0x8*(parseInt(_0x58455b(0x1df))/0x9);if(_0x410f2e===_0x3ec138)break;else _0x27278c['push'](_0x27278c['shift']());}catch(_0x1a35dd){_0x27278c['push'](_0x27278c['shift']());}}}(_0x1cc5,0xadfa7));import{ButtonView as _0x2a5981,View as _0x2fdec4}from'ckeditor5/src/ui.js';import{IconAddComment as _0x3fe27b}from'ckeditor5/src/icons.js';export class AnnotationCounterButtonView extends _0x2a5981{[_0x18fe60(0x1ef)];constructor(_0x1e306c){const _0x3beae2=_0x18fe60;super(_0x1e306c);const _0x4760a7=this[_0x3beae2(0x1de)];this[_0x3beae2(0x1dd)](_0x3beae2(0x1e0),!0x1),this[_0x3beae2(0x1dd)](_0x3beae2(0x1f1),0x0),this[_0x3beae2(0x1eb)](_0x3beae2(0x1d6))['to'](this,_0x3beae2(0x1e0),this,_0x3beae2(0x1f1),(_0x496105,_0x66e240)=>_0x496105?_0x3beae2(0x1ea):_0x66e240[_0x3beae2(0x1e9)]()),this[_0x3beae2(0x1dd)](_0x3beae2(0x1ed),''),this[_0x3beae2(0x1e7)]=_0x3fe27b,this[_0x3beae2(0x1da)]({'attributes':{'class':[_0x3beae2(0x1db)]}}),this[_0x3beae2(0x1ef)]=new _0x2fdec4(),this[_0x3beae2(0x1ef)][_0x3beae2(0x1d7)]({'tag':_0x3beae2(0x1e4),'attributes':{'class':[_0x3beae2(0x1dc),_0x4760a7['to'](_0x3beae2(0x1ed),_0xe9c593=>_0x3beae2(0x1e2)+_0xe9c593),_0x4760a7['if'](_0x3beae2(0x1e0),_0x3beae2(0x1e1))]},'children':[{'text':_0x4760a7['to'](_0x3beae2(0x1d6))}]}),this[_0x3beae2(0x1e8)][_0x3beae2(0x1d9)](this[_0x3beae2(0x1ef)]);}}