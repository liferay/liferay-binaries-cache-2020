/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
export { Comments } from './comments.js';
export { CommentsOnly } from './commentsonly.js';
export { CommentsUI } from './comments/commentsui.js';
export { CommentsRepository, CommentThread, Comment, type CommentDataJSON, type CommentThreadContext, type CommentThreadDataJSON, type CommentsAdapter, type AddCommentThreadEventData, type CommentPermissionsConfig, type BaseCommentThread, type BaseComment, type BaseCommentData, type AddCommentThreadEvent, type CommentThreadData, type SubmitCommentThreadEvent, type UpdateCommentThreadEvent, type UpdateCommentThreadEventData, type ResolveCommentThreadEvent, type ResolveCommentThreadEventData, type ReopenCommentThreadEvent, type RemoveCommentThreadEvent, type AddCommentEvent, type CommentData, type CommentEventData, type UpdateCommentEvent, type UpdateCommentData, type UpdateCommentEventData, type RemoveCommentEvent } from './comments/commentsrepository.js';
export { CommentThreadController } from './comments/ui/commentthreadcontroller.js';
export { Annotation, type AnnotationEscapeEvent, type AnnotationTargetBase, type AnnotationTarget } from './annotations/annotation.js';
export { Annotations, type AnnotationOptions, type ActivateAnnotationEvent, type DeactivateAllAnnotationsEvent } from './annotations/annotations.js';
export { AnnotationCollection, bindAnnotationCollections, type AnnotationFocusEvent, type AnnotationBlurEvent } from './annotations/annotationcollection.js';
export { AnnotationsUIs, type AnnotationUI, type AnnotationsUI } from './annotations/annotationsuis.js';
export { EditorAnnotations } from './annotations/editorannotations.js';
export { InlineAnnotations } from './annotations/inlineannotations.js';
export { Sidebar } from './annotations/sidebar.js';
export { WideSidebar } from './annotations/widesidebar.js';
export { NarrowSidebar } from './annotations/narrowsidebar.js';
export { AnnotationView, type AnnotationMainView } from './annotations/view/annotationview.js';
export { AnnotationsSidebarItemView } from './annotations/view/sidebaritemview.js';
export { AnnotationsSidebarView } from './annotations/view/sidebarview.js';
export { BaseCommentView, type UIAddCommentEvent, type UIUpdateCommentEvent, type UIRemoveCommentEvent } from './comments/ui/view/basecommentview.js';
export { BaseCommentThreadView, type UISubmitCommentThreadEvent, type UIRemoveCommentThreadEvent, type UIResolveCommentThreadEvent } from './comments/ui/view/basecommentthreadview.js';
export { CommentsListView } from './comments/ui/view/commentslistview.js';
export { CommentView } from './comments/ui/view/commentview.js';
export { CommentThreadView } from './comments/ui/view/commentthreadview.js';
export { CommentThreadInputView } from './comments/ui/view/commentthreadinputview.js';
export { AddCommentThreadCommand } from './comments/addcommentthreadcommand.js';
export { CommentsArchive } from './comments/commentsarchive.js';
export { CommentsArchiveUI } from './comments/commentsarchiveui.js';
export type { CommentsConfig, AnnotationsSidebarConfig, CommentsClipboardCopyConfig, CommentThreadConfig, CommentViewConfig } from './config.js';
export { CommentsEditing } from './comments/commentsediting.js';
export { AnnotationCounterButtonView } from './annotations/view/annotationcounterbuttonview.js';
import './augmentation.js';
