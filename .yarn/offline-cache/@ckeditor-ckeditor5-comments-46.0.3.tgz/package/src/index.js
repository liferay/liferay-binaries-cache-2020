/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x1ed9c6,_0xd235ff){var _0x3cd760=_0x546a,_0x587754=_0x1ed9c6();while(!![]){try{var _0xeacac3=-parseInt(_0x3cd760(0x170))/0x1+parseInt(_0x3cd760(0x172))/0x2*(-parseInt(_0x3cd760(0x177))/0x3)+parseInt(_0x3cd760(0x171))/0x4*(parseInt(_0x3cd760(0x176))/0x5)+-parseInt(_0x3cd760(0x16c))/0x6*(-parseInt(_0x3cd760(0x16d))/0x7)+-parseInt(_0x3cd760(0x174))/0x8*(-parseInt(_0x3cd760(0x173))/0x9)+-parseInt(_0x3cd760(0x16b))/0xa*(parseInt(_0x3cd760(0x16e))/0xb)+-parseInt(_0x3cd760(0x16f))/0xc*(-parseInt(_0x3cd760(0x175))/0xd);if(_0xeacac3===_0xd235ff)break;else _0x587754['push'](_0x587754['shift']());}catch(_0x26ed2b){_0x587754['push'](_0x587754['shift']());}}}(_0x50a4,0xdad92));export{Comments}from'./comments.js';export{CommentsOnly}from'./commentsonly.js';export{CommentsUI}from'./comments/commentsui.js';export{CommentsRepository,CommentThread,Comment}from'./comments/commentsrepository.js';export{CommentThreadController}from'./comments/ui/commentthreadcontroller.js';export{Annotation}from'./annotations/annotation.js';export{Annotations}from'./annotations/annotations.js';export{AnnotationCollection,bindAnnotationCollections}from'./annotations/annotationcollection.js';export{AnnotationsUIs}from'./annotations/annotationsuis.js';export{EditorAnnotations}from'./annotations/editorannotations.js';export{InlineAnnotations}from'./annotations/inlineannotations.js';export{Sidebar}from'./annotations/sidebar.js';export{WideSidebar}from'./annotations/widesidebar.js';export{NarrowSidebar}from'./annotations/narrowsidebar.js';export{AnnotationView}from'./annotations/view/annotationview.js';function _0x50a4(){var _0xc2c6d5=['65thWDyC','100qyAxWY','3372jdJKzv','11500ysLrxh','4998252yjGFHe','14woUvXa','11759VTmRuK','600876MGPQvy','730013wqrPJI','202668xFAIVd','362vWYzay','54HuKCXn','172560CEqAKI'];_0x50a4=function(){return _0xc2c6d5;};return _0x50a4();}export{AnnotationsSidebarItemView}from'./annotations/view/sidebaritemview.js';export{AnnotationsSidebarView}from'./annotations/view/sidebarview.js';export{BaseCommentView}from'./comments/ui/view/basecommentview.js';function _0x546a(_0x21ec92,_0x4b775d){var _0x50a4f8=_0x50a4();return _0x546a=function(_0x546a16,_0xb5d534){_0x546a16=_0x546a16-0x16b;var _0x1e79db=_0x50a4f8[_0x546a16];return _0x1e79db;},_0x546a(_0x21ec92,_0x4b775d);}export{BaseCommentThreadView}from'./comments/ui/view/basecommentthreadview.js';export{CommentsListView}from'./comments/ui/view/commentslistview.js';export{CommentView}from'./comments/ui/view/commentview.js';export{CommentThreadView}from'./comments/ui/view/commentthreadview.js';export{CommentThreadInputView}from'./comments/ui/view/commentthreadinputview.js';export{AddCommentThreadCommand}from'./comments/addcommentthreadcommand.js';export{CommentsArchive}from'./comments/commentsarchive.js';export{CommentsArchiveUI}from'./comments/commentsarchiveui.js';export{CommentsEditing}from'./comments/commentsediting.js';export{AnnotationCounterButtonView}from'./annotations/view/annotationcounterbuttonview.js';import'./augmentation.js';