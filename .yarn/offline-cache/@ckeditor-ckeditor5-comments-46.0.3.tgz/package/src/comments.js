/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x3f67(_0x276d73,_0x2cfb5f){var _0x2eab7=_0x2eab();return _0x3f67=function(_0x3f6768,_0x3252ad){_0x3f6768=_0x3f6768-0x16d;var _0x27eb33=_0x2eab7[_0x3f6768];return _0x27eb33;},_0x3f67(_0x276d73,_0x2cfb5f);}var _0x58c0a0=_0x3f67;(function(_0x5732bd,_0x2f4b17){var _0x1b00fe=_0x3f67,_0xadc3aa=_0x5732bd();while(!![]){try{var _0x41a5b9=-parseInt(_0x1b00fe(0x16d))/0x1+-parseInt(_0x1b00fe(0x174))/0x2+parseInt(_0x1b00fe(0x17c))/0x3*(-parseInt(_0x1b00fe(0x172))/0x4)+parseInt(_0x1b00fe(0x178))/0x5+-parseInt(_0x1b00fe(0x170))/0x6*(-parseInt(_0x1b00fe(0x17a))/0x7)+-parseInt(_0x1b00fe(0x177))/0x8*(parseInt(_0x1b00fe(0x171))/0x9)+-parseInt(_0x1b00fe(0x176))/0xa*(-parseInt(_0x1b00fe(0x175))/0xb);if(_0x41a5b9===_0x2f4b17)break;else _0xadc3aa['push'](_0xadc3aa['shift']());}catch(_0xdf9578){_0xadc3aa['push'](_0xadc3aa['shift']());}}}(_0x2eab,0x8a04e));import{Plugin as _0x399166}from'ckeditor5/src/core.js';import{CommentsRepository as _0x9e8b9c}from'./comments/commentsrepository.js';import{CommentsEditing as _0xb2606f}from'./comments/commentsediting.js';import{CommentsUI as _0x35aa01}from'./comments/commentsui.js';import{CommentsOnly as _0x19ac18}from'./commentsonly.js';import{WideSidebar as _0x4c17d6}from'./annotations/widesidebar.js';import{NarrowSidebar as _0x49085d}from'./annotations/narrowsidebar.js';import{InlineAnnotations as _0x3c849c}from'./annotations/inlineannotations.js';import{CommentsArchiveUI as _0x49c046}from'./comments/commentsarchiveui.js';import{CommentsArchive as _0x44df18}from'./comments/commentsarchive.js';export class Comments extends _0x399166{static get[_0x58c0a0(0x16e)](){return[_0x9e8b9c,_0xb2606f,_0x35aa01,_0x44df18,_0x49c046,_0x19ac18,_0x4c17d6,_0x49085d,_0x3c849c];}static get[_0x58c0a0(0x173)](){var _0x8bca7f=_0x58c0a0;return _0x8bca7f(0x16f);}static get[_0x58c0a0(0x179)](){return!0x0;}static get[_0x58c0a0(0x17b)](){return!0x0;}}function _0x2eab(){var _0x444b6d=['4472501XwUeks','70CtcyTO','356568cXNFza','1308890jCzKzu','isOfficialPlugin','1071OzUmLc','isPremiumPlugin','174006bZwkgj','1029397cJraHt','requires','Comments','17256gJNkQg','45hiTulU','56SEyVgO','pluginName','1836674CknWlA'];_0x2eab=function(){return _0x444b6d;};return _0x2eab();}