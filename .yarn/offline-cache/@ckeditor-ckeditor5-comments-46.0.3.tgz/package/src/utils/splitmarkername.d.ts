/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * Returns marker name split to group and id.
 */
export declare function splitMarkerName(name: string): {
    group: string;
    id: string;
    part: string;
};
