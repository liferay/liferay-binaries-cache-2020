/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x232f(_0x3bf534,_0xf2b0aa){const _0x467e27=_0x467e();return _0x232f=function(_0x232fb4,_0x519bb5){_0x232fb4=_0x232fb4-0x15d;let _0x1d2cbf=_0x467e27[_0x232fb4];return _0x1d2cbf;},_0x232f(_0x3bf534,_0xf2b0aa);}function _0x467e(){const _0x2e8559=['117unMjod','111860POzphm','455888cRWcGq','589479WPhqVF','10Nrwntr','7thLxuY','162388meMIXd','2246394rdeljk','136hXscvG','split','696731RSgtUz','887502lkkJBS'];_0x467e=function(){return _0x2e8559;};return _0x467e();}(function(_0x5ddb74,_0x2155ee){const _0x2669e1=_0x232f,_0x85f01e=_0x5ddb74();while(!![]){try{const _0x54b92f=parseInt(_0x2669e1(0x163))/0x1+-parseInt(_0x2669e1(0x15f))/0x2+parseInt(_0x2669e1(0x164))/0x3+parseInt(_0x2669e1(0x161))/0x4*(parseInt(_0x2669e1(0x166))/0x5)+parseInt(_0x2669e1(0x160))/0x6*(-parseInt(_0x2669e1(0x15e))/0x7)+-parseInt(_0x2669e1(0x167))/0x8*(parseInt(_0x2669e1(0x165))/0x9)+parseInt(_0x2669e1(0x15d))/0xa*(-parseInt(_0x2669e1(0x168))/0xb);if(_0x54b92f===_0x2155ee)break;else _0x85f01e['push'](_0x85f01e['shift']());}catch(_0x244b34){_0x85f01e['push'](_0x85f01e['shift']());}}}(_0x467e,0x7adad));export function splitMarkerName(_0x247b7a){const _0x5c72df=_0x232f,_0xfe90c=_0x247b7a[_0x5c72df(0x162)](':');return{'group':_0xfe90c[0x0],'id':_0xfe90c[0x1],'part':_0xfe90c[0x2]};}