/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x23df(_0x2c705c,_0x2d3dad){const _0x404f97=_0x404f();return _0x23df=function(_0x23df86,_0x361808){_0x23df86=_0x23df86-0x160;let _0x338d3e=_0x404f97[_0x23df86];return _0x338d3e;},_0x23df(_0x2c705c,_0x2d3dad);}(function(_0x352df6,_0x52d8fa){const _0x548333=_0x23df,_0x1f3373=_0x352df6();while(!![]){try{const _0x2588a5=-parseInt(_0x548333(0x173))/0x1*(-parseInt(_0x548333(0x170))/0x2)+-parseInt(_0x548333(0x16e))/0x3*(-parseInt(_0x548333(0x160))/0x4)+-parseInt(_0x548333(0x164))/0x5*(-parseInt(_0x548333(0x169))/0x6)+-parseInt(_0x548333(0x168))/0x7+-parseInt(_0x548333(0x165))/0x8+parseInt(_0x548333(0x161))/0x9*(-parseInt(_0x548333(0x16b))/0xa)+parseInt(_0x548333(0x16a))/0xb;if(_0x2588a5===_0x52d8fa)break;else _0x1f3373['push'](_0x1f3373['shift']());}catch(_0x3826e0){_0x1f3373['push'](_0x1f3373['shift']());}}}(_0x404f,0x91a64));import{throttle as _0x42dc66}from'es-toolkit/compat';export function createMutationObserver(_0x1f28fa){const _0x4b843e=_0x42dc66(_0x1f28fa,0x1e),_0x93c711=new MutationObserver(_0x51a714=>{const _0x5cc328=_0x23df;for(const _0x565007 of _0x51a714)(_0x5cc328(0x171)==_0x565007[_0x5cc328(0x16d)]&&_0x5cc328(0x166)==_0x565007[_0x5cc328(0x162)]||_0x5cc328(0x167)==_0x565007[_0x5cc328(0x16d)]||_0x5cc328(0x163)==_0x565007[_0x5cc328(0x16d)])&&_0x4b843e();});return{'attach'(_0x2d3747){const _0x3d46b7=_0x23df;_0x93c711[_0x3d46b7(0x16c)](_0x2d3747,{'attributes':!0x0,'childList':!0x0,'subtree':!0x0,'characterData':!0x0});},'detach'(){const _0x52883b=_0x23df;_0x93c711[_0x52883b(0x172)](),_0x4b843e[_0x52883b(0x16f)]();}};}function _0x404f(){const _0xf17d14=['28660ZLUJjq','1778920fbplAn','class','childList','6847491bnGDLE','60AmUYIt','24175580NvNzep','5500540SNCQQe','observe','type','12oxJTVv','cancel','129652cqEZqj','attributes','disconnect','7lEfnVg','188384tqLxuH','18kLCron','attributeName','characterData'];_0x404f=function(){return _0xf17d14;};return _0x404f();}