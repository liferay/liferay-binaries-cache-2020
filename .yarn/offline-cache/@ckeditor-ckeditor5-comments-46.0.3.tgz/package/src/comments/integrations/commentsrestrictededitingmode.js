/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0xe313(){const _0x105b4c=['afterInit','editor','1854jYgVRT','enableCommand','9352912OeoRcx','10zLWlDO','get','9391765zcYtKE','153QAZfHs','has','74176fkMgDp','48086214CizNvk','plugins','938uIwfWR','addCommentThread','7kmCBqH','929628kUJgJo','14462118Fntboq','RestrictedEditingModeEditing'];_0xe313=function(){return _0x105b4c;};return _0xe313();}const _0x317f09=_0x35e3;function _0x35e3(_0x312d4e,_0x55da05){const _0xe3137=_0xe313();return _0x35e3=function(_0x35e300,_0x3507d5){_0x35e300=_0x35e300-0x1b6;let _0x49b56a=_0xe3137[_0x35e300];return _0x49b56a;},_0x35e3(_0x312d4e,_0x55da05);}(function(_0x557586,_0x24a889){const _0x32d263=_0x35e3,_0x3538c5=_0x557586();while(!![]){try{const _0x287d41=-parseInt(_0x32d263(0x1b8))/0x1*(parseInt(_0x32d263(0x1c0))/0x2)+parseInt(_0x32d263(0x1c6))/0x3*(-parseInt(_0x32d263(0x1c8))/0x4)+-parseInt(_0x32d263(0x1c5))/0x5+parseInt(_0x32d263(0x1bb))/0x6*(-parseInt(_0x32d263(0x1ba))/0x7)+-parseInt(_0x32d263(0x1c2))/0x8+parseInt(_0x32d263(0x1bc))/0x9+parseInt(_0x32d263(0x1c3))/0xa*(parseInt(_0x32d263(0x1b6))/0xb);if(_0x287d41===_0x24a889)break;else _0x3538c5['push'](_0x3538c5['shift']());}catch(_0x5aa384){_0x3538c5['push'](_0x3538c5['shift']());}}}(_0xe313,0xea8bd));import{Plugin as _0x480999}from'ckeditor5/src/core.js';export class CommentsRestrictedEditingMode extends _0x480999{[_0x317f09(0x1be)](){const _0x5cd1d1=_0x317f09,_0x2bbf69=this[_0x5cd1d1(0x1bf)];if(!_0x2bbf69[_0x5cd1d1(0x1b7)][_0x5cd1d1(0x1c7)](_0x5cd1d1(0x1bd)))return;_0x2bbf69[_0x5cd1d1(0x1b7)][_0x5cd1d1(0x1c4)](_0x5cd1d1(0x1bd))[_0x5cd1d1(0x1c1)](_0x5cd1d1(0x1b9));}}