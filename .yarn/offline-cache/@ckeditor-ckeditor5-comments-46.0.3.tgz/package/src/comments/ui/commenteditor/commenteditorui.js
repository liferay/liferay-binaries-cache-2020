/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x4fde94=_0xf1bf;(function(_0x585f39,_0x13518c){const _0x444c31=_0xf1bf,_0x3db54e=_0x585f39();while(!![]){try{const _0x4cc3a0=parseInt(_0x444c31(0x188))/0x1*(parseInt(_0x444c31(0x183))/0x2)+-parseInt(_0x444c31(0x17b))/0x3+parseInt(_0x444c31(0x16d))/0x4+parseInt(_0x444c31(0x178))/0x5*(parseInt(_0x444c31(0x175))/0x6)+-parseInt(_0x444c31(0x179))/0x7*(-parseInt(_0x444c31(0x177))/0x8)+-parseInt(_0x444c31(0x176))/0x9+-parseInt(_0x444c31(0x185))/0xa;if(_0x4cc3a0===_0x13518c)break;else _0x3db54e['push'](_0x3db54e['shift']());}catch(_0x1334df){_0x3db54e['push'](_0x3db54e['shift']());}}}(_0x2ebd,0x75a99));import{EditorUI as _0x33e82e}from'ckeditor5/src/ui.js';import{CommentEditorUIView as _0x3fd1a6}from'./commenteditoruiview.js';function _0xf1bf(_0x289ce4,_0x439c50){const _0x2ebd4d=_0x2ebd();return _0xf1bf=function(_0xf1bf2d,_0x671da0){_0xf1bf2d=_0xf1bf2d-0x16d;let _0x501c85=_0x2ebd4d[_0xf1bf2d];return _0x501c85;},_0xf1bf(_0x289ce4,_0x439c50);}function _0x2ebd(){const _0xf1b288=['view','343342SiDfTX','isFocused','destroy','2118168LVITMA','render','bind','getRoot','element','focusTracker','ready','editor','18984fVhRsk','7724025lxgtOS','2151232FdNeGw','1115joRTHo','21VdyzHV','document','939504BosOnw','init','name','editable','locale','fire','editing','attachDomRoot','4wvosfi','rootName','10751720lQfxRc','setEditableElement'];_0x2ebd=function(){return _0xf1b288;};return _0x2ebd();}export class CommentEditorUI extends _0x33e82e{[_0x4fde94(0x187)];constructor(_0x22e8a0){const _0x41381b=_0x4fde94;super(_0x22e8a0),this[_0x41381b(0x187)]=new _0x3fd1a6(_0x22e8a0[_0x41381b(0x17f)],_0x22e8a0[_0x41381b(0x181)][_0x41381b(0x187)]);}get[_0x4fde94(0x171)](){const _0x26bacc=_0x4fde94;return this[_0x26bacc(0x187)][_0x26bacc(0x171)];}[_0x4fde94(0x17c)](){const _0x5b7b52=_0x4fde94,_0x2bad53=this[_0x5b7b52(0x174)][_0x5b7b52(0x181)][_0x5b7b52(0x187)],_0x1220c=this[_0x5b7b52(0x187)][_0x5b7b52(0x17e)],_0x39ee5f=_0x2bad53[_0x5b7b52(0x17a)][_0x5b7b52(0x170)]();_0x1220c[_0x5b7b52(0x17d)]=_0x39ee5f[_0x5b7b52(0x184)],this[_0x5b7b52(0x187)][_0x5b7b52(0x16e)]();const _0x1b556c=_0x1220c[_0x5b7b52(0x171)];this[_0x5b7b52(0x186)](_0x1220c[_0x5b7b52(0x17d)],_0x1b556c),this[_0x5b7b52(0x187)][_0x5b7b52(0x17e)][_0x5b7b52(0x16f)](_0x5b7b52(0x189))['to'](this[_0x5b7b52(0x172)]),_0x2bad53[_0x5b7b52(0x182)](_0x1b556c),this[_0x5b7b52(0x180)](_0x5b7b52(0x173));}[_0x4fde94(0x18a)](){const _0x3e09c0=_0x4fde94;super[_0x3e09c0(0x18a)](),this[_0x3e09c0(0x187)][_0x3e09c0(0x18a)]();}}