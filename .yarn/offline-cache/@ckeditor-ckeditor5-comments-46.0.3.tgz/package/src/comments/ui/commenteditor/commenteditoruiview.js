/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x543d2c=_0x1a1d;(function(_0x3f46ee,_0x1992d8){const _0x479672=_0x1a1d,_0x4f6b8e=_0x3f46ee();while(!![]){try{const _0x2493da=parseInt(_0x479672(0xf6))/0x1*(parseInt(_0x479672(0xf8))/0x2)+-parseInt(_0x479672(0xf1))/0x3+parseInt(_0x479672(0xfd))/0x4*(-parseInt(_0x479672(0xf3))/0x5)+-parseInt(_0x479672(0xf5))/0x6*(parseInt(_0x479672(0x103))/0x7)+parseInt(_0x479672(0xf0))/0x8*(parseInt(_0x479672(0x104))/0x9)+-parseInt(_0x479672(0xe7))/0xa*(parseInt(_0x479672(0xf4))/0xb)+-parseInt(_0x479672(0xf7))/0xc*(-parseInt(_0x479672(0xef))/0xd);if(_0x2493da===_0x1992d8)break;else _0x4f6b8e['push'](_0x4f6b8e['shift']());}catch(_0x4f43e0){_0x4f6b8e['push'](_0x4f6b8e['shift']());}}}(_0x283b,0xaac85));import{InlineEditableUIView as _0x4b358b,EditorUIView as _0x25f202}from'ckeditor5/src/ui.js';import{uid as _0x35540d}from'ckeditor5/src/utils.js';function _0x1a1d(_0xe87e7f,_0x3212fe){const _0x283bb9=_0x283b();return _0x1a1d=function(_0x1a1d06,_0x59ce0e){_0x1a1d06=_0x1a1d06-0xe5;let _0x4a38da=_0x283bb9[_0x1a1d06];return _0x4a38da;},_0x1a1d(_0xe87e7f,_0x3212fe);}import{getTranslation as _0x2cb434}from'../../../utils/common-translations.js';export class CommentEditorUIView extends _0x25f202{[_0x543d2c(0xfc)];[_0x543d2c(0xe9)];constructor(_0x5b4dba,_0x4616f3){const _0x39101e=_0x543d2c;super(_0x5b4dba);const _0x1a1fb7=_0x35540d();this[_0x39101e(0xfc)]=this[_0x39101e(0xeb)](),this[_0x39101e(0xe9)]=new _0x4b358b(_0x5b4dba,_0x4616f3,void 0x0,{'label':()=>_0x2cb434(_0x5b4dba,_0x39101e(0xe8))}),this[_0x39101e(0xee)]({'tag':_0x39101e(0x101),'attributes':{'class':[_0x39101e(0xf9),_0x39101e(0xea),_0x39101e(0xe6),_0x39101e(0xfe)],'dir':_0x5b4dba[_0x39101e(0x100)],'lang':_0x5b4dba[_0x39101e(0xe5)],'aria-labelledby':_0x39101e(0xff)+_0x1a1fb7},'children':[{'tag':_0x39101e(0x101),'attributes':{'class':_0x39101e(0xec),'role':_0x39101e(0xfb)},'children':this[_0x39101e(0xfc)]}]});}[_0x543d2c(0xfa)](){const _0x539abb=_0x543d2c;super[_0x539abb(0xfa)](),this[_0x539abb(0xfc)][_0x539abb(0x102)](this[_0x539abb(0xe9)]);}[_0x543d2c(0xed)](){const _0x27b2ca=_0x543d2c;this[_0x27b2ca(0xe9)][_0x27b2ca(0xf2)][_0x27b2ca(0xed)]();}}function _0x283b(){const _0x2f027e=['Comment\x20editor','editable','ck-editor','createCollection','ck-editor__main','focus','setTemplate','15834XZYPTB','8VDmOqP','3795144YSipgK','element','4038270zaubEj','902lnEvyJ','90sQPBkt','594410YImIqX','17604FFPQpd','4paZJJs','ck-reset','render','presentation','main','4fvUumE','ck-comment__input','cke-editor__aria-label_','uiLanguageDirection','div','add','406938zeXotx','11411541nRQZUw','uiLanguage','ck-rounded-corners','73090iUYkWv'];_0x283b=function(){return _0x2f027e;};return _0x283b();}