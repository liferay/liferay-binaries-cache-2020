/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x41c342=_0x2a84;function _0x2a84(_0x27cb2b,_0x58ee2a){var _0x71eed8=_0x71ee();return _0x2a84=function(_0x2a84a1,_0x50e7e8){_0x2a84a1=_0x2a84a1-0x127;var _0x50dcab=_0x71eed8[_0x2a84a1];return _0x50dcab;},_0x2a84(_0x27cb2b,_0x58ee2a);}(function(_0x3408dd,_0x4e5e71){var _0x5c43d9=_0x2a84,_0x418f0a=_0x3408dd();while(!![]){try{var _0x53c495=parseInt(_0x5c43d9(0x133))/0x1*(parseInt(_0x5c43d9(0x128))/0x2)+-parseInt(_0x5c43d9(0x132))/0x3+-parseInt(_0x5c43d9(0x12a))/0x4+parseInt(_0x5c43d9(0x127))/0x5*(parseInt(_0x5c43d9(0x12d))/0x6)+-parseInt(_0x5c43d9(0x131))/0x7+-parseInt(_0x5c43d9(0x139))/0x8+parseInt(_0x5c43d9(0x129))/0x9;if(_0x53c495===_0x4e5e71)break;else _0x418f0a['push'](_0x418f0a['shift']());}catch(_0x1f340e){_0x418f0a['push'](_0x418f0a['shift']());}}}(_0x71ee,0xd123a));function _0x71ee(){var _0xd6f481=['25rcweIi','348532vhSdsa','23886594TeQJQd','3435788lwBCEl','div','ck-content','1240962WErgYV','setTemplate','ck-comment__content','render','7415604lhvIgk','5021853ZKYrNK','6ZWskol','ck-annotation__content','element','innerHTML','set','change:content','2279144jkUjdH','content'];_0x71ee=function(){return _0xd6f481;};return _0x71ee();}import{View as _0x33b2dc}from'ckeditor5/src/ui.js';export class CommentContentView extends _0x33b2dc{constructor(_0x1ba0ae){var _0x21c59f=_0x2a84;super(_0x1ba0ae),this[_0x21c59f(0x137)](_0x21c59f(0x13a),''),this[_0x21c59f(0x12e)]({'tag':_0x21c59f(0x12b),'attributes':{'class':[_0x21c59f(0x12c),_0x21c59f(0x12f),_0x21c59f(0x134)]}});}[_0x41c342(0x130)](){var _0x3bbb00=_0x41c342;super[_0x3bbb00(0x130)](),this['on'](_0x3bbb00(0x138),(_0x20fa39,_0x43d19a,_0x2444ff)=>{var _0x4a6a78=_0x3bbb00;this[_0x4a6a78(0x135)][_0x4a6a78(0x136)]=_0x2444ff;}),this[_0x3bbb00(0x135)][_0x3bbb00(0x136)]=this[_0x3bbb00(0x13a)];}}