/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0xc733(){const _0x25e0d3=['7cEaipg','THREAD_CONTEXT_LABEL','bindTemplate','focus','3200AJQZMu','33837Ibbdfk','9SQOuVs','contextValue','span','setTemplate','855282mjHpxy','10lOCLdb','754264ULvqYM','ck-context__value','element','1715850aRgNiX','set','1280wUiMEu','1816441qzzihc','425472lmpKku'];_0xc733=function(){return _0x25e0d3;};return _0xc733();}function _0x5566(_0x1d3835,_0x70735b){const _0xc73392=_0xc733();return _0x5566=function(_0x5566b1,_0x164c1e){_0x5566b1=_0x5566b1-0x136;let _0x3be4ce=_0xc73392[_0x5566b1];return _0x3be4ce;},_0x5566(_0x1d3835,_0x70735b);}const _0x54806b=_0x5566;(function(_0x1881a5,_0x5f19f8){const _0x2adb03=_0x5566,_0x24391c=_0x1881a5();while(!![]){try{const _0x53259f=parseInt(_0x2adb03(0x138))/0x1*(parseInt(_0x2adb03(0x13e))/0x2)+-parseInt(_0x2adb03(0x146))/0x3+parseInt(_0x2adb03(0x137))/0x4*(parseInt(_0x2adb03(0x144))/0x5)+-parseInt(_0x2adb03(0x13d))/0x6*(-parseInt(_0x2adb03(0x147))/0x7)+-parseInt(_0x2adb03(0x13f))/0x8*(-parseInt(_0x2adb03(0x139))/0x9)+-parseInt(_0x2adb03(0x142))/0xa+-parseInt(_0x2adb03(0x145))/0xb;if(_0x53259f===_0x5f19f8)break;else _0x24391c['push'](_0x24391c['shift']());}catch(_0x1d04de){_0x24391c['push'](_0x24391c['shift']());}}}(_0xc733,0x204b3));import{View as _0x52d3df}from'ckeditor5/src/ui.js';import{getTranslation as _0x950bb3}from'../../../utils/common-translations.js';export class CommentThreadHeaderContextView extends _0x52d3df{constructor(_0x2b6865){const _0x3bdfbd=_0x5566;super(_0x2b6865);const _0x25fec0=this[_0x3bdfbd(0x149)];this[_0x3bdfbd(0x143)](_0x3bdfbd(0x13a),''),this[_0x3bdfbd(0x13c)]({'tag':_0x3bdfbd(0x13b),'attributes':{'class':['ck',_0x3bdfbd(0x140)],'aria-label':_0x25fec0['to'](_0x3bdfbd(0x13a),_0x501cef=>_0x950bb3(_0x2b6865,_0x3bdfbd(0x148),_0x501cef)),'tabindex':-0x1},'children':[{'text':_0x25fec0['to'](_0x3bdfbd(0x13a))}]});}[_0x54806b(0x136)](){const _0x517de7=_0x54806b;this[_0x517de7(0x141)][_0x517de7(0x136)]();}}