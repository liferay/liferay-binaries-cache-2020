/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x5ee7ba,_0x4e051e){const _0x11f451=_0xc020,_0x1707db=_0x5ee7ba();while(!![]){try{const _0x525ea9=parseInt(_0x11f451(0x163))/0x1+parseInt(_0x11f451(0x158))/0x2+parseInt(_0x11f451(0x155))/0x3+-parseInt(_0x11f451(0x15d))/0x4+parseInt(_0x11f451(0x15e))/0x5*(-parseInt(_0x11f451(0x157))/0x6)+-parseInt(_0x11f451(0x162))/0x7*(parseInt(_0x11f451(0x15b))/0x8)+-parseInt(_0x11f451(0x156))/0x9;if(_0x525ea9===_0x4e051e)break;else _0x1707db['push'](_0x1707db['shift']());}catch(_0x429319){_0x1707db['push'](_0x1707db['shift']());}}}(_0x1aa3,0xeafb9));function _0xc020(_0x263a57,_0x34a37e){const _0x1aa3d9=_0x1aa3();return _0xc020=function(_0xc0205f,_0x24021b){_0xc0205f=_0xc0205f-0x155;let _0x3e5299=_0x1aa3d9[_0xc0205f];return _0x3e5299;},_0xc020(_0x263a57,_0x34a37e);}import{View as _0x283203}from'ckeditor5/src/ui.js';function _0x1aa3(){const _0x311f19=['count','1474109YdLHLf','1277735MuHxMS','2541858Qlfuin','8388279MVgFrz','1268916ZXUoCc','3440850xszEFL','set','setTemplate','40NesYnq','bindTemplate','2746020bbHzNo','5QmFplF','ck-thread__comment-count','NUMBER_OF_COMMENTS'];_0x1aa3=function(){return _0x311f19;};return _0x1aa3();}import{getTranslation as _0xce4624}from'../../../utils/common-translations.js';export class CollapsedCommentsView extends _0x283203{constructor(_0x54200b){const _0x4c663f=_0xc020;super(_0x54200b);const _0x38163a=this[_0x4c663f(0x15c)];this[_0x4c663f(0x159)](_0x4c663f(0x161),void 0x0),this[_0x4c663f(0x15a)]({'tag':'li','attributes':{'class':_0x4c663f(0x15f)},'children':[{'text':_0x38163a['to'](_0x4c663f(0x161),_0x525a29=>_0xce4624(_0x54200b,_0x4c663f(0x160),_0x525a29))}]});}}