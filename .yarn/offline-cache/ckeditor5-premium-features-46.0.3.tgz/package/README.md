CKEditor&nbsp;5 Premium features
================================

[![npm version](https://badge.fury.io/js/ckeditor5-premium-features.svg)](https://www.npmjs.com/package/ckeditor5-premium-features)

This package contains all official premium features available for CKEditor&nbsp;5. Sign up for a [free non-commitment 14-day trial](https://portal.ckeditor.com/checkout?plan=free), or see: [https://ckeditor.com/pricing](https://ckeditor.com/pricing) for more information.

## Installation

This plugin is part of the `ckeditor5-premium-features` package. Install the whole package to use it.

```bash
npm install ckeditor5-premium-features
```

## Create free account

If you want to check full CKEditor&nbsp;5 capabilities, sign up for a [free non-commitment 14-day trial](https://portal.ckeditor.com/checkout?plan=free).

## Documentation

See the [CKEditor&nbsp;5 documentation](https://ckeditor.com/docs/ckeditor5/latest/) for an installation guide.

## Getting support

CKEditor&nbsp;5 Premium Features comes with outstanding support from a dedicated team of customer care specialists, QA engineers, and CKEditor&nbsp;5 developers. The team will gladly assist you in all aspects from setting up your account to integrating the CKEditor&nbsp;5 with your application.

As a licensed CKEditor&nbsp;5 user you can report bugs and request features directly through the CKEditor Ecosystem customer dashboard.

## License

**CKEditor&nbsp;5 Premium features**<br>
Copyright (c) 2003–2025, [CKSource Holding sp. z o.o.](https://cksource.com) All rights reserved.

CKEditor&nbsp;5 Premium features are licensed under a commercial license and are protected by copyright law. For more information, see: [https://ckeditor.com/pricing](https://ckeditor.com/pricing).

### Trademarks

**CKEditor** is a trademark of [CKSource Holding sp. z o.o.](https://cksource.com) All other brand and product names are trademarks, registered trademarks, or service marks of their respective holders.
