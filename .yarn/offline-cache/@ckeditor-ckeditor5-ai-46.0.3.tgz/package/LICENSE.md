Software License Agreement
==========================

**CKEditor&nbsp;5 AI&nbsp;Assistant feature** (https://ckeditor.com/ckeditor-5/)<br>
Copyright (c) 2003–2025, [CKSource Holding sp. z o.o.](https://cksource.com)  All rights reserved.

CKEditor&nbsp;5 AI&nbsp;Assistant feature is licensed under a commercial license and is protected by copyright law.
For more information, see: [https://ckeditor.com/pricing](https://ckeditor.com/pricing).

Sources of Intellectual Property Included in CKEditor&nbsp;5 AI&nbsp;Assistant feature
--------------------------------------------------------------------------------------

Where not otherwise indicated, all CKEditor&nbsp;5 AI&nbsp;Assistant feature content is authored by CKSource engineers and consists of CKSource-owned intellectual property.

The following libraries are included in CKEditor&nbsp;5 AI&nbsp;Assistant under the [Apache License, version 2.0](https://opensource.org/license/apache-2-0/):

* @aws-sdk/client-bedrock-runtime - Copyright 2018–2023 Amazon.com, Inc. or its affiliates. All Rights Reserved.

The following libraries are included in CKEditor&nbsp;5 AI&nbsp;Assistant under the [MIT license](https://opensource.org/licenses/MIT):

* es-toolkit - Copyright (c) 2024 Viva Republica, Inc.

Trademarks
----------

**CKEditor** is a trademark of [CKSource Holding sp. z o.o.](https://cksource.com)  All other brand and product names are trademarks, registered trademarks, or service marks of their respective holders.
