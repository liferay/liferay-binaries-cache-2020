/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module ai/utils/normalizecommandsconfig
 */
import type { Locale } from 'ckeditor5/src/utils.js';
import type { AIGroupDefinition, AICommandDefinition } from '../aiassistant.js';
export declare const UNGROUPED_COMMANDS_GROUP_ID = "_ungrouppedCommands";
/**
 * Normalizes the `config.ai.aiAssistant.commands` configuration taking into account different possible config formats (or lack thereof).
 */
export declare function normalizeCommandsConfig(config: Array<AIGroupDefinition | AICommandDefinition>, locale: Locale): Array<AIGroupDefinition>;
