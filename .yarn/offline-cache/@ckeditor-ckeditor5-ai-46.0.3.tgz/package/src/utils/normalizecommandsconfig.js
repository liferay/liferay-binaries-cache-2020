/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
export const UNGROUPED_COMMANDS_GROUP_ID='_ungrouppedCommands';export function normalizeCommandsConfig(_0x476953,_0x9ad375){const _0x52ec7c=(0x0,_0x9ad375['t'])('Other');return _0x476953['length']?'groupId'in _0x476953[0x0]?_0x476953:[{'groupId':'_ungrouppedCommands','groupLabel':_0x52ec7c,'order':0x1/0x0,'commands':_0x476953}]:[{'groupId':'_ungrouppedCommands','groupLabel':_0x52ec7c,'order':0x1/0x0,'commands':[]}];}