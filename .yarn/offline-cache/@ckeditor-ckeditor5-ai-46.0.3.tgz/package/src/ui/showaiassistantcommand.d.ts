/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module ai/ui/showaiassistantcommand
 * @publicApi
 */
import { Command, type Editor } from 'ckeditor5/src/core.js';
import type { AICommandDefinition } from '../aiassistant.js';
/**
 * Command that shows the AI Assistant user interface.
 */
export declare class ShowAIAssistantCommand extends Command {
    /**
     * An array with ids of the AI commands enabled for the current selection.
     *
     * @observable
     */
    enabledCommandsIds: Array<string>;
    /**
     * Creates an instance of the command.
     */
    constructor(editor: Editor, commandDefinitions: Array<AICommandDefinition>);
    /**
     * @inheritDoc
     */
    refresh(): void;
    /**
     * Opens AI Assistant user interface for the current document selection.
     *
     * @param query The initial query. If set, the AI assistant will automatically submit given query to the AI service.
     * @param label Label to be displayed in the AI assistant query input field while the AI assistant processes the initial query.
     * @param actionId The id of the executed action. It can be used in extended and custom adapters to customize the request. It
     * will be prefixed with `aiAssistant:`. See also
     * {@link module:ai/adapters/aitextadapter~AITextAdapterRequestData#actionId `AITextAdapterRequestData#actionId`}.
     * @fires execute
     */
    execute(query?: string, label?: string, actionId?: string): void;
}
