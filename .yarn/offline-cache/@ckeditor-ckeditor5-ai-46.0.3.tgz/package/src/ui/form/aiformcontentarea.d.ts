/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module ai/ui/aiformcontentarea
 */
import { type Locale } from 'ckeditor5/src/utils.js';
import { View, ButtonView } from 'ckeditor5/src/ui.js';
/**
 * A class representing the text area view of the AI assistant.
 */
export declare class AIFormContentArea extends View {
    /**
     * The value which is displayed in the content field.
     *
     * @observable
     */
    value: string | null;
    /**
     * Controls whether the content area is visible.
     *
     * @observable
     * @default false
     */
    isVisible: boolean;
    /**
     * Indicates if the content area is during processing which can change inner values.
     */
    isProcessing: boolean;
    /**
     * The textarea view.
     */
    contentFieldView: ContentFieldView;
    /**
     * The copy button displayed in the bottom-right corner of text area.
     */
    copyButtonView: ButtonView;
    /**
     * @inheritDoc
     */
    constructor(locale: Locale, extraCssClass?: string);
    /**
     * @inheritDoc
     */
    render(): void;
    focus(): void;
}
