/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module ai/ui/aihistorylistview
 */
import { ListView, ListItemGroupView, ButtonView, type FilteredView } from 'ckeditor5/src/ui.js';
import type { Locale } from 'ckeditor5/src/utils.js';
/**
 * A list view that displays a list of AI prompts with filter pass-through.
 *
 * @private
 */
export declare class AIHistoryListView extends ListView implements FilteredView {
    historyGroupView: ListItemGroupView;
    clearHistoryButton: ButtonView;
    constructor(locale: Locale);
    /**
     * @inheritDoc
     */
    filter(): {
        resultsCount: number;
        totalItemsCount: number;
    };
}
/**
 * Fired when the clear history button was executed by the user.
 *
 * @eventName ~AIHistoryListView#clearHistory
 */
export type AIHistoryListViewClearHistoryEvent = {
    name: 'clearHistory';
    args: [];
};
