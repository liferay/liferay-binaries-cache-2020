/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import { Collection } from 'ckeditor5/src/utils.js';
/**
 * A collection that stores the prompt history in the session storage as a side effect.
 */
export declare class PromptHistory extends Collection<PromptHistoryEntry> {
    /**
     * @inheritDoc
     */
    constructor();
}
/**
 * An object that represents a historical prompt.
 */
export type PromptHistoryEntry = {
    prompt: string;
};
