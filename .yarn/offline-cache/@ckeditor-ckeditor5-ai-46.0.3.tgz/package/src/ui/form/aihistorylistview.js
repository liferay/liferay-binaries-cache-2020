/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x50bd(_0x1bcb65,_0x429448){const _0x5ea45c=_0x5ea4();return _0x50bd=function(_0x50bdb6,_0x37f02e){_0x50bdb6=_0x50bdb6-0x128;let _0x476b53=_0x5ea45c[_0x50bdb6];return _0x476b53;},_0x50bd(_0x1bcb65,_0x429448);}const _0x52f0ee=_0x50bd;(function(_0x290e04,_0x1c4158){const _0x55cd7b=_0x50bd,_0x214e6e=_0x290e04();while(!![]){try{const _0x3e40bb=parseInt(_0x55cd7b(0x140))/0x1+-parseInt(_0x55cd7b(0x12d))/0x2+parseInt(_0x55cd7b(0x12e))/0x3+-parseInt(_0x55cd7b(0x135))/0x4*(-parseInt(_0x55cd7b(0x136))/0x5)+-parseInt(_0x55cd7b(0x13a))/0x6*(parseInt(_0x55cd7b(0x12b))/0x7)+-parseInt(_0x55cd7b(0x129))/0x8+parseInt(_0x55cd7b(0x12c))/0x9;if(_0x3e40bb===_0x1c4158)break;else _0x214e6e['push'](_0x214e6e['shift']());}catch(_0x2cfa07){_0x214e6e['push'](_0x214e6e['shift']());}}}(_0x5ea4,0xd5307));import{ListView as _0x2266ac,ListItemGroupView as _0x5ebab4,ButtonView as _0x395714}from'ckeditor5/src/ui.js';import{getTranslation as _0x64d0a1}from'../../utils/common-translations.js';function _0x5ea4(){const _0x357741=['1671549JfeTYv','delegate','Prompt\x20history','6894408NMMzxO','add','9266950WQIpaW','15298686KPNNns','2435186RLXHmC','2568915fdFAGD','_createClearHistoryButton','set','execute','children','fire','historyGroupView','12ilVihV','81265VVNRGM','clearHistory','length','Clear','6VcZUrI','label','items','clearHistoryButton','locale','filter'];_0x5ea4=function(){return _0x357741;};return _0x5ea4();}export class AIHistoryListView extends _0x2266ac{[_0x52f0ee(0x134)];[_0x52f0ee(0x13d)];constructor(_0x1ac0dc){const _0x535012=_0x52f0ee;super(_0x1ac0dc),this[_0x535012(0x13d)]=this[_0x535012(0x12f)](),this[_0x535012(0x134)]=new _0x5ebab4(),this[_0x535012(0x134)][_0x535012(0x132)][_0x535012(0x12a)](this[_0x535012(0x13d)],0x1),this[_0x535012(0x134)][_0x535012(0x13b)]=_0x64d0a1(_0x1ac0dc,_0x535012(0x128)),this[_0x535012(0x134)][_0x535012(0x13c)][_0x535012(0x141)](_0x535012(0x131))['to'](this),this[_0x535012(0x13c)][_0x535012(0x12a)](this[_0x535012(0x134)]);}[_0x52f0ee(0x13f)](){const _0x46ef83=_0x52f0ee;let _0x4a9b4e=0x0;for(const _0x547d44 of this[_0x46ef83(0x13c)])_0x4a9b4e+=_0x547d44[_0x46ef83(0x13c)][_0x46ef83(0x138)];return{'resultsCount':_0x4a9b4e,'totalItemsCount':_0x4a9b4e};}[_0x52f0ee(0x12f)](){const _0x2d88d7=_0x52f0ee,_0x4feb18=this[_0x2d88d7(0x13e)],_0x5bfcc1=new _0x395714(this[_0x2d88d7(0x13e)]);return _0x5bfcc1[_0x2d88d7(0x130)]({'label':'('+_0x64d0a1(_0x4feb18,_0x2d88d7(0x139))+')','withText':!0x0}),_0x5bfcc1['on'](_0x2d88d7(0x131),()=>this[_0x2d88d7(0x133)](_0x2d88d7(0x137))),_0x5bfcc1;}}