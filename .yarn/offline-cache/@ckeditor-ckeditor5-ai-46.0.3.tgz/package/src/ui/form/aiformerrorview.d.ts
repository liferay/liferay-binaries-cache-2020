/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import { View } from 'ckeditor5/src/ui.js';
import type { Locale } from 'ckeditor5/src/utils.js';
/**
 * A class representing the error view of the AI assistant.
 */
export declare class AIFormErrorView extends View {
    /**
     * The text of the error.
     *
     * @observable
     */
    text: string;
    /**
     * Creates an instance of the {@link module:ai/ui/aiformerrorview~AIFormErrorView} class.
     *
     * @param locale The localization services instance.
     */
    constructor(locale: Locale, text?: string);
}
