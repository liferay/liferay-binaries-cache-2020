/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x36ca7d=_0x406e;function _0x406e(_0x5ef98f,_0x342f12){const _0x2f4367=_0x2f43();return _0x406e=function(_0x406e00,_0x4b1166){_0x406e00=_0x406e00-0x109;let _0x5ac7de=_0x2f4367[_0x406e00];return _0x5ac7de;},_0x406e(_0x5ef98f,_0x342f12);}(function(_0x4d42d8,_0x595203){const _0x6e69fd=_0x406e,_0x4c727d=_0x4d42d8();while(!![]){try{const _0x80572=-parseInt(_0x6e69fd(0x11f))/0x1*(-parseInt(_0x6e69fd(0x116))/0x2)+-parseInt(_0x6e69fd(0x10c))/0x3+-parseInt(_0x6e69fd(0x11e))/0x4*(parseInt(_0x6e69fd(0x11d))/0x5)+parseInt(_0x6e69fd(0x119))/0x6+parseInt(_0x6e69fd(0x111))/0x7+parseInt(_0x6e69fd(0x121))/0x8+-parseInt(_0x6e69fd(0x113))/0x9;if(_0x80572===_0x595203)break;else _0x4c727d['push'](_0x4c727d['shift']());}catch(_0x5e9c73){_0x4c727d['push'](_0x4c727d['shift']());}}}(_0x2f43,0x2affc));import{Collection as _0x56e4c0}from'ckeditor5/src/utils.js';const ts=_0x36ca7d(0x10d);export class PromptHistory extends _0x56e4c0{constructor(){const _0x2508a5=_0x36ca7d;super(),this[_0x2508a5(0x112)](),this['on'](_0x2508a5(0x10a),(_0x47c0e4,_0x3666ad)=>{const _0x37d35d=_0x2508a5,_0x573cf8=os(_0x3666ad[_0x37d35d(0x10b)]);for(const _0x1cf8d0 of this)if(_0x1cf8d0!=_0x3666ad&&os(_0x1cf8d0[_0x37d35d(0x10b)])===_0x573cf8){this[_0x37d35d(0x110)](_0x1cf8d0);break;}this[_0x37d35d(0x10e)]>0x14&&this[_0x37d35d(0x110)](this[_0x37d35d(0x118)]),this[_0x37d35d(0x120)]();}),this['on'](_0x2508a5(0x110),()=>{const _0xdf7f33=_0x2508a5;this[_0xdf7f33(0x120)]();});}[_0x36ca7d(0x112)](){const _0x50f9ea=_0x36ca7d,_0x3e2616=sessionStorage[_0x50f9ea(0x10f)](ts)||'[]';this[_0x50f9ea(0x11b)](JSON[_0x50f9ea(0x109)](_0x3e2616));}[_0x36ca7d(0x120)](){const _0x4518a6=_0x36ca7d;sessionStorage[_0x4518a6(0x11c)](ts,JSON[_0x4518a6(0x11a)](this[_0x4518a6(0x115)](_0x4ee5a2=>_0x4ee5a2)));}}function _0x2f43(){const _0x49a70a=['trim','map','974MbvoCi','toLowerCase','last','950352TPIxxv','stringify','addMany','setItem','39030fkjCpk','124xTNSQS','269lvREnq','_saveToSessionStorage','372232GCCFMQ','parse','add','prompt','91101mQKXRU','CKEditor/AIFormView/PromptHistory','length','getItem','remove','2009707plLoOY','_loadFromSessionStorage','1570932sTSAdd'];_0x2f43=function(){return _0x49a70a;};return _0x2f43();}function os(_0x16e0a9){const _0x219a0d=_0x36ca7d;return _0x16e0a9[_0x219a0d(0x117)]()[_0x219a0d(0x114)]();}