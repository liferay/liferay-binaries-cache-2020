/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module ai/ui/aiformpromptview
 */
import { type Locale } from 'ckeditor5/src/utils.js';
import { AutocompleteView, ButtonView, type TextareaView, type AutocompleteViewConfig } from 'ckeditor5/src/ui.js';
/**
 * A textarea field allowing to ask AI.
 */
export declare class AIFormPromptView extends AutocompleteView<TextareaView> {
    /**
     * The submit button view.
     */
    submitButtonView: ButtonView;
    /**
     * The button that shows and hides the history autocomplete panel.
     */
    showHistoryButtonView: ButtonView;
    /**
     * Creates `AIFormPromptView` instance.
     *
     * @param locale The localization services instance.
     * @param config Autocomplete config.
     */
    constructor(locale: Locale, config: AutocompleteViewConfig<TextareaView>);
    /**
     * @inheritDoc
     */
    render(): void;
    /**
     * @inheritDoc
     */
    focus(direction?: 1 | -1): void;
}
/**
 * Fired when the query is submitted by the user.
 *
 * @eventName ~AIFormPromptView#submit
 */
export type AIFormPromptViewSubmitEvent = {
    name: 'submit';
    args: [query: string];
};
