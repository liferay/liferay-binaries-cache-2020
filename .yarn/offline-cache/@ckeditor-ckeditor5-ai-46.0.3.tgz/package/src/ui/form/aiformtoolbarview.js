/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x4f4c70=_0x3180;function _0x3180(_0x5eede3,_0x94d77b){const _0x5e51b9=_0x5e51();return _0x3180=function(_0x31806d,_0x246d34){_0x31806d=_0x31806d-0x6f;let _0x7fbc13=_0x5e51b9[_0x31806d];return _0x7fbc13;},_0x3180(_0x5eede3,_0x94d77b);}(function(_0xdf57d8,_0x47da44){const _0x2c4047=_0x3180,_0x1d9e52=_0xdf57d8();while(!![]){try{const _0x17e3c1=parseInt(_0x2c4047(0x70))/0x1*(-parseInt(_0x2c4047(0x7a))/0x2)+parseInt(_0x2c4047(0x87))/0x3+parseInt(_0x2c4047(0x79))/0x4*(-parseInt(_0x2c4047(0x81))/0x5)+parseInt(_0x2c4047(0x75))/0x6+-parseInt(_0x2c4047(0x74))/0x7+-parseInt(_0x2c4047(0x73))/0x8*(parseInt(_0x2c4047(0x80))/0x9)+parseInt(_0x2c4047(0x85))/0xa;if(_0x17e3c1===_0x47da44)break;else _0x1d9e52['push'](_0x1d9e52['shift']());}catch(_0x18fd1d){_0x1d9e52['push'](_0x1d9e52['shift']());}}}(_0x5e51,0x845e3));import{ToolbarView as _0x225101,ButtonView as _0x462f39}from'ckeditor5/src/ui.js';import{getTranslation as _0x49c244}from'../../utils/common-translations.js';export const AIFormToolbarViewMainActionLabel={'REPLACE':_0x4f4c70(0x91),'INSERT':_0x4f4c70(0x8f)};export class AIFormToolbarView extends _0x225101{constructor(_0x2e77fa){const _0x3774c3=_0x4f4c70;super(_0x2e77fa),this[_0x3774c3(0x92)](_0x3774c3(0x7f),!0x1),this[_0x3774c3(0x92)](_0x3774c3(0x6f),AIFormToolbarViewMainActionLabel[_0x3774c3(0x88)]),this[_0x3774c3(0x77)]=this[_0x3774c3(0x84)]('',_0x3774c3(0x8d)),this[_0x3774c3(0x77)][_0x3774c3(0x7c)](_0x3774c3(0x83))['to'](this,_0x3774c3(0x6f),_0x2cd030=>_0x49c244(_0x2e77fa,_0x3774c3(0x78)+_0x2cd030[_0x3774c3(0x8a)]()+_0x3774c3(0x89))),this[_0x3774c3(0x8c)]=this[_0x3774c3(0x84)](_0x49c244(_0x2e77fa,_0x3774c3(0x71))),this[_0x3774c3(0x7d)]=this[_0x3774c3(0x84)](_0x49c244(_0x2e77fa,_0x3774c3(0x7b))),this[_0x3774c3(0x72)]=this[_0x3774c3(0x84)](_0x49c244(_0x2e77fa,_0x3774c3(0x7e)));const _0x29b31b=this[_0x3774c3(0x90)];this[_0x3774c3(0x8e)]({'attributes':{'class':[_0x3774c3(0x93),_0x29b31b['if'](_0x3774c3(0x7f),_0x3774c3(0x76),_0x5dcdb6=>!_0x5dcdb6)]}}),this[_0x3774c3(0x86)][_0x3774c3(0x8b)]([this[_0x3774c3(0x77)],this[_0x3774c3(0x8c)],this[_0x3774c3(0x7d)],this[_0x3774c3(0x72)]]);}[_0x4f4c70(0x84)](_0x148ced,_0x31af47){const _0x4d3de3=_0x4f4c70,_0x34b29c=new _0x462f39(this[_0x4d3de3(0x82)]);return _0x34b29c[_0x4d3de3(0x92)]({'label':_0x148ced,'class':_0x31af47||'','isVisible':!0x0,'withText':!0x0}),_0x34b29c;}}function _0x5e51(){const _0x4be263=['Insert\x20below','stopButton','8iweiIb','554106cHiXgA','1571496BIEayL','ck-hidden','replaceButton','AI_','1556iLRVui','48OybzDS','Try\x20again','bind','tryAgainButton','Stop','isVisible','4800078hHSkOB','7075NFDDoL','locale','label','_createButton','18473670VoGEFj','items','1326717NJUesH','REPLACE','_CONTENT','toUpperCase','addMany','insertButton','ck-button-action','extendTemplate','insert','bindTemplate','replace','set','ck-ai-form__toolbar','mainAction','35267STtjIu'];_0x5e51=function(){return _0x4be263;};return _0x5e51();}