/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module ai/ui/aihistorylistitemview
 */
import { ListItemView } from 'ckeditor5/src/ui.js';
import type { PromptHistoryEntry } from './prompthistory.js';
/**
 * A list item view that displays a historical prompt
 */
export declare class AIHistoryListItemView extends ListItemView {
    /**
     * @inheritDoc
     */
    constructor(promptHistoryEntry: PromptHistoryEntry);
}
