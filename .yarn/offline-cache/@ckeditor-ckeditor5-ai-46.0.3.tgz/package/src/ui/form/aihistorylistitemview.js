/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x752b54,_0xe0d662){const _0x45c124=_0x3452,_0x32ea87=_0x752b54();while(!![]){try{const _0x5830f9=parseInt(_0x45c124(0xd9))/0x1+parseInt(_0x45c124(0xc9))/0x2+parseInt(_0x45c124(0xd5))/0x3*(parseInt(_0x45c124(0xd1))/0x4)+parseInt(_0x45c124(0xcf))/0x5*(-parseInt(_0x45c124(0xd3))/0x6)+-parseInt(_0x45c124(0xd6))/0x7*(parseInt(_0x45c124(0xce))/0x8)+-parseInt(_0x45c124(0xca))/0x9+-parseInt(_0x45c124(0xd4))/0xa*(-parseInt(_0x45c124(0xd7))/0xb);if(_0x5830f9===_0xe0d662)break;else _0x32ea87['push'](_0x32ea87['shift']());}catch(_0x1029ab){_0x32ea87['push'](_0x32ea87['shift']());}}}(_0x3ffc,0xf402f));function _0x3452(_0x36cc51,_0x5a633a){const _0x3ffc11=_0x3ffc();return _0x3452=function(_0x3452d0,_0x29c418){_0x3452d0=_0x3452d0-0xc9;let _0x26c2ba=_0x3ffc11[_0x3452d0];return _0x26c2ba;},_0x3452(_0x36cc51,_0x5a633a);}function _0x3ffc(){const _0x304f88=['2064002eWpkpK','11894202sbpMPk','set','prompt','execute','80jCrbfQ','503340BXZiPh','locale','40UYJzqg','add','72Ipssfo','3779260bjjyvI','165084EQLwfi','773017qIYoHV','44xBiRll','children','1539390mAOUyO','fire'];_0x3ffc=function(){return _0x304f88;};return _0x3ffc();}import{ListItemView as _0x202669,ButtonView as _0x1f73d7,ButtonLabelView as _0x9daf2}from'ckeditor5/src/ui.js';import{unescape as _0x4a3e28}from'es-toolkit/compat';export class AIHistoryListItemView extends _0x202669{constructor(_0x3a4ce3){const _0x581b1e=_0x3452;super();const _0x4b1020=new _0x9daf2(),_0x4a1883=new _0x1f73d7(this[_0x581b1e(0xd0)],_0x4b1020);this[_0x581b1e(0xd8)][_0x581b1e(0xd2)](_0x4a1883),_0x4a1883[_0x581b1e(0xcb)]({'label':_0x3a4ce3[_0x581b1e(0xcc)],'withText':!0x0}),_0x4a1883['on'](_0x581b1e(0xcd),()=>{const _0x2e4e8a=_0x581b1e;this[_0x2e4e8a(0xda)](_0x2e4e8a(0xcd),{'value':_0x4a3e28(_0x3a4ce3[_0x2e4e8a(0xcc)])});});}}