/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module ai/ui/aiformview
 */
import { FocusTracker, KeystrokeHandler, type Locale } from 'ckeditor5/src/utils.js';
import { View, type ViewWithFocusCycler } from 'ckeditor5/src/ui.js';
import { AIFormToolbarView, AIFormToolbarViewMainActionLabel } from './aiformtoolbarview.js';
import { AIFormContentArea } from './aiformcontentarea.js';
import { AIFormErrorView } from './aiformerrorview.js';
import { AIFormPromptView } from './aiformpromptview.js';
/**
 * A class representing the form view of the AI assistant.
 */
export declare class AIFormView extends View implements ViewWithFocusCycler {
    /**
     * Tracks information about the DOM focus in the form.
     *
     * @readonly
     */
    focusTracker: FocusTracker;
    /**
     * An instance of the {@link module:utils/keystrokehandler~KeystrokeHandler}.
     *
     * @readonly
     */
    keystrokes: KeystrokeHandler;
    /**
     * The text area view that is used to display AI response.
     */
    contentArea: AIFormContentArea;
    /**
     * Toolbar view containing button views that manage the AI response and this form itself.
     */
    toolbar: AIFormToolbarView;
    /**
     * The component used for handling the user's query, including history and submit buttons.
     */
    promptView: AIFormPromptView;
    /**
     * View that is used to display the error message.
     */
    errorView: AIFormErrorView;
    /**
     * The prompt text can be configured either during construction when the AI command has been selected,
     * or later by submitting the {@link #labeledInput}, if it hasn't been previously initialized.
     * After setting this value the AI request is triggered.
     */
    prompt: string;
    /**
     * The value that is generated after user submitting the user prompt.
     */
    value: string;
    /**
     * Flag that indicates if the AI assistant form view is enabled or disabled.
     *
     * If it is disabled, all interactive elements of this view are disabled as well.
     */
    isEnabled: boolean;
    /**
     * Indicates if the AI request is processing.
     */
    isProcessing: boolean;
    /**
     * Indicates if the AI request failed.
     */
    isError: boolean;
    /**
     * The action name for the main insertion button in the {@link #toolbar}.
     *
     * See {@link module:ai/ui/aiformtoolbarview~AIFormToolbarView#replaceButton}.
     *
     * @default 'replace'
     */
    mainAction: typeof AIFormToolbarViewMainActionLabel[keyof typeof AIFormToolbarViewMainActionLabel];
    /**
     * Creates an instance of the {@link module:ai/ui/aiformview~AIFormView} class.
     *
     * @param locale The localization services instance.
     */
    constructor(locale: Locale, uiClasses: string, contentAreaCssClass?: string);
    /**
     * @inheritDoc
     */
    render(): void;
    /**
     * @inheritDoc
     */
    focus(direction?: 1 | -1): void;
    /**
     * Resets the form to the initial values.
     */
    reset(): void;
}
/**
 * Fired when a user performed an action that should lead to replace the current selection by generated content.
 *
 * @eventName ~AIFormView#replaceContent
 */
export type ReplaceContentEvent = {
    name: 'replaceContent';
    args: [];
};
/**
 * Fired when a user performed an action that should lead to insert generated content below the current selection.
 *
 * @eventName ~AIFormView#insertContentBelow
 */
export type InsertContentBelowEvent = {
    name: 'insertContentBelow';
    args: [];
};
/**
 * Fired when a user performed an action that should lead to retry the previous request to AI.
 *
 * @eventName ~AIFormView#tryAgainEvent
 */
export type TryAgainEvent = {
    name: 'tryAgainEvent';
    args: [];
};
/**
 * Fired when a user performed an action that should lead to stop the processing of AI.
 *
 * @eventName ~AIFormView#stopProcessing
 */
export type StopProcessingEvent = {
    name: 'stopProcessing';
    args: [];
};
/**
 * Fired when a user performed an action that should lead to ask AI.
 *
 * @eventName ~AIFormView#submitPrompt
 */
export type SubmitPromptEvent = {
    name: 'submitPrompt';
    args: [prompt: string];
};
