/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module ai/ui/aiformtoolbarview
 */
import type { Locale } from 'ckeditor5/src/utils.js';
import { ToolbarView, ButtonView } from 'ckeditor5/src/ui.js';
/**
 * The action name affecting the label of {@link ~AIFormToolbarView#replaceButton}.
 *
 * Available keys are:
 * * `AIFormToolbarViewMainActionLabel.REPLACE`,
 * * `AIFormToolbarViewMainActionLabel.INSERT`
 */
export declare const AIFormToolbarViewMainActionLabel: {
    readonly REPLACE: "replace";
    readonly INSERT: "insert";
};
/**
 * A class representing the text area view of the AI assistant.
 */
export declare class AIFormToolbarView extends ToolbarView {
    /**
     * Controls whether the toolbar is visible.
     *
     * @observable
     * @default false
     */
    isVisible: boolean;
    /**
     * Button that is used to replace the selected content by the generated one.
     */
    replaceButton: ButtonView;
    /**
     * Button that is used to insert the generated content below the selection.
     */
    insertButton: ButtonView;
    /**
     * Button that is used to regenerate the response.
     */
    tryAgainButton: ButtonView;
    /**
     * Button that is used to stop the processing of the request.
     */
    stopButton: ButtonView;
    /**
     * The action name affecting the label of {@link #replaceButton}.
     *
     * @default 'replace'
     */
    mainAction: typeof AIFormToolbarViewMainActionLabel[keyof typeof AIFormToolbarViewMainActionLabel];
    /**
     * @inheritDoc
     */
    constructor(locale: Locale);
}
