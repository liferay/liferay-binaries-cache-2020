/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x3b8fd9,_0xe069b2){const _0x15f9fc=_0x116d,_0x3f1a7c=_0x3b8fd9();while(!![]){try{const _0x59352c=-parseInt(_0x15f9fc(0xd2))/0x1+parseInt(_0x15f9fc(0xdc))/0x2+parseInt(_0x15f9fc(0xd7))/0x3+parseInt(_0x15f9fc(0xd6))/0x4*(-parseInt(_0x15f9fc(0xd9))/0x5)+-parseInt(_0x15f9fc(0xe1))/0x6+-parseInt(_0x15f9fc(0xd8))/0x7*(parseInt(_0x15f9fc(0xdf))/0x8)+parseInt(_0x15f9fc(0xde))/0x9*(parseInt(_0x15f9fc(0xe0))/0xa);if(_0x59352c===_0xe069b2)break;else _0x3f1a7c['push'](_0x3f1a7c['shift']());}catch(_0x4c9c74){_0x3f1a7c['push'](_0x3f1a7c['shift']());}}}(_0x4da5,0xc24ba));import{IconError as _0x5495ee}from'ckeditor5/src/icons.js';function _0x116d(_0x421cf4,_0x8dcce1){const _0x4da5a2=_0x4da5();return _0x116d=function(_0x116d7b,_0x3114f8){_0x116d7b=_0x116d7b-0xd1;let _0x421ce5=_0x4da5a2[_0x116d7b];return _0x421ce5;},_0x116d(_0x421cf4,_0x8dcce1);}import{View as _0x33db27,IconView as _0x59c02c}from'ckeditor5/src/ui.js';function _0x4da5(){const _0x5c562f=['div','text','content','5109744nJgahz','4258782iRmIWY','7bSnXUD','5dKDAKW','ck-ai-form__error','bindTemplate','584608uhNlSy','set','4701861zqLmSG','315816dfPDUC','30cYuCUS','4019520cITWhn','setTemplate','496518YKZezc'];_0x4da5=function(){return _0x5c562f;};return _0x4da5();}export class AIFormErrorView extends _0x33db27{constructor(_0x749aa1,_0x5d792a=''){const _0x212828=_0x116d;super(_0x749aa1);const _0x48fb72=new _0x59c02c(),_0x16bd39=this[_0x212828(0xdb)];this[_0x212828(0xdd)](_0x212828(0xd4),_0x5d792a),_0x48fb72[_0x212828(0xd5)]=_0x5495ee,this[_0x212828(0xd1)]({'tag':_0x212828(0xd3),'attributes':{'class':['ck',_0x212828(0xda)]},'children':[_0x48fb72,{'text':_0x16bd39['to'](_0x212828(0xd4))}]});}}