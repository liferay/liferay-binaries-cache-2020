/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import { type AITextAdapter } from '../adapters/aitextadapter.js';
import type { AIFormView } from './form/aiformview.js';
import type { AIFormToolbarViewMainActionLabel } from './form/aiformtoolbarview.js';
import type { Editor } from 'ckeditor5/src/core.js';
declare const AIAssistantController_base: {
    new (): import("ckeditor5/src/utils.js").Observable;
    prototype: import("ckeditor5/src/utils.js").Observable;
};
/**
 * Controller for the AI assistant.
*
 * It takes a AI form view, listens to events fired by that view and based on them performs actions on an AI handler.
 * This controller is also responsible for streaming the AI response for the UI.
 */
export declare class AIAssistantController extends /* #__PURE__ -- @preserve */ AIAssistantController_base {
    /**
     * The editor instance.
     */
    readonly editor: Editor;
    /**
     * An instance of the {@link module:ai/adapters/aitextadapter~AITextAdapter}.
     */
    readonly textAdapter: AITextAdapter;
    /**
     * An instance of the {@link module:ai/ui/aiformview~AIFormView}.
     */
    readonly view: AIFormView;
    /**
     * It is the selected HTML content from the editor on which the dialog has been initialized.
     */
    initialContext: string;
    /**
     * The latest value returned by the AI while executing the request. It is before parsing and normalization.
     */
    currentResponse: string;
    /**
     * The latest value returned by the AI while executing the request. It is after parsing and normalization. It will be used as context
     * for the next calls.
     *
     * This value is also displayed in the view (after sanitization).
     */
    currentContext: string;
    /**
     * The previous value of the context for the AI request. It is kept to handle the try again event.
     *
     * Initially it is the selected HTML content from the editor. Subsequently, the context is replaced by each response from AI.
     *
     * @observable
     */
    previousContext?: string;
    /**
     * The previous value of the user query. It is kept to handle the try again event.
     *
     * @observable
     */
    previousQuery?: string;
    /**
     * The label of the previous executed query. It is connected to {@link ~AIAssistantController#previousQuery `previousQuery`} and is kept
     * to handle the "try again" event.
     *
     * @observable
     */
    previousLabel?: string;
    /**
     * The id of the previous executed action. It is kept to handle the try again event.
     *
     * @observable
     */
    previousActionId?: string;
    /**
     * Flag that indicates if the processing is in progress.
     *
     * @observable
     */
    isProcessing: boolean;
    /**
     * @param adapter AI connector instance.
     * @param view AI form view.
     */
    constructor(editor: Editor, adapter: AITextAdapter, view: AIFormView);
    /**
     * Destroys `AIAssistantController` instance.
     */
    destroy(): void;
    /**
     * Handles the initial query for a new context and inits the listener for the visible view.
     *
     * This function should be called whenever the AI dialog is displayed.
     *
     * @param options
     * @param options.actionId ID of the performed action. See {@link module:ai/adapters/aitextadapter~AITextAdapterRequestData#actionId}.
     * @param options.htmlContent The selected HTML content on which the AI should base.
     * @param options.query The initial query to be processed.
     * @param options.label The label that will be displayed in the view.
     * @param options.mainActionLabel The action label for the main insertion button.
     */
    updateView({ actionId, query, htmlContent, label, mainActionLabel }: {
        actionId: string;
        query: string;
        htmlContent: string;
        label: string;
        mainActionLabel: typeof AIFormToolbarViewMainActionLabel[keyof typeof AIFormToolbarViewMainActionLabel];
    }): Promise<void>;
}
export {};
