/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module ai/adapters/aiadapter
 * @publicApi
 */
import { Plugin } from 'ckeditor5/src/core.js';
import { type AITextAdapter } from './aitextadapter.js';
/**
 * Main adapter plugin that is a common interface between AI features and AI adapters.
 *
 * Various AI features require to make calls to AI services. On the other hand, there are various AI adapters that can be
 * loaded, which provide access to different AI service providers.
 *
 * `AIAdapter` brings both parties together. Features use the `AIAdapter` API that is known to them. On the other hand, a concrete adapter
 * implementation can inject itself into `AIAdapter`. This way features and adapters are decoupled.
 *
 * For example:
 *
 * * `AIAssistant` feature needs to make text AI requests, so it uses `AIAdapter#textAdapter`.
 * * `OpenAITextAdapter` plugin, when loaded, sets itself as `AIAdapter#textAdapter`, so features can use it.
 */
export declare class AIAdapter extends Plugin {
    /**
     * The instance of the loaded AI text adapter instance.
     *
     * The adapter is provided by a different plugin that has to be additionally loaded.
     */
    textAdapter: AITextAdapter;
    /**
     * @inheritDoc
     */
    static get pluginName(): "AIAdapter";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    afterInit(): void;
}
/**
 * Error which may be thrown by various AI adapters.
 *
 * When this error is thrown it should be handled by the feature which used the adapter.
 */
export declare class AIRequestError extends Error {
    constructor(message: string);
}
