/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x5005d3=_0x2a06;(function(_0x37b718,_0x30241b){var _0x195809=_0x2a06,_0x989b42=_0x37b718();while(!![]){try{var _0x4ce4f0=parseInt(_0x195809(0x145))/0x1+parseInt(_0x195809(0x151))/0x2+parseInt(_0x195809(0x146))/0x3*(-parseInt(_0x195809(0x148))/0x4)+parseInt(_0x195809(0x150))/0x5+-parseInt(_0x195809(0x149))/0x6*(parseInt(_0x195809(0x142))/0x7)+-parseInt(_0x195809(0x14d))/0x8+-parseInt(_0x195809(0x147))/0x9;if(_0x4ce4f0===_0x30241b)break;else _0x989b42['push'](_0x989b42['shift']());}catch(_0x294bbe){_0x989b42['push'](_0x989b42['shift']());}}}(_0x344b,0xd8080));import{Plugin as _0x22d674}from'ckeditor5/src/core.js';import{CKEditorError as _0x344492}from'ckeditor5/src/utils.js';export class AIAdapter extends _0x22d674{static get[_0x5005d3(0x14c)](){var _0x256158=_0x5005d3;return _0x256158(0x14b);}static get[_0x5005d3(0x152)](){return!0x0;}static get[_0x5005d3(0x14f)](){return!0x0;}[_0x5005d3(0x14e)](){var _0x20aa20=_0x5005d3;if(!this[_0x20aa20(0x144)])throw new _0x344492(_0x20aa20(0x153),null);}}function _0x2a06(_0x3f0977,_0x357988){var _0x344bde=_0x344b();return _0x2a06=function(_0x2a0688,_0x25263e){_0x2a0688=_0x2a0688-0x142;var _0x49e6f1=_0x344bde[_0x2a0688];return _0x49e6f1;},_0x2a06(_0x3f0977,_0x357988);}export class AIRequestError extends Error{constructor(_0x335023){var _0x30f8f4=_0x5005d3;super(_0x335023),this[_0x30f8f4(0x143)]=_0x30f8f4(0x14a);}}function _0x344b(){var _0x112f02=['pluginName','3711112HJyQkq','afterInit','isPremiumPlugin','334055ioMgcq','1978326aQvIAs','isOfficialPlugin','aiadapter-text-adapter-not-set','23737HNADZI','name','textAdapter','1758213OdikVY','579nAkIFv','2454570BHJNzT','2300fpnGfk','1914oOEhvE','AIRequestError','AIAdapter'];_0x344b=function(){return _0x112f02;};return _0x344b();}