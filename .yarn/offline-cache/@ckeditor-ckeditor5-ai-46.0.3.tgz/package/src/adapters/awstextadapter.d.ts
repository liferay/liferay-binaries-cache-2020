/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module ai/adapters/awstextadapter
 * @publicApi
 */
import { type Editor } from 'ckeditor5/src/core.js';
import { AITextAdapter, type AITextAdapterRequestData, type AIRequestHeaders, type AIRequestParameters } from './aitextadapter.js';
import { type BedrockRuntimeClientConfig } from '@aws-sdk/client-bedrock-runtime';
/**
 * Adapter for AI text-related requests that supports the Amazon Bedrock service.
 *
 * See also {@link module:ai/adapters/aitextadapter~AITextAdapter}.
 */
export declare class AWSTextAdapter extends AITextAdapter {
    /**
     * @inheritDoc
     */
    static get pluginName(): "AWSTextAdapter";
    /**
     * @inheritDoc
     */
    constructor(editor: Editor);
    /**
     * Performs the request to the Amazon Bedrock service or to the endpoint provided in the editor configuration.
     *
     * If you want to extend this adapter, you can overload this method to do some additional processing or make an external call.
     */
    sendRequest({ query, context, onData, actionId }: AITextAdapterRequestData): Promise<void>;
    /**
     * Prepares the actual full prompt for the request to the Amazon Bedrock API.
     *
     * The prompt may differ depending on what model is used.
     *
     * You can overload this method to customize the prompts that are sent to the AI service.
     *
     * @param query The user's query. The instruction which the model should perform.
     * @param context The context for the instruction. Usually this will be a part of the editor content. Can be empty.
     * @param model Model that is used to perform the request.
     * @param actionId ID of the performed action. See {@link module:ai/adapters/aitextadapter~AITextAdapterRequestData#actionId}.
     */
    preparePrompt(query: string, context: string, model: string, actionId: string): Promise<string>;
    /**
     * For a given model, it returns the family to which this model belongs.
     *
     * For example, for `anthropic.claude-instant-v1` it will return `anthropic.claude`.
     *
     * Throws {@link module:ai/adapters/aiadapter~AIRequestError `AIRequestError`} if a given model is not supported.
     */
    getModelFamily(model: string): AIAWSModelFamily;
}
/**
 * The configuration for the Amazon Bedrock adapter.
 *
 * The properties defined in this configuration are set in the `config.ai.aws` namespace.
 *
 * ```ts
 * ClassicEditor
 * 	.create( editorElement, {
 * 		ai: {
 * 		    aws: {
 * 		        apiUrl: 'https://url.to.your.application/ai'
 * 		    }
 * 		}
 * 	} )
 * 	.then( ... )
 * 	.catch( ... );
 * ```
 *
 * See {@link module:ai/aiconfig~AIConfig the full AI configuration}.
 *
 * See {@link module:core/editor/editorconfig~EditorConfig all editor options}.
 */
export interface AIAWSTextAdapterConfig {
    /**
     * The URL to which the AI service request will be sent.
     *
     * Set this value only if you want to connect to Amazon Bedrock using a proxy endpoint.
     *
     * If `apiUrl` is not provided, the AWS-SDK library will be used to process the request. It will set a proper URL on its own.
     */
    apiUrl?: string;
    /**
     * An object with headers to set in the request to the AI service.
     *
     * **These headers are only used when connecting to AWS through the proxy endpoint (that is, when `apiUrl` is set).**
     *
     * Otherwise, the AWS-SDK library is used, and it sets the request headers on its own. In this mode, the request headers cannot be
     * customized.
     *
     * If the provided value is an object, it is simply used as provided.
     *
     * ```js
     * {
     * 	ai: {
     * 		aws: {
     * 			requestHeaders: {
     * 		 		'Authorization': 'Bearer YOUR_API_KEY'
     * 			}
     * 		}
     * 		// ...
     * 	}
     * }
     * ```
     *
     * If the provided value is a function, it should be a function that returns a promise which resolves with the headers object.
     * This way, you can perform an authorization request to your application and receive the authorization token (and also implement
     * any custom logic on the backend side). The headers object is then used to make the actual call to the AI service.
     *
     * ```js
     * {
     * 	ai: {
     * 		aws: {
     * 			requestHeaders: async () => {
     * 				const jwt = await fetch( 'https://example.com/jwt-endpoint' );
     *
     * 				return {
     * 					'Authorization': 'Bearer ' + jwt
     * 				}
     * 			}
     * 		}
     * 		// ...
     * 	}
     * }
     * ```
     *
     * The function is passed the {@link module:ai/adapters/aitextadapter~AITextAdapterRequestData#actionId `actionId`} parameter to make it
     * possible to further customize the headers.
     *
     * If the function fails for any reason, the promise should be rejected. In this case, a feature that made the request should display
     * an error notification.
     */
    requestHeaders?: AIRequestHeaders;
    /**
     * Additional configuration parameters for the AI service request. Use it to customize how the AI service generates responses.
     * Note that the value you will set here will fully overwrite the default value.
     *
     * The exact configuration (available parameters) depends on the used model. Keep in mind that some properties are not supported by some
     * models.
     *
     * See [AWS model parameters reference](https://docs.aws.amazon.com/bedrock/latest/userguide/model-parameters.html) to learn more.
     *
     * If the provided value is an object, it is passed to the request as provided.
     *
     * If the provided value is a function, it should be a function that returns a promise which resolves with the request parameters
     * object. This gives you more flexibility to provide parameters for the AI model.
     *
     * The function is passed the {@link module:ai/adapters/aitextadapter~AITextAdapterRequestData#actionId `actionId`} parameter to make it
     * possible to further customize the parameters.
     *
     * If the function fails for any reason, the promise should be rejected. In this case, the feature that made the request should display
     * an error notification.
     *
     * Defaults to:
     *
     * ```json
     * {
     * 	model: 'anthropic.claude-v2',
     * 	max_tokens_to_sample: 500,
     * 	temperature: 1,
     * 	top_k: 250,
     * 	top_p: 1,
     * 	anthropic_version: 'bedrock-2023-05-31',
     * 	stream: true
     * }
     * ```
     */
    requestParameters?: AIRequestParameters;
    /**
     * The configuration for AWS-SDK Bedrock Runtime Client.
     *
     * If `apiUrl` is not provided, this configuration will be used to initialize the Bedrock Runtime Client which will be used to process
     * the requests. The adapter will make requests directly to the Amazon Bedrock service.
     */
    bedrockClientConfig?: BedrockRuntimeClientConfig;
}
export type AIAWSModelFamily = 'anthropic.claude' | 'ai21.j2' | 'cohere.command' | 'meta.llama';
