/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import { type AIAssistant } from './aiassistant.js';
import { type ShowAIAssistantCommand } from './ui/showaiassistantcommand.js';
import { type AIAssistantEditing } from './aiassistantediting.js';
import { type AIAssistantUI } from './aiassistantui.js';
import { type AIConfig } from './aiconfig.js';
import { type AIAdapter } from './adapters/aiadapter.js';
declare module '@ckeditor/ckeditor5-core' {
    interface EditorConfig {
        /**
         * Configuration for AI features.
         */
        ai?: AIConfig;
    }
    interface PluginsMap {
        [AIAdapter.pluginName]: AIAdapter;
        [AIAssistant.pluginName]: AIAssistant;
        [AIAssistantUI.pluginName]: AIAssistantUI;
        [AIAssistantEditing.pluginName]: AIAssistantEditing;
    }
    interface CommandsMap {
        showAIAssistant: ShowAIAssistantCommand;
    }
}
