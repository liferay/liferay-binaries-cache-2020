/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module ai
 */
export { AIAssistant, getDefaultAICommands, type AIAssistantConfig, type AIGroupDefinition, type AICommandDefinition } from './aiassistant.js';
export { AIAssistantUI } from './aiassistantui.js';
export type { AIConfig } from './aiconfig.js';
export { AIAdapter, AIRequestError } from './adapters/aiadapter.js';
export { AITextAdapter, type AITextAdapterRequestData, type AIRequestHeaders, type AIRequestParameters, type AITextAdapterDataCallback } from './adapters/aitextadapter.js';
export { OpenAITextAdapter, type OpenAITextAdapterConfig } from './adapters/openaitextadapter.js';
export { AWSTextAdapter, type AIAWSTextAdapterConfig, type AIAWSModelFamily } from './adapters/awstextadapter.js';
export type { AIRequestMessageItem } from './adapters/openaitextadapter.js';
export { ShowAIAssistantCommand } from './ui/showaiassistantcommand.js';
import './augmentation.js';
