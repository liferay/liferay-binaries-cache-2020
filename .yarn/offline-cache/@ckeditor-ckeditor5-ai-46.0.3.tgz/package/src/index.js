/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x3f603c,_0x101b09){var _0x1f863d=_0x5617,_0x36dd5d=_0x3f603c();while(!![]){try{var _0x18767a=parseInt(_0x1f863d(0x1ed))/0x1+parseInt(_0x1f863d(0x1e6))/0x2+parseInt(_0x1f863d(0x1e9))/0x3+parseInt(_0x1f863d(0x1e5))/0x4+parseInt(_0x1f863d(0x1ea))/0x5+parseInt(_0x1f863d(0x1e8))/0x6*(parseInt(_0x1f863d(0x1ec))/0x7)+-parseInt(_0x1f863d(0x1e7))/0x8*(parseInt(_0x1f863d(0x1eb))/0x9);if(_0x18767a===_0x101b09)break;else _0x36dd5d['push'](_0x36dd5d['shift']());}catch(_0x47683b){_0x36dd5d['push'](_0x36dd5d['shift']());}}}(_0x3b77,0x274cf));function _0x5617(_0xda613e,_0x5bca4e){var _0x3b77f5=_0x3b77();return _0x5617=function(_0x5617be,_0x1adb90){_0x5617be=_0x5617be-0x1e5;var _0x1f87b9=_0x3b77f5[_0x5617be];return _0x1f87b9;},_0x5617(_0xda613e,_0x5bca4e);}export{AIAssistant,getDefaultAICommands}from'./aiassistant.js';export{AIAssistantUI}from'./aiassistantui.js';export{AIAdapter,AIRequestError}from'./adapters/aiadapter.js';export{AITextAdapter}from'./adapters/aitextadapter.js';export{OpenAITextAdapter}from'./adapters/openaitextadapter.js';export{AWSTextAdapter}from'./adapters/awstextadapter.js';function _0x3b77(){var _0x28cde6=['1606395ymtPAU','126xoyBPc','772849jQVToH','134877nxtmRo','437404MQRjGH','112832VgXeSh','415096LdDxFf','6adsayl','465189QzbbDG'];_0x3b77=function(){return _0x28cde6;};return _0x3b77();}export{ShowAIAssistantCommand}from'./ui/showaiassistantcommand.js';import'./augmentation.js';