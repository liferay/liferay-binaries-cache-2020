/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import { Plugin } from 'ckeditor5/src/core.js';
import { type ModelPosition } from 'ckeditor5/src/engine.js';
/**
 * The AI assistant editing plugin.
 */
export declare class AIAssistantEditing extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "AIAssistantEditing";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    init(): void;
    /**
     * @inheritDoc
     */
    afterInit(): void;
    /**
     * Displays a fake visual selection.
     *
     * This adds a 'ai-ui-candidate' (for the commands dropdown) or 'ai-ui' (for the assistant dialog)
     * marker into the document that is rendered as a highlight on selected text fragment.
     */
    showFakeVisualSelection(): void;
    /**
     * Removes a fake visual selection.
     *
     * This clears a 'ai-ui-candidate' (for the commands dropdown) or 'ai-ui' (for the assistant dialog)
     * marker from the document.
     */
    hideFakeVisualSelection(): void;
    /**
     * Converts the HTML string into the model fragment and inserts it at the specified position.
     *
     * If a position is not provided, the insertion will replace the visual selection marker.
     */
    insertContent(html: string, position?: ModelPosition): void;
    /**
     * Converts the HTML string into the model fragment and inserts it below the visual selection marker.
     */
    insertContentBelow(content: string): void;
}
