/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x12ea(_0x29c6d1,_0x143233){var _0x519bed=_0x519b();return _0x12ea=function(_0x12ead6,_0x33cc4d){_0x12ead6=_0x12ead6-0x9f;var _0x52c208=_0x519bed[_0x12ead6];return _0x52c208;},_0x12ea(_0x29c6d1,_0x143233);}(function(_0x1f01a9,_0x2bdf42){var _0xf82cf7=_0x12ea,_0x2d36c6=_0x1f01a9();while(!![]){try{var _0x37be06=parseInt(_0xf82cf7(0xa8))/0x1+parseInt(_0xf82cf7(0xa0))/0x2+-parseInt(_0xf82cf7(0xa2))/0x3*(-parseInt(_0xf82cf7(0xa4))/0x4)+-parseInt(_0xf82cf7(0x9f))/0x5+parseInt(_0xf82cf7(0xa3))/0x6+-parseInt(_0xf82cf7(0xa1))/0x7*(parseInt(_0xf82cf7(0xa7))/0x8)+-parseInt(_0xf82cf7(0xa5))/0x9*(parseInt(_0xf82cf7(0xa6))/0xa);if(_0x37be06===_0x2bdf42)break;else _0x2d36c6['push'](_0x2d36c6['shift']());}catch(_0x3aedc8){_0x2d36c6['push'](_0x2d36c6['shift']());}}}(_0x519b,0x855fa));import{CKEditorError as _0x255375}from'ckeditor5/src/utils.js';function _0x519b(){var _0x33b043=['3071028rRJGYL','144pATlCy','27EavkUS','754530QkwTXL','8rFGWRI','336320noSMGp','1697620SmbIWH','209172QxXlUq','2943157SxnPmb','48324POClps'];_0x519b=function(){return _0x33b043;};return _0x519b();}