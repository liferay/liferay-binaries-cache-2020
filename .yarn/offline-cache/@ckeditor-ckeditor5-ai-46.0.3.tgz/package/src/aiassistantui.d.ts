/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module ai/aiassistantui
 * @publicApi
 */
import { Plugin, type Editor } from 'ckeditor5/src/core.js';
import { Dialog } from 'ckeditor5/src/ui.js';
import { AIAssistantEditing } from './aiassistantediting.js';
import { AIAdapter } from './adapters/aiadapter.js';
import '../theme/ai.css';
import '../theme/ai-dropdown.css';
import '../theme/ai-form.css';
import { ClipboardMarkersUtils } from 'ckeditor5/src/clipboard.js';
/**
 * The UI plugin of the AI assistant.
 */
export declare class AIAssistantUI extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "AIAssistantUI";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    static get requires(): readonly [typeof ClipboardMarkersUtils, typeof AIAssistantEditing, typeof AIAdapter, typeof Dialog];
    /**
     * @inheritDoc
     */
    constructor(editor: Editor);
    /**
     * @inheritDoc
     */
    init(): void;
    destroy(): void;
    /**
     * Initializes the AI Assistant main view and displays it in a dialog, based on the selection. Also, shows fake selection marker.
     *
     * @param query The initial query. If set, the AI assistant will automatically submit given query to the AI service.
     * @param label Label to be displayed in the AI assistant query input field while the AI assistant processes the initial query.
     * @param actionId The id of the executed action. It can be used in extended and custom adapters to customize the request.
     */
    showUI(query?: string, label?: string, actionId?: string): void;
    /**
     * Hides the AI dialog.
     */
    hideUI(): void;
}
