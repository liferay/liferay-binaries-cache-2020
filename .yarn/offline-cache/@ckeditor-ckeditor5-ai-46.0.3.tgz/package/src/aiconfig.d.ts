/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module ai/aiconfig
 * @publicApi
 */
import type { AIAssistantConfig } from './aiassistant.js';
import type { OpenAITextAdapterConfig } from './adapters/openaitextadapter.js';
import type { AIAWSTextAdapterConfig } from './adapters/awstextadapter.js';
/**
 * The configuration for all AI-related functionalities.
 *
 * Provides configuration properties for both AI features and AI adapters (which connect to the external AI services),
 *
 * ```ts
 * ClassicEditor
 * 	.create( editorElement, {
 * 		ai: {
 * 			openAI: {
 * 				requestHeaders: {
 * 					Authorization: 'Bearer API_KEY'
 * 				}
 * 			},
 * 			useTheme: false
 * 		}
 * 	} )
 * 	.then( ... )
 * 	.catch( ... );
 * ```
 *
 * See {@link module:core/editor/editorconfig~EditorConfig all editor configuration options}.
 */
export interface AIConfig {
    /**
     * The configuration of the {@link module:ai/aiassistant~AIAssistant AI Assistant feature}.
     *
     * Read more in {@link module:ai/aiassistant~AIAssistantConfig}.
     */
    aiAssistant?: AIAssistantConfig;
    /**
     * The configuration for the {@link module:ai/adapters/openaitextadapter~OpenAITextAdapter `OpenAITextAdapter`}.
     *
     * This is required only if you connect to OpenAI or Azure OpenAI service.
     *
     * Read more in {@link module:ai/adapters/openaitextadapter~OpenAITextAdapterConfig}.
     */
    openAI?: OpenAITextAdapterConfig;
    /**
     * The configuration for the {@link module:ai/adapters/awstextadapter~AWSTextAdapter `AWSTextAdapter`}.
     *
     * This is required only if you connect to Amazon Bedrock service.
     *
     * Read more in {@link module:ai/adapters/awstextadapter~AIAWSTextAdapterConfig}.
     */
    aws?: AIAWSTextAdapterConfig;
    /**
     * Enables or disables the colored UI theme for AI features.
     *
     * * Leaving this property unset will preserve the default theme on AI features UI elements.
     * * Setting this property to **`false`** will remove the default theme from AI features UI elements.
     *
     * See the AI Assistant integration guide to learn how you can use CSS variables to change the default theme to a different color.
     *
     * @default true
     */
    useTheme?: boolean;
}
