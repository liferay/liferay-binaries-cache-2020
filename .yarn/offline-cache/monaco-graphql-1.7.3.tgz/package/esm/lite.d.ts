export { initializeMode, LANGUAGE_ID } from './initialize';
//# sourceMappingURL=lite.d.ts.map