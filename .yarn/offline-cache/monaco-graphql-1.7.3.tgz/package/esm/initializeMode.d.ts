import './full';
export { initializeMode, LANGUAGE_ID } from './initialize';
//# sourceMappingURL=initializeMode.d.ts.map