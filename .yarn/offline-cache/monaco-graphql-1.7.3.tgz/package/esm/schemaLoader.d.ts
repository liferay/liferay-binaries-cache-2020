import type { SchemaLoader } from './typings';
export declare const defaultSchemaLoader: SchemaLoader;
//# sourceMappingURL=schemaLoader.d.ts.map