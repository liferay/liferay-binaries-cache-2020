import { IDisposable } from './monaco-editor';
import { MonacoGraphQLAPI } from './api';
export declare function setupMode(defaults: MonacoGraphQLAPI): IDisposable;
//# sourceMappingURL=graphqlMode.d.ts.map