import 'monaco-editor/esm/vs/basic-languages/graphql/graphql.contribution.js';
import 'monaco-editor/esm/vs/language/json/monaco.contribution.js';
export * from 'monaco-editor';
//# sourceMappingURL=monaco-editor.d.ts.map