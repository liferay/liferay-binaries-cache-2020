import { MonacoGraphQLAPI } from './api';
import type { MonacoGraphQLInitializeConfig } from './typings';
export declare const LANGUAGE_ID = "graphql";
export declare function initializeMode(config?: MonacoGraphQLInitializeConfig): MonacoGraphQLAPI;
//# sourceMappingURL=initialize.d.ts.map