export { modeConfigurationDefault, SchemaEntry, formattingDefaults, MonacoGraphQLAPI, MonacoGraphQLAPIOptions, diagnosticSettingDefault, } from './api';
import { LANGUAGE_ID } from './initializeMode';
export * from './typings';
export { LANGUAGE_ID };
//# sourceMappingURL=monaco.contribution.d.ts.map