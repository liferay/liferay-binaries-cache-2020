import { CodecSettings, Schema, ShapeSerializer } from "@smithy/types";
import { SerdeContextConfig } from "../ConfigurableSerdeContext";
export declare class QueryShapeSerializer
  extends SerdeContextConfig
  implements ShapeSerializer<string | Uint8Array>
{
  private settings;
  private buffer;
  constructor(settings: CodecSettings);
  write(schema: Schema, value: unknown, prefix?: string): void;
  flush(): string | Uint8Array;
  protected writeKey(key: string): void;
  protected writeValue(value: string): void;
}
