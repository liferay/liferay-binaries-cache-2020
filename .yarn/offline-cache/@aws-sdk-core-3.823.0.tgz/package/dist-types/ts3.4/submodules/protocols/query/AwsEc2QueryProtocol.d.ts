import { AwsQueryProtocol } from "./AwsQueryProtocol";
export declare class AwsEc2QueryProtocol extends AwsQueryProtocol {}
