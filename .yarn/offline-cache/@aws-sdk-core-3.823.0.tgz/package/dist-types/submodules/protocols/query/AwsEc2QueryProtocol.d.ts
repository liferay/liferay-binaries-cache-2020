import { AwsQueryProtocol } from "./AwsQueryProtocol";
/**
 * @alpha
 */
export declare class AwsEc2QueryProtocol extends AwsQueryProtocol {
}
