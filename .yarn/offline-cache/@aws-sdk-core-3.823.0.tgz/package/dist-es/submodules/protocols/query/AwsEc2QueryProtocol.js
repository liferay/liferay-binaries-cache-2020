import { AwsQueryProtocol } from "./AwsQueryProtocol";
export class AwsEc2QueryProtocol extends AwsQueryProtocol {
}
