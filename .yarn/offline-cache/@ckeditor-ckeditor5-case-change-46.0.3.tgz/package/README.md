CKEditor&nbsp;5 Case change feature
===================================

[![npm version](https://badge.fury.io/js/%40ckeditor%2Fckeditor5-case-change.svg)](https://www.npmjs.com/package/@ckeditor/ckeditor5-case-change)

This package contains the Case change feature for CKEditor&nbsp;5. It lets you quickly change the letter case of the selected content. Use it to format part of the text like a title or change it to all-caps and back.

This is a premium feature. Sign up for a [free non-commitment 14-day trial](https://portal.ckeditor.com/checkout?plan=free), or see: [https://ckeditor.com/pricing](https://ckeditor.com/pricing) for more information.

## Installation

This plugin is part of the `ckeditor5-premium-features` package. Install the whole package to use it.

```bash
npm install ckeditor5-premium-features
```

## Create free account

If you want to check full CKEditor&nbsp;5 capabilities, sign up for a [free non-commitment 14-day trial](https://portal.ckeditor.com/checkout?plan=free).

## Demo

Check out the [demo in the Case change feature](https://ckeditor.com/docs/ckeditor5/latest/features/case-change.html#demo) feature guide.

## Documentation

See the [`@ckeditor/ckeditor5-case-change` package](https://ckeditor.com/docs/ckeditor5/latest/api/case-change.html) page in the [CKEditor&nbsp;5 documentation](https://ckeditor.com/docs/ckeditor5/latest/) as well as the [Case change](https://ckeditor.com/docs/ckeditor5/latest/features/case-change.html) feature guide.

## Getting support

The CKEditor&nbsp;5 Case change feature comes with outstanding support from a dedicated team of customer care specialists, QA engineers, and CKEditor&nbsp;5 developers. The team will gladly assist you in all aspects from setting up your account to integrating the CKEditor&nbsp;5 Case change feature with your application.

As a licensed CKEditor&nbsp;5 Case change feature user you can report bugs and request features directly through the CKEditor Ecosystem customer dashboard.

## License

**CKEditor&nbsp;5 Case change feature** (https://ckeditor.com/ckeditor-5/)<br>
Copyright (c) 2003–2025, [CKSource Holding sp. z o.o.](https://cksource.com)  All rights reserved.

CKEditor&nbsp;5 Case change feature is licensed under a commercial license and is protected by copyright law. For more information, see: [https://ckeditor.com/pricing](https://ckeditor.com/pricing).

### Trademarks

**CKEditor** is a trademark of [CKSource Holding sp. z o.o.](https://cksource.com)  All other brand and product names are trademarks, registered trademarks, or service marks of their respective holders.
