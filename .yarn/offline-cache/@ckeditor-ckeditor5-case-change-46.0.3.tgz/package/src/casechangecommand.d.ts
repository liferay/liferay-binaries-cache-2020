/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module case-change/casechangecommand
 * @publicApi
 */
import { Command, type Editor } from 'ckeditor5/src/core.js';
/**
 * This command changes the case of the selected text.
 */
export declare class CaseChangeCommand extends Command {
    /**
     * Creates a new `CaseChangeCommand` instance.
     *
     * @param editor The editor on which this command will be used.
     */
    constructor(editor: Editor, transformCallback: CaseChangeTransformCallback);
    /**
     * Transforms the selected text with the defined case change callback.
     *
     * @fires execute
     */
    execute(): void;
    /**
     * @inheritDoc
     */
    refresh(): void;
}
export type CaseChangeTransformCallback = (arg: string) => string;
