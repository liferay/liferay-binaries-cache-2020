/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module case-change/casechange
 * @publicApi
 */
import { Plugin } from 'ckeditor5/src/core.js';
import { CaseChangeEditing } from './casechangeediting.js';
import { CaseChangeUI } from './casechangeui.js';
/**
 * The case change feature.
 *
 * For a detailed overview, check the {@glink features/case-change Case change} feature guide.
 */
export declare class CaseChange extends Plugin {
    /**
     * @inheritDoc
     */
    static get requires(): readonly [typeof CaseChangeEditing, typeof CaseChangeUI];
    /**
     * @inheritDoc
     */
    static get pluginName(): "CaseChange";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
}
/**
 * The configuration of the {@link module:case-change/casechange~CaseChange case change feature}.
 *
 * ```ts
 * ClassicEditor
 * 	.create( editorElement, {
 * 		caseChange:  ... // Case change feature configuration.
 * 	} )
 * 	.then( /* ... *\/ )
 * 	.catch( /* ... *\/ );
 * ```
 *
 * See {@link module:core/editor/editorconfig~EditorConfig all editor options}.
 */
export interface CaseChangeConfig {
    /**
     * Title case configuration.
     */
    titleCase?: CaseChangeTitleCaseConfig;
}
/**
 * Title case configuration.
 * It allows setting words that should not be capitalized when formatted as title case.
 *
 * ```ts
 * ClassicEditor
 * 	.create( editorElement, {
 * 		caseChange: {
 * 			titleCase {
 *				excludeWords: [ 'a', 'an', 'the' ]
 * 			}
 *		}
 * 	} )
 * 	.then( /* ... *\/ )
 * 	.catch( /* ... *\/ );
 * ```
 *
 * ```ts
 * ClassicEditor
 * 	.create( editorElement, {
 * 		caseChange: {
 *			titleCase {
 *				excludeWords: ( word ) => [ 'a', 'an', 'the' ].includes( word )
 * 			}
 *		}
 * 	} )
 * 	.then( /* ... *\/ )
 * 	.catch( /* ... *\/ );
 * ```
 *
 * ```ts
 * ClassicEditor
 * 	.create( editorElement, {
 * 		caseChange: {
 *			titleCase {
 *				excludeWords: ( word, { wordIndex } ) => wordIndex > 0 && [ 'a', 'an', 'the' ].includes( word )
 * 			}
 *		}
 * 	} )
 * 	.then( /* ... *\/ )
 * 	.catch( /* ... *\/ );
 * ```
 *
 * See {@link module:core/editor/editorconfig~EditorConfig all editor options}.
 */
export interface CaseChangeTitleCaseConfig {
    /**
     * Words which should not be capitalized.
     */
    excludeWords?: Array<string> | CaseChangeExcludeWordsCallback;
}
/**
 * The exclude word callback.
 */
export type CaseChangeExcludeWordsCallback = (word: string, context: CaseChangeExcludeWordsCallbackContext) => boolean;
/**
 * The exclude word callback context.
 */
export interface CaseChangeExcludeWordsCallbackContext {
    /**
     * The offset in the text where the given word starts.
     */
    charOffset: number;
    /**
     * The word index in the given text.
     */
    wordIndex: number;
    /**
     * The block text.
     */
    blockText: string;
}
