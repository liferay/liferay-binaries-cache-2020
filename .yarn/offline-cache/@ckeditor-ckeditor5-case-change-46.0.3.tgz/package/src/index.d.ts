/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module case-change
 */
export { CaseChange, type CaseChangeConfig, type CaseChangeTitleCaseConfig, type CaseChangeExcludeWordsCallback, type CaseChangeExcludeWordsCallbackContext } from './casechange.js';
export { CaseChangeEditing } from './casechangeediting.js';
export { CaseChangeUI } from './casechangeui.js';
export { CaseChangeCommand } from './casechangecommand.js';
export type { CaseChangeTransformCallback } from './casechangecommand.js';
import './augmentation.js';
