/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x4f96(_0x5cae61,_0x353ac6){var _0x16f360=_0x16f3();return _0x4f96=function(_0x4f9676,_0x50e95b){_0x4f9676=_0x4f9676-0x1bf;var _0x57f12e=_0x16f360[_0x4f9676];return _0x57f12e;},_0x4f96(_0x5cae61,_0x353ac6);}(function(_0x61e11a,_0x2b618c){var _0x4c43d2=_0x4f96,_0x37964c=_0x61e11a();while(!![]){try{var _0x28053c=parseInt(_0x4c43d2(0x1bf))/0x1+-parseInt(_0x4c43d2(0x1c8))/0x2*(parseInt(_0x4c43d2(0x1c5))/0x3)+parseInt(_0x4c43d2(0x1c9))/0x4*(-parseInt(_0x4c43d2(0x1c2))/0x5)+parseInt(_0x4c43d2(0x1c1))/0x6*(parseInt(_0x4c43d2(0x1c4))/0x7)+-parseInt(_0x4c43d2(0x1c3))/0x8*(-parseInt(_0x4c43d2(0x1c0))/0x9)+parseInt(_0x4c43d2(0x1c6))/0xa+-parseInt(_0x4c43d2(0x1ca))/0xb*(parseInt(_0x4c43d2(0x1c7))/0xc);if(_0x28053c===_0x2b618c)break;else _0x37964c['push'](_0x37964c['shift']());}catch(_0x453ff1){_0x37964c['push'](_0x37964c['shift']());}}}(_0x16f3,0xa35bc));import{CKEditorError as _0x2fadb4}from'ckeditor5/src/utils.js';function _0x16f3(){var _0x72c5ad=['249758OuDHgp','2727tPifiY','6aJGvnI','5qzkIlw','11416ryLxeQ','6272854tqWenm','8769HzSKjY','1051570RtPHKa','325104qVkwNi','282uZRgla','2191900lpopVv','22ovDwTz'];_0x16f3=function(){return _0x72c5ad;};return _0x16f3();}