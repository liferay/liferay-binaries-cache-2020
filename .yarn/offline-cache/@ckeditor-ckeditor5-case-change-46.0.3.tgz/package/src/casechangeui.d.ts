/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module case-change/casechangeui
 * @publicApi
 */
import { Plugin } from 'ckeditor5/src/core.js';
/**
 * The case change UI plugin.
 */
export declare class CaseChangeUI extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "CaseChangeUI";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    init(): void;
    /**
     * @inheritDoc
     */
    destroy(): void;
}
