/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x5d72c3=_0x4393;(function(_0x36fd2d,_0x3b6a85){var _0x4ed471=_0x4393,_0x39f504=_0x36fd2d();while(!![]){try{var _0x379c31=parseInt(_0x4ed471(0xbe))/0x1*(parseInt(_0x4ed471(0xba))/0x2)+parseInt(_0x4ed471(0xbb))/0x3+-parseInt(_0x4ed471(0xbf))/0x4+parseInt(_0x4ed471(0xb9))/0x5*(parseInt(_0x4ed471(0xb4))/0x6)+-parseInt(_0x4ed471(0xc0))/0x7*(-parseInt(_0x4ed471(0xbc))/0x8)+parseInt(_0x4ed471(0xb5))/0x9+-parseInt(_0x4ed471(0xb6))/0xa;if(_0x379c31===_0x3b6a85)break;else _0x39f504['push'](_0x39f504['shift']());}catch(_0x40f6b6){_0x39f504['push'](_0x39f504['shift']());}}}(_0x1429,0xb8418));import{Plugin as _0x1c9550}from'ckeditor5/src/core.js';import{CaseChangeEditing as _0x3e4a16}from'./casechangeediting.js';import{CaseChangeUI as _0xde3182}from'./casechangeui.js';function _0x4393(_0x1650ee,_0x27e75c){var _0x142921=_0x1429();return _0x4393=function(_0x4393ae,_0x1192ab){_0x4393ae=_0x4393ae-0xb4;var _0x50c74e=_0x142921[_0x4393ae];return _0x50c74e;},_0x4393(_0x1650ee,_0x27e75c);}function _0x1429(){var _0x5006f1=['1eHrQWP','283640CgWIYV','1278550OrjUup','pluginName','CaseChange','7545606jYrnCx','1134648yOfnNT','26780150cuxjbx','isOfficialPlugin','isPremiumPlugin','5aopjkn','1139346uJInpD','2459073mkjiss','32cYGMdg','requires'];_0x1429=function(){return _0x5006f1;};return _0x1429();}export class CaseChange extends _0x1c9550{static get[_0x5d72c3(0xbd)](){return[_0x3e4a16,_0xde3182];}static get[_0x5d72c3(0xc1)](){var _0x49d709=_0x5d72c3;return _0x49d709(0xc2);}static get[_0x5d72c3(0xb7)](){return!0x0;}static get[_0x5d72c3(0xb8)](){return!0x0;}}