/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x452696,_0x56eff2){var _0x3c9ff7=_0x1a8e,_0x517aeb=_0x452696();while(!![]){try{var _0x7b3400=parseInt(_0x3c9ff7(0x15c))/0x1+parseInt(_0x3c9ff7(0x156))/0x2+parseInt(_0x3c9ff7(0x158))/0x3+-parseInt(_0x3c9ff7(0x15a))/0x4*(-parseInt(_0x3c9ff7(0x159))/0x5)+parseInt(_0x3c9ff7(0x15d))/0x6+parseInt(_0x3c9ff7(0x155))/0x7*(parseInt(_0x3c9ff7(0x15b))/0x8)+-parseInt(_0x3c9ff7(0x157))/0x9;if(_0x7b3400===_0x56eff2)break;else _0x517aeb['push'](_0x517aeb['shift']());}catch(_0x5e4883){_0x517aeb['push'](_0x517aeb['shift']());}}}(_0x5979,0xb6f33));export{CaseChange}from'./casechange.js';export{CaseChangeEditing}from'./casechangeediting.js';export{CaseChangeUI}from'./casechangeui.js';function _0x1a8e(_0x12d8bd,_0xfef0e){var _0x597930=_0x5979();return _0x1a8e=function(_0x1a8e5f,_0x39e2cb){_0x1a8e5f=_0x1a8e5f-0x155;var _0x335ad1=_0x597930[_0x1a8e5f];return _0x335ad1;},_0x1a8e(_0x12d8bd,_0xfef0e);}function _0x5979(){var _0x46fc8b=['1532muuDqS','9876648vmXcIw','143127qZcKsn','3144588imZIjZ','7XQUICg','2536322HdgVhj','30123054lYczTH','746625FvtsJw','8845KvRSes'];_0x5979=function(){return _0x46fc8b;};return _0x5979();}export{CaseChangeCommand}from'./casechangecommand.js';import'./augmentation.js';