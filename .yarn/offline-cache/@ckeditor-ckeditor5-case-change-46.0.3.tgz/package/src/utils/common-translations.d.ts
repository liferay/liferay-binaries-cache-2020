/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module case-change/utils/common-translations
 */
import type { Locale } from 'ckeditor5/src/utils.js';
export declare function getTranslation(locale: Locale, id: string, ...args: Array<any>): string;
