/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
export function getTranslation(_0x4aab2b,_0x373d70,..._0x4ea212){const t=_0x4aab2b['t'];switch(_0x373d70){case'Case\x20change':return t('Case\x20change');case'UPPERCASE':return t('UPPERCASE');case'lowercase':return t('lowercase');case'Title\x20Case':return t('Title\x20Case');case'Change\x20text\x20case':return t('Change\x20text\x20case');case'Changed\x20case\x20to\x20%0':return t('Changed\x20case\x20to\x20%0',..._0x4ea212);default:return _0x373d70;}}