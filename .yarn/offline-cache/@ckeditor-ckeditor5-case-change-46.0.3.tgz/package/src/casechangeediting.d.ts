/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module case-change/casechangeediting
 */
import { Plugin } from 'ckeditor5/src/core.js';
/**
 * The case change editing feature. It introduces three commands: `changeCaseUpper`, `changeCaseLower`, and `changeCaseTitle`.
 */
export declare class CaseChangeEditing extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "CaseChangeEditing";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    init(): void;
    /**
     * @inheritDoc
     */
    afterInit(): void;
}
