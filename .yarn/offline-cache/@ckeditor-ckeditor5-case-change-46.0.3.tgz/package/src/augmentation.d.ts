/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import type { CaseChange, CaseChangeEditing, CaseChangeUI, CaseChangeCommand, CaseChangeConfig } from './index.js';
declare module '@ckeditor/ckeditor5-core' {
    interface EditorConfig {
        caseChange?: CaseChangeConfig;
    }
    interface PluginsMap {
        [CaseChange.pluginName]: CaseChange;
        [CaseChangeEditing.pluginName]: CaseChangeEditing;
        [CaseChangeUI.pluginName]: CaseChangeUI;
    }
    interface CommandsMap {
        caseChange: CaseChangeCommand;
    }
}
