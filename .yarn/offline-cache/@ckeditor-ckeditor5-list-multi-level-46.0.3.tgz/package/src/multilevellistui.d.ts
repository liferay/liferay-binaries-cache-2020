/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module list-multi-level/multilevellistui
 */
import { Plugin } from 'ckeditor5/src/core.js';
/**
 * The multi-level list UI plugin. It introduces the `multiLevelList` toolbar button that allows users
 * to apply user-defined list markers. The default style is `legal` numbering.
 */
export declare class MultiLevelListUI extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "MultiLevelListUI";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    init(): void;
    /**
     * @inheritDoc
     */
    destroy(): void;
}
