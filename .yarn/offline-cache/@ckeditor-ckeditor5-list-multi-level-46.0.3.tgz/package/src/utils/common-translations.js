/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
export function getTranslation(_0x9a9e06,_0x4cd466){const _0x1aae17=_0x9a9e06['t'],t=_0x9a9e06['t'];switch(_0x4cd466){case'Start\x20at':return _0x1aae17('Start\x20at');case'Start\x20index\x20must\x20be\x20greater\x20than\x200.':return _0x1aae17('Start\x20index\x20must\x20be\x20greater\x20than\x200.');case'Invalid\x20start\x20index\x20value.':return _0x1aae17('Invalid\x20start\x20index\x20value.');case'List\x20properties':return _0x1aae17('List\x20properties');case'Multi-level\x20List':return t('Multi-level\x20List');case'Multi-level\x20list\x20styles\x20toolbar':return t('Multi-level\x20list\x20styles\x20toolbar');default:return _0x4cd466;}}