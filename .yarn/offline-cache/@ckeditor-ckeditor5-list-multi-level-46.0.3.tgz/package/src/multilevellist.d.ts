/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module list-multi-level/multilevellist
 * @publicApi
 */
import { Plugin } from 'ckeditor5/src/core.js';
import { MultiLevelListEditing } from './multilevellistediting.js';
import { MultiLevelListUI } from './multilevellistui.js';
import '../theme/multilevellist.css';
/**
 * The Multi-level List feature.
 *
 * For a detailed overview, check the {@glink features/lists/multi-level-lists Multi-level list} feature guide.
 */
export declare class MultiLevelList extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "MultiLevelList";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    static get requires(): readonly [typeof MultiLevelListEditing, typeof MultiLevelListUI];
}
/**
 * The configuration of the {@link module:list-multi-level/multilevellist~MultiLevelList multi-level list feature}.
 *
 * ```ts
 * ClassicEditor
 * 	.create( editorElement, {
 * 		listMultiLevel:  ... // Multi-level list feature configuration.
 * 	} )
 * 	.then( /* ... *\/ )
 * 	.catch( /* ... *\/ );
 * ```
 *
 * See {@link module:core/editor/editorconfig~EditorConfig all editor options}.
 */
export interface MultiLevelListConfig {
    /**
     * Custom list definitions configuration.
     */
    listDefinitions?: Array<MultiLevelListDefinition>;
}
/**
 * Multi-level list definition config.
 * It allows to define custom multi-level list configurations.
 */
export interface MultiLevelListDefinition {
    /**
     * The type of multi-level list.
     */
    listType: 'customNumbered' | 'customBulleted';
    /**
     * The name of the list marker style. This is used as a parameter when the command is executed.
     */
    listMarkerStyle: string;
    /**
     * The name of the CSS class to add to the list element.
     */
    className: string;
    /**
     * An array of definitions for a multi-level list. Each definition represents a list indentation level, starting from 0.
     */
    listMarkers: Array<MultiLevelListMarkerDefinition>;
}
/**
 * A multi-level list marker definition.
 */
export interface MultiLevelListMarkerDefinition {
    /**
     * If true, the full marker path is displayed, e.g. '1.2.4.' If false, only the current level number is displayed, e.g. '4.'.
     */
    showMarkerPath?: boolean;
    /**
     * The list marker pattern. This defines how the list marker is displayed.
     */
    marker: MultiLevelListMarkerPattern;
}
/**
 * The list marker pattern. Can be a string used in bulleted lists, e.g. '*',
 * or a function that returns a string representation of the marker.
 */
export type MultiLevelListMarkerPattern = string | ((value: number) => string);
