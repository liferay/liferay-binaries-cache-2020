/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module list-multi-level/multilevellistcommand
 * @publicApi
 */
import { Command, type Editor } from 'ckeditor5/src/core.js';
import type { MultiLevelListDefinition } from './multilevellist.js';
/**
 * The multi-level list command. It changes `listMarkerStyle` attribute of the selected list items, letting the user
 * choose styles for the list item markers. It also changes `listType` attribute to `customNumbered` or `customBulleted`.
 */
export declare class MultiLevelListCommand extends Command {
    /**
     * If the first selected block is a list item, its `listMarkerStyle` value is set in this property.
     *
     * @observable
     * @readonly
     */
    value: string | null;
    /**
     * The default type of the list marker style.
     */
    readonly defaultListMarkerStyle: string;
    /**
     * Creates an instance of the command.
     *
     * @param editor The editor instance.
     * @param defaultListMarkerStyle The list marker style that will be used by default if the value was not specified
     * during the command execution.
     * @param listDefinitions The list of multi-level list definitions.
     */
    constructor(editor: Editor, defaultListMarkerStyle: string, listDefinitions: Array<MultiLevelListDefinition>);
    /**
     * @inheritDoc
     */
    refresh(): void;
    /**
     * Executes the command.
     *
     * @fires execute
     * @param options.listMarkerStyle The multi-level list marker style. If not specified, the default style will be applied.
     */
    execute(options?: {
        listMarkerStyle?: string;
    }): void;
}
