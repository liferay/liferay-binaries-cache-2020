/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x41ae4b=_0x4f89;(function(_0x429b1d,_0x25acb7){var _0x4f7946=_0x4f89,_0xb0d291=_0x429b1d();while(!![]){try{var _0x43bf61=parseInt(_0x4f7946(0x1a2))/0x1+parseInt(_0x4f7946(0x1a6))/0x2*(parseInt(_0x4f7946(0x1a7))/0x3)+-parseInt(_0x4f7946(0x1a4))/0x4+-parseInt(_0x4f7946(0x1aa))/0x5*(-parseInt(_0x4f7946(0x1a3))/0x6)+-parseInt(_0x4f7946(0x1a0))/0x7*(-parseInt(_0x4f7946(0x1a9))/0x8)+-parseInt(_0x4f7946(0x1a8))/0x9*(parseInt(_0x4f7946(0x1a5))/0xa)+-parseInt(_0x4f7946(0x1ab))/0xb;if(_0x43bf61===_0x25acb7)break;else _0xb0d291['push'](_0xb0d291['shift']());}catch(_0x5e8b92){_0xb0d291['push'](_0xb0d291['shift']());}}}(_0x5a8f,0x8da02));import{Plugin as _0x5d95fe}from'ckeditor5/src/core.js';function _0x4f89(_0x4797a0,_0x4578e9){var _0x5a8f9e=_0x5a8f();return _0x4f89=function(_0x4f8986,_0x51391c){_0x4f8986=_0x4f8986-0x19f;var _0x1ede16=_0x5a8f9e[_0x4f8986];return _0x1ede16;},_0x4f89(_0x4797a0,_0x4578e9);}import{MultiLevelListEditing as _0x5dd05c}from'./multilevellistediting.js';import{MultiLevelListUI as _0x1f7ece}from'./multilevellistui.js';function _0x5a8f(){var _0x57796b=['6YxUYAl','2546144cgfquJ','7326570qyXVRw','2320226zRYmDG','3gvwhGH','9zQCHnk','24ASbpaa','3284595jWcNZN','9349824rNpbrA','requires','isOfficialPlugin','isPremiumPlugin','MultiLevelList','695821kAbbzr','pluginName','684034fhQkLY'];_0x5a8f=function(){return _0x57796b;};return _0x5a8f();}import'../theme/multilevellist.css';export class MultiLevelList extends _0x5d95fe{static get[_0x41ae4b(0x1a1)](){var _0x5d2852=_0x41ae4b;return _0x5d2852(0x19f);}static get[_0x41ae4b(0x1ad)](){return!0x0;}static get[_0x41ae4b(0x1ae)](){return!0x0;}static get[_0x41ae4b(0x1ac)](){return[_0x5dd05c,_0x1f7ece];}}