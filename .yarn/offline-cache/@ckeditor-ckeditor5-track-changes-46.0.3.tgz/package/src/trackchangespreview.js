/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0xe96085=_0x420c;(function(_0x35c212,_0x29dc3a){const _0x29612d=_0x420c,_0x5dcfd8=_0x35c212();while(!![]){try{const _0x5e1239=parseInt(_0x29612d(0x10b))/0x1*(-parseInt(_0x29612d(0x103))/0x2)+-parseInt(_0x29612d(0x102))/0x3*(-parseInt(_0x29612d(0xf8))/0x4)+parseInt(_0x29612d(0x106))/0x5*(parseInt(_0x29612d(0xf9))/0x6)+parseInt(_0x29612d(0x109))/0x7*(parseInt(_0x29612d(0x104))/0x8)+-parseInt(_0x29612d(0xf2))/0x9+-parseInt(_0x29612d(0x108))/0xa*(parseInt(_0x29612d(0xf4))/0xb)+-parseInt(_0x29612d(0xf3))/0xc*(-parseInt(_0x29612d(0xff))/0xd);if(_0x5e1239===_0x29dc3a)break;else _0x5dcfd8['push'](_0x5dcfd8['shift']());}catch(_0x32ef24){_0x5dcfd8['push'](_0x5dcfd8['shift']());}}}(_0xf7d5,0x9f5bf));import{Plugin as _0x4caeed}from'ckeditor5/src/core.js';import{Dialog as _0x31c186}from'ckeditor5/src/ui.js';import{TrackChangesData as _0x4f13e1}from'./trackchangesdata.js';function _0x420c(_0x4b35b3,_0x11d9cf){const _0xf7d567=_0xf7d5();return _0x420c=function(_0x420c9c,_0xfe632a){_0x420c9c=_0x420c9c-0xf2;let _0x50028c=_0xf7d567[_0x420c9c];return _0x50028c;},_0x420c(_0x4b35b3,_0x11d9cf);}import{PreviewFinalContentCommand as _0x555472}from'./commands/previewfinalcontentcommand.js';import'../theme/trackchangespreview.css';function _0xf7d5(){const _0x1e0194=['define','pluginName','previewFinalContent','isPremiumPlugin','260mKQOtS','config','requires','42BkAEtt','14IpNDim','1391944TlGECk','isOfficialPlugin','25HHYCZd','trackChanges.preview.renderFunction','448270ESQWNx','28PzLpvJ','appendChild','29948iSKdOk','10101969lpfNCl','809448RWfLei','77hCFwML','editor','add','commands','47224exgHxn','105918wEJBEv','TrackChangesPreview'];_0xf7d5=function(){return _0x1e0194;};return _0xf7d5();}export class TrackChangesPreview extends _0x4caeed{static get[_0xe96085(0x101)](){return[_0x4f13e1,_0x31c186];}static get[_0xe96085(0xfc)](){const _0x4fcfad=_0xe96085;return _0x4fcfad(0xfa);}static get[_0xe96085(0x105)](){return!0x0;}static get[_0xe96085(0xfe)](){return!0x0;}constructor(_0x1abd8f){const _0x1b7325=_0xe96085;super(_0x1abd8f),_0x1abd8f[_0x1b7325(0xf7)][_0x1b7325(0xf6)](_0x1b7325(0xfd),new _0x555472(this[_0x1b7325(0xf5)])),_0x1abd8f[_0x1b7325(0x100)][_0x1b7325(0xfb)](_0x1b7325(0x107),(_0x296c70,_0x519f17)=>{const _0x55a1ac=_0x1b7325;for(const _0x472cf2 of _0x519f17)_0x296c70[_0x55a1ac(0x10a)](_0x472cf2);});}}