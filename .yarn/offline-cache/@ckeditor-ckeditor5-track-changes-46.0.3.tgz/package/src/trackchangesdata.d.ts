/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module track-changes/trackchangesdata
 * @publicApi
 */
import { Plugin, type Editor } from 'ckeditor5/src/core.js';
import { TrackChangesEditing } from './trackchangesediting.js';
/**
 * This plugin returns the editor data with accepted or discarded suggestions without modifying the editor content.
 */
export declare class TrackChangesData extends Plugin {
    /**
     * @inheritDoc
     */
    static get requires(): readonly [typeof TrackChangesEditing];
    /**
     * @inheritDoc
     */
    static get pluginName(): "TrackChangesData";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    init(): void;
    /**
     * Returns the editor data with all the suggestions accepted.
     *
     * @param options Options for {@link module:engine/controller/datacontroller~DataController#get}.
     * @returns A promise which resolves with the output data.
     */
    getDataWithAcceptedSuggestions(options?: Record<string, unknown>): Promise<string | Record<string, string>>;
    /**
     * Returns the editor data with all the suggestions discarded.
     *
     * @param options Options for {@link module:engine/controller/datacontroller~DataController#get}.
     * @returns A promise which resolves with the output data.
     */
    getDataWithDiscardedSuggestions(options: Record<string, unknown>): Promise<string | Record<string, string>>;
}
/**
 * Fake plugin to avoid UBB requests from virtual editor.
 * License key checker knows not to send the request when this plugin is loaded.
 */
export declare class TrackChangesDataGetter extends Plugin {
    result: string;
    static get pluginName(): "TrackChangesDataGetter";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    constructor(editor: Editor);
    init(): void;
}
