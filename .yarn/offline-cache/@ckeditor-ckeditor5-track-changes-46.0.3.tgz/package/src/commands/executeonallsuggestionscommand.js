/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x1e46a8=_0x1ba2;(function(_0x4d527f,_0x5e6706){const _0x485beb=_0x1ba2,_0x3f60a1=_0x4d527f();while(!![]){try{const _0x19336e=parseInt(_0x485beb(0x75))/0x1*(-parseInt(_0x485beb(0x7d))/0x2)+-parseInt(_0x485beb(0x7c))/0x3*(parseInt(_0x485beb(0x6d))/0x4)+-parseInt(_0x485beb(0x71))/0x5+-parseInt(_0x485beb(0x72))/0x6*(-parseInt(_0x485beb(0x70))/0x7)+parseInt(_0x485beb(0x7f))/0x8*(-parseInt(_0x485beb(0x78))/0x9)+-parseInt(_0x485beb(0x7e))/0xa+parseInt(_0x485beb(0x83))/0xb;if(_0x19336e===_0x5e6706)break;else _0x3f60a1['push'](_0x3f60a1['shift']());}catch(_0x5e3dcb){_0x3f60a1['push'](_0x3f60a1['shift']());}}}(_0x69d0,0x9383a));import{Command as _0x6f3ca}from'ckeditor5/src/core.js';function _0x69d0(){const _0x73175a=['model','from','34120867DMCuhO','some','refresh','4YXSbqF','isEnabled','editor','406434XXbfCj','440175TTkuUO','6poAFkB','_suggestions','values','437302tbOqjy','isInContent','_isEnabledBasedOnSelection','99IaIFch','canEditAt','execute','getRanges','1790787zXsAYL','2ndygZV','10116140ERGpWv','306808IHgKAl','_command'];_0x69d0=function(){return _0x73175a;};return _0x69d0();}import{sortSuggestions as _0x39b524,executeCommandForSuggestions as _0x710e1}from'../utils/utils.js';function _0x1ba2(_0x1b3af1,_0x35beca){const _0x69d071=_0x69d0();return _0x1ba2=function(_0x1ba27a,_0x7d1fbc){_0x1ba27a=_0x1ba27a-0x6b;let _0x283746=_0x69d071[_0x1ba27a];return _0x283746;},_0x1ba2(_0x1b3af1,_0x35beca);}export class ExecuteOnAllSuggestionsCommand extends _0x6f3ca{[_0x1e46a8(0x80)];[_0x1e46a8(0x73)];constructor(_0x1b7bcf,_0xbe58b9,_0x5525c5){const _0xb784a5=_0x1e46a8;super(_0x1b7bcf),this[_0xb784a5(0x80)]=_0xbe58b9,this[_0xb784a5(0x73)]=_0x5525c5,this[_0xb784a5(0x6c)](),this[_0xb784a5(0x77)]=!0x1;}[_0x1e46a8(0x6c)](){const _0x509b62=_0x1e46a8,_0x2353c9=Array[_0x509b62(0x82)](this[_0x509b62(0x73)][_0x509b62(0x74)]())[_0x509b62(0x6b)](_0x4bb6b9=>_0x4bb6b9[_0x509b62(0x76)]);this[_0x509b62(0x6e)]=this[_0x509b62(0x80)][_0x509b62(0x6e)]&&_0x2353c9;}[_0x1e46a8(0x7a)](){const _0x42d202=_0x1e46a8,_0x3ee9d3=_0x39b524(Array[_0x42d202(0x82)](this[_0x42d202(0x73)][_0x42d202(0x74)]()));for(const _0x177f46 of _0x3ee9d3){const _0x545127=_0x177f46[_0x42d202(0x7b)]();if(!this[_0x42d202(0x6f)][_0x42d202(0x81)][_0x42d202(0x79)](_0x545127))return;}_0x710e1(this[_0x42d202(0x6f)][_0x42d202(0x81)],this[_0x42d202(0x80)],_0x3ee9d3);}}