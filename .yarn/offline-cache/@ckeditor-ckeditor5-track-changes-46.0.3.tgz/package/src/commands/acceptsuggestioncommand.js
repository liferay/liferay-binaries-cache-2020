/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x4f2636=_0x378b;function _0x1541(){const _0x2d48f4=['editor','plugins','66410zzXrSy','TrackChangesEditing','67220iBMDgP','acceptSuggestion','_suggestions','execute','isEnabled','40Ghltst','1167363ajppQs','60kGoHGp','model','1gGTjSS','track-changes-accept-suggestion-not-found','732000gmKYvW','1663096QEUuGD','1340148hEqFNB','get','canEditAt','refresh','556164MYOmeE','getRanges','_isEnabledBasedOnSelection'];_0x1541=function(){return _0x2d48f4;};return _0x1541();}(function(_0x2018db,_0x6edefa){const _0x1ba65b=_0x378b,_0x3727a1=_0x2018db();while(!![]){try{const _0x4d5a55=-parseInt(_0x1ba65b(0x7f))/0x1*(parseInt(_0x1ba65b(0x8c))/0x2)+-parseInt(_0x1ba65b(0x81))/0x3+parseInt(_0x1ba65b(0x7b))/0x4*(parseInt(_0x1ba65b(0x76))/0x5)+-parseInt(_0x1ba65b(0x83))/0x6+-parseInt(_0x1ba65b(0x87))/0x7+-parseInt(_0x1ba65b(0x82))/0x8+-parseInt(_0x1ba65b(0x7c))/0x9*(-parseInt(_0x1ba65b(0x7d))/0xa);if(_0x4d5a55===_0x6edefa)break;else _0x3727a1['push'](_0x3727a1['shift']());}catch(_0x416068){_0x3727a1['push'](_0x3727a1['shift']());}}}(_0x1541,0x1e76c));function _0x378b(_0x38dfed,_0x4f6fcb){const _0x154113=_0x1541();return _0x378b=function(_0x378b15,_0x367d03){_0x378b15=_0x378b15-0x75;let _0x498087=_0x154113[_0x378b15];return _0x498087;},_0x378b(_0x38dfed,_0x4f6fcb);}import{Command as _0x5ae3e0}from'ckeditor5/src/core.js';import{CKEditorError as _0x2b990f}from'ckeditor5/src/utils.js';export class AcceptSuggestionCommand extends _0x5ae3e0{[_0x4f2636(0x78)];constructor(_0x5e68dd,_0x269c83){const _0x2304fb=_0x4f2636;super(_0x5e68dd),this[_0x2304fb(0x78)]=_0x269c83,this[_0x2304fb(0x86)](),this[_0x2304fb(0x89)]=!0x1;}[_0x4f2636(0x86)](){const _0x4ab8a9=_0x4f2636;this[_0x4ab8a9(0x7a)]=!0x0;}[_0x4f2636(0x79)](_0x210281){const _0x1bd5f6=_0x4f2636,_0x57d830=this[_0x1bd5f6(0x78)][_0x1bd5f6(0x84)](_0x210281);if(!_0x57d830)throw new _0x2b990f(_0x1bd5f6(0x80),this);const _0x55ec01=_0x57d830[_0x1bd5f6(0x88)]();this[_0x1bd5f6(0x8a)][_0x1bd5f6(0x7e)][_0x1bd5f6(0x85)](_0x55ec01)&&this[_0x1bd5f6(0x8a)][_0x1bd5f6(0x8b)][_0x1bd5f6(0x84)](_0x1bd5f6(0x75))[_0x1bd5f6(0x77)](_0x57d830);}}