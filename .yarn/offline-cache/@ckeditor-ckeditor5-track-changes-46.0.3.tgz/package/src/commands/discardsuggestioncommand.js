/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x5100ec=_0x582c;(function(_0x32e129,_0x5a7009){const _0x24b4f8=_0x582c,_0x12cec6=_0x32e129();while(!![]){try{const _0x180a26=-parseInt(_0x24b4f8(0xc2))/0x1*(-parseInt(_0x24b4f8(0xc0))/0x2)+-parseInt(_0x24b4f8(0xcd))/0x3*(parseInt(_0x24b4f8(0xc7))/0x4)+parseInt(_0x24b4f8(0xcb))/0x5+parseInt(_0x24b4f8(0xbd))/0x6+parseInt(_0x24b4f8(0xc6))/0x7+parseInt(_0x24b4f8(0xc4))/0x8+-parseInt(_0x24b4f8(0xca))/0x9;if(_0x180a26===_0x5a7009)break;else _0x12cec6['push'](_0x12cec6['shift']());}catch(_0x22828d){_0x12cec6['push'](_0x12cec6['shift']());}}}(_0x2b15,0xeb262));import{Command as _0x27cb7c}from'ckeditor5/src/core.js';function _0x582c(_0x53c719,_0x2e7661){const _0x2b1528=_0x2b15();return _0x582c=function(_0x582cdc,_0x2fed91){_0x582cdc=_0x582cdc-0xb8;let _0x4eebe4=_0x2b1528[_0x582cdc];return _0x4eebe4;},_0x582c(_0x53c719,_0x2e7661);}import{CKEditorError as _0x21afff}from'ckeditor5/src/utils.js';export class DiscardSuggestionCommand extends _0x27cb7c{[_0x5100ec(0xc1)];constructor(_0x1b6b23,_0x97c1a6){const _0x96d915=_0x5100ec;super(_0x1b6b23),this[_0x96d915(0xc1)]=_0x97c1a6,this[_0x96d915(0xbf)](),this[_0x96d915(0xc3)]=!0x1;}[_0x5100ec(0xbf)](){const _0x15a2d7=_0x5100ec;this[_0x15a2d7(0xbc)]=!0x0;}[_0x5100ec(0xc5)](_0x35579c){const _0x5a472b=_0x5100ec,_0x2f2284=this[_0x5a472b(0xc1)][_0x5a472b(0xb8)](_0x35579c);if(!_0x2f2284)throw new _0x21afff(_0x5a472b(0xc8),this);const _0x2863a5=_0x2f2284[_0x5a472b(0xce)]();this[_0x5a472b(0xb9)][_0x5a472b(0xbb)][_0x5a472b(0xba)](_0x2863a5)&&this[_0x5a472b(0xb9)][_0x5a472b(0xcc)][_0x5a472b(0xb8)](_0x5a472b(0xc9))[_0x5a472b(0xbe)](_0x2f2284);}}function _0x2b15(){const _0x50f3df=['_isEnabledBasedOnSelection','14577464vIauWF','execute','4536266MwbCjO','37684voTUVr','track-changes-discard-suggestion-not-found','TrackChangesEditing','25632189gAlnAh','534715RKnmRS','plugins','90MiphwF','getRanges','get','editor','canEditAt','model','isEnabled','7438020DDgpgD','discardSuggestion','refresh','553974vUoKVw','_suggestions','1QcKHIz'];_0x2b15=function(){return _0x50f3df;};return _0x2b15();}