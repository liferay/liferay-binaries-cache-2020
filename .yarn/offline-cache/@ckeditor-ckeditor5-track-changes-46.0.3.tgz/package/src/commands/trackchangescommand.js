/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x2edfb0=_0xb2af;(function(_0x2aba2d,_0xcb404a){const _0x541dac=_0xb2af,_0x30efe8=_0x2aba2d();while(!![]){try{const _0x40f479=parseInt(_0x541dac(0x160))/0x1*(parseInt(_0x541dac(0x162))/0x2)+parseInt(_0x541dac(0x166))/0x3+parseInt(_0x541dac(0x16d))/0x4*(parseInt(_0x541dac(0x163))/0x5)+-parseInt(_0x541dac(0x16a))/0x6*(parseInt(_0x541dac(0x15d))/0x7)+-parseInt(_0x541dac(0x164))/0x8*(parseInt(_0x541dac(0x15a))/0x9)+-parseInt(_0x541dac(0x173))/0xa+parseInt(_0x541dac(0x15c))/0xb;if(_0x40f479===_0xcb404a)break;else _0x30efe8['push'](_0x30efe8['shift']());}catch(_0x296e7b){_0x30efe8['push'](_0x30efe8['shift']());}}}(_0x43ee,0xe2f8f));function _0xb2af(_0x1cbb86,_0x50f76a){const _0x43eeb9=_0x43ee();return _0xb2af=function(_0xb2af43,_0x43b0c4){_0xb2af43=_0xb2af43-0x15a;let _0x443461=_0x43eeb9[_0xb2af43];return _0x443461;},_0xb2af(_0x1cbb86,_0x50f76a);}import{Command as _0x2abe41}from'ckeditor5/src/core.js';export class TrackChangesCommand extends _0x2abe41{[_0x2edfb0(0x169)];constructor(_0x517678,_0x272681){const _0xfcd725=_0x2edfb0;super(_0x517678),this[_0xfcd725(0x169)]=_0x272681,this[_0xfcd725(0x16c)]=!0x1,this[_0xfcd725(0x15f)](),this[_0xfcd725(0x16e)]=!0x1;}[_0x2edfb0(0x15f)](){const _0x1604ba=_0x2edfb0;this[_0x1604ba(0x161)]=!0x0;}[_0x2edfb0(0x15b)](){const _0x3c2248=_0x2edfb0;this[_0x3c2248(0x16c)]=!this[_0x3c2248(0x16c)],this[_0x3c2248(0x16c)]?this[_0x3c2248(0x167)]():this[_0x3c2248(0x172)]();}[_0x2edfb0(0x167)](){const _0x27a1f9=_0x2edfb0;for(const _0x183194 of this[_0x27a1f9(0x16f)][_0x27a1f9(0x171)][_0x27a1f9(0x171)]())_0x183194[_0x27a1f9(0x15e)]&&!this[_0x27a1f9(0x169)][_0x27a1f9(0x165)](_0x183194)&&_0x183194[_0x27a1f9(0x168)](_0x27a1f9(0x16b));}[_0x2edfb0(0x172)](){const _0x4d5b4f=_0x2edfb0;for(const _0x67736b of this[_0x4d5b4f(0x16f)][_0x4d5b4f(0x171)][_0x4d5b4f(0x171)]())_0x67736b[_0x4d5b4f(0x15e)]&&!this[_0x4d5b4f(0x169)][_0x4d5b4f(0x165)](_0x67736b)&&_0x67736b[_0x4d5b4f(0x170)](_0x4d5b4f(0x16b));}}function _0x43ee(){const _0x265b11=['_enableCommands','6901250loetTJ','1162674mrCmHW','execute','6781104KMFPXJ','1630874eDrwdM','affectsData','refresh','1gXazzV','isEnabled','1301628xFbWsI','415mjZOgp','64tnaBCZ','has','4607988RnplqK','_disableUnsupportedCommands','forceDisabled','_enabledCommands','6ZhySiR','TrackChangesCommand','value','4000LfBcDp','_isEnabledBasedOnSelection','editor','clearForceDisabled','commands'];_0x43ee=function(){return _0x265b11;};return _0x43ee();}