/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x3e0b(){const _0x80790b=['_suggestions','canEditAt','values','editor','24NnymHw','130MBFxdc','refresh','_command','_selectedSuggestions','document','execute','776047TyYVtJ','selection','1138764BxFTeM','413IMUfdz','from','34302BgwdvT','_isEnabledBasedOnSelection','5294515GXuORP','118652tmtaYW','8rGwVVE','size','136944cneOSC','getRanges','5559336mYNcMm','model','isEnabled'];_0x3e0b=function(){return _0x80790b;};return _0x3e0b();}const _0x4405df=_0xe9f1;(function(_0x38a16e,_0x3f2d9b){const _0x4db958=_0xe9f1,_0x2ddf0c=_0x38a16e();while(!![]){try{const _0x2f0963=parseInt(_0x4db958(0x7c))/0x1+parseInt(_0x4db958(0x84))/0x2*(parseInt(_0x4db958(0x75))/0x3)+-parseInt(_0x4db958(0x6c))/0x4+-parseInt(_0x4db958(0x83))/0x5+-parseInt(_0x4db958(0x81))/0x6*(parseInt(_0x4db958(0x7f))/0x7)+parseInt(_0x4db958(0x6a))/0x8*(-parseInt(_0x4db958(0x6e))/0x9)+parseInt(_0x4db958(0x76))/0xa*(parseInt(_0x4db958(0x7e))/0xb);if(_0x2f0963===_0x3f2d9b)break;else _0x2ddf0c['push'](_0x2ddf0c['shift']());}catch(_0x40d7df){_0x2ddf0c['push'](_0x2ddf0c['shift']());}}}(_0x3e0b,0x85de1));import{Command as _0x47c262}from'ckeditor5/src/core.js';import{sortSuggestions as _0x53eac3,getSelectedSuggestions as _0x202ff7,executeCommandForSuggestions as _0x4db801}from'../utils/utils.js';function _0xe9f1(_0x53505e,_0x101eb0){const _0x3e0bd4=_0x3e0b();return _0xe9f1=function(_0xe9f1eb,_0x2fc65a){_0xe9f1eb=_0xe9f1eb-0x6a;let _0x204d53=_0x3e0bd4[_0xe9f1eb];return _0x204d53;},_0xe9f1(_0x53505e,_0x101eb0);}export class ExecuteOnSelectedSuggestionsCommand extends _0x47c262{[_0x4405df(0x78)];[_0x4405df(0x71)];[_0x4405df(0x79)];constructor(_0x28df55,_0x560870,_0x552f26){const _0xb176dd=_0x4405df;super(_0x28df55),this[_0xb176dd(0x78)]=_0x560870,this[_0xb176dd(0x71)]=_0x552f26,this[_0xb176dd(0x79)]=new Set(),this[_0xb176dd(0x77)](),this[_0xb176dd(0x82)]=!0x1;}[_0x4405df(0x77)](){const _0x2d3860=_0x4405df,_0x2b94e2=this[_0x2d3860(0x74)][_0x2d3860(0x6f)][_0x2d3860(0x7a)][_0x2d3860(0x7d)],_0x4fec03=Array[_0x2d3860(0x80)](this[_0x2d3860(0x71)][_0x2d3860(0x73)]());this[_0x2d3860(0x79)]=_0x202ff7(_0x2b94e2,_0x4fec03),this[_0x2d3860(0x70)]=this[_0x2d3860(0x78)][_0x2d3860(0x70)]&&!!this[_0x2d3860(0x79)][_0x2d3860(0x6b)];}[_0x4405df(0x7b)](){const _0x511e1a=_0x4405df,_0x8aaf73=_0x53eac3(Array[_0x511e1a(0x80)](this[_0x511e1a(0x79)]));for(const _0x2f45ad of _0x8aaf73){const _0x2ea25b=_0x2f45ad[_0x511e1a(0x6d)]();if(!this[_0x511e1a(0x74)][_0x511e1a(0x6f)][_0x511e1a(0x72)](_0x2ea25b))return;}_0x4db801(this[_0x511e1a(0x74)][_0x511e1a(0x6f)],this[_0x511e1a(0x78)],_0x8aaf73);}}