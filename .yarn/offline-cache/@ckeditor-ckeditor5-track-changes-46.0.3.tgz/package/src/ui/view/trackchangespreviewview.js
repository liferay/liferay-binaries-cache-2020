/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0xf61423=_0x261d;function _0x261d(_0x377708,_0x236f3d){const _0x237610=_0x2376();return _0x261d=function(_0x261d66,_0x2d854d){_0x261d66=_0x261d66-0x77;let _0xef2349=_0x237610[_0x261d66];return _0xef2349;},_0x261d(_0x377708,_0x236f3d);}(function(_0x1f68a6,_0xd3c56d){const _0x485e0a=_0x261d,_0x10191a=_0x1f68a6();while(!![]){try{const _0x3f0898=parseInt(_0x485e0a(0x80))/0x1*(parseInt(_0x485e0a(0x88))/0x2)+parseInt(_0x485e0a(0x81))/0x3+parseInt(_0x485e0a(0x7a))/0x4+parseInt(_0x485e0a(0x86))/0x5+parseInt(_0x485e0a(0x79))/0x6*(-parseInt(_0x485e0a(0x92))/0x7)+parseInt(_0x485e0a(0x78))/0x8*(-parseInt(_0x485e0a(0x94))/0x9)+parseInt(_0x485e0a(0x77))/0xa*(-parseInt(_0x485e0a(0x8e))/0xb);if(_0x3f0898===_0xd3c56d)break;else _0x10191a['push'](_0x10191a['shift']());}catch(_0x241981){_0x10191a['push'](_0x10191a['shift']());}}}(_0x2376,0xdac60));import{View as _0x3e8926}from'ckeditor5/src/ui.js';export class TrackChangesPreviewView extends _0x3e8926{[_0xf61423(0x84)];constructor(_0x5c0412,_0x27b53d){const _0x435a98=_0xf61423;super(_0x5c0412),this[_0x435a98(0x84)]=_0x27b53d,this[_0x435a98(0x8a)]({'tag':_0x435a98(0x83),'attributes':{'class':['ck',_0x435a98(0x7e),_0x435a98(0x82)],'tabindex':-0x1}});}[_0xf61423(0x7d)](){const _0x16d1ae=_0xf61423;super[_0x16d1ae(0x7d)](),this[_0x16d1ae(0x8c)][_0x16d1ae(0x7f)][_0x16d1ae(0x87)]=this[_0x16d1ae(0x84)][_0x16d1ae(0x98)][_0x16d1ae(0x87)]+'px',this[_0x16d1ae(0x8c)][_0x16d1ae(0x7f)][_0x16d1ae(0x7b)]=this[_0x16d1ae(0x84)][_0x16d1ae(0x98)][_0x16d1ae(0x7b)]+'px';}[_0xf61423(0x8f)](_0x4a7f40,_0x329efc){const _0x5f1ead=_0xf61423;if(!this[_0x5f1ead(0x8c)])return;const _0xcb11db=[];for(const [_0x2c28a1,_0x19517a]of _0x4a7f40){const _0x378635=document[_0x5f1ead(0x93)](_0x5f1ead(0x83));_0x378635[_0x5f1ead(0x8d)](_0x5f1ead(0x85),_0x2c28a1),_0x378635[_0x5f1ead(0x99)]=_0x19517a[_0x5f1ead(0x7c)]+_0x5f1ead(0x96),_0x378635[_0x5f1ead(0x8b)]=_0x19517a[_0x5f1ead(0x90)],_0xcb11db[_0x5f1ead(0x91)](_0x378635);}_0x329efc(this[_0x5f1ead(0x8c)],_0xcb11db),this[_0x5f1ead(0x8c)][_0x5f1ead(0x7f)][_0x5f1ead(0x7b)]='',this[_0x5f1ead(0x97)](_0x5f1ead(0x95));}[_0xf61423(0x89)](){const _0x326388=_0xf61423;this[_0x326388(0x8c)][_0x326388(0x89)]();}}function _0x2376(){const _0x26e06a=['27VNLNAp','previewDataReady','\x20ck-track-changes-preview__root-container','fire','dialogRects','className','10NewjPQ','1982584pOycIg','80826YQrxuX','6774360OqWWuL','height','classes','render','ck-reset','style','521682NHNhGM','699198TmHNre','ck-track-changes-preview','div','options','data-ck-root-name','5348280CSAeCO','width','2HchoiK','focus','setTemplate','innerHTML','element','setAttribute','16810013AomuIP','setPreviewData','content','push','182SLgzZT','createElement'];_0x2376=function(){return _0x26e06a;};return _0x2376();}