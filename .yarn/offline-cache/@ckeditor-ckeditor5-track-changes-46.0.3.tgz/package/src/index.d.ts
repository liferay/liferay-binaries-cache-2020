/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
export { TrackChanges, type SuggestionData, type TrackChangesAdapter, type AddSuggestionInput, type UpdateSuggestionInput } from './trackchanges.js';
export { TrackChangesData, TrackChangesDataGetter } from './trackchangesdata.js';
export { TrackChangesEditing, type SuggestionAttributeData, type SuggestionFormatData } from './trackchangesediting.js';
export { TrackChangesPreview } from './trackchangespreview.js';
export { TrackChangesUI } from './trackchangesui.js';
export { Suggestion, type SuggestionJSON, type SuggestionOptions, type SuggestionType } from './suggestion.js';
export { BaseSuggestionThreadView, type AcceptSuggestionEvent, type DiscardSuggestionEvent, type SuggestionThreadConfig } from './ui/view/basesuggestionthreadview.js';
export { SuggestionThreadView } from './ui/view/suggestionthreadview.js';
export { SuggestionView, type SuggestionConfig } from './ui/view/suggestionview.js';
export { AcceptSuggestionCommand } from './commands/acceptsuggestioncommand.js';
export { DiscardSuggestionCommand } from './commands/discardsuggestioncommand.js';
export { ExecuteOnAllSuggestionsCommand } from './commands/executeonallsuggestionscommand.js';
export { ExecuteOnSelectedSuggestionsCommand } from './commands/executeonselectedsuggestionscommand.js';
export { TrackChangesCommand } from './commands/trackchangescommand.js';
export { PreviewFinalContentCommand } from './commands/previewfinalcontentcommand.js';
export { SuggestionDescriptionFactory, type SuggestionDescription, type SuggestionDescriptionCallback, type SuggestionDescriptionItem, type SuggestionLabelCallback } from './suggestiondescriptionfactory.js';
export type { TrackChangesConfig, TrackChangesPreviewConfig } from './trackchangesconfig.js';
import './augmentation.js';
