/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x559e59,_0x233bde){var _0x4a9a71=_0x3c49,_0x27c461=_0x559e59();while(!![]){try{var _0x7aab39=-parseInt(_0x4a9a71(0x1f2))/0x1*(parseInt(_0x4a9a71(0x1f1))/0x2)+-parseInt(_0x4a9a71(0x1f8))/0x3*(parseInt(_0x4a9a71(0x1ef))/0x4)+parseInt(_0x4a9a71(0x1f4))/0x5+parseInt(_0x4a9a71(0x1f0))/0x6*(-parseInt(_0x4a9a71(0x1f7))/0x7)+-parseInt(_0x4a9a71(0x1f3))/0x8*(parseInt(_0x4a9a71(0x1f5))/0x9)+parseInt(_0x4a9a71(0x1f6))/0xa+parseInt(_0x4a9a71(0x1f9))/0xb;if(_0x7aab39===_0x233bde)break;else _0x27c461['push'](_0x27c461['shift']());}catch(_0x5757f1){_0x27c461['push'](_0x27c461['shift']());}}}(_0x5387,0xd34a1));export{TrackChanges}from'./trackchanges.js';export{TrackChangesData,TrackChangesDataGetter}from'./trackchangesdata.js';function _0x3c49(_0x274f00,_0x46ddf8){var _0x5387a3=_0x5387();return _0x3c49=function(_0x3c49fc,_0x32b95e){_0x3c49fc=_0x3c49fc-0x1ef;var _0x7f8a51=_0x5387a3[_0x3c49fc];return _0x7f8a51;},_0x3c49(_0x274f00,_0x46ddf8);}export{TrackChangesEditing}from'./trackchangesediting.js';export{TrackChangesPreview}from'./trackchangespreview.js';export{TrackChangesUI}from'./trackchangesui.js';export{Suggestion}from'./suggestion.js';export{BaseSuggestionThreadView}from'./ui/view/basesuggestionthreadview.js';export{SuggestionThreadView}from'./ui/view/suggestionthreadview.js';export{SuggestionView}from'./ui/view/suggestionview.js';function _0x5387(){var _0x428654=['4149765pmXONE','366174oteEpJ','7019600RHPQzw','3595543evoyeE','2280252GexosJ','25192299UogIIh','4qhUFQn','6cUBKuP','656UqqmqH','2402QuKFnX','176bmFNWJ'];_0x5387=function(){return _0x428654;};return _0x5387();}export{AcceptSuggestionCommand}from'./commands/acceptsuggestioncommand.js';export{DiscardSuggestionCommand}from'./commands/discardsuggestioncommand.js';export{ExecuteOnAllSuggestionsCommand}from'./commands/executeonallsuggestionscommand.js';export{ExecuteOnSelectedSuggestionsCommand}from'./commands/executeonselectedsuggestionscommand.js';export{TrackChangesCommand}from'./commands/trackchangescommand.js';export{PreviewFinalContentCommand}from'./commands/previewfinalcontentcommand.js';export{SuggestionDescriptionFactory}from'./suggestiondescriptionfactory.js';import'./augmentation.js';