/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x1cc8(){const _0x329635=['9841070CPDYyi','4392904pUmQSj','editor','TrackChangesEditing','1921025mCuAyX','1594797Fyhehq','7iNvVvi','plugins','374916MZeLAO','4215738QgScka','334534JkMqBc','Template','get','insertTemplate','9OcHHYn','3JkyDtj','has','afterInit','enableCommand'];_0x1cc8=function(){return _0x329635;};return _0x1cc8();}const _0x1bec8d=_0x5d46;function _0x5d46(_0x490353,_0x1abac3){const _0x1cc87f=_0x1cc8();return _0x5d46=function(_0x5d46d9,_0x375a07){_0x5d46d9=_0x5d46d9-0x197;let _0x547d7c=_0x1cc87f[_0x5d46d9];return _0x547d7c;},_0x5d46(_0x490353,_0x1abac3);}(function(_0x578fb0,_0xe659c8){const _0x579dac=_0x5d46,_0x190d92=_0x578fb0();while(!![]){try{const _0x10a4e4=-parseInt(_0x579dac(0x197))/0x1*(-parseInt(_0x579dac(0x1a5))/0x2)+parseInt(_0x579dac(0x1a0))/0x3+parseInt(_0x579dac(0x1a3))/0x4+-parseInt(_0x579dac(0x19f))/0x5+parseInt(_0x579dac(0x1a4))/0x6*(-parseInt(_0x579dac(0x1a1))/0x7)+-parseInt(_0x579dac(0x19c))/0x8+-parseInt(_0x579dac(0x1a9))/0x9*(-parseInt(_0x579dac(0x19b))/0xa);if(_0x10a4e4===_0xe659c8)break;else _0x190d92['push'](_0x190d92['shift']());}catch(_0x4ca77a){_0x190d92['push'](_0x190d92['shift']());}}}(_0x1cc8,0x7409f));import{Plugin as _0x2cd4ec}from'ckeditor5/src/core.js';export class TrackChangesTemplate extends _0x2cd4ec{[_0x1bec8d(0x199)](){const _0xabc7ac=_0x1bec8d,_0xdd5106=this[_0xabc7ac(0x19d)];_0xdd5106[_0xabc7ac(0x1a2)][_0xabc7ac(0x198)](_0xabc7ac(0x1a6))&&_0xdd5106[_0xabc7ac(0x1a2)][_0xabc7ac(0x1a7)](_0xabc7ac(0x19e))[_0xabc7ac(0x19a)](_0xabc7ac(0x1a8));}}