/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x220c(_0x44ed51,_0x26c45b){const _0x3e8177=_0x3e81();return _0x220c=function(_0x220c2b,_0x9e3f43){_0x220c2b=_0x220c2b-0x69;let _0x479a3a=_0x3e8177[_0x220c2b];return _0x479a3a;},_0x220c(_0x44ed51,_0x26c45b);}const _0x2403f5=_0x220c;function _0x3e81(){const _0x17d442=['format','792691kdrKfZ','has','registerBlockAttribute','ELEMENT_CONTENT_TABLE','get','getAttribute','registerElementLabel','7269309dGqbxM','table','plugins','descriptionFactory','8jJUhAW','4939942tjlsHK','content','key','tableType','enableCommand','1088344SNpmTH','2152990gkiird','34425910NroRYj','*Set\x20table\x20type:*\x20%0','6xIejVQ','insertTableLayout','TrackChangesEditing','84oraSwr','layout','registerDescriptionCallback','editor','element','141316opzDbZ','TableLayout','newValue','ELEMENT_LAYOUT_TABLE','afterInit','locale','enableDefaultAttributesIntegration'];_0x3e81=function(){return _0x17d442;};return _0x3e81();}(function(_0x38c9f0,_0xed8c64){const _0x396295=_0x220c,_0x415fbe=_0x38c9f0();while(!![]){try{const _0x3f59f8=-parseInt(_0x396295(0x69))/0x1+-parseInt(_0x396295(0x7a))/0x2+parseInt(_0x396295(0x81))/0x3*(-parseInt(_0x396295(0x86))/0x4)+-parseInt(_0x396295(0x7b))/0x5*(parseInt(_0x396295(0x7e))/0x6)+-parseInt(_0x396295(0x75))/0x7*(-parseInt(_0x396295(0x74))/0x8)+-parseInt(_0x396295(0x70))/0x9+parseInt(_0x396295(0x7c))/0xa;if(_0x3f59f8===_0xed8c64)break;else _0x415fbe['push'](_0x415fbe['shift']());}catch(_0x3fba49){_0x415fbe['push'](_0x415fbe['shift']());}}}(_0x3e81,0x8e8f3));import{Plugin as _0x5e4408}from'ckeditor5/src/core.js';import{getTranslation as _0x1d3315}from'../utils/common-translations.js';export class TrackChangesTableLayout extends _0x5e4408{[_0x2403f5(0x8a)](){const _0x5e49bb=_0x2403f5,_0x158f7f=this[_0x5e49bb(0x84)],_0x219032=_0x158f7f[_0x5e49bb(0x8b)],_0x363e56=_0x158f7f[_0x5e49bb(0x72)][_0x5e49bb(0x6d)](_0x5e49bb(0x80));function _0x254a3a(_0x34465a){const _0x2118c5=_0x5e49bb;return{'type':_0x2118c5(0x8d),'content':''+_0x1d3315(_0x219032,_0x2118c5(0x7d),_0x34465a)};}_0x158f7f[_0x5e49bb(0x72)][_0x5e49bb(0x6a)](_0x5e49bb(0x87))&&(_0x363e56[_0x5e49bb(0x79)](_0x5e49bb(0x7f)),_0x363e56[_0x5e49bb(0x8c)](_0x5e49bb(0x78)),_0x363e56[_0x5e49bb(0x6b)](_0x5e49bb(0x78)),_0x363e56[_0x5e49bb(0x73)][_0x5e49bb(0x6f)](_0x1bf313=>_0x1bf313['is'](_0x5e49bb(0x85),_0x5e49bb(0x71))&&_0x5e49bb(0x82)===_0x1bf313[_0x5e49bb(0x6e)](_0x5e49bb(0x78)),_0x519624=>_0x1d3315(_0x219032,_0x5e49bb(0x89),_0x519624)),_0x363e56[_0x5e49bb(0x73)][_0x5e49bb(0x83)](_0x218430=>{const _0x27a24d=_0x5e49bb,{data:_0x3e844b}=_0x218430;if(_0x3e844b&&_0x27a24d(0x78)==_0x3e844b[_0x27a24d(0x77)])switch(_0x3e844b[_0x27a24d(0x88)]){case _0x27a24d(0x82):return _0x254a3a(_0x1d3315(_0x219032,_0x27a24d(0x89)));case _0x27a24d(0x76):return _0x254a3a(_0x1d3315(_0x219032,_0x27a24d(0x6c)));}}));}}