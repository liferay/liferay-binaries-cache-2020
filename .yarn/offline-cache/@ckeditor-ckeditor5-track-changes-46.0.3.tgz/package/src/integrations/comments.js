/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x3c9f2c=_0x1349;function _0x2f5c(){const _0x17cb5a=['addCommentThread','2554993VHUOue','30VZmzMI','284782JxWrHF','plugins','2452460urqMME','has','afterInit','editor','2BhLjqU','get','3jGPOWj','CommentsEditing','12678200DUiWZN','2454831ZAsEct','enableCommand','29695hzErdB','1389648nzRGzP','TrackChangesEditing'];_0x2f5c=function(){return _0x17cb5a;};return _0x2f5c();}(function(_0x3e6b4e,_0x41f7d0){const _0x27bf4b=_0x1349,_0x2a3373=_0x3e6b4e();while(!![]){try{const _0x26fab6=-parseInt(_0x27bf4b(0x1f3))/0x1*(parseInt(_0x27bf4b(0x1e6))/0x2)+parseInt(_0x27bf4b(0x1e8))/0x3*(-parseInt(_0x27bf4b(0x1f5))/0x4)+-parseInt(_0x27bf4b(0x1ed))/0x5*(-parseInt(_0x27bf4b(0x1f2))/0x6)+parseInt(_0x27bf4b(0x1f1))/0x7+-parseInt(_0x27bf4b(0x1ee))/0x8+-parseInt(_0x27bf4b(0x1eb))/0x9+parseInt(_0x27bf4b(0x1ea))/0xa;if(_0x26fab6===_0x41f7d0)break;else _0x2a3373['push'](_0x2a3373['shift']());}catch(_0x24897e){_0x2a3373['push'](_0x2a3373['shift']());}}}(_0x2f5c,0x4dac8));import{Plugin as _0x1744d8}from'ckeditor5/src/core.js';function _0x1349(_0xeac12,_0x57f10){const _0x2f5ce6=_0x2f5c();return _0x1349=function(_0x13491d,_0xaebf0f){_0x13491d=_0x13491d-0x1e6;let _0x179467=_0x2f5ce6[_0x13491d];return _0x179467;},_0x1349(_0xeac12,_0x57f10);}export class TrackChangesComments extends _0x1744d8{[_0x3c9f2c(0x1f7)](){const _0xdf3877=_0x3c9f2c,_0x34e780=this[_0xdf3877(0x1f8)];if(!_0x34e780[_0xdf3877(0x1f4)][_0xdf3877(0x1f6)](_0xdf3877(0x1e9)))return;_0x34e780[_0xdf3877(0x1f4)][_0xdf3877(0x1e7)](_0xdf3877(0x1ef))[_0xdf3877(0x1ec)](_0xdf3877(0x1f0));}}