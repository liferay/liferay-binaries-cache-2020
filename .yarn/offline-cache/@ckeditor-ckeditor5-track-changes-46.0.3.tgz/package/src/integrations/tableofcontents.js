/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x21c281=_0x5aa9;function _0x166d(){const _0xf20ad=['registerElementLabel','6054McHjPe','enableCommand','afterInit','27960McTtra','editor','5517090nKPJfm','1435MCkYBf','4040404rdpAKE','ELEMENT_TABLE_OF_CONTENTS','locale','commands','988328TXRZFG','plugins','descriptionFactory','get','TrackChangesEditing','1784970MCvNEU','981596JxockJ','9AGgvpg','tableOfContents','insertTableOfContents','188ScYjyY'];_0x166d=function(){return _0xf20ad;};return _0x166d();}(function(_0xe5c8b4,_0xe2684c){const _0x18878f=_0x5aa9,_0x274f9a=_0xe5c8b4();while(!![]){try{const _0x560792=parseInt(_0x18878f(0x1a8))/0x1+parseInt(_0x18878f(0x1ac))/0x2*(-parseInt(_0x18878f(0x1b1))/0x3)+parseInt(_0x18878f(0x1b5))/0x4+parseInt(_0x18878f(0x1a7))/0x5+-parseInt(_0x18878f(0x1ae))/0x6*(parseInt(_0x18878f(0x1b4))/0x7)+parseInt(_0x18878f(0x1b9))/0x8*(-parseInt(_0x18878f(0x1a9))/0x9)+-parseInt(_0x18878f(0x1b3))/0xa;if(_0x560792===_0xe2684c)break;else _0x274f9a['push'](_0x274f9a['shift']());}catch(_0x21ead9){_0x274f9a['push'](_0x274f9a['shift']());}}}(_0x166d,0x902b4));import{Plugin as _0x9a974d}from'ckeditor5/src/core.js';import{getTranslation as _0x18990f}from'../utils/common-translations.js';function _0x5aa9(_0x2ff932,_0xa491d0){const _0x166d54=_0x166d();return _0x5aa9=function(_0x5aa9a1,_0x48aa43){_0x5aa9a1=_0x5aa9a1-0x1a6;let _0x3f677a=_0x166d54[_0x5aa9a1];return _0x3f677a;},_0x5aa9(_0x2ff932,_0xa491d0);}export class TrackChangesTableOfContents extends _0x9a974d{[_0x21c281(0x1b0)](){const _0x45c3fd=_0x21c281,_0x32924b=this[_0x45c3fd(0x1b2)];if(!_0x32924b[_0x45c3fd(0x1b8)][_0x45c3fd(0x1bc)](_0x45c3fd(0x1ab)))return;_0x32924b[_0x45c3fd(0x1ba)][_0x45c3fd(0x1bc)](_0x45c3fd(0x1a6))[_0x45c3fd(0x1af)](_0x45c3fd(0x1ab));const _0xa824b6=_0x32924b[_0x45c3fd(0x1ba)][_0x45c3fd(0x1bc)](_0x45c3fd(0x1a6)),_0x38d894=_0x32924b[_0x45c3fd(0x1b7)];_0xa824b6[_0x45c3fd(0x1bb)][_0x45c3fd(0x1ad)](_0x45c3fd(0x1aa),_0x30a174=>_0x18990f(_0x38d894,_0x45c3fd(0x1b6),_0x30a174));}}