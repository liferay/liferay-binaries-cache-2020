/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x48dcd2=_0x4a28;(function(_0x17eb63,_0xfb3d1b){const _0x39a6a3=_0x4a28,_0x745dda=_0x17eb63();while(!![]){try{const _0x31aec3=parseInt(_0x39a6a3(0x1a3))/0x1*(parseInt(_0x39a6a3(0x1a8))/0x2)+parseInt(_0x39a6a3(0x19c))/0x3+parseInt(_0x39a6a3(0x196))/0x4*(-parseInt(_0x39a6a3(0x1ac))/0x5)+-parseInt(_0x39a6a3(0x1a6))/0x6+-parseInt(_0x39a6a3(0x198))/0x7*(-parseInt(_0x39a6a3(0x1a1))/0x8)+parseInt(_0x39a6a3(0x19d))/0x9*(-parseInt(_0x39a6a3(0x1b0))/0xa)+-parseInt(_0x39a6a3(0x1ae))/0xb*(-parseInt(_0x39a6a3(0x19f))/0xc);if(_0x31aec3===_0xfb3d1b)break;else _0x745dda['push'](_0x745dda['shift']());}catch(_0x25b884){_0x745dda['push'](_0x745dda['shift']());}}}(_0x4dc0,0x2795f));import{Plugin as _0x3319dd}from'ckeditor5/src/core.js';function _0x4dc0(){const _0x2fe392=['_registerLegacyDescription','1693836mqeaoi','commandName','2272cvZCeo','get','1gyzaOP','formatInline','RemoveFormatEditing','147096FaOWAQ','type','221322TkzFCX','plugins','has','locale','465zxegRO','TrackChangesEditing','11JGrKbz','formatBlock','239450Wtgfat','registerDescriptionCallback','enableDefaultAttributesIntegration','removeFormat','afterInit','11100HbuhkB','*Remove\x20all\x20formatting*','6482LsbJgw','editor','descriptionFactory','format','364488veQuLt','72nMEVAq'];_0x4dc0=function(){return _0x2fe392;};return _0x4dc0();}import{getTranslation as _0x2b1ff6}from'../utils/common-translations.js';function _0x4a28(_0x886dc8,_0x35951e){const _0x4dc0e9=_0x4dc0();return _0x4a28=function(_0x4a28f7,_0x1f2254){_0x4a28f7=_0x4a28f7-0x193;let _0x5ea75c=_0x4dc0e9[_0x4a28f7];return _0x5ea75c;},_0x4a28(_0x886dc8,_0x35951e);}export class TrackChangesRemoveFormat extends _0x3319dd{[_0x48dcd2(0x195)](){const _0x4c9ff1=_0x48dcd2,_0x33953=this[_0x4c9ff1(0x199)];if(!_0x33953[_0x4c9ff1(0x1a9)][_0x4c9ff1(0x1aa)](_0x4c9ff1(0x1a5)))return;_0x33953[_0x4c9ff1(0x1a9)][_0x4c9ff1(0x1a2)](_0x4c9ff1(0x1ad))[_0x4c9ff1(0x193)](_0x4c9ff1(0x194)),this[_0x4c9ff1(0x19e)]();}[_0x48dcd2(0x19e)](){const _0x59d04e=_0x48dcd2,_0x50e2aa=this[_0x59d04e(0x199)];_0x50e2aa[_0x59d04e(0x1a9)][_0x59d04e(0x1a2)](_0x59d04e(0x1ad))[_0x59d04e(0x19a)][_0x59d04e(0x1b1)](_0x3a9fb9=>{const _0x196897=_0x59d04e;if(_0x196897(0x1af)!=_0x3a9fb9[_0x196897(0x1a7)]&&_0x196897(0x1a4)!=_0x3a9fb9[_0x196897(0x1a7)])return;const {data:_0x252d35}=_0x3a9fb9;return _0x252d35&&_0x196897(0x194)==_0x252d35[_0x196897(0x1a0)]?{'type':_0x196897(0x19b),'content':_0x2b1ff6(_0x50e2aa[_0x196897(0x1ab)],_0x196897(0x197))}:void 0x0;});}}