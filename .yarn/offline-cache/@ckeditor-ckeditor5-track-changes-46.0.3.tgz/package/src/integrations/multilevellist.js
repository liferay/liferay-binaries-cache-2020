/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x1465(_0x14a3e8,_0x2e88d7){const _0x1a006a=_0x1a00();return _0x1465=function(_0x146521,_0x14ddd0){_0x146521=_0x146521-0x147;let _0xb71df0=_0x1a006a[_0x146521];return _0xb71df0;},_0x1465(_0x14a3e8,_0x2e88d7);}function _0x1a00(){const _0x55d587=['TrackChangesEditing','*Remove\x20format:*\x20%0','7gxQuJM','has','9170361iWvUfL','afterInit','editor','listType','28942111hbrMRc','registerBlockAttribute','1496636QMIRtT','next','oldValue','format','MultiLevelList','head','2493NWSUfv','locale','8GwUpFj','3631725DHEsPK','2366728KnLdjm','newValue','138HceKQz','descriptionFactory','10UJVdpy','ELEMENT_MULTI_LEVEL_LIST','plugins','handleDescriptions','listMarkerStyle','key','enableDefaultAttributesIntegration','data','registerDescriptionCallback','get','*Set\x20format:*\x20%0','335275KfdnnZ','multiLevelList'];_0x1a00=function(){return _0x55d587;};return _0x1a00();}const _0x4f218f=_0x1465;(function(_0x1b0148,_0xe90d58){const _0x5cc260=_0x1465,_0x57c9d3=_0x1b0148();while(!![]){try{const _0x2b69e5=-parseInt(_0x5cc260(0x149))/0x1*(parseInt(_0x5cc260(0x14b))/0x2)+-parseInt(_0x5cc260(0x14c))/0x3+-parseInt(_0x5cc260(0x168))/0x4+-parseInt(_0x5cc260(0x15c))/0x5*(parseInt(_0x5cc260(0x14f))/0x6)+parseInt(_0x5cc260(0x160))/0x7*(parseInt(_0x5cc260(0x14d))/0x8)+parseInt(_0x5cc260(0x162))/0x9*(parseInt(_0x5cc260(0x151))/0xa)+parseInt(_0x5cc260(0x166))/0xb;if(_0x2b69e5===_0xe90d58)break;else _0x57c9d3['push'](_0x57c9d3['shift']());}catch(_0x506785){_0x57c9d3['push'](_0x57c9d3['shift']());}}}(_0x1a00,0xc57c4));import{Plugin as _0x49e291}from'ckeditor5/src/core.js';import{getTranslation as _0x3ed5e4}from'../utils/common-translations.js';export class TrackChangesMultiLevelList extends _0x49e291{[_0x4f218f(0x163)](){const _0x2fa951=_0x4f218f,_0xf6059b=this[_0x2fa951(0x164)],_0x3dd5f8=_0xf6059b[_0x2fa951(0x153)][_0x2fa951(0x15a)](_0x2fa951(0x15e));_0xf6059b[_0x2fa951(0x153)][_0x2fa951(0x161)](_0x2fa951(0x147))&&(_0x3dd5f8[_0x2fa951(0x157)](_0x2fa951(0x15d)),_0x3dd5f8[_0x2fa951(0x167)](_0x2fa951(0x155)),_0x3dd5f8[_0x2fa951(0x150)][_0x2fa951(0x159)](_0x3e4b48=>this[_0x2fa951(0x154)](_0x3e4b48)));}[_0x4f218f(0x154)](_0x424270){const _0x352400=_0x4f218f,_0xb90a13=this[_0x352400(0x164)][_0x352400(0x14a)],{data:_0x536cfd}=_0x424270,_0xee7cb8={'type':_0x352400(0x16b),'content':''};if(_0x536cfd&&_0x352400(0x155)==_0x536cfd[_0x352400(0x156)]){if(!_0x536cfd[_0x352400(0x16a)])return{'type':_0x352400(0x16b),'content':_0x3ed5e4(_0xb90a13,_0x352400(0x15b),_0x3ed5e4(_0xb90a13,_0x352400(0x152)))+'\x20('+_0x536cfd[_0x352400(0x14e)]+')'};if(!_0x536cfd[_0x352400(0x14e)]){let _0x5c3e6e=_0x424270[_0x352400(0x148)];for(;_0x5c3e6e;){if(_0x5c3e6e[_0x352400(0x158)]&&_0x352400(0x165)==_0x5c3e6e[_0x352400(0x158)][_0x352400(0x156)]&&_0x5c3e6e[_0x352400(0x158)][_0x352400(0x14e)])return _0xee7cb8;_0x5c3e6e=_0x5c3e6e[_0x352400(0x169)];}return{'type':_0x352400(0x16b),'content':_0x3ed5e4(_0xb90a13,_0x352400(0x15f),_0x3ed5e4(_0xb90a13,_0x352400(0x152)))+'\x20('+_0x536cfd[_0x352400(0x16a)]+')'};}}}}