/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x2dbcf9=_0x14e4;(function(_0x57b9ac,_0x19e9ea){const _0x4ba846=_0x14e4,_0x5c1864=_0x57b9ac();while(!![]){try{const _0x5f420c=-parseInt(_0x4ba846(0x1f0))/0x1+-parseInt(_0x4ba846(0x1f2))/0x2+parseInt(_0x4ba846(0x1f6))/0x3+-parseInt(_0x4ba846(0x1e8))/0x4*(-parseInt(_0x4ba846(0x1d5))/0x5)+-parseInt(_0x4ba846(0x1d3))/0x6*(-parseInt(_0x4ba846(0x1da))/0x7)+parseInt(_0x4ba846(0x1e9))/0x8+-parseInt(_0x4ba846(0x1de))/0x9;if(_0x5f420c===_0x19e9ea)break;else _0x5c1864['push'](_0x5c1864['shift']());}catch(_0x17e64d){_0x5c1864['push'](_0x5c1864['shift']());}}}(_0x1ee2,0x417fa));import{Plugin as _0xb4539d}from'ckeditor5/src/core.js';import{getTranslation as _0x168a3b}from'../utils/common-translations.js';function _0x14e4(_0x4ca48f,_0x3f7778){const _0x1ee26a=_0x1ee2();return _0x14e4=function(_0x14e471,_0x1967f5){_0x14e471=_0x14e471-0x1d3;let _0x47eac9=_0x1ee26a[_0x14e471];return _0x47eac9;},_0x14e4(_0x4ca48f,_0x3f7778);}function _0x1ee2(){const _0x1d3b19=['insertBookmark','88194AZUYGH','BookmarkEditing','15tljnug','attribute','newValue','afterInit','deletion','196xOideJ','key','*Set\x20bookmark:*\x20%0','registerDescriptionCallback','4622391SGfTmX','plugins','enableDefaultAttributesIntegration','locale','type','getAttribute','getContainedElement','format','*Insert:*\x20%0','get','595436jYXTax','3371200pLSCKy','element','has','enableCommand','insertion','bookmark','updateBookmark','469270QXJXYD','TrackChangesEditing','753108hqeCFz','bookmarkId','descriptionFactory','*Remove:*\x20%0','1044468gzHVPg','editor','registerBlockAttribute','ELEMENT_BOOKMARK'];_0x1ee2=function(){return _0x1d3b19;};return _0x1ee2();}export class TrackChangesBookmark extends _0xb4539d{[_0x2dbcf9(0x1d8)](){const _0x35a652=_0x2dbcf9,_0x65ce67=this[_0x35a652(0x1f7)],_0x35cc62=_0x65ce67[_0x35a652(0x1e1)],_0x35428f=_0x65ce67[_0x35a652(0x1df)][_0x35a652(0x1e7)](_0x35a652(0x1f1));_0x65ce67[_0x35a652(0x1df)][_0x35a652(0x1eb)](_0x35a652(0x1d4))&&(_0x35428f[_0x35a652(0x1ec)](_0x35a652(0x1fa)),_0x35428f[_0x35a652(0x1e0)](_0x35a652(0x1ef)),_0x35428f[_0x35a652(0x1f8)](_0x35a652(0x1f3)),_0x35428f[_0x35a652(0x1f4)][_0x35a652(0x1dd)](_0x3db9cc=>{const _0x3ada23=_0x35a652;if(_0x3ada23(0x1ed)!=_0x3db9cc[_0x3ada23(0x1e2)]&&_0x3ada23(0x1d9)!=_0x3db9cc[_0x3ada23(0x1e2)]&&_0x3ada23(0x1d6)!=_0x3db9cc[_0x3ada23(0x1e2)])return;const _0x44596a=_0x3db9cc[_0x3ada23(0x1e4)]();if(null==_0x44596a)return;if(!_0x44596a['is'](_0x3ada23(0x1ea),_0x3ada23(0x1ee)))return;const _0x1a5019=_0x44596a[_0x3ada23(0x1e3)](_0x3ada23(0x1f3));if(_0x3ada23(0x1ed)==_0x3db9cc[_0x3ada23(0x1e2)])return{'type':_0x3ada23(0x1ed),'content':_0x168a3b(_0x35cc62,_0x3ada23(0x1e6),'\x22'+_0x1a5019+'\x22\x20'+_0x168a3b(_0x35cc62,_0x3ada23(0x1f9)))};if(_0x3ada23(0x1d9)==_0x3db9cc[_0x3ada23(0x1e2)])return{'type':_0x3ada23(0x1d9),'content':_0x168a3b(_0x35cc62,_0x3ada23(0x1f5),'\x22'+_0x1a5019+'\x22\x20'+_0x168a3b(_0x35cc62,_0x3ada23(0x1f9)))};const {data:_0x345881}=_0x3db9cc;if(!_0x345881||_0x3ada23(0x1f3)!=_0x345881[_0x3ada23(0x1db)])return;return{'type':_0x3ada23(0x1e5),'content':_0x168a3b(_0x35cc62,_0x3ada23(0x1dc),'\x22'+_0x345881[_0x3ada23(0x1d7)]+'\x22')};}));}}