/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x1d27ec=_0x3fe9;(function(_0x17e5ae,_0x3bed57){const _0x4c9716=_0x3fe9,_0x567ac2=_0x17e5ae();while(!![]){try{const _0x3305d9=parseInt(_0x4c9716(0x1f1))/0x1+parseInt(_0x4c9716(0x1f6))/0x2*(parseInt(_0x4c9716(0x204))/0x3)+-parseInt(_0x4c9716(0x1ef))/0x4+-parseInt(_0x4c9716(0x208))/0x5+parseInt(_0x4c9716(0x207))/0x6+parseInt(_0x4c9716(0x1f2))/0x7*(-parseInt(_0x4c9716(0x1ff))/0x8)+-parseInt(_0x4c9716(0x1fb))/0x9;if(_0x3305d9===_0x3bed57)break;else _0x567ac2['push'](_0x567ac2['shift']());}catch(_0x4a6645){_0x567ac2['push'](_0x567ac2['shift']());}}}(_0x5b35,0x8aa9d));import{Plugin as _0x591a21}from'ckeditor5/src/core.js';function _0x3fe9(_0xcd697e,_0x344f0a){const _0x5b35cd=_0x5b35();return _0x3fe9=function(_0x3fe930,_0x236d4c){_0x3fe930=_0x3fe930-0x1ef;let _0x3648f0=_0x5b35cd[_0x3fe930];return _0x3648f0;},_0x3fe9(_0xcd697e,_0x344f0a);}function _0x5b35(){const _0x4d1543=['992079iGNUCt','RestrictedEditingModeEditing','acceptAllSuggestions','goToPreviousRestrictedEditingException','8395312AJqOef','plugins','discardSuggestion','editor','get','102iTxmAA','acceptSelectedSuggestions','discardSelectedSuggestions','5976834cyHDju','3457855XDQQje','457136tsPObC','trackChanges','943312lsmWjR','7YlPAaL','TrackChangesEditing','discardAllSuggestions','has','34942tDFrdL','goToNextRestrictedEditingException','afterInit','acceptSuggestion','enableCommand'];_0x5b35=function(){return _0x4d1543;};return _0x5b35();}export class TrackChangesRestrictedEditingMode extends _0x591a21{[_0x1d27ec(0x1f8)](){const _0x17618a=_0x1d27ec,_0x2b492b=this[_0x17618a(0x202)];if(!_0x2b492b[_0x17618a(0x200)][_0x17618a(0x1f5)](_0x17618a(0x1fc)))return;const _0x2bf538=_0x2b492b[_0x17618a(0x200)][_0x17618a(0x203)](_0x17618a(0x1f3));_0x2bf538[_0x17618a(0x1fa)](_0x17618a(0x1fe)),_0x2bf538[_0x17618a(0x1fa)](_0x17618a(0x1f7));const _0xb49f69=_0x2b492b[_0x17618a(0x200)][_0x17618a(0x203)](_0x17618a(0x1fc));_0xb49f69[_0x17618a(0x1fa)](_0x17618a(0x1f0)),_0xb49f69[_0x17618a(0x1fa)](_0x17618a(0x1f9)),_0xb49f69[_0x17618a(0x1fa)](_0x17618a(0x201)),_0xb49f69[_0x17618a(0x1fa)](_0x17618a(0x1fd)),_0xb49f69[_0x17618a(0x1fa)](_0x17618a(0x1f4)),_0xb49f69[_0x17618a(0x1fa)](_0x17618a(0x205)),_0xb49f69[_0x17618a(0x1fa)](_0x17618a(0x206));}}