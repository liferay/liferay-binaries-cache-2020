/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module track-changes/integrations/findandreplace
 */
import { Plugin } from 'ckeditor5/src/core.js';
/**
 * Provides track changes plugin integration for find and replace feature.
 */
export declare class TrackChangesFindAndReplace extends Plugin {
    /**
     * @inheritDoc
     */
    afterInit(): void;
    handleFindCommand(executeCommand: Function, callbackOrText: Function | string, options?: {
        matchCase?: boolean;
        wholeWords?: boolean;
    }): unknown;
}
