/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x14ced2=_0xf404;(function(_0x5bcfc2,_0x53c1cc){const _0x3bcfb5=_0xf404,_0x141532=_0x5bcfc2();while(!![]){try{const _0x35c01b=parseInt(_0x3bcfb5(0x14a))/0x1+parseInt(_0x3bcfb5(0x13d))/0x2*(parseInt(_0x3bcfb5(0x136))/0x3)+-parseInt(_0x3bcfb5(0x14d))/0x4+parseInt(_0x3bcfb5(0x13c))/0x5*(-parseInt(_0x3bcfb5(0x13e))/0x6)+parseInt(_0x3bcfb5(0x149))/0x7+parseInt(_0x3bcfb5(0x140))/0x8*(parseInt(_0x3bcfb5(0x144))/0x9)+-parseInt(_0x3bcfb5(0x141))/0xa*(parseInt(_0x3bcfb5(0x138))/0xb);if(_0x35c01b===_0x53c1cc)break;else _0x141532['push'](_0x141532['shift']());}catch(_0x488693){_0x141532['push'](_0x141532['shift']());}}}(_0x28d1,0x9cea5));function _0x28d1(){const _0x54b63a=['1509064gGtBTR','1539110CpyGkS','locale','afterInit','45DtvBMD','editor','FORMAT_LINE_HEIGHT','descriptionFactory','enableDefaultAttributesIntegration','5308863yZMQQK','147804CWJPAN','get','plugins','1313696wTqmoC','LineHeight','2847813EQlvlL','TrackChangesEditing','110NdZTpW','registerAttributeLabel','lineHeight','registerBlockAttribute','288390IbGulQ','2qZbPmH','30giIbYG','has'];_0x28d1=function(){return _0x54b63a;};return _0x28d1();}import{Plugin as _0x4b4997}from'ckeditor5/src/core.js';function _0xf404(_0xcc09dc,_0x11b6d0){const _0x28d173=_0x28d1();return _0xf404=function(_0xf40499,_0x5b4071){_0xf40499=_0xf40499-0x135;let _0x29f889=_0x28d173[_0xf40499];return _0x29f889;},_0xf404(_0xcc09dc,_0x11b6d0);}import{getTranslation as _0x23f0bb}from'../utils/common-translations.js';export class TrackChangesLineHeight extends _0x4b4997{[_0x14ced2(0x143)](){const _0x47c8a8=_0x14ced2,_0x15c21c=this[_0x47c8a8(0x145)];if(!_0x15c21c[_0x47c8a8(0x14c)][_0x47c8a8(0x13f)](_0x47c8a8(0x135)))return;const _0x3c6346=_0x15c21c[_0x47c8a8(0x14c)][_0x47c8a8(0x14b)](_0x47c8a8(0x137)),_0x24ea50=_0x15c21c[_0x47c8a8(0x142)];_0x3c6346[_0x47c8a8(0x148)](_0x47c8a8(0x13a)),_0x3c6346[_0x47c8a8(0x13b)](_0x47c8a8(0x13a)),_0x3c6346[_0x47c8a8(0x147)][_0x47c8a8(0x139)](_0x47c8a8(0x13a),_0x23f0bb(_0x24ea50,_0x47c8a8(0x146)));}}