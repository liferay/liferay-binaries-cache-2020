/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x494f66=_0xe023;(function(_0x1f9231,_0x42b914){const _0x143a52=_0xe023,_0x22b5bd=_0x1f9231();while(!![]){try{const _0x78cfe0=parseInt(_0x143a52(0xe5))/0x1*(-parseInt(_0x143a52(0xed))/0x2)+-parseInt(_0x143a52(0xda))/0x3*(-parseInt(_0x143a52(0xe7))/0x4)+-parseInt(_0x143a52(0xea))/0x5*(-parseInt(_0x143a52(0xec))/0x6)+-parseInt(_0x143a52(0xef))/0x7*(-parseInt(_0x143a52(0xeb))/0x8)+parseInt(_0x143a52(0xdf))/0x9+parseInt(_0x143a52(0xe9))/0xa*(-parseInt(_0x143a52(0xe0))/0xb)+parseInt(_0x143a52(0xe1))/0xc*(parseInt(_0x143a52(0xd9))/0xd);if(_0x78cfe0===_0x42b914)break;else _0x22b5bd['push'](_0x22b5bd['shift']());}catch(_0x50d28f){_0x22b5bd['push'](_0x22b5bd['shift']());}}}(_0x5033,0x31028));function _0xe023(_0xf778d6,_0xe85f59){const _0x503360=_0x5033();return _0xe023=function(_0xe023f2,_0x2887d2){_0xe023f2=_0xe023f2-0xd9;let _0x3c9938=_0x503360[_0xe023f2];return _0x3c9938;},_0xe023(_0xf778d6,_0xe85f59);}import{Plugin as _0xc33f55}from'ckeditor5/src/core.js';import{TrackChangesTable as _0x1f2f13}from'./table.js';function _0x5033(){const _0x5e4bfe=['plugins','editor','has','toggleTableCaption','191448jWbrKc','3786431AWfwUG','264VkNnSm','get','TrackChangesEditing','afterInit','1TUjkxp','requires','266872qVtjEK','enableCommand','10cIQcWN','4295HYHpvs','1992FJVYBm','1710IleIAY','708496ZoSUfa','TableCaptionEditing','10206NFrwxq','1898tOuDWE','12XJgwWA'];_0x5033=function(){return _0x5e4bfe;};return _0x5033();}export class TrackChangesTableCaption extends _0xc33f55{static get[_0x494f66(0xe6)](){return[_0x1f2f13];}[_0x494f66(0xe4)](){const _0x119b41=_0x494f66,_0x3c8143=this[_0x119b41(0xdc)];if(!_0x3c8143[_0x119b41(0xdb)][_0x119b41(0xdd)](_0x119b41(0xee)))return;_0x3c8143[_0x119b41(0xdb)][_0x119b41(0xe2)](_0x119b41(0xe3))[_0x119b41(0xe8)](_0x119b41(0xde));}}