/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x2462fe=_0xf3c4;(function(_0x4644b6,_0x33d339){const _0x5c26c7=_0xf3c4,_0x393c94=_0x4644b6();while(!![]){try{const _0x1927d0=-parseInt(_0x5c26c7(0x1bd))/0x1*(-parseInt(_0x5c26c7(0x1c9))/0x2)+-parseInt(_0x5c26c7(0x1b7))/0x3*(-parseInt(_0x5c26c7(0x1b3))/0x4)+parseInt(_0x5c26c7(0x1bf))/0x5+-parseInt(_0x5c26c7(0x1b5))/0x6*(-parseInt(_0x5c26c7(0x1ba))/0x7)+parseInt(_0x5c26c7(0x1c1))/0x8+parseInt(_0x5c26c7(0x1b4))/0x9*(-parseInt(_0x5c26c7(0x1ca))/0xa)+parseInt(_0x5c26c7(0x1c0))/0xb*(-parseInt(_0x5c26c7(0x1b6))/0xc);if(_0x1927d0===_0x33d339)break;else _0x393c94['push'](_0x393c94['shift']());}catch(_0x46b650){_0x393c94['push'](_0x393c94['shift']());}}}(_0x3e53,0x3f43d));function _0xf3c4(_0x46a67a,_0x4ed115){const _0x3e53d7=_0x3e53();return _0xf3c4=function(_0xf3c4ab,_0x47d1d3){_0xf3c4ab=_0xf3c4ab-0x1b2;let _0xe6df83=_0x3e53d7[_0xf3c4ab];return _0xe6df83;},_0xf3c4(_0x46a67a,_0x4ed115);}function _0x3e53(){const _0x1eadca=['56681tfoWao','enableCommand','693660Thdnyy','11vIettu','2625192tTpcAZ','editor','locale','TrackChangesEditing','get','registerElementLabel','descriptionFactory','pageBreak','10CKOaWu','3220DRBFBF','PageBreakEditing','48376fmOJAF','7164slCUlv','2684898lkSRJI','8333016bOEtcD','3zSPDSm','has','afterInit','7rHgIJG','ELEMENT_PAGE_BREAK','plugins'];_0x3e53=function(){return _0x1eadca;};return _0x3e53();}import{Plugin as _0x2dd802}from'ckeditor5/src/core.js';import{getTranslation as _0x2058e9}from'../utils/common-translations.js';export class TrackChangesPageBreak extends _0x2dd802{[_0x2462fe(0x1b9)](){const _0x37fda3=_0x2462fe,_0xb5df53=this[_0x37fda3(0x1c2)];if(!_0xb5df53[_0x37fda3(0x1bc)][_0x37fda3(0x1b8)](_0x37fda3(0x1b2)))return;_0xb5df53[_0x37fda3(0x1bc)][_0x37fda3(0x1c5)](_0x37fda3(0x1c4))[_0x37fda3(0x1be)](_0x37fda3(0x1c8));const _0x431bfd=_0xb5df53[_0x37fda3(0x1bc)][_0x37fda3(0x1c5)](_0x37fda3(0x1c4)),_0x1e807a=_0xb5df53[_0x37fda3(0x1c3)];_0x431bfd[_0x37fda3(0x1c7)][_0x37fda3(0x1c6)](_0x37fda3(0x1c8),_0x4fca60=>_0x2058e9(_0x1e807a,_0x37fda3(0x1bb),_0x4fca60));}}