/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x1e1469=_0x4db6;function _0x2869(){const _0x4e1008=['1804frTeAn','70aMLkSP','9845fgCNHP','TrackChangesEditing','20816VhkKZG','2444buIxrs','MentionEditing','1683326kEPCev','98870jLDOBg','has','75yyQuqj','get','editor','333WjfHBE','107186kYrJKt','enableCommand','141528cgZrAj','mention','plugins','afterInit','76624332LUrqAi'];_0x2869=function(){return _0x4e1008;};return _0x2869();}(function(_0x4a230d,_0x196baf){const _0x4dcf2a=_0x4db6,_0x2d8c62=_0x4a230d();while(!![]){try{const _0x5b1af1=-parseInt(_0x4dcf2a(0xde))/0x1+-parseInt(_0x4dcf2a(0xe5))/0x2*(parseInt(_0x4dcf2a(0xe1))/0x3)+-parseInt(_0x4dcf2a(0xdc))/0x4*(parseInt(_0x4dcf2a(0xd9))/0x5)+-parseInt(_0x4dcf2a(0xe7))/0x6*(-parseInt(_0x4dcf2a(0xd8))/0x7)+parseInt(_0x4dcf2a(0xdb))/0x8*(parseInt(_0x4dcf2a(0xe4))/0x9)+-parseInt(_0x4dcf2a(0xdf))/0xa*(parseInt(_0x4dcf2a(0xd7))/0xb)+parseInt(_0x4dcf2a(0xd6))/0xc;if(_0x5b1af1===_0x196baf)break;else _0x2d8c62['push'](_0x2d8c62['shift']());}catch(_0x3e01bd){_0x2d8c62['push'](_0x2d8c62['shift']());}}}(_0x2869,0xd45cd));function _0x4db6(_0x11bca6,_0x465a25){const _0x2869e7=_0x2869();return _0x4db6=function(_0x4db699,_0x3995ad){_0x4db699=_0x4db699-0xd3;let _0x415a7f=_0x2869e7[_0x4db699];return _0x415a7f;},_0x4db6(_0x11bca6,_0x465a25);}import{Plugin as _0x18efe3}from'ckeditor5/src/core.js';export class TrackChangesMention extends _0x18efe3{[_0x1e1469(0xd5)](){const _0x48c255=_0x1e1469,_0x9dd65f=this[_0x48c255(0xe3)];_0x9dd65f[_0x48c255(0xd4)][_0x48c255(0xe0)](_0x48c255(0xdd))&&_0x9dd65f[_0x48c255(0xd4)][_0x48c255(0xe2)](_0x48c255(0xda))[_0x48c255(0xe6)](_0x48c255(0xd3));}}