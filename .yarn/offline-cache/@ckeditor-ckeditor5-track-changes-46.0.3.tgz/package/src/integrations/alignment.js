/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x599dce=_0x1495;(function(_0x5b0b83,_0xc4ebd2){const _0x24ffb7=_0x1495,_0x36bc6d=_0x5b0b83();while(!![]){try{const _0x57387a=parseInt(_0x24ffb7(0x1d8))/0x1+parseInt(_0x24ffb7(0x1b8))/0x2+-parseInt(_0x24ffb7(0x1d1))/0x3+-parseInt(_0x24ffb7(0x1c0))/0x4*(-parseInt(_0x24ffb7(0x1d6))/0x5)+parseInt(_0x24ffb7(0x1c3))/0x6+parseInt(_0x24ffb7(0x1dc))/0x7+-parseInt(_0x24ffb7(0x1b9))/0x8;if(_0x57387a===_0xc4ebd2)break;else _0x36bc6d['push'](_0x36bc6d['shift']());}catch(_0x5069bf){_0x36bc6d['push'](_0x36bc6d['shift']());}}}(_0x2eef,0x9e206));function _0x1495(_0x51b055,_0x167d01){const _0x2eef27=_0x2eef();return _0x1495=function(_0x14957f,_0x49a97a){_0x14957f=_0x14957f-0x1b7;let _0x28ec7c=_0x2eef27[_0x14957f];return _0x28ec7c;},_0x1495(_0x51b055,_0x167d01);}function _0x2eef(){const _0x2d8a3d=['afterInit','type','5298174ZvISrG','locale','registerBlockAttribute','*Format:*\x20%0','FORMAT_ALIGN_TO_LEFT','registerDescriptionCallback','FORMAT_ALIGN_TO_CENTER','formatBlock','registerAttributeLabel','FORMAT_JUSTIFY_TEXT','editor','value','get','TrackChangesEditing','2596257OBOlLA','right','left','enableDefaultAttributesIntegration','plugins','620ObDNki','has','53527bqzstl','alignment','commandName','justify','1030323fqAdiK','center','descriptionFactory','2173154JotDWF','6779464fDEJxo','AlignmentEditing','format','FORMAT_ALIGN_TO_RIGHT','commandParams','_registerLegacyDescription','FORMAT_ALIGNMENT','6136HQVCoU'];_0x2eef=function(){return _0x2d8a3d;};return _0x2eef();}import{Plugin as _0x53e87d}from'ckeditor5/src/core.js';import{getTranslation as _0x5a8ddc}from'../utils/common-translations.js';export class TrackChangesAlignment extends _0x53e87d{[_0x599dce(0x1c1)](){const _0x1d5fbe=_0x599dce,_0x227bad=this[_0x1d5fbe(0x1cd)],_0x120244=_0x227bad[_0x1d5fbe(0x1c4)];if(!_0x227bad[_0x1d5fbe(0x1d5)][_0x1d5fbe(0x1d7)](_0x1d5fbe(0x1ba)))return;const _0x28956a=_0x227bad[_0x1d5fbe(0x1d5)][_0x1d5fbe(0x1cf)](_0x1d5fbe(0x1d0));_0x28956a[_0x1d5fbe(0x1d4)](_0x1d5fbe(0x1d9)),_0x28956a[_0x1d5fbe(0x1c5)](_0x1d5fbe(0x1d9)),_0x28956a[_0x1d5fbe(0x1b7)][_0x1d5fbe(0x1cb)](_0x1d5fbe(0x1d9),_0x5a8ddc(_0x120244,_0x1d5fbe(0x1bf))),this[_0x1d5fbe(0x1be)]();}[_0x599dce(0x1be)](){const _0x391853=_0x599dce,_0x1feeb0=this[_0x391853(0x1cd)],_0x5b102a=_0x1feeb0[_0x391853(0x1c4)];_0x1feeb0[_0x391853(0x1d5)][_0x391853(0x1cf)](_0x391853(0x1d0))[_0x391853(0x1b7)][_0x391853(0x1c8)](_0x26a355=>{const _0x2fde14=_0x391853;if(_0x2fde14(0x1ca)!=_0x26a355[_0x2fde14(0x1c2)])return;const {data:_0x3d0360}=_0x26a355;if(_0x3d0360&&_0x2fde14(0x1d9)==_0x3d0360[_0x2fde14(0x1da)]){const _0x6e0c63=_0x3d0360[_0x2fde14(0x1bd)][0x0][_0x2fde14(0x1ce)];return{'type':_0x2fde14(0x1bb),'content':_0x5a8ddc(_0x5b102a,_0x2fde14(0x1c6),function(_0xb1f318){const _0x4c4cc6=_0x2fde14;switch(_0xb1f318){case _0x4c4cc6(0x1d3):return _0x5a8ddc(_0x5b102a,_0x4c4cc6(0x1c7));case _0x4c4cc6(0x1d2):return _0x5a8ddc(_0x5b102a,_0x4c4cc6(0x1bc));case _0x4c4cc6(0x1dd):return _0x5a8ddc(_0x5b102a,_0x4c4cc6(0x1c9));case _0x4c4cc6(0x1db):return _0x5a8ddc(_0x5b102a,_0x4c4cc6(0x1cc));}}(_0x6e0c63))};}});}}