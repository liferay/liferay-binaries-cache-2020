/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module track-changes/integrations/casechange
 */
import { Plugin } from 'ckeditor5/src/core.js';
/**
 * Provides track changes plugin integration for case change feature.
 */
export declare class TrackChangesCaseChange extends Plugin {
    /**
     * @inheritDoc
     */
    afterInit(): void;
}
