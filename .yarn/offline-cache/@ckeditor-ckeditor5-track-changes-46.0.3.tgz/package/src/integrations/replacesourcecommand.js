/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x187365=_0x41df;function _0x318e(){const _0x3c5510=['1949776iKdXEe','editor','33jaRNaQ','18994729vWtRZr','enableCommand','get','1663980dHtCxq','3wyBrmQ','3246mAbEzT','21ndDyaC','replaceSource','2780350PYYgPY','TrackChangesEditing','6591128nWukcq','87298jmwvUc','afterInit','9KcXiNd','30zxVOCz','5495eyNHFu','commands','plugins'];_0x318e=function(){return _0x3c5510;};return _0x318e();}(function(_0x484214,_0x386bfe){const _0x132c08=_0x41df,_0x4c1d93=_0x484214();while(!![]){try{const _0x1b9a0a=-parseInt(_0x132c08(0x15a))/0x1*(parseInt(_0x132c08(0x157))/0x2)+-parseInt(_0x132c08(0x150))/0x3*(-parseInt(_0x132c08(0x156))/0x4)+-parseInt(_0x132c08(0x146))/0x5*(-parseInt(_0x132c08(0x151))/0x6)+-parseInt(_0x132c08(0x152))/0x7*(-parseInt(_0x132c08(0x149))/0x8)+parseInt(_0x132c08(0x159))/0x9*(parseInt(_0x132c08(0x154))/0xa)+parseInt(_0x132c08(0x14b))/0xb*(parseInt(_0x132c08(0x14f))/0xc)+-parseInt(_0x132c08(0x14c))/0xd;if(_0x1b9a0a===_0x386bfe)break;else _0x4c1d93['push'](_0x4c1d93['shift']());}catch(_0x5e802e){_0x4c1d93['push'](_0x4c1d93['shift']());}}}(_0x318e,0xdafa6));import{Plugin as _0x5e7f7b}from'ckeditor5/src/core.js';function _0x41df(_0x26bc81,_0x5bbce5){const _0x318e52=_0x318e();return _0x41df=function(_0x41dfd7,_0x1966b4){_0x41dfd7=_0x41dfd7-0x146;let _0x98b7e0=_0x318e52[_0x41dfd7];return _0x98b7e0;},_0x41df(_0x26bc81,_0x5bbce5);}export class TrackChangesReplaceSourceCommand extends _0x5e7f7b{[_0x187365(0x158)](){const _0x54c57f=_0x187365,_0x2b57d7=this[_0x54c57f(0x14a)];_0x2b57d7[_0x54c57f(0x147)][_0x54c57f(0x14e)](_0x54c57f(0x153))&&_0x2b57d7[_0x54c57f(0x148)][_0x54c57f(0x14e)](_0x54c57f(0x155))[_0x54c57f(0x14d)](_0x54c57f(0x153));}}