/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x43d1(){const _0x40bdae=['TrackChangesEditing','4958472RKmdRB','6434900SICXio','586345ULDmpQ','emoji','editor','afterInit','plugins','2856021UHCazw','2HyUHpg','1598649ZKWqiI','3844000QtkopI','get','enableCommand','commands','5762136QzPzVx'];_0x43d1=function(){return _0x40bdae;};return _0x43d1();}function _0x5d4c(_0x31ff85,_0x4bd0c0){const _0x43d10c=_0x43d1();return _0x5d4c=function(_0x5d4cd4,_0x2fcbdd){_0x5d4cd4=_0x5d4cd4-0x15a;let _0x48551c=_0x43d10c[_0x5d4cd4];return _0x48551c;},_0x5d4c(_0x31ff85,_0x4bd0c0);}const _0x39cf3b=_0x5d4c;(function(_0x259ca3,_0x4835b5){const _0x395d38=_0x5d4c,_0x230a64=_0x259ca3();while(!![]){try{const _0x4040be=-parseInt(_0x395d38(0x162))/0x1*(-parseInt(_0x395d38(0x168))/0x2)+parseInt(_0x395d38(0x169))/0x3+parseInt(_0x395d38(0x161))/0x4+-parseInt(_0x395d38(0x15a))/0x5+-parseInt(_0x395d38(0x160))/0x6+parseInt(_0x395d38(0x167))/0x7+-parseInt(_0x395d38(0x15e))/0x8;if(_0x4040be===_0x4835b5)break;else _0x230a64['push'](_0x230a64['shift']());}catch(_0x482409){_0x230a64['push'](_0x230a64['shift']());}}}(_0x43d1,0xc84fd));import{Plugin as _0x1f4985}from'ckeditor5/src/core.js';export class TrackChangesEmoji extends _0x1f4985{[_0x39cf3b(0x165)](){const _0x457300=_0x39cf3b,_0xb50706=this[_0x457300(0x164)];_0xb50706[_0x457300(0x15d)][_0x457300(0x15b)](_0x457300(0x163))&&_0xb50706[_0x457300(0x166)][_0x457300(0x15b)](_0x457300(0x15f))[_0x457300(0x15c)](_0x457300(0x163));}}