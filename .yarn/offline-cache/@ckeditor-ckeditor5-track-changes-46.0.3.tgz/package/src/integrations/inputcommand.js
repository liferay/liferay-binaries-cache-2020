/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x4e2ad8=_0x1d28;(function(_0x1b7d02,_0x30f82f){var _0xa8a08e=_0x1d28,_0x5ec6c1=_0x1b7d02();while(!![]){try{var _0x20ce81=-parseInt(_0xa8a08e(0x9d))/0x1+-parseInt(_0xa8a08e(0xa0))/0x2+-parseInt(_0xa8a08e(0x9a))/0x3*(parseInt(_0xa8a08e(0x9b))/0x4)+-parseInt(_0xa8a08e(0xa1))/0x5+parseInt(_0xa8a08e(0x93))/0x6*(parseInt(_0xa8a08e(0x96))/0x7)+parseInt(_0xa8a08e(0x94))/0x8+parseInt(_0xa8a08e(0x99))/0x9;if(_0x20ce81===_0x30f82f)break;else _0x5ec6c1['push'](_0x5ec6c1['shift']());}catch(_0x2ae99b){_0x5ec6c1['push'](_0x5ec6c1['shift']());}}}(_0x4d69,0xc1bd5));import{Plugin as _0x785e44}from'ckeditor5/src/core.js';function _0x4d69(){var _0x25cf06=['5376tqzVjG','plugins','requires','13666455zdBCPw','24jimtpO','186440USRadu','input','1125417YIMAYG','editor','get','884644KTyGQB','670930VqnLyN','TrackChangesEditing','enableCommand','2796tYvKAd','7935832uAowUN','init'];_0x4d69=function(){return _0x25cf06;};return _0x4d69();}function _0x1d28(_0x396360,_0x3963a8){var _0x4d69cd=_0x4d69();return _0x1d28=function(_0x1d28ed,_0xa74f4c){_0x1d28ed=_0x1d28ed-0x92;var _0x1db527=_0x4d69cd[_0x1d28ed];return _0x1db527;},_0x1d28(_0x396360,_0x3963a8);}import{Input as _0x466836}from'ckeditor5/src/typing.js';export class TrackChangesInputCommand extends _0x785e44{static get[_0x4e2ad8(0x98)](){return[_0x466836];}[_0x4e2ad8(0x95)](){var _0x3dc005=_0x4e2ad8;this[_0x3dc005(0x9e)][_0x3dc005(0x97)][_0x3dc005(0x9f)](_0x3dc005(0xa2))[_0x3dc005(0x92)](_0x3dc005(0x9c));}}