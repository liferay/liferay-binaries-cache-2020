/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x431a3f=_0x338d;function _0x338d(_0x221446,_0x51e358){const _0x3ab280=_0x3ab2();return _0x338d=function(_0x338d04,_0x439d6a){_0x338d04=_0x338d04-0x121;let _0x31e1fa=_0x3ab280[_0x338d04];return _0x31e1fa;},_0x338d(_0x221446,_0x51e358);}(function(_0x563800,_0x1575fb){const _0x10eca8=_0x338d,_0x16d3ef=_0x563800();while(!![]){try{const _0x42d48b=parseInt(_0x10eca8(0x122))/0x1*(-parseInt(_0x10eca8(0x12f))/0x2)+parseInt(_0x10eca8(0x133))/0x3*(parseInt(_0x10eca8(0x12d))/0x4)+parseInt(_0x10eca8(0x131))/0x5*(parseInt(_0x10eca8(0x134))/0x6)+parseInt(_0x10eca8(0x124))/0x7+-parseInt(_0x10eca8(0x12a))/0x8+-parseInt(_0x10eca8(0x130))/0x9+parseInt(_0x10eca8(0x129))/0xa;if(_0x42d48b===_0x1575fb)break;else _0x16d3ef['push'](_0x16d3ef['shift']());}catch(_0x2a11f6){_0x16d3ef['push'](_0x16d3ef['shift']());}}}(_0x3ab2,0x558dd));import{Plugin as _0x3394d6}from'ckeditor5/src/core.js';export class TrackChangesUndo extends _0x3394d6{[_0x431a3f(0x12b)](){const _0x5b7cdc=_0x431a3f,_0x554716=this[_0x5b7cdc(0x12c)],_0x7bc437=_0x554716[_0x5b7cdc(0x126)][_0x5b7cdc(0x12e)](_0x5b7cdc(0x125));_0x554716[_0x5b7cdc(0x126)][_0x5b7cdc(0x121)](_0x5b7cdc(0x123))&&(_0x7bc437[_0x5b7cdc(0x128)](_0x5b7cdc(0x127)),_0x7bc437[_0x5b7cdc(0x128)](_0x5b7cdc(0x132)));}}function _0x3ab2(){const _0x5d3fa0=['UndoEditing','1357118ccbIzI','TrackChangesEditing','plugins','undo','enableCommand','6208220gECmmU','4050784kciIok','afterInit','editor','1349588mbAuan','get','22gBZhDP','6079230bfqFqG','7715YYOisD','redo','3IHdreR','1506NVPUws','has','649xktxJd'];_0x3ab2=function(){return _0x5d3fa0;};return _0x3ab2();}