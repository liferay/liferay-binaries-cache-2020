/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x5cf9dc=_0x534e;(function(_0x371a98,_0x16251c){const _0x9c9af0=_0x534e,_0x4f7d4d=_0x371a98();while(!![]){try{const _0x35a216=parseInt(_0x9c9af0(0xa7))/0x1+parseInt(_0x9c9af0(0xa2))/0x2*(-parseInt(_0x9c9af0(0xc1))/0x3)+parseInt(_0x9c9af0(0xa5))/0x4*(-parseInt(_0x9c9af0(0xc6))/0x5)+parseInt(_0x9c9af0(0xa1))/0x6+-parseInt(_0x9c9af0(0xab))/0x7+parseInt(_0x9c9af0(0xad))/0x8+parseInt(_0x9c9af0(0xb9))/0x9*(-parseInt(_0x9c9af0(0xaf))/0xa);if(_0x35a216===_0x16251c)break;else _0x4f7d4d['push'](_0x4f7d4d['shift']());}catch(_0x5a7c40){_0x4f7d4d['push'](_0x4f7d4d['shift']());}}}(_0x222b,0x9fd51));import{Plugin as _0x133e73}from'ckeditor5/src/core.js';import{getTranslation as _0x2f5a5a}from'../utils/common-translations.js';export class TrackChangesHighlight extends _0x133e73{[_0x5cf9dc(0xbc)](){const _0x1ff178=_0x5cf9dc,_0x4f1315=this[_0x1ff178(0xb4)];if(!_0x4f1315[_0x1ff178(0xb1)][_0x1ff178(0xc5)](_0x1ff178(0xc7)))return;const _0x31dee7=_0x4f1315[_0x1ff178(0xb1)][_0x1ff178(0xbb)](_0x1ff178(0xa3)),_0x80531c=_0x4f1315[_0x1ff178(0xa6)];_0x31dee7[_0x1ff178(0xb2)](_0x1ff178(0xb6)),_0x31dee7[_0x1ff178(0xba)](_0x1ff178(0xb6)),_0x31dee7[_0x1ff178(0xa8)][_0x1ff178(0xb5)](_0x1ff178(0xb6),_0x2f5a5a(_0x80531c,_0x1ff178(0xc3))),this[_0x1ff178(0xac)]();}[_0x5cf9dc(0xac)](){const _0x1db1df=_0x5cf9dc,_0xdb7a15=this[_0x1db1df(0xb4)],_0x3ef2e3=_0xdb7a15[_0x1db1df(0xa6)];_0xdb7a15[_0x1db1df(0xb1)][_0x1db1df(0xbb)](_0x1db1df(0xa3))[_0x1db1df(0xa8)][_0x1db1df(0xc4)](_0x2b69eb=>{const _0x7382ba=_0x1db1df;if(_0x7382ba(0xb0)!=_0x2b69eb[_0x7382ba(0xb8)])return;const {data:_0xa52dba}=_0x2b69eb;if(_0xa52dba&&_0x7382ba(0xb6)==_0xa52dba[_0x7382ba(0xc8)]){const _0x317414=_0x3ef2e3['t'],_0x575c80=_0xa52dba[_0x7382ba(0xbe)][0x0][_0x7382ba(0xae)];if(_0x575c80){const _0xe63c4d=_0xdb7a15[_0x7382ba(0xb3)][_0x7382ba(0xbb)](_0x7382ba(0xaa))[_0x7382ba(0xa4)](_0x286485=>_0x286485[_0x7382ba(0xb7)]==_0x575c80),_0x28cf1d=_0x317414(_0xe63c4d[_0x7382ba(0xbd)])[_0x7382ba(0xbf)]();return{'type':_0x7382ba(0xa0),'content':_0x2f5a5a(_0x3ef2e3,_0x7382ba(0xa9),_0x28cf1d),'color':{'value':_0xe63c4d[_0x7382ba(0xc0)],'title':_0xe63c4d[_0x7382ba(0xbd)]}};}return{'type':_0x7382ba(0xa0),'content':_0x2f5a5a(_0x3ef2e3,_0x7382ba(0xc2),_0x2f5a5a(_0x3ef2e3,_0x7382ba(0xc3)))};}});}}function _0x534e(_0x635624,_0x382656){const _0x222bae=_0x222b();return _0x534e=function(_0x534eae,_0x2b36b0){_0x534eae=_0x534eae-0xa0;let _0x8c61f7=_0x222bae[_0x534eae];return _0x8c61f7;},_0x534e(_0x635624,_0x382656);}function _0x222b(){const _0x3050d6=['21tVmtsp','*Remove\x20highlight*','FORMAT_HIGHLIGHT','registerDescriptionCallback','has','25dvsSiV','HighlightEditing','commandName','format','7478862YEeRkq','18152nYCCPj','TrackChangesEditing','find','897428gvZBaa','locale','317560btMbrh','descriptionFactory','*Set\x20highlight:*\x20%0','highlight.options','40642WNdhTt','_registerLegacyDescription','6675560XWixVK','value','20lBunYf','formatInline','plugins','enableDefaultAttributesIntegration','config','editor','registerAttributeLabel','highlight','model','type','2487087gwvbnz','registerInlineAttribute','get','afterInit','title','commandParams','toLowerCase','color'];_0x222b=function(){return _0x3050d6;};return _0x222b();}