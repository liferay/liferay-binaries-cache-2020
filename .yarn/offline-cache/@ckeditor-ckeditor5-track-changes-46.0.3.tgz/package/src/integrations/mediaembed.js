/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0xb596f2=_0x5db5;(function(_0x51661f,_0x3da6d6){const _0x19cb8b=_0x5db5,_0x480648=_0x51661f();while(!![]){try{const _0x58d8fc=-parseInt(_0x19cb8b(0x11a))/0x1+parseInt(_0x19cb8b(0x122))/0x2+parseInt(_0x19cb8b(0x10a))/0x3*(parseInt(_0x19cb8b(0x10d))/0x4)+parseInt(_0x19cb8b(0x103))/0x5*(-parseInt(_0x19cb8b(0x11b))/0x6)+-parseInt(_0x19cb8b(0x10c))/0x7*(parseInt(_0x19cb8b(0x115))/0x8)+parseInt(_0x19cb8b(0x111))/0x9*(parseInt(_0x19cb8b(0x11e))/0xa)+parseInt(_0x19cb8b(0x120))/0xb;if(_0x58d8fc===_0x3da6d6)break;else _0x480648['push'](_0x480648['shift']());}catch(_0x5c7c21){_0x480648['push'](_0x480648['shift']());}}}(_0x19d7,0x88600));function _0x5db5(_0x5e8b15,_0x581f99){const _0x19d73e=_0x19d7();return _0x5db5=function(_0x5db58e,_0x1f62b4){_0x5db58e=_0x5db58e-0xfd;let _0x15bde4=_0x19d73e[_0x5db58e];return _0x15bde4;},_0x5db5(_0x5e8b15,_0x581f99);}import{Plugin as _0x21c4b8}from'ckeditor5/src/core.js';function _0x19d7(){const _0x36b2fc=['15897321PTxufZ','enableCommand','660688OdTAsA','options','locale','MediaEmbedEditing','dataDowncast','mediaEmbed','elementToElement','70535pRfgHj','showSuggestionHighlights','descriptionFactory','stop','TrackChangesEditing','registerElementLabel','attribute:url:media','29904ffdzXx','afterInit','32669CKMqrJ','132BGjZpr','media','div','get','19377etrvNZ','data','plugins','has','1704LVZwXR','high','ELEMENT_MEDIA','for','createEmptyElement','1045354MKAfzh','204nvuWTu','conversion','editor','4520NGhYef','downcastDispatcher'];_0x19d7=function(){return _0x36b2fc;};return _0x19d7();}import{getTranslation as _0x3c40f1}from'../utils/common-translations.js';export class TrackChangesMediaEmbed extends _0x21c4b8{[_0xb596f2(0x10b)](){const _0xfe050=_0xb596f2,_0x32b471=this[_0xfe050(0x11d)];if(!_0x32b471[_0xfe050(0x113)][_0xfe050(0x114)](_0xfe050(0xff)))return;const _0x57eed4=_0x32b471[_0xfe050(0x113)][_0xfe050(0x110)](_0xfe050(0x107)),_0x110a8e=_0x32b471[_0xfe050(0xfe)];_0x57eed4[_0xfe050(0x121)](_0xfe050(0x101)),_0x57eed4[_0xfe050(0x105)][_0xfe050(0x108)](_0xfe050(0x10e),_0x22d9bd=>_0x3c40f1(_0x110a8e,_0xfe050(0x117),_0x22d9bd)),_0x32b471[_0xfe050(0x11c)][_0xfe050(0x118)](_0xfe050(0x100))[_0xfe050(0x102)]({'model':_0xfe050(0x10e),'view':(_0x526c34,{writer:_0x34f3af,options:_0xb9cbb5})=>{const _0x318fc6=_0xfe050;if(_0xb9cbb5[_0x318fc6(0x104)])return _0x34f3af[_0x318fc6(0x119)](_0x318fc6(0x10f));},'converterPriority':_0xfe050(0x116)}),_0x32b471[_0xfe050(0x112)][_0xfe050(0x11f)]['on'](_0xfe050(0x109),(_0x4ecc52,_0x4ef0f2,_0x446f0c)=>{const _0x1aee9d=_0xfe050;_0x446f0c[_0x1aee9d(0xfd)][_0x1aee9d(0x104)]&&_0x4ecc52[_0x1aee9d(0x106)]();},{'priority':_0xfe050(0x116)});}}