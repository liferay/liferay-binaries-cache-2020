/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x3a8285=_0x1e08;function _0x1e08(_0x52a38e,_0x222da5){const _0x5cf357=_0x5cf3();return _0x1e08=function(_0x1e081e,_0x11b238){_0x1e081e=_0x1e081e-0x18f;let _0x3b0ee8=_0x5cf357[_0x1e081e];return _0x3b0ee8;},_0x1e08(_0x52a38e,_0x222da5);}(function(_0x4eced4,_0x508b68){const _0x21c46e=_0x1e08,_0x37a61f=_0x4eced4();while(!![]){try{const _0x39f2aa=parseInt(_0x21c46e(0x1a1))/0x1*(-parseInt(_0x21c46e(0x194))/0x2)+parseInt(_0x21c46e(0x18f))/0x3*(-parseInt(_0x21c46e(0x19d))/0x4)+-parseInt(_0x21c46e(0x198))/0x5+parseInt(_0x21c46e(0x199))/0x6+-parseInt(_0x21c46e(0x19b))/0x7*(-parseInt(_0x21c46e(0x197))/0x8)+parseInt(_0x21c46e(0x19c))/0x9*(-parseInt(_0x21c46e(0x192))/0xa)+-parseInt(_0x21c46e(0x1a0))/0xb*(-parseInt(_0x21c46e(0x191))/0xc);if(_0x39f2aa===_0x508b68)break;else _0x37a61f['push'](_0x37a61f['shift']());}catch(_0x5d2fd8){_0x37a61f['push'](_0x37a61f['shift']());}}}(_0x5cf3,0x8ef0b));import{Plugin as _0xc0417f}from'ckeditor5/src/core.js';export class TrackChangesAIAssistant extends _0xc0417f{[_0x3a8285(0x19f)](){const _0x5d8254=_0x3a8285,_0x39f3ba=this[_0x5d8254(0x1a2)],_0x5db858=_0x39f3ba[_0x5d8254(0x195)][_0x5d8254(0x19a)](_0x5d8254(0x190));_0x39f3ba[_0x5d8254(0x196)][_0x5d8254(0x19a)](_0x5d8254(0x19e))&&_0x5db858[_0x5d8254(0x193)](_0x5d8254(0x19e));}}function _0x5cf3(){const _0x354031=['TrackChangesEditing','372ypaBOe','100IyXKus','enableCommand','1011652XZAUuY','plugins','commands','1776zBwcYx','4300635vZlAKJ','1118712gmhfHk','get','15960jRTaGU','295335hcBdxI','1064sngfmT','showAIAssistant','afterInit','886358RIeFYd','2dIYkyo','editor','4569CytfKL'];_0x5cf3=function(){return _0x354031;};return _0x5cf3();}