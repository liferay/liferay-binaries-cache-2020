/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x3a24(_0x4ba685,_0x217b26){const _0x51bcc9=_0x51bc();return _0x3a24=function(_0x3a246b,_0x13891a){_0x3a246b=_0x3a246b-0xee;let _0x19c695=_0x51bcc9[_0x3a246b];return _0x19c695;},_0x3a24(_0x4ba685,_0x217b26);}function _0x51bc(){const _0x1b5ded=['afterInit','419532OVvTqs','288OlCKgg','editor','get','48970pOWCdR','8527072pwUtQr','420874dAETZO','enableCommand','39955XaqSxf','commands','ckbox','7753998GqNwXk','2844AfsaPc','plugins','9UhAKoq','1151359pPclac','TrackChangesEditing'];_0x51bc=function(){return _0x1b5ded;};return _0x51bc();}const _0x2d1bf9=_0x3a24;(function(_0x23637d,_0x1621ef){const _0x39e1d4=_0x3a24,_0x3a8b65=_0x23637d();while(!![]){try{const _0x43d6bc=parseInt(_0x39e1d4(0xee))/0x1+-parseInt(_0x39e1d4(0xf7))/0x2*(-parseInt(_0x39e1d4(0xff))/0x3)+parseInt(_0x39e1d4(0xf2))/0x4*(-parseInt(_0x39e1d4(0xf9))/0x5)+parseInt(_0x39e1d4(0xf1))/0x6+-parseInt(_0x39e1d4(0xfc))/0x7+-parseInt(_0x39e1d4(0xf6))/0x8+-parseInt(_0x39e1d4(0xfd))/0x9*(-parseInt(_0x39e1d4(0xf5))/0xa);if(_0x43d6bc===_0x1621ef)break;else _0x3a8b65['push'](_0x3a8b65['shift']());}catch(_0xc0c2a0){_0x3a8b65['push'](_0x3a8b65['shift']());}}}(_0x51bc,0x9ef56));import{Plugin as _0x28c05c}from'ckeditor5/src/core.js';export class TrackChangesCKBox extends _0x28c05c{[_0x2d1bf9(0xf0)](){const _0x47add9=_0x2d1bf9,_0x481e01=this[_0x47add9(0xf3)];_0x481e01[_0x47add9(0xfa)][_0x47add9(0xf4)](_0x47add9(0xfb))&&_0x481e01[_0x47add9(0xfe)][_0x47add9(0xf4)](_0x47add9(0xef))[_0x47add9(0xf8)](_0x47add9(0xfb));}}