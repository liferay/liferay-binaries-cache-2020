/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0xcfb6(){const _0x231b40=['8283uanrTw','TrackChangesEditing','591670xqDgqE','enableCommand','changeCaseTitle','861007XJGERe','21oWFynd','8TfWqGA','has','changeCaseLower','afterInit','get','13220XYhUxb','42SJChwr','131542xFQARO','7374051QyMlnX','changeCaseUpper','editor','765466YTBNhQ','CaseChange','3178460jJYcrw','plugins'];_0xcfb6=function(){return _0x231b40;};return _0xcfb6();}const _0x4f6b3f=_0x1ee4;function _0x1ee4(_0x37a67d,_0x5b3fff){const _0xcfb6bf=_0xcfb6();return _0x1ee4=function(_0x1ee491,_0x4795c0){_0x1ee491=_0x1ee491-0x17d;let _0x32cd6c=_0xcfb6bf[_0x1ee491];return _0x32cd6c;},_0x1ee4(_0x37a67d,_0x5b3fff);}(function(_0x2acdca,_0x399512){const _0x29e5bf=_0x1ee4,_0x13c9ca=_0x2acdca();while(!![]){try{const _0x400d5c=-parseInt(_0x29e5bf(0x189))/0x1+parseInt(_0x29e5bf(0x185))/0x2*(-parseInt(_0x29e5bf(0x17d))/0x3)+parseInt(_0x29e5bf(0x18b))/0x4+-parseInt(_0x29e5bf(0x18f))/0x5*(-parseInt(_0x29e5bf(0x184))/0x6)+parseInt(_0x29e5bf(0x192))/0x7*(-parseInt(_0x29e5bf(0x17e))/0x8)+-parseInt(_0x29e5bf(0x186))/0x9+parseInt(_0x29e5bf(0x183))/0xa*(parseInt(_0x29e5bf(0x18d))/0xb);if(_0x400d5c===_0x399512)break;else _0x13c9ca['push'](_0x13c9ca['shift']());}catch(_0x2a09d7){_0x13c9ca['push'](_0x13c9ca['shift']());}}}(_0xcfb6,0x6dea8));import{Plugin as _0x3405c9}from'ckeditor5/src/core.js';export class TrackChangesCaseChange extends _0x3405c9{[_0x4f6b3f(0x181)](){const _0x479583=_0x4f6b3f,_0x496ebb=this[_0x479583(0x188)];_0x496ebb[_0x479583(0x18c)][_0x479583(0x17f)](_0x479583(0x18a))&&(_0x496ebb[_0x479583(0x18c)][_0x479583(0x182)](_0x479583(0x18e))[_0x479583(0x190)](_0x479583(0x187)),_0x496ebb[_0x479583(0x18c)][_0x479583(0x182)](_0x479583(0x18e))[_0x479583(0x190)](_0x479583(0x180)),_0x496ebb[_0x479583(0x18c)][_0x479583(0x182)](_0x479583(0x18e))[_0x479583(0x190)](_0x479583(0x191)));}}