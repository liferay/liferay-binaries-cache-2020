/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x4f1d(_0x114324,_0x7d7c4b){const _0x236bc5=_0x236b();return _0x4f1d=function(_0x4f1d40,_0x312f4c){_0x4f1d40=_0x4f1d40-0x76;let _0x30bfc7=_0x236bc5[_0x4f1d40];return _0x30bfc7;},_0x4f1d(_0x114324,_0x7d7c4b);}const _0x580210=_0x4f1d;function _0x236b(){const _0x5884ee=['TrackChangesEditing','plugins','1620576HpxJnw','675NKmKNP','728442uaEeAl','Uploadcare','47389YborNP','attribute','registerDescriptionCallback','5116LWtqzm','enableCommand','10PlnTrf','uploadcareImageId','4826556vVZWBx','get','type','UploadcareImageEdit','has','166472YiHfry','descriptionFactory','uploadcareImageReplace','key','registerBlockAttribute','editor','uploadcareImageEdit','format','enableDefaultAttributesIntegration','uploadcare','2540909NNgXsB','afterInit'];_0x236b=function(){return _0x5884ee;};return _0x236b();}(function(_0x57edfa,_0x39b100){const _0x3b9745=_0x4f1d,_0x2ee1b7=_0x57edfa();while(!![]){try{const _0x5ace9d=-parseInt(_0x3b9745(0x7f))/0x1*(-parseInt(_0x3b9745(0x84))/0x2)+-parseInt(_0x3b9745(0x7d))/0x3+-parseInt(_0x3b9745(0x82))/0x4*(-parseInt(_0x3b9745(0x7c))/0x5)+parseInt(_0x3b9745(0x7b))/0x6+parseInt(_0x3b9745(0x77))/0x7+-parseInt(_0x3b9745(0x8b))/0x8+-parseInt(_0x3b9745(0x86))/0x9;if(_0x5ace9d===_0x39b100)break;else _0x2ee1b7['push'](_0x2ee1b7['shift']());}catch(_0x4266cc){_0x2ee1b7['push'](_0x2ee1b7['shift']());}}}(_0x236b,0x3b462));import{Plugin as _0x182cae}from'ckeditor5/src/core.js';export class TrackChangesUploadcare extends _0x182cae{[_0x580210(0x78)](){const _0x494f25=_0x580210,_0x371db7=this[_0x494f25(0x90)],_0x35b20f=_0x371db7[_0x494f25(0x7a)][_0x494f25(0x87)](_0x494f25(0x79));_0x371db7[_0x494f25(0x7a)][_0x494f25(0x8a)](_0x494f25(0x7e))&&(_0x35b20f[_0x494f25(0x83)](_0x494f25(0x76)),_0x371db7[_0x494f25(0x7a)][_0x494f25(0x8a)](_0x494f25(0x89))&&(_0x35b20f[_0x494f25(0x83)](_0x494f25(0x91)),_0x35b20f[_0x494f25(0x93)](_0x494f25(0x8d)),_0x35b20f[_0x494f25(0x8f)](_0x494f25(0x85)),_0x35b20f[_0x494f25(0x8c)][_0x494f25(0x81)](_0x48d99f=>{const _0xd05e49=_0x494f25;if(_0xd05e49(0x80)!=_0x48d99f[_0xd05e49(0x88)])return;const {data:_0x4972bb}=_0x48d99f;return _0x4972bb&&_0xd05e49(0x85)==_0x4972bb[_0xd05e49(0x8e)]?{'type':_0xd05e49(0x92),'content':''}:void 0x0;})));}}