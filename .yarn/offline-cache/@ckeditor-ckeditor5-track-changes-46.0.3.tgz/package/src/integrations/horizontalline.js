/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0xccd8(_0x883d30,_0x3d7113){const _0x2af1dd=_0x2af1();return _0xccd8=function(_0xccd836,_0xdb9c19){_0xccd836=_0xccd836-0x103;let _0x2b399d=_0x2af1dd[_0xccd836];return _0x2b399d;},_0xccd8(_0x883d30,_0x3d7113);}const _0x565137=_0xccd8;(function(_0x30a736,_0x493ff5){const _0x136317=_0xccd8,_0x3c3528=_0x30a736();while(!![]){try{const _0x53fbef=parseInt(_0x136317(0x112))/0x1*(-parseInt(_0x136317(0x105))/0x2)+parseInt(_0x136317(0x10c))/0x3+-parseInt(_0x136317(0x115))/0x4*(parseInt(_0x136317(0x114))/0x5)+parseInt(_0x136317(0x11b))/0x6+parseInt(_0x136317(0x106))/0x7+parseInt(_0x136317(0x10e))/0x8*(-parseInt(_0x136317(0x11d))/0x9)+parseInt(_0x136317(0x125))/0xa;if(_0x53fbef===_0x493ff5)break;else _0x3c3528['push'](_0x3c3528['shift']());}catch(_0x30e93a){_0x3c3528['push'](_0x3c3528['shift']());}}}(_0x2af1,0xdf0ce));function _0x2af1(){const _0x11df71=['addClass','TrackChangesEditing','5082135wFtSRC','locale','8Cheups','dataDowncast','registerElementLabel','editor','12237plgudA','high','320kMwErc','101788UdXmBa','createContainerElement','insert','createPositionAt','descriptionFactory','plugins','10513092MsypgA','HorizontalLineEditing','8098587nwYJBb','ck-horizontal-line','showSuggestionHighlights','get','for','horizontalLine','conversion','enableCommand','6190730ISKJlO','createEmptyElement','has','elementToStructure','266dGFcoU','7030002VUqnXf','div','afterInit','ELEMENT_HORIZONTAL_LINE'];_0x2af1=function(){return _0x11df71;};return _0x2af1();}import{Plugin as _0x5ec5d2}from'ckeditor5/src/core.js';import{getTranslation as _0xd85e7f}from'../utils/common-translations.js';export class TrackChangesHorizontalLine extends _0x5ec5d2{[_0x565137(0x108)](){const _0x2df3a8=_0x565137,_0x2474f7=this[_0x2df3a8(0x111)];if(!_0x2474f7[_0x2df3a8(0x11a)][_0x2df3a8(0x103)](_0x2df3a8(0x11c)))return;_0x2474f7[_0x2df3a8(0x11a)][_0x2df3a8(0x120)](_0x2df3a8(0x10b))[_0x2df3a8(0x124)](_0x2df3a8(0x122));const _0xa7a612=_0x2474f7[_0x2df3a8(0x11a)][_0x2df3a8(0x120)](_0x2df3a8(0x10b)),_0x4db470=_0x2474f7[_0x2df3a8(0x10d)];_0xa7a612[_0x2df3a8(0x119)][_0x2df3a8(0x110)](_0x2df3a8(0x122),_0x31e875=>_0xd85e7f(_0x4db470,_0x2df3a8(0x109),_0x31e875)),_0x2474f7[_0x2df3a8(0x123)][_0x2df3a8(0x121)](_0x2df3a8(0x10f))[_0x2df3a8(0x104)]({'model':_0x2df3a8(0x122),'view':(_0x2462b3,{writer:_0x2bf4d6,options:_0x2e3994})=>{const _0xcae8a9=_0x2df3a8;if(!_0x2e3994[_0xcae8a9(0x11f)])return null;const _0x79d0ac=_0x2bf4d6[_0xcae8a9(0x116)](_0xcae8a9(0x107)),_0x33c9b1=_0x2bf4d6[_0xcae8a9(0x126)]('hr');return _0x2bf4d6[_0xcae8a9(0x10a)](_0xcae8a9(0x11e),_0x79d0ac),_0x2bf4d6[_0xcae8a9(0x117)](_0x2bf4d6[_0xcae8a9(0x118)](_0x79d0ac,0x0),_0x33c9b1),_0x79d0ac;},'converterPriority':_0x2df3a8(0x113)});}}