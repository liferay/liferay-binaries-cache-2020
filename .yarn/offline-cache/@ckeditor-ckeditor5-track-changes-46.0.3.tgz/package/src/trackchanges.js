/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x374f(){var _0x26a4f6=['requires','4KqVtoN','get','25773956wqVLMs','12YjnczL','addSuggestionData','pluginName','TrackChanges','isPremiumPlugin','getSuggestion','22aVsiOt','11IFBEvT','adapter','3984WtSKxX','getSuggestions','9620790YWjZAi','addSuggestion','1763514NFCJHz','3444245kjQJFv','19296uROkuo','66532OmMkNi','5JOFIHX','isOfficialPlugin','Comments','editor','plugins','2415999beAMbX'];_0x374f=function(){return _0x26a4f6;};return _0x374f();}var _0x2049be=_0x3ac2;(function(_0x3a8b1f,_0x40af2a){var _0x25c166=_0x3ac2,_0x133e02=_0x3a8b1f();while(!![]){try{var _0x553153=parseInt(_0x25c166(0x14c))/0x1*(parseInt(_0x25c166(0x15d))/0x2)+-parseInt(_0x25c166(0x152))/0x3*(parseInt(_0x25c166(0x154))/0x4)+parseInt(_0x25c166(0x14d))/0x5*(parseInt(_0x25c166(0x164))/0x6)+parseInt(_0x25c166(0x165))/0x7+-parseInt(_0x25c166(0x160))/0x8*(parseInt(_0x25c166(0x14b))/0x9)+parseInt(_0x25c166(0x162))/0xa*(-parseInt(_0x25c166(0x15e))/0xb)+-parseInt(_0x25c166(0x157))/0xc*(-parseInt(_0x25c166(0x156))/0xd);if(_0x553153===_0x40af2a)break;else _0x133e02['push'](_0x133e02['shift']());}catch(_0x117ca3){_0x133e02['push'](_0x133e02['shift']());}}}(_0x374f,0xa26ce));import{Plugin as _0x3e6404}from'ckeditor5/src/core.js';function _0x3ac2(_0x3cd564,_0x2eb0c2){var _0x374fb7=_0x374f();return _0x3ac2=function(_0x3ac2a6,_0x7b9690){_0x3ac2a6=_0x3ac2a6-0x14b;var _0x52e7f8=_0x374fb7[_0x3ac2a6];return _0x52e7f8;},_0x3ac2(_0x3cd564,_0x2eb0c2);}import{TrackChangesUI as _0x3fa1db}from'./trackchangesui.js';import{TrackChangesEditing as _0x16f1c3}from'./trackchangesediting.js';import'ckeditor5-collaboration/src/collaboration-core.js';export class TrackChanges extends _0x3e6404{static get[_0x2049be(0x153)](){var _0x5168ce=_0x2049be;return[_0x16f1c3,_0x3fa1db,_0x5168ce(0x14f)];}static get[_0x2049be(0x159)](){var _0x4c7906=_0x2049be;return _0x4c7906(0x15a);}static get[_0x2049be(0x14e)](){return!0x0;}static get[_0x2049be(0x15b)](){return!0x0;}set[_0x2049be(0x15f)](_0x3e5500){var _0x1c56a3=_0x2049be;this[_0x1c56a3(0x150)][_0x1c56a3(0x151)][_0x1c56a3(0x155)](_0x16f1c3)[_0x1c56a3(0x15f)]=_0x3e5500;}get[_0x2049be(0x15f)](){var _0x22a1af=_0x2049be;return this[_0x22a1af(0x150)][_0x22a1af(0x151)][_0x22a1af(0x155)](_0x16f1c3)[_0x22a1af(0x15f)];}[_0x2049be(0x163)](_0x468367){var _0x58517e=_0x2049be;return this[_0x58517e(0x150)][_0x58517e(0x151)][_0x58517e(0x155)](_0x16f1c3)[_0x58517e(0x158)](_0x468367);}[_0x2049be(0x161)]({skipNotAttached:_0x460b3e=!0x1,toJSON:_0xcd9fac=!0x1}={}){var _0x470658=_0x2049be;return this[_0x470658(0x150)][_0x470658(0x151)][_0x470658(0x155)](_0x16f1c3)[_0x470658(0x161)]({'skipNotAttached':_0x460b3e,'toJSON':_0xcd9fac});}[_0x2049be(0x15c)](_0x40736a){var _0x487736=_0x2049be;return this[_0x487736(0x150)][_0x487736(0x151)][_0x487736(0x155)](_0x16f1c3)[_0x487736(0x15c)](_0x40736a);}}