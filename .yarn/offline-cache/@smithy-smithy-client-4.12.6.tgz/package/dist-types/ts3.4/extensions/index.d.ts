export * from "./defaultExtensionConfiguration";
