/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x33cb2b,_0x285cf6){var _0x188388=_0x221d,_0x407a15=_0x33cb2b();while(!![]){try{var _0x1e487b=-parseInt(_0x188388(0x17e))/0x1*(-parseInt(_0x188388(0x179))/0x2)+parseInt(_0x188388(0x181))/0x3*(parseInt(_0x188388(0x17b))/0x4)+-parseInt(_0x188388(0x17f))/0x5+parseInt(_0x188388(0x176))/0x6*(-parseInt(_0x188388(0x178))/0x7)+parseInt(_0x188388(0x177))/0x8*(-parseInt(_0x188388(0x17c))/0x9)+parseInt(_0x188388(0x17a))/0xa*(-parseInt(_0x188388(0x180))/0xb)+parseInt(_0x188388(0x17d))/0xc;if(_0x1e487b===_0x285cf6)break;else _0x407a15['push'](_0x407a15['shift']());}catch(_0x490858){_0x407a15['push'](_0x407a15['shift']());}}}(_0x3c6f,0xe36fb));export*from'@ckeditor/ckeditor5-collaboration-core';function _0x221d(_0x49dc6b,_0x22bdbd){var _0x3c6feb=_0x3c6f();return _0x221d=function(_0x221dcb,_0x2eacf6){_0x221dcb=_0x221dcb-0x176;var _0x2ba845=_0x3c6feb[_0x221dcb];return _0x2ba845;},_0x221d(_0x49dc6b,_0x22bdbd);}function _0x3c6f(){var _0x24df16=['3863070ykcniK','41889648SkcxsG','120027uwwdiW','8785390eQvDhZ','715pLQRvk','12LkgZcx','582BBiMAH','8VdxtlG','47383XLQCac','18zipWvw','221230JVFQWs','641428ExRDtK'];_0x3c6f=function(){return _0x24df16;};return _0x3c6f();}