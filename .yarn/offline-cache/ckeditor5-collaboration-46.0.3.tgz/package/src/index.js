/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x2bd9(){var _0xfb3592=['3153508hHCLgH','1472148zeYrOz','290hTrqFO','1082480pIKXtC','1031949szHclC','2254cWLaGy','1472hPQAlg','4147302XTbGYg','527771jpLUrt','3zUqHiu'];_0x2bd9=function(){return _0xfb3592;};return _0x2bd9();}function _0x2a85(_0x37b449,_0x35f2a1){var _0x2bd9dc=_0x2bd9();return _0x2a85=function(_0x2a852a,_0x4cf887){_0x2a852a=_0x2a852a-0xe1;var _0x308c9e=_0x2bd9dc[_0x2a852a];return _0x308c9e;},_0x2a85(_0x37b449,_0x35f2a1);}(function(_0x55af02,_0x697cde){var _0x167942=_0x2a85,_0x27bad5=_0x55af02();while(!![]){try{var _0x35dba5=-parseInt(_0x167942(0xea))/0x1+-parseInt(_0x167942(0xe3))/0x2+-parseInt(_0x167942(0xe1))/0x3*(parseInt(_0x167942(0xe2))/0x4)+-parseInt(_0x167942(0xe5))/0x5+-parseInt(_0x167942(0xe9))/0x6+parseInt(_0x167942(0xe7))/0x7*(parseInt(_0x167942(0xe8))/0x8)+-parseInt(_0x167942(0xe6))/0x9*(-parseInt(_0x167942(0xe4))/0xa);if(_0x35dba5===_0x697cde)break;else _0x27bad5['push'](_0x27bad5['shift']());}catch(_0x4e5de8){_0x27bad5['push'](_0x27bad5['shift']());}}}(_0x2bd9,0x67a22));export*from'./collaboration-core.js';