CKEditor&nbsp;5 Collaboration features
======================================

[![npm version](https://badge.fury.io/js/%40ckeditor%2Fckeditor5-collaboration.svg)](https://www.npmjs.com/package/@ckeditor/ckeditor5-collaboration)

CKEditor&nbsp;5 collaboration is a low-level API that provides base features to support multiple users working together in a rich text editor. It is used in collaborative features such as [comments](https://ckeditor.com/collaboration/comments/), [track changes](https://ckeditor.com/collaboration/track-changes/), [revision history](https://ckeditor.com/ckeditor-5/revision-history/) or [real-time collaboration](https://ckeditor.com/collaboration/real-time/) in CKEditor&nbsp;5.

This is a premium feature. Sign up for a [free non-commitment 14-day trial](https://portal.ckeditor.com/checkout?plan=free), or see: [https://ckeditor.com/pricing](https://ckeditor.com/pricing) for more information.

## Installation

This plugin is part of the `ckeditor5-premium-features` package. Install the whole package to use it.

```bash
npm install ckeditor5-premium-features
```

## Create free account

If you want to check full CKEditor&nbsp;5 capabilities, sign up for a [free non-commitment 14-day trial](https://portal.ckeditor.com/checkout?plan=free).

## Documentation

For more information about collaboration features visit [CKEditor&nbsp;5 collaboration features overview documentation](https://ckeditor.com/docs/ckeditor5/latest/features/collaboration/collaboration.html).

Also, make sure you visit the [CKEditor&nbsp;5 changelog](https://github.com/ckeditor/ckeditor5/blob/master/CHANGELOG.md) whenever a new version of the package is released.

## Getting support

CKEditor&nbsp;5 collaboration comes with outstanding support from a dedicated team of customer care specialists, QA engineers and CKEditor&nbsp;5 developers. The team will gladly assist you in all aspects from setting up your account to integrating CKEditor&nbsp;5 collaboration features with your application.

As a licensed CKEditor&nbsp;5 collaboration features user you can report bugs and request features directly through the CKEditor Ecosystem customer dashboard.

## License

**CKEditor&nbsp;5 Collaboration features**<br>
Copyright (c) 2003–2025, [CKSource Holding sp. z o.o.](https://cksource.com) All rights reserved.

CKEditor&nbsp;5 Collaboration features are licensed under a commercial license and are protected by copyright law. For more information, see: [https://ckeditor.com/pricing](https://ckeditor.com/pricing).

### Trademarks

**CKEditor** is a trademark of [CKSource Holding sp. z o.o.](https://cksource.com) All other brand and product names are trademarks, registered trademarks or service marks of their respective holders.
