Software License Agreement
==========================

**CKEditor&nbsp;5 Uploadcare feature** – https://github.com/ckeditor/ckeditor5-uploadcare <br>
Copyright (c) 2003–2024, [CKSource Holding sp. z o.o.](https://cksource.com) All rights reserved.

Licensed under the terms of [GNU General Public License Version 2 or later](http://www.gnu.org/licenses/gpl.html).

Sources of Intellectual Property Included in CKEditor
-----------------------------------------------------

Where not otherwise indicated, all CKEditor content is authored by CKSource engineers and consists of CKSource-owned intellectual property. In some specific instances, CKEditor will incorporate work done by developers outside of CKSource with their express permission.

The following libraries are included in CKEditor&nbsp;5 Uploadcare under the [MIT license](https://opensource.org/licenses/MIT):

* @uploadcare/file-uploader - Copyright (c) Uploadcare Inc.
* @uploadcare/upload-client - Copyright (c) Uploadcare Inc.

Trademarks
----------

**CKEditor** is a trademark of [CKSource Holding sp. z o.o.](https://cksource.com) All other brand and product names are trademarks, registered trademarks, or service marks of their respective holders.
