/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module uploadcare/uploadcareuploadadapter
 * @publicApi
 */
import { Plugin } from 'ckeditor5/src/core.js';
import { FileRepository } from 'ckeditor5/src/upload.js';
import { UploadcareEditing } from './uploadcareediting.js';
/**
 * A plugin that enables file uploads in CKEditor 5 using the Uploadcare server–side connector.
 *
 * Check out the {@glink features/images/image-upload/image-upload Image upload overview} guide to learn about
 * other ways to upload images into CKEditor 5.
 */
export declare class UploadcareUploadAdapter extends Plugin {
    /**
     * @inheritDoc
     */
    static get requires(): readonly ["ImageUploadEditing", "ImageUploadProgress", typeof FileRepository, typeof UploadcareEditing];
    /**
     * @inheritDoc
     */
    static get pluginName(): "UploadcareUploadAdapter";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    afterInit(): Promise<void>;
}
