/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module uploadcare/uploadcarecommand
 * @publicApi
 */
import { Command, type Editor } from 'ckeditor5/src/core.js';
import { Dialog } from 'ckeditor5/src/ui.js';
import { UploadcareEditing } from './uploadcareediting.js';
import type { UploadcareSource } from './uploadcareconfig.js';
/**
 * The Uploadcare command. It is used by the {@link module:uploadcare/uploadcareediting~UploadcareEditing Uploadcare editing feature}
 * to open the dialog with the context of the chosen uploading source.
 *
 * ```ts
 * editor.execute( 'uploadcare' );
 * ```
 */
export declare class UploadcareCommand extends Command {
    /**
     * @inheritDoc
     */
    static get requires(): readonly [typeof Dialog, typeof UploadcareEditing];
    /**
     * @inheritDoc
     */
    constructor(editor: Editor);
    /**
     * @inheritDoc
     */
    refresh(): void;
    /**
     * @inheritDoc
     */
    execute(type: UploadcareSource): void;
}
