/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x51ddac=_0x4434;(function(_0x49533f,_0x5e6708){var _0xadd8dc=_0x4434,_0x2f8edc=_0x49533f();while(!![]){try{var _0x38688b=-parseInt(_0xadd8dc(0x9a))/0x1*(parseInt(_0xadd8dc(0x93))/0x2)+parseInt(_0xadd8dc(0x90))/0x3+parseInt(_0xadd8dc(0x91))/0x4*(parseInt(_0xadd8dc(0x8f))/0x5)+parseInt(_0xadd8dc(0x96))/0x6+-parseInt(_0xadd8dc(0x9e))/0x7+parseInt(_0xadd8dc(0x9d))/0x8+parseInt(_0xadd8dc(0x92))/0x9*(parseInt(_0xadd8dc(0x9c))/0xa);if(_0x38688b===_0x5e6708)break;else _0x2f8edc['push'](_0x2f8edc['shift']());}catch(_0x395ab8){_0x2f8edc['push'](_0x2f8edc['shift']());}}}(_0x3e66,0x63583));import{Plugin as _0x498fc2}from'ckeditor5/src/core.js';import{UploadcareUI as _0x5878b8}from'./uploadcareui.js';import{UploadcareEditing as _0x4bb64f}from'./uploadcareediting.js';import{UploadcareSource as _0x53e2a6}from'./uploadcareconfig.js';function _0x4434(_0x427567,_0x1d2636){var _0x3e668d=_0x3e66();return _0x4434=function(_0x443431,_0x2fb660){_0x443431=_0x443431-0x8e;var _0x5ac803=_0x3e668d[_0x443431];return _0x5ac803;},_0x4434(_0x427567,_0x1d2636);}function _0x3e66(){var _0x164298=['400390xMkILu','5194688qVoPee','38150KoMnnA','requires','config','isOfficialPlugin','uploadcare.uploader.sourceList','defineComponents','29795CRfFdO','452784isNfbe','12PNYlSK','9FxYzaZ','222MfEdCk','Local','Uploadcare','926172EORVCJ','URL','pluginName','isPremiumPlugin','5407pSUUrN','define'];_0x3e66=function(){return _0x164298;};return _0x3e66();}import*as _0xfcd2 from'@uploadcare/file-uploader';export class Uploadcare extends _0x498fc2{static get[_0x51ddac(0x9f)](){return[_0x4bb64f,_0x5878b8];}static get[_0x51ddac(0x98)](){var _0x1f87df=_0x51ddac;return _0x1f87df(0x95);}static get[_0x51ddac(0xa1)](){return!0x0;}static get[_0x51ddac(0x99)](){return!0x0;}constructor(_0x3b8169){var _0x301d9c=_0x51ddac;super(_0x3b8169),_0x3b8169[_0x301d9c(0xa0)][_0x301d9c(0x9b)](_0x301d9c(0xa2),[_0x53e2a6[_0x301d9c(0x94)],_0x53e2a6[_0x301d9c(0x97)]]),_0xfcd2[_0x301d9c(0x8e)](_0xfcd2);}}