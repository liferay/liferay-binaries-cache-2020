/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import type { Editor } from 'ckeditor5/src/core.js';
import { UploadcareSource } from '../uploadcareconfig.js';
import { type UploadcareEditing } from '../uploadcareediting.js';
declare const UploadcareController_base: {
    new (): import("ckeditor5/src/utils.js").Observable;
    prototype: import("ckeditor5/src/utils.js").Observable;
};
/**
 * The Uploadcare controller. It is used by the {@link module:uploadcare/uploadcarecommand~UploadcareCommand Uploadcare command}
 * to initialize the uploading flow. The controller opens the dialog with the context of the chosen uploading source.
 */
export declare class UploadcareController extends /* #__PURE__ -- @preserve */ UploadcareController_base {
    /**
     * @inheritDoc
     */
    constructor(editor: Editor, editing: UploadcareEditing, source: UploadcareSource);
    /**
     * Destroys the controller and its components.
     */
    destroy(): void;
}
export {};
