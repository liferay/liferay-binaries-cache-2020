/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module uploadcare/ui/uploadcareformview
 */
import { type Locale } from 'ckeditor5/src/utils.js';
import { DialogFocusManagerView } from '../utils/dialogfocusmanagerview.js';
import '../../theme/uploadcare-form.css';
/**
 * A class representing the form view of the Uploadcare feature.
 */
export declare class UploadcareFormView extends DialogFocusManagerView {
    /**
     * @inheritDoc
     */
    constructor(locale: Locale, id: string);
    /**
     * @inheritDoc
     */
    focus(): void;
}
