/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x39fc4d=_0x4f3c;(function(_0x549c2c,_0x5bc499){var _0xc709fe=_0x4f3c,_0x3dcbdf=_0x549c2c();while(!![]){try{var _0x1f8411=-parseInt(_0xc709fe(0x16b))/0x1+parseInt(_0xc709fe(0x160))/0x2+-parseInt(_0xc709fe(0x170))/0x3*(-parseInt(_0xc709fe(0x163))/0x4)+-parseInt(_0xc709fe(0x173))/0x5*(-parseInt(_0xc709fe(0x161))/0x6)+parseInt(_0xc709fe(0x169))/0x7+parseInt(_0xc709fe(0x162))/0x8+parseInt(_0xc709fe(0x16e))/0x9*(-parseInt(_0xc709fe(0x16d))/0xa);if(_0x1f8411===_0x5bc499)break;else _0x3dcbdf['push'](_0x3dcbdf['shift']());}catch(_0x1a3d3f){_0x3dcbdf['push'](_0x3dcbdf['shift']());}}}(_0x1143,0x4cc32));import{DialogFocusManagerView as _0x2161d0}from'../utils/dialogfocusmanagerview.js';function _0x4f3c(_0x1ccd5f,_0x1d8e79){var _0x1143f5=_0x1143();return _0x4f3c=function(_0x4f3cc5,_0x29ff3a){_0x4f3cc5=_0x4f3cc5-0x15f;var _0x8c9e82=_0x1143f5[_0x4f3cc5];return _0x8c9e82;},_0x4f3c(_0x1ccd5f,_0x1d8e79);}import'../../theme/uploadcare-form.css';function _0x1143(){var _0x2c2606=['732872qfleaD','4OIYRkd','ck-uploadcare-form','div','uc-light','uc-file-uploader-inline','ck-reset_all-excluded','710416FjCkfF','element','522684cpZVNJ','uploader-','1497080tiwNrC','36lXxPmK','ck-uploadcare-theme','1393230dptkMQ','getFocusableElement','setTemplate','195QRHtcZ','focus','1255618CTioAj','23172zAKHqC'];_0x1143=function(){return _0x2c2606;};return _0x1143();}export class UploadcareFormView extends _0x2161d0{constructor(_0x39164e,_0x30a0dc){var _0x32eda6=_0x4f3c;super(_0x39164e),this[_0x32eda6(0x172)]({'tag':_0x32eda6(0x165),'attributes':{'class':['ck',_0x32eda6(0x168),_0x32eda6(0x164)],'tabindex':'-1'},'children':[{'tag':_0x32eda6(0x167),'attributes':{'class':[_0x32eda6(0x166),_0x32eda6(0x16f)],'ctx-name':_0x32eda6(0x16c)+_0x30a0dc}},this[_0x32eda6(0x171)]()]});}[_0x39fc4d(0x15f)](){var _0x470687=_0x39fc4d;this[_0x470687(0x16a)][_0x470687(0x15f)]();}}