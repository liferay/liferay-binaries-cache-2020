/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x4e4a7b=_0x23d9;(function(_0x172528,_0x5b0d1d){var _0x194aa3=_0x23d9,_0x26ed3b=_0x172528();while(!![]){try{var _0x3619c7=parseInt(_0x194aa3(0xcb))/0x1+-parseInt(_0x194aa3(0xcd))/0x2+-parseInt(_0x194aa3(0xc2))/0x3*(-parseInt(_0x194aa3(0xca))/0x4)+-parseInt(_0x194aa3(0xc1))/0x5*(-parseInt(_0x194aa3(0xce))/0x6)+-parseInt(_0x194aa3(0xc5))/0x7*(parseInt(_0x194aa3(0xcf))/0x8)+parseInt(_0x194aa3(0xc9))/0x9+parseInt(_0x194aa3(0xc4))/0xa*(-parseInt(_0x194aa3(0xc7))/0xb);if(_0x3619c7===_0x5b0d1d)break;else _0x26ed3b['push'](_0x26ed3b['shift']());}catch(_0x3eef1f){_0x26ed3b['push'](_0x26ed3b['shift']());}}}(_0x54d1,0x56445));import{Plugin as _0x57f645}from'ckeditor5/src/core.js';function _0x23d9(_0x5d4725,_0x32c0f3){var _0x54d1f7=_0x54d1();return _0x23d9=function(_0x23d900,_0x1169d8){_0x23d900=_0x23d900-0xc1;var _0x5dfa6b=_0x54d1f7[_0x23d900];return _0x5dfa6b;},_0x23d9(_0x5d4725,_0x32c0f3);}function _0x54d1(){var _0x552049=['requires','20gxwEKz','2394bPdkiO','isPremiumPlugin','3506943VSIeoe','UploadcareImageEdit','1537776KjFSPw','1959580DPIYpR','665196HQXAKN','isOfficialPlugin','1051796HzbIcM','948dGwpOW','4456PDXHNT','pluginName','12070xuyZQA','3ptACqe'];_0x54d1=function(){return _0x552049;};return _0x54d1();}import{UploadcareImageEditEditing as _0x284380}from'./uploadcareimageedit/uploadcareimageeditediting.js';import{UploadcareImageEditUI as _0x1c2d95}from'./uploadcareimageedit/uploadcareimageeditui.js';export class UploadcareImageEdit extends _0x57f645{static get[_0x4e4a7b(0xd0)](){var _0x18d838=_0x4e4a7b;return _0x18d838(0xc8);}static get[_0x4e4a7b(0xc3)](){return[_0x284380,_0x1c2d95];}static get[_0x4e4a7b(0xcc)](){return!0x0;}static get[_0x4e4a7b(0xc6)](){return!0x0;}}