/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x567b7d=_0x4e3e;function _0x418d(){var _0x5f052a=['plugins','20jZKEvW','17129XMeqAa','1601786KzCYJQ','commands','get','requires','631878JdzyZc','_editing','editor','3704hPNmBa','isEnabled','3459090RUuRaU','14427135LoovoI','2537995toyKVf','2245584alRaFQ','destroy','_checkEnabled','insertImage','execute','refresh','1scbbPd','_controller'];_0x418d=function(){return _0x5f052a;};return _0x418d();}(function(_0xae1819,_0x3dbf20){var _0x12ef17=_0x4e3e,_0x287fa0=_0xae1819();while(!![]){try{var _0x2def47=-parseInt(_0x12ef17(0x135))/0x1*(parseInt(_0x12ef17(0x13a))/0x2)+-parseInt(_0x12ef17(0x13e))/0x3+-parseInt(_0x12ef17(0x12f))/0x4+-parseInt(_0x12ef17(0x145))/0x5+parseInt(_0x12ef17(0x143))/0x6+-parseInt(_0x12ef17(0x139))/0x7*(parseInt(_0x12ef17(0x141))/0x8)+-parseInt(_0x12ef17(0x144))/0x9*(-parseInt(_0x12ef17(0x138))/0xa);if(_0x2def47===_0x3dbf20)break;else _0x287fa0['push'](_0x287fa0['shift']());}catch(_0x24b1a3){_0x287fa0['push'](_0x287fa0['shift']());}}}(_0x418d,0x8aeee));function _0x4e3e(_0x572614,_0xed4c3c){var _0x418d71=_0x418d();return _0x4e3e=function(_0x4e3e77,_0x564a45){_0x4e3e77=_0x4e3e77-0x12f;var _0x10738f=_0x418d71[_0x4e3e77];return _0x10738f;},_0x4e3e(_0x572614,_0xed4c3c);}import{Command as _0xd78014}from'ckeditor5/src/core.js';import{Dialog as _0x2f987d}from'ckeditor5/src/ui.js';import{UploadcareEditing as _0x3312b8}from'./uploadcareediting.js';import{UploadcareController as _0x578922}from'./ui/uploadcarecontroller.js';export class UploadcareCommand extends _0xd78014{[_0x567b7d(0x13f)];[_0x567b7d(0x136)]=null;static get[_0x567b7d(0x13d)](){return[_0x2f987d,_0x3312b8];}constructor(_0x46f837){var _0x2d9c04=_0x567b7d;super(_0x46f837),this[_0x2d9c04(0x13f)]=_0x46f837[_0x2d9c04(0x137)][_0x2d9c04(0x13c)](_0x3312b8);}[_0x567b7d(0x134)](){var _0x2cf815=_0x567b7d;this[_0x2cf815(0x142)]=this[_0x2cf815(0x131)]();}[_0x567b7d(0x133)](_0x5028fa){var _0x47c5a3=_0x567b7d;this[_0x47c5a3(0x136)]&&(this[_0x47c5a3(0x136)][_0x47c5a3(0x130)](),this[_0x47c5a3(0x136)]=null),this[_0x47c5a3(0x136)]=new _0x578922(this[_0x47c5a3(0x140)],this[_0x47c5a3(0x13f)],_0x5028fa);}[_0x567b7d(0x131)](){var _0x41d791=_0x567b7d;return this[_0x41d791(0x140)][_0x41d791(0x13b)][_0x41d791(0x13c)](_0x41d791(0x132))[_0x41d791(0x142)];}}