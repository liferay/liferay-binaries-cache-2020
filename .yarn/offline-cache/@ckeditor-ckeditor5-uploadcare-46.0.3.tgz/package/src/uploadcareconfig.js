/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x52481c,_0x5a83f7){var _0xd795bf=_0x772b,_0xa94eb9=_0x52481c();while(!![]){try{var _0x1d71ec=-parseInt(_0xd795bf(0x1f0))/0x1*(parseInt(_0xd795bf(0x1e9))/0x2)+parseInt(_0xd795bf(0x1e5))/0x3+-parseInt(_0xd795bf(0x1f1))/0x4+-parseInt(_0xd795bf(0x1e1))/0x5+parseInt(_0xd795bf(0x1df))/0x6+parseInt(_0xd795bf(0x1e0))/0x7+parseInt(_0xd795bf(0x1eb))/0x8*(parseInt(_0xd795bf(0x1e6))/0x9);if(_0x1d71ec===_0x5a83f7)break;else _0xa94eb9['push'](_0xa94eb9['shift']());}catch(_0x489af8){_0xa94eb9['push'](_0xa94eb9['shift']());}}}(_0x53ad,0x998f1));function _0x53ad(){var _0xbafc5a=['Facebook','Dropbox','9TXqdCz','1473692ogaJrZ','url','local','URL','GDrive','18522GLxBHz','7513464QknDgo','4554355Iiochk','facebook','Local','gdrive','1145052fUhRkN','315kmPJXc','dropbox','gphotos','188686jeLAiR','onedrive','296968iSsjTi','OneDrive','GPhotos'];_0x53ad=function(){return _0xbafc5a;};return _0x53ad();}function _0x772b(_0xa269de,_0x36b003){var _0x53adbe=_0x53ad();return _0x772b=function(_0x772b3d,_0x2c7eb8){_0x772b3d=_0x772b3d-0x1de;var _0x3f867d=_0x53adbe[_0x772b3d];return _0x3f867d;},_0x772b(_0xa269de,_0x36b003);}export var UploadcareSource;!function(_0x556c92){var _0x3db2fb=_0x772b;_0x556c92[_0x3db2fb(0x1e3)]=_0x3db2fb(0x1f3),_0x556c92[_0x3db2fb(0x1f4)]=_0x3db2fb(0x1f2),_0x556c92[_0x3db2fb(0x1ef)]=_0x3db2fb(0x1e7),_0x556c92[_0x3db2fb(0x1de)]=_0x3db2fb(0x1e4),_0x556c92[_0x3db2fb(0x1ee)]=_0x3db2fb(0x1e2),_0x556c92[_0x3db2fb(0x1ed)]=_0x3db2fb(0x1e8),_0x556c92[_0x3db2fb(0x1ec)]=_0x3db2fb(0x1ea);}(UploadcareSource||(UploadcareSource={}));