/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module uploadcare/uploadcareediting
 * @publicApi
 */
import { Plugin, type Editor } from 'ckeditor5/src/core.js';
import { Dialog } from 'ckeditor5/src/ui.js';
import { UploadcareUploadAdapter } from './uploadcareuploadadapter.js';
import type { UploaderBlock } from '@uploadcare/file-uploader';
/**
 * The Uploadcare editing feature. It introduces the {@link module:uploadcare/uploadcarecommand~UploadcareCommand command}.
 */
export declare class UploadcareEditing extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "UploadcareEditing";
    /**
     * @inheritDoc
     */
    static get requires(): readonly ["PictureEditing", typeof UploadcareUploadAdapter, typeof Dialog];
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * A unique ID used to make the `ctx-name` property distinct.
     *
     * This ID ensures that each editor instance references to a different Uploadcare web components.
     */
    ucContextId: string;
    /**
     * Returns the DOM element that represents the Uploadcare config web component.
     */
    get configElement(): HTMLElement | null;
    /**
     * Returns the DOM element associated with the Uploadcare context web component.
     */
    get ctxElement(): UploaderBlock | null;
    /**
     * @inheritDoc
     */
    constructor(editor: Editor);
    /**
     * @inheritDoc
     */
    init(): void;
    /**
     * @inheritDoc
     */
    afterInit(): void;
}
