/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import{IconError as _0x31177e}from'ckeditor5/src/icons.js';import{ButtonView as _0x18df0a,IconView as _0x1d7b68,View as _0x5141b5}from'ckeditor5/src/ui.js';export class UploadcareImageEditFormErrorView extends _0x5141b5{constructor(_0x2dcb41){super(_0x2dcb41);const t=_0x2dcb41['t'];this['set']('errorType',null);const _0x5e5c55=new _0x18df0a(_0x2dcb41);_0x5e5c55['label']=t({'id':'Try\x20again\x20(Uploadcare)','string':'Try\x20again'}),_0x5e5c55['withText']=!0x0,_0x5e5c55['class']='ck-button-action',_0x5e5c55['on']('execute',()=>{this['fire']('retry');}),_0x5e5c55['bind']('isVisible')['to'](this,'errorType',_0x557430=>'NotFound'!==_0x557430);const _0x32983b=new _0x1d7b68();_0x32983b['content']=_0x31177e,_0x32983b['extendTemplate']({'attributes':{'style':{'width':'50px','height':'50px'}}});const _0x2949e3=this['bindTemplate'];this['setTemplate']({'tag':'div','attributes':{'class':['ck-uploadcare-form__error'],'tabindex':'-1'},'children':[{'tag':'div','attributes':{'class':['ck-uploadcare-form__error-contents']},'children':[_0x32983b,{'tag':'h3','attributes':{'style':{'fontWeight':'bold'}},'children':[{'text':t('Unable\x20to\x20load')}]},{'text':_0x2949e3['to']('errorType',_0x55efc6=>t('NotFound'!==_0x55efc6?'We\x20were\x20unable\x20to\x20load\x20the\x20image\x20due\x20to\x20network\x20connection\x20issues.':'The\x20image\x20was\x20not\x20found.\x20Its\x20source\x20may\x20have\x20been\x20removed.'))},_0x5e5c55]},{'tag':'div','attributes':{'class':['ck-uploadcare-form__skeleton']},'children':[{'tag':'div','children':[{'tag':'span'},{'tag':'span'},{'tag':'span'}]},{'tag':'div','children':[{'tag':'span'},{'tag':'span'},{'tag':'span'},{'tag':'span'},{'tag':'span'}]}]}]});}}