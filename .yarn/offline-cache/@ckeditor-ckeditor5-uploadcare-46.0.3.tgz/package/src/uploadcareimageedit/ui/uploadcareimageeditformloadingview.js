/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import{SpinnerView as _0x41f4f5,View as _0x204db9}from'ckeditor5/src/ui.js';export class UploadcareImageEditFormLoadingView extends _0x204db9{constructor(_0x2fe7b8){super(_0x2fe7b8);const t=_0x2fe7b8['t'],_0x243102=this['bindTemplate'],_0x461b8f=new _0x41f4f5();_0x461b8f['isVisible']=!0x0,this['setTemplate']({'tag':'div','attributes':{'class':['ck-uploadcare-form__loading'],'tabindex':'-1'},'children':[{'tag':'div','attributes':{'class':['ck-uploadcare-form__loading-spinner']},'children':[_0x461b8f,{'text':_0x243102['to']('imageUploadProgress',_0x368bd4=>t('Loading\x20image...')+'\x20('+(_0x368bd4||0x0)+'%)')}]},{'tag':'div','attributes':{'class':['ck-uploadcare-form__skeleton']},'children':[{'tag':'div','children':[{'tag':'span'},{'tag':'span'},{'tag':'span'}]},{'tag':'div','children':[{'tag':'span'},{'tag':'span'},{'tag':'span'},{'tag':'span'},{'tag':'span'}]}]}]});}}