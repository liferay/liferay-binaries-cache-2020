/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x8b08(){const _0x369395=['4ZgiAvK','120AGseBw','9719072jtEDQo','uc-light','image-edit','1vmbGZv','686049tdTPIJ','bindTemplate','1439105uuqxpS','ck-uploadcare-theme','10TGcLjn','set','uc-cloud-image-editor','2110612kZIhaY','7821304YMIGFl','250579deRhHY','imageSrc','setTemplate','10080738eogUkV'];_0x8b08=function(){return _0x369395;};return _0x8b08();}(function(_0x3c530e,_0x351410){const _0x47b5e8=_0x116a,_0x13509d=_0x3c530e();while(!![]){try{const _0x304260=-parseInt(_0x47b5e8(0x1b7))/0x1*(-parseInt(_0x47b5e8(0x1bf))/0x2)+-parseInt(_0x47b5e8(0x1b8))/0x3+parseInt(_0x47b5e8(0x1b2))/0x4*(-parseInt(_0x47b5e8(0x1ba))/0x5)+parseInt(_0x47b5e8(0x1b3))/0x6*(-parseInt(_0x47b5e8(0x1c1))/0x7)+parseInt(_0x47b5e8(0x1c0))/0x8+-parseInt(_0x47b5e8(0x1b1))/0x9*(parseInt(_0x47b5e8(0x1bc))/0xa)+parseInt(_0x47b5e8(0x1b4))/0xb;if(_0x304260===_0x351410)break;else _0x13509d['push'](_0x13509d['shift']());}catch(_0x4a5d36){_0x13509d['push'](_0x13509d['shift']());}}}(_0x8b08,0x89b1b));function _0x116a(_0x25538f,_0x4aa331){const _0x8b080=_0x8b08();return _0x116a=function(_0x116a54,_0x548e19){_0x116a54=_0x116a54-0x1b1;let _0x35fdc5=_0x8b080[_0x116a54];return _0x35fdc5;},_0x116a(_0x25538f,_0x4aa331);}import{View as _0x4a3288}from'ckeditor5/src/ui.js';export class UploadcareImageEditFormEditingView extends _0x4a3288{constructor(_0x5118b9,_0x52f21){const _0x4d7faf=_0x116a;super(_0x5118b9);const _0x12a7ba=this[_0x4d7faf(0x1b9)];this[_0x4d7faf(0x1bd)](_0x4d7faf(0x1c2),''),this[_0x4d7faf(0x1c3)]({'tag':_0x4d7faf(0x1be),'attributes':{..._0x52f21,'class':[_0x4d7faf(0x1b5),_0x4d7faf(0x1bb)],'ctx-name':_0x4d7faf(0x1b6),'cdn-url':_0x12a7ba['to'](_0x4d7faf(0x1c2))}});}}