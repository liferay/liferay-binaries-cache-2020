/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module uploadcare/uploadcareimageedit/ui/uploadcareimageeditformview
 */
import { type Locale } from 'ckeditor5/src/utils.js';
import { type UploadcareImageEditController } from './uploadcareimageeditcontroller.js';
import { DialogFocusManagerView } from '../../utils/dialogfocusmanagerview.js';
import type { UploadcareEditorConfig } from '../../uploadcareconfig.js';
import '../../../theme/uploadcare-form.css';
/**
 * A class representing the form view of the Uploadcare image edit feature.
 */
export declare class UploadcareImageEditFormView extends DialogFocusManagerView {
    /**
     * Status of the image passed to the view;
     *
     * @observable
     * @readonly
     */
    status: ThisType<UploadcareImageEditController['imageStatus']>;
    /**
     * @inheritDoc
     */
    constructor(locale: Locale, imageStatus: string, attributes: UploadcareEditorConfig);
    /**
     * @inheritDoc
     */
    focus(): void;
}
