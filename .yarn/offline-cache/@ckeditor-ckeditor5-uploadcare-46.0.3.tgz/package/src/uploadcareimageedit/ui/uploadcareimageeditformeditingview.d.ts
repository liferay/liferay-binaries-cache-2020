/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module uploadcare/uploadcareimageedit/ui/uploadcareimageeditformeditingview
 */
import { type Locale } from 'ckeditor5/src/utils.js';
import { View } from 'ckeditor5/src/ui.js';
import type { UploadcareEditorConfig } from '../../uploadcareconfig.js';
/**
 * A class representing the form editing view of the Uploadcare image edit feature.
 */
export declare class UploadcareImageEditFormEditingView extends View {
    /**
     * Image source URL.
     *
     * @observable
     */
    imageSrc: string | null;
    /**
     * @inheritDoc
     */
    constructor(locale: Locale, attributes: UploadcareEditorConfig);
}
