/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module uploadcare/uploadcareimageedit/ui/uploadcareimageeditformloadingview
 */
import { type Locale } from 'ckeditor5/src/utils.js';
import { View } from 'ckeditor5/src/ui.js';
/**
 * A class representing the form loading view of the Uploadcare image edit feature.
 */
export declare class UploadcareImageEditFormLoadingView extends View {
    /**
     * The image upload progress.
     *
     * @observable
     */
    imageUploadProgress: number | null;
    /**
     * @inheritDoc
     */
    constructor(locale: Locale);
}
