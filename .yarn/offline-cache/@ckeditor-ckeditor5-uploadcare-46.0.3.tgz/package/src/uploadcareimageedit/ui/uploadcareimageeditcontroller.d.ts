/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import { type Dialog } from 'ckeditor5/src/ui.js';
import type { Editor } from 'ckeditor5/src/core.js';
import type { ModelElement } from 'ckeditor5/src/engine.js';
declare const UploadcareImageEditController_base: {
    new (): import("ckeditor5/src/utils.js").Observable;
    prototype: import("ckeditor5/src/utils.js").Observable;
};
/**
 * Controller for the Image Edit Dialog.
 *
 * It manages the dialog and all the related actions during dialog instance lifecycle. It is bound to a dialog instance
 * and an active image element and destroyed when dialog instance is closed.
 */
export declare class UploadcareImageEditController extends /* #__PURE__ -- @preserve */ UploadcareImageEditController_base {
    /**
     * Whenever the controller is active and dialog UI visible.
     *
     * @observable
     * @readonly
     */
    isActive: boolean;
    /**
     * Status of the selected image when command is executed:
     *
     * * `uploading` - image is being uploaded to Uploadcare,
     * * `ready` - image is ready to be edited (already in Uploadcare or just uploaded to it),
     * * `error` - error occurred during image upload.
     *
     * @observable
     * @readonly
     */
    imageStatus: 'uploading' | 'ready' | 'error';
    imageErrorType: 'Network' | 'NotFound' | null;
    /**
     * The Uploadcare image ID.
     *
     * @observable
     * @readonly
     */
    imageId: string | null;
    /**
     * The Uploadcare image source URL.
     *
     * @observable
     * @readonly
     */
    imageSrc: string | null;
    /**
     * The image width and height. It is used to calculate proper `srcset` attributes and aspect ratio.
     *
     * @observable
     * @readonly
     */
    imageDimension: {
        width: number;
        height: number;
    } | null;
    /**
     * The Uploadcare image upload progress.
     *
     * @observable
     * @readonly
     */
    imageUploadProgress: number | null;
    /**
     * Creates a new instance of `UploadcareImageEditController`.
     */
    constructor(editor: Editor, dialog: Dialog, imageElement: ModelElement);
    /**
     * Destroys `UploadcareImageEditController` instance.
     */
    destroy(): void;
}
export {};
