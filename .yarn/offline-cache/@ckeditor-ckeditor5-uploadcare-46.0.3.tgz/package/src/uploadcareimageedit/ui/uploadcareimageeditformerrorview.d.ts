/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import { View } from 'ckeditor5/src/ui.js';
import type { Locale } from 'ckeditor5/src/utils.js';
import { type UploadcareImageEditController } from './uploadcareimageeditcontroller.js';
/**
 * A class representing the form error view of the Uploadcare image edit feature.
 */
export declare class UploadcareImageEditFormErrorView extends View {
    /**
     * The image upload error details.
     *
     * @observable
     */
    errorType: UploadcareImageEditController['imageErrorType'];
    /**
     * Creates an instance of the UploadcareImageEditFormErrorView view.
     *
     * @fires retry
     */
    constructor(locale: Locale);
}
