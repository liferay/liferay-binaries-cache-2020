/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x582bdb=_0x5b88;(function(_0x8d6a45,_0x385a06){const _0x247c84=_0x5b88,_0x4e51a6=_0x8d6a45();while(!![]){try{const _0x4f3f8b=-parseInt(_0x247c84(0xc0))/0x1*(parseInt(_0x247c84(0xc7))/0x2)+-parseInt(_0x247c84(0xc3))/0x3*(-parseInt(_0x247c84(0xde))/0x4)+parseInt(_0x247c84(0xca))/0x5+parseInt(_0x247c84(0xc4))/0x6*(parseInt(_0x247c84(0xc1))/0x7)+-parseInt(_0x247c84(0xd3))/0x8+parseInt(_0x247c84(0xcf))/0x9+-parseInt(_0x247c84(0xc9))/0xa;if(_0x4f3f8b===_0x385a06)break;else _0x4e51a6['push'](_0x4e51a6['shift']());}catch(_0x30695f){_0x4e51a6['push'](_0x4e51a6['shift']());}}}(_0x20f6,0x396dc));import{Command as _0x706b32}from'ckeditor5/src/core.js';import{Dialog as _0x11beb7}from'ckeditor5/src/ui.js';import{UploadcareImageEditController as _0x883b2d}from'./ui/uploadcareimageeditcontroller.js';import{createEditabilityChecker as _0x35e30f}from'../utils/editingutils.js';function _0x20f6(){const _0x47b551=['config','2506648BGFFuA','model','bind','selection','document','uploadcare.allowExternalImagesEditing','plugins','getSelectedElement','imageEditController','isActive','refresh','806356ofsdCE','_isEditable','137WBWjqg','2233vErrPg','editor','6qGtBeD','7470xQRbkc','set','get','1740OztvAD','isEnabled','5345070IPKcJv','1160295wzPkRy','execute','element','imageBlock','unbind','1528776pdagZx','requires','imageInline'];_0x20f6=function(){return _0x47b551;};return _0x20f6();}function _0x5b88(_0x3474d8,_0x405597){const _0x20f6fd=_0x20f6();return _0x5b88=function(_0x5b8890,_0x53d326){_0x5b8890=_0x5b8890-0xc0;let _0x489d55=_0x20f6fd[_0x5b8890];return _0x489d55;},_0x5b88(_0x3474d8,_0x405597);}export class UploadcareImageEditCommand extends _0x706b32{[_0x582bdb(0xdb)];static get[_0x582bdb(0xd0)](){return[_0x11beb7];}[_0x582bdb(0xdf)];constructor(_0x2c9d9b){const _0x4a41ae=_0x582bdb;super(_0x2c9d9b),this[_0x4a41ae(0xdb)]=void 0x0,this[_0x4a41ae(0xdf)]=_0x35e30f(_0x2c9d9b[_0x4a41ae(0xd2)][_0x4a41ae(0xc6)](_0x4a41ae(0xd8))||[]),this[_0x4a41ae(0xc5)]({'isActive':!0x1});}[_0x582bdb(0xdd)](){const _0x61e8e=_0x582bdb,_0x312dc5=this[_0x61e8e(0xc2)][_0x61e8e(0xd4)][_0x61e8e(0xd7)][_0x61e8e(0xd6)][_0x61e8e(0xda)]();this[_0x61e8e(0xc8)]=this[_0x61e8e(0xdf)](_0x312dc5);}[_0x582bdb(0xcb)](){const _0x6ca032=_0x582bdb;this[_0x6ca032(0xdb)]&&(this[_0x6ca032(0xce)](_0x6ca032(0xdc)),this[_0x6ca032(0xdb)]=void 0x0);const _0x1f463c=this[_0x6ca032(0xc2)][_0x6ca032(0xd4)][_0x6ca032(0xd7)][_0x6ca032(0xd6)][_0x6ca032(0xda)]();_0x1f463c&&(_0x1f463c['is'](_0x6ca032(0xcc),_0x6ca032(0xcd))||_0x1f463c['is'](_0x6ca032(0xcc),_0x6ca032(0xd1)))&&(this[_0x6ca032(0xdb)]=new _0x883b2d(this[_0x6ca032(0xc2)],this[_0x6ca032(0xc2)][_0x6ca032(0xd9)][_0x6ca032(0xc6)](_0x11beb7),_0x1f463c),this[_0x6ca032(0xd5)](_0x6ca032(0xdc))['to'](this[_0x6ca032(0xdb)],_0x6ca032(0xdc)));}}