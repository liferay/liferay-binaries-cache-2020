/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x42bafe=_0x23da;(function(_0x4f2f6e,_0x37c26c){const _0x21405d=_0x23da,_0x3f08b7=_0x4f2f6e();while(!![]){try{const _0x29ef25=-parseInt(_0x21405d(0xf4))/0x1*(parseInt(_0x21405d(0xf3))/0x2)+-parseInt(_0x21405d(0xf0))/0x3+-parseInt(_0x21405d(0xf7))/0x4*(parseInt(_0x21405d(0xef))/0x5)+parseInt(_0x21405d(0xf2))/0x6*(parseInt(_0x21405d(0x102))/0x7)+parseInt(_0x21405d(0x104))/0x8+-parseInt(_0x21405d(0xf6))/0x9+parseInt(_0x21405d(0xee))/0xa;if(_0x29ef25===_0x37c26c)break;else _0x3f08b7['push'](_0x3f08b7['shift']());}catch(_0x4a59b6){_0x3f08b7['push'](_0x3f08b7['shift']());}}}(_0x6494,0xd28d4));function _0x6494(){const _0x54b13b=['imageInline','model','sizes','7QRLHEW','imageBlock','10365880LnsEyj','element','removeAttribute','setAttributes','36840180tKBOJZ','5urgbzs','4170963BEGcBy','execute','4998462EvQDNk','548866QrkkSv','5jvbeSh','document','11785437fKOqnH','3513724sWfHsV','getSelectedElement','editor','isEnabled','refresh','change','selection','srcset'];_0x6494=function(){return _0x54b13b;};return _0x6494();}import{Command as _0x37ca36}from'ckeditor5/src/core.js';function _0x23da(_0x325765,_0x2239f1){const _0x649425=_0x6494();return _0x23da=function(_0x23dab8,_0x27fb01){_0x23dab8=_0x23dab8-0xec;let _0x597586=_0x649425[_0x23dab8];return _0x597586;},_0x23da(_0x325765,_0x2239f1);}export class UploadcareImageReplaceCommand extends _0x37ca36{[_0x42bafe(0xfb)](){const _0x1709c8=_0x42bafe,_0x1f455c=this[_0x1709c8(0xf9)][_0x1709c8(0x100)][_0x1709c8(0xf5)][_0x1709c8(0xfd)][_0x1709c8(0xf8)]();this[_0x1709c8(0xfa)]=Boolean(_0x1f455c&&(_0x1f455c['is'](_0x1709c8(0x105),_0x1709c8(0x103))||_0x1f455c['is'](_0x1709c8(0x105),_0x1709c8(0xff))));}[_0x42bafe(0xf1)](_0x3187a6){const _0x4ea616=_0x42bafe,_0x5aadf7=this[_0x4ea616(0xf9)][_0x4ea616(0x100)][_0x4ea616(0xf5)][_0x4ea616(0xfd)][_0x4ea616(0xf8)]();this[_0x4ea616(0xf9)][_0x4ea616(0x100)][_0x4ea616(0xfc)](_0x5f3259=>{const _0x5e723a=_0x4ea616;_0x5f3259[_0x5e723a(0xed)](_0x3187a6,_0x5aadf7),_0x5f3259[_0x5e723a(0xec)](_0x5e723a(0xfe),_0x5aadf7),_0x5f3259[_0x5e723a(0xec)](_0x5e723a(0x101),_0x5aadf7);});}}