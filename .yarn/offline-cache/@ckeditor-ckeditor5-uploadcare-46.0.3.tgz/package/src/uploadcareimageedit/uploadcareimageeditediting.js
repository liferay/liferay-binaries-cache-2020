/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x4b8964=_0x1de7;(function(_0x4d10fb,_0x3dab1d){const _0x2f1f04=_0x1de7,_0x31f457=_0x4d10fb();while(!![]){try{const _0x387a99=parseInt(_0x2f1f04(0xcb))/0x1*(-parseInt(_0x2f1f04(0xc1))/0x2)+parseInt(_0x2f1f04(0xca))/0x3+parseInt(_0x2f1f04(0xc8))/0x4+parseInt(_0x2f1f04(0xc5))/0x5+parseInt(_0x2f1f04(0xc3))/0x6*(-parseInt(_0x2f1f04(0xd1))/0x7)+parseInt(_0x2f1f04(0xc4))/0x8+parseInt(_0x2f1f04(0xcc))/0x9;if(_0x387a99===_0x3dab1d)break;else _0x31f457['push'](_0x31f457['shift']());}catch(_0x2a4d2b){_0x31f457['push'](_0x31f457['shift']());}}}(_0x4a4c,0x45dec));import{Plugin as _0x5461a0}from'ckeditor5/src/core.js';function _0x4a4c(){const _0x539ed1=['2063022QNVIbu','184592YEAdCY','387910Ssafcm','isPremiumPlugin','commands','1917568zNTSSB','init','630141BjKPBc','2VtbrKa','3171654YdDbEg','add','uploadcareImageReplace','UploadcareImageEditEditing','requires','7jyEVQy','uploadcareImageEdit','isOfficialPlugin','ImageUtils','pluginName','512476IdGtoX','ImageEditing'];_0x4a4c=function(){return _0x539ed1;};return _0x4a4c();}import{Notification as _0x5528f2}from'ckeditor5/src/ui.js';import{UploadcareImageEditCommand as _0x1941fb}from'./uploadcareimageeditcommand.js';import{UploadcareImageReplaceCommand as _0x1132cf}from'./uploadcareimagereplacecommand.js';import{UploadcareEditing as _0x1e476d}from'../uploadcareediting.js';function _0x1de7(_0x115840,_0x26a150){const _0x4a4c22=_0x4a4c();return _0x1de7=function(_0x1de77c,_0x44dbe2){_0x1de77c=_0x1de77c-0xbf;let _0x3ada33=_0x4a4c22[_0x1de77c];return _0x3ada33;},_0x1de7(_0x115840,_0x26a150);}export class UploadcareImageEditEditing extends _0x5461a0{static get[_0x4b8964(0xc0)](){const _0x2ac4a3=_0x4b8964;return _0x2ac4a3(0xcf);}static get[_0x4b8964(0xd0)](){const _0x3ed76b=_0x4b8964;return[_0x1e476d,_0x5528f2,_0x3ed76b(0xbf),_0x3ed76b(0xc2)];}static get[_0x4b8964(0xd3)](){return!0x0;}static get[_0x4b8964(0xc6)](){return!0x0;}[_0x4b8964(0xc9)](){const _0xac7cd9=_0x4b8964,{editor:_0x5a0f0a}=this;_0x5a0f0a[_0xac7cd9(0xc7)][_0xac7cd9(0xcd)](_0xac7cd9(0xd2),new _0x1941fb(_0x5a0f0a)),_0x5a0f0a[_0xac7cd9(0xc7)][_0xac7cd9(0xcd)](_0xac7cd9(0xce),new _0x1132cf(_0x5a0f0a));}}