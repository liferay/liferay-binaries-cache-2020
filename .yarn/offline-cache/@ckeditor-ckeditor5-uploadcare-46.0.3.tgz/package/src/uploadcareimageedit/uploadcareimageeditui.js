/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import{Plugin as _0xc8f148}from'ckeditor5/src/core.js';import{ButtonView as _0x14680b}from'ckeditor5/src/ui.js';import{IconUploadcareImageEdit as _0x476554}from'ckeditor5/src/icons.js';import{createElement as _0x591725}from'ckeditor5/src/utils.js';import'@uploadcare/file-uploader/web/uc-cloud-image-editor.min.css';import'../../theme/uploadcare-theme.css';export class UploadcareImageEditUI extends _0xc8f148{['_imageCache']=new Map();static get['pluginName'](){return'UploadcareImageEditUI';}static get['isOfficialPlugin'](){return!0x0;}static get['isPremiumPlugin'](){return!0x0;}get['imageCache'](){return this['_imageCache'];}['init'](){const _0x2f259a=this['editor'];_0x2f259a['ui']['componentFactory']['add']('uploadcareImageEdit',_0xd2cfe4=>{const _0x395b85=_0x2f259a['commands']['get']('uploadcareImageEdit'),_0x1d8561=new _0x14680b(_0xd2cfe4),t=_0xd2cfe4['t'];return _0x1d8561['set']({'icon':_0x476554,'tooltip':!0x0,'label':t({'id':'Edit\x20Image\x20(Uploadcare)','string':'Edit\x20image'})}),_0x1d8561['bind']('isEnabled')['to'](_0x395b85),_0x1d8561['bind']('isOn')['to'](_0x395b85,'isActive'),this['listenTo'](_0x1d8561,'execute',()=>{_0x2f259a['execute']('uploadcareImageEdit'),_0x2f259a['editing']['view']['focus']();}),_0x1d8561;}),this['_initConfig']();}['_initConfig'](){const _0x530833=_0x591725(document,'uc-config',{'ctx-name':'image-edit','removeCopyright':'true','localeName':this['editor']['locale']['contentLanguage']});document['body']['appendChild'](_0x530833),this['listenTo'](this['editor'],'destroy',()=>{_0x530833['remove']();});}}