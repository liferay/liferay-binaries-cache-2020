/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module uploadcare/uploadcareimageedit/uploadcareimageeditcommand
 * @publicApi
 */
import { Command, type Editor } from 'ckeditor5/src/core.js';
import { Dialog } from 'ckeditor5/src/ui.js';
import { UploadcareImageEditController } from './ui/uploadcareimageeditcontroller.js';
/**
 * The Uploadcare edit image command.
 *
 * It opens the Uploadcare dialog for editing the image.
 *
 * ```ts
 * editor.execute( 'uploadcareImageEdit' );
 * ```
 */
export declare class UploadcareImageEditCommand extends Command {
    /**
     * Whenever the controller is active and dialog UI visible.
     *
     * @observable
     * @readonly
     */
    isActive: boolean;
    /**
     * The Uploadcare image edit controller instance.
     */
    imageEditController: UploadcareImageEditController | undefined;
    /**
     * @inheritDoc
     */
    static get requires(): readonly [typeof Dialog];
    /**
     * @inheritDoc
     */
    constructor(editor: Editor);
    /**
     * @inheritDoc
     */
    refresh(): void;
    /**
     * @inheritDoc
     */
    execute(): void;
}
