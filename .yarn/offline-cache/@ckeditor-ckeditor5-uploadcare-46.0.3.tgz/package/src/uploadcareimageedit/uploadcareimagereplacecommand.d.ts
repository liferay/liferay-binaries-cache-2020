/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module uploadcare/uploadcareimageedit/uploadcareimagereplacecommand
 */
import { Command } from 'ckeditor5/src/core.js';
/**
 * The Uploadcare replace image command.
 *
 * It replaces given image element attributes.
 */
export declare class UploadcareImageReplaceCommand extends Command {
    /**
     * @inheritDoc
     */
    refresh(): void;
    /**
     * @inheritDoc
     */
    execute(attributes: Record<string, string | number | any>): void;
}
