/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module uploadcare/uploadcareimageedit/uploadcareimageeditui
 * @publicApi
 */
import { Plugin } from 'ckeditor5/src/core.js';
import '@uploadcare/file-uploader/web/uc-cloud-image-editor.min.css';
import '../../theme/uploadcare-theme.css';
/**
 * The UI plugin of the Uploadcare image edit feature.
 *
 * It registers the `'uploadcareImageEdit'` UI button in the editor's {@link module:ui/componentfactory~ComponentFactory component factory}
 * that allows you to open the Uploadcare dialog and edit the image.
 */
export declare class UploadcareImageEditUI extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "UploadcareImageEditUI";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * The cache of image URLs that had been uploaded to Uploadcare.
     */
    get imageCache(): UploadcareImageCache;
    /**
     * @inheritDoc
     */
    init(): void;
}
export type UploadcareImageCache = Map<string, {
    id: string;
    url: string;
    dimension: {
        width: number;
        height: number;
    };
}>;
