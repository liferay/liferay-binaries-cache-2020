/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module uploadcare/uploadcareimageedit/uploadcareimageeditediting
 * @publicApi
 */
import { Plugin } from 'ckeditor5/src/core.js';
import { Notification } from 'ckeditor5/src/ui.js';
import { UploadcareEditing } from '../uploadcareediting.js';
/**
 * The Uploadcare image editing plugin.
 *
 * It complements the {@link module:uploadcare/uploadcare~Uploadcare Uploadcare feature} by adding editing capabilities for uploaded images.
 */
export declare class UploadcareImageEditEditing extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "UploadcareImageEditEditing";
    /**
     * @inheritDoc
     */
    static get requires(): readonly [typeof UploadcareEditing, typeof Notification, "ImageUtils", "ImageEditing"];
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    init(): void;
}
