/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import{Plugin as _0x4dc05e}from'ckeditor5/src/core.js';import{FileRepository as _0x321565}from'ckeditor5/src/upload.js';import{UploadcareEditing as _0x57a5af}from'./uploadcareediting.js';import{UploadUtils as _0x2f4482}from'./utils/uploadutils.js';import{getImageUrls as _0x527ff8}from'./utils/editingutils.js';export class UploadcareUploadAdapter extends _0x4dc05e{static get['requires'](){return['ImageUploadEditing','ImageUploadProgress',_0x321565,_0x57a5af];}static get['pluginName'](){return'UploadcareUploadAdapter';}static get['isOfficialPlugin'](){return!0x0;}static get['isPremiumPlugin'](){return!0x0;}async['afterInit'](){const _0x16fa0a=this['editor'];if(!!!_0x16fa0a['config']['get']('uploadcare'))return;_0x16fa0a['plugins']['get'](_0x321565)['createUploadAdapter']=_0x1ffb0a=>new A(_0x1ffb0a,_0x16fa0a),_0x16fa0a['plugins']['get']('ImageUploadEditing')['on']('uploadComplete',(_0x1ae630,{imageElement:_0x5173ac,data:_0x1dad44})=>{_0x16fa0a['model']['change'](_0x44ac20=>{_0x44ac20['setAttribute']('uploadcareImageId',_0x1dad44['uploadcareImageId'],_0x5173ac);});});}}class A{['loader'];['editor'];['controller'];constructor(_0x57bbc7,_0x14de47){this['loader']=_0x57bbc7,this['editor']=_0x14de47,this['controller']=new AbortController();}async['upload'](){const t=this['editor']['t'],_0x443164=this['editor']['config']['get']('uploadcare.pubkey'),_0x110fde=await this['loader']['file'];return _0x2f4482['upload']({'file':_0x110fde,'publicKey':_0x443164,'signal':this['controller']['signal'],'onProgress':_0x58df1a=>{_0x58df1a&&_0x58df1a['isComputable']&&(this['loader']['uploadTotal']=0x1,this['loader']['uploaded']=_0x58df1a['value']);}})['then'](async _0x8ce9fa=>{const {imageFallbackUrl:_0x2514a8,imageSources:_0x5cbb11}=_0x527ff8(_0x8ce9fa['cdnUrl'],_0x8ce9fa['imageInfo']['width']);return{'uploadcareImageId':_0x8ce9fa['uuid'],'default':_0x2514a8,'sources':_0x5cbb11};})['catch'](()=>{const _0xaad4f5=t('Cannot\x20upload\x20file:')+('\x20'+_0x110fde['name']+'.');return Promise['reject'](_0xaad4f5);});}['abort'](){this['controller']['abort']();}}