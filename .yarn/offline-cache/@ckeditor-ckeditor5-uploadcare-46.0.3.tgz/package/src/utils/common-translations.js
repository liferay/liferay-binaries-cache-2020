/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
import{UploadcareSource as _0x23b4b1}from'../uploadcareconfig.js';export function getTranslation(_0x5672a1,_0x1c4086,_0x203016){const t=_0x5672a1['t'],_0x40cef5=_0x5672a1['t'];switch(_0x1c4086){case _0x23b4b1['Local']:return{'text':_0x40cef5('Insert'===_0x203016?'Upload\x20from\x20computer':'Replace\x20from\x20computer'),'shortText':_0x40cef5('From\x20computer')};case _0x23b4b1['URL']:return{'text':'Insert'===_0x203016?_0x40cef5('Insert\x20via\x20URL'):t('Replace\x20via\x20URL'),'shortText':_0x40cef5('Via\x20URL')};case _0x23b4b1['Dropbox']:return{'text':t('Insert'===_0x203016?'Insert\x20with\x20Dropbox':'Replace\x20with\x20Dropbox'),'shortText':t('With\x20Dropbox')};case _0x23b4b1['Facebook']:return{'text':t('Insert'===_0x203016?'Insert\x20with\x20Facebook':'Replace\x20with\x20Facebook'),'shortText':t('With\x20Facebook')};case _0x23b4b1['GDrive']:return{'text':t('Insert'===_0x203016?'Insert\x20with\x20Google\x20Drive':'Replace\x20with\x20Google\x20Drive'),'shortText':t('With\x20Google\x20Drive')};case _0x23b4b1['GPhotos']:return{'text':t('Insert'===_0x203016?'Insert\x20with\x20Google\x20Photos':'Replace\x20with\x20Google\x20Photos'),'shortText':t('With\x20Google\x20Photos')};case _0x23b4b1['OneDrive']:return{'text':t('Insert'===_0x203016?'Insert\x20with\x20OneDrive':'Replace\x20with\x20OneDrive'),'shortText':t('With\x20OneDrive')};default:return _0x1c4086;}}