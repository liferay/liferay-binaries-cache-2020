/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * Checks if specified wrapper element is one of the ancestors of event target element.
 */
export declare function isAncestor(evt: KeyboardEvent, wrapper: HTMLElement): boolean;
