/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x8a5669=_0x2657;(function(_0xecd1be,_0x1fcafc){var _0xcc5ba3=_0x2657,_0x18c6b7=_0xecd1be();while(!![]){try{var _0x2b9bcd=-parseInt(_0xcc5ba3(0x175))/0x1+parseInt(_0xcc5ba3(0x181))/0x2*(parseInt(_0xcc5ba3(0x17c))/0x3)+-parseInt(_0xcc5ba3(0x17d))/0x4*(-parseInt(_0xcc5ba3(0x176))/0x5)+parseInt(_0xcc5ba3(0x17e))/0x6+-parseInt(_0xcc5ba3(0x177))/0x7+-parseInt(_0xcc5ba3(0x17f))/0x8*(-parseInt(_0xcc5ba3(0x180))/0x9)+parseInt(_0xcc5ba3(0x17a))/0xa;if(_0x2b9bcd===_0x1fcafc)break;else _0x18c6b7['push'](_0x18c6b7['shift']());}catch(_0x487d05){_0x18c6b7['push'](_0x18c6b7['shift']());}}}(_0x3ab8,0x803f0));import{uploadFile as _0x6990d3,info as _0x4f4183}from'@uploadcare/upload-client';function _0x2657(_0x7c3a44,_0x22e3d8){var _0x3ab86b=_0x3ab8();return _0x2657=function(_0x2657fe,_0x3e7787){_0x2657fe=_0x2657fe-0x175;var _0xb19ff3=_0x3ab86b[_0x2657fe];return _0xb19ff3;},_0x2657(_0x7c3a44,_0x22e3d8);}export class UploadUtils{static[_0x8a5669(0x179)]({file:_0x432afe,publicKey:_0x14a2d7,signal:_0x272081,onProgress:_0x4b6a5d}){var _0x52336b=_0x8a5669;return _0x6990d3(_0x432afe,{'publicKey':_0x14a2d7,'store':_0x52336b(0x178),'signal':_0x272081,'onProgress':_0x4b6a5d});}static[_0x8a5669(0x17b)](_0x3d655c,_0x27b0e3){return _0x4f4183(_0x3d655c,_0x27b0e3);}}function _0x3ab8(){var _0x2175d2=['3318770JDqOkq','auto','upload','4514490kVIOfY','getInfo','3TPtGnw','638692iUXnzd','4786788sXIHub','48uPaJFY','485010Mwpxqh','325362BhJnEl','895535meQGfK','5AhLmow'];_0x3ab8=function(){return _0x2175d2;};return _0x3ab8();}