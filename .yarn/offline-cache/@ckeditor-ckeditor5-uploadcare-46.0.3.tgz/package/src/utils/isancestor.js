/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x1389(_0x2e8624,_0x489b84){var _0x225524=_0x2255();return _0x1389=function(_0x138988,_0x1c94e8){_0x138988=_0x138988-0xa2;var _0x158d00=_0x225524[_0x138988];return _0x158d00;},_0x1389(_0x2e8624,_0x489b84);}(function(_0x4a2020,_0x1987c9){var _0x5ffb76=_0x1389,_0x597471=_0x4a2020();while(!![]){try{var _0xf0f608=-parseInt(_0x5ffb76(0xa6))/0x1+parseInt(_0x5ffb76(0xa3))/0x2+-parseInt(_0x5ffb76(0xab))/0x3*(parseInt(_0x5ffb76(0xa9))/0x4)+-parseInt(_0x5ffb76(0xad))/0x5+-parseInt(_0x5ffb76(0xa4))/0x6*(parseInt(_0x5ffb76(0xa5))/0x7)+parseInt(_0x5ffb76(0xa7))/0x8+parseInt(_0x5ffb76(0xac))/0x9*(parseInt(_0x5ffb76(0xa8))/0xa);if(_0xf0f608===_0x1987c9)break;else _0x597471['push'](_0x597471['shift']());}catch(_0x28d531){_0x597471['push'](_0x597471['shift']());}}}(_0x2255,0xb6b0f));import{getAncestors as _0x16b203}from'ckeditor5/src/utils.js';function _0x2255(){var _0xfec945=['784679eTLsEE','1101817XrapBh','4571384RNXVzl','10jASDQz','4iVVAGu','includes','311169zlDetH','13098681RToZwM','1761265UOWKkO','target','1455304iOcsCQ','24oPtQoj'];_0x2255=function(){return _0xfec945;};return _0x2255();}export function isAncestor(_0x3e5935,_0x5324ec){var _0x20de9a=_0x1389;return _0x16b203(_0x3e5935[_0x20de9a(0xa2)])[_0x20de9a(0xaa)](_0x5324ec);}