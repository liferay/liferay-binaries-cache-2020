/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x12d099=_0x146d;(function(_0x370072,_0x4ec5b1){var _0x11b4f1=_0x146d,_0x1c8c8b=_0x370072();while(!![]){try{var _0x5b44eb=parseInt(_0x11b4f1(0xe5))/0x1+parseInt(_0x11b4f1(0xde))/0x2+parseInt(_0x11b4f1(0xe2))/0x3*(parseInt(_0x11b4f1(0xdb))/0x4)+parseInt(_0x11b4f1(0xe4))/0x5+-parseInt(_0x11b4f1(0xda))/0x6+-parseInt(_0x11b4f1(0xe8))/0x7*(parseInt(_0x11b4f1(0xe3))/0x8)+parseInt(_0x11b4f1(0xd9))/0x9*(-parseInt(_0x11b4f1(0xe0))/0xa);if(_0x5b44eb===_0x4ec5b1)break;else _0x1c8c8b['push'](_0x1c8c8b['shift']());}catch(_0x1e27c0){_0x1c8c8b['push'](_0x1c8c8b['shift']());}}}(_0x1a4b,0x9f783));import{FocusTracker as _0x54c9d7}from'ckeditor5/src/utils.js';import{View as _0x3a72bd,FocusCycler as _0x14a2dd}from'ckeditor5/src/ui.js';function _0x1a4b(){var _0x3cc1b5=['4941300EytNRx','271467bFVpeY','div','forwardCycle','329DsHpEh','bindTemplate','focusCycler','createCollection','183177vnDzSt','3640662OaRvrH','104jXqUPf','fire','focusTracker','1144504mrZJwM','true','500iJRECe','getFocusableElement','134886uliljW','123128EdNOjd'];_0x1a4b=function(){return _0x3cc1b5;};return _0x1a4b();}import'../../theme/uploadcare-form.css';function _0x146d(_0x55f26a,_0x376bf0){var _0x1a4b02=_0x1a4b();return _0x146d=function(_0x146dcf,_0x30211c){_0x146dcf=_0x146dcf-0xd9;var _0x3ab7a0=_0x1a4b02[_0x146dcf];return _0x3ab7a0;},_0x146d(_0x55f26a,_0x376bf0);}export class DialogFocusManagerView extends _0x3a72bd{[_0x12d099(0xdd)];[_0x12d099(0xea)];constructor(_0x1d3721){var _0x3e2d1e=_0x12d099;super(_0x1d3721),this[_0x3e2d1e(0xdd)]=new _0x54c9d7(),this[_0x3e2d1e(0xea)]=new _0x14a2dd({'focusables':this[_0x3e2d1e(0xeb)](),'focusTracker':this[_0x3e2d1e(0xdd)]});}[_0x12d099(0xe1)](){var _0x35cc5b=_0x12d099;return{'tag':_0x35cc5b(0xe6),'attributes':{'aria-hidden':_0x35cc5b(0xdf),'tabindex':'0'},'on':{'focus':this[_0x35cc5b(0xe9)]['to'](()=>{var _0x235495=_0x35cc5b;this[_0x235495(0xea)][_0x235495(0xdc)](_0x235495(0xe7));})}};}}