/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module uploadcare/utils/dialogfocusmanagerview
 */
import { type Locale } from 'ckeditor5/src/utils.js';
import { View, type TemplateDefinition } from 'ckeditor5/src/ui.js';
import '../../theme/uploadcare-form.css';
/**
 * A helper class that facilitates managing focus within a dialog form. It provides a mechanism
 * for adding a focusable element to the template that redirects the focus back to the dialog.
 *
 * Uploadcare provides web components and iframes that can disrupt the focus flow in the dialog,
 * especially during keyboard navigation, which can result in users losing the ability to cycle through
 * dialog elements.
 */
export declare abstract class DialogFocusManagerView extends View {
    /**
     * @inheritDoc
     */
    constructor(locale: Locale);
    /**
     * Returns a focusable element that should be added to the template where needed.
     * This element helps with focus management within the dialog.
     */
    getFocusableElement(): TemplateDefinition;
}
