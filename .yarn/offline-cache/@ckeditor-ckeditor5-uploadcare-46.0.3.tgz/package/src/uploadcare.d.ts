/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module uploadcare/uploadcare
 * @publicApi
 */
import { Plugin, type Editor } from 'ckeditor5/src/core.js';
import { UploadcareUI } from './uploadcareui.js';
import { UploadcareEditing } from './uploadcareediting.js';
import * as UC from '@uploadcare/file-uploader';
declare global {
    interface HTMLElementTagNameMap {
        'uc-config': HTMLElement;
        'uc-upload-ctx-provider': UC.UploaderBlock;
        'uc-file-uploader-inline': UC.FileUploaderInline;
        'uc-cloud-image-editor': UC.CloudImageEditor;
    }
}
/**
 * The Uploadcare feature, a bridge between the CKEditor 5 WYSIWYG editor and the Uploadcare file uploader.
 *
 * Check out the {@glink features/images/image-upload/image-upload Image upload} guide to learn about other ways to upload
 * images into CKEditor 5.
 */
export declare class Uploadcare extends Plugin {
    /**
     * @inheritDoc
     */
    static get requires(): readonly [typeof UploadcareEditing, typeof UploadcareUI];
    /**
     * @inheritDoc
     */
    static get pluginName(): "Uploadcare";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    constructor(editor: Editor);
}
