/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module uploadcare/uploadcareimageedit
 * @publicApi
 */
import { Plugin } from 'ckeditor5/src/core.js';
import { UploadcareImageEditEditing } from './uploadcareimageedit/uploadcareimageeditediting.js';
import { UploadcareImageEditUI } from './uploadcareimageedit/uploadcareimageeditui.js';
/**
 * The Uploadcare image edit feature.
 */
export declare class UploadcareImageEdit extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "UploadcareImageEdit";
    /**
     * @inheritDoc
     */
    static get requires(): readonly [typeof UploadcareImageEditEditing, typeof UploadcareImageEditUI];
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
}
