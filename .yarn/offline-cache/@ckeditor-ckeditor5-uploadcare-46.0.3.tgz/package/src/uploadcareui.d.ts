/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module uploadcare/uploadcareui
 * @publicApi
 */
import { Plugin } from 'ckeditor5/src/core.js';
import '@uploadcare/file-uploader/web/uc-file-uploader-inline.min.css';
import '../theme/uploadcare-theme.css';
import '../theme/uploadcareimageedit.css';
/**
 * The UI plugin of the AI assistant.
 */
export declare class UploadcareUI extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "UploadcareUI";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    init(): void;
    /**
     * @inheritDoc
     */
    afterInit(): void;
    /**
     * @inheritDoc
     */
    destroy(): void;
}
