CKEditor&nbsp;5 Format painter feature
======================================

[![npm version](https://badge.fury.io/js/%40ckeditor%2Fckeditor5-format-painter.svg)](https://www.npmjs.com/package/@ckeditor/ckeditor5-format-painter)

This package contains the format painter feature for CKEditor&nbsp;5. It allows you to copy text formatting (such as bold, italic, font size, color, etc.) and apply it in a different place in the edited document.

This is a premium feature. Sign up for a [free non-commitment 14-day trial](https://portal.ckeditor.com/checkout?plan=free), or see: [https://ckeditor.com/pricing](https://ckeditor.com/pricing) for more information.

## Installation

This plugin is part of the `ckeditor5-premium-features` package. Install the whole package to use it.

```bash
npm install ckeditor5-premium-features
```

## Create free account

If you want to check full CKEditor&nbsp;5 capabilities, sign up for a [free non-commitment 14-day trial](https://portal.ckeditor.com/checkout?plan=free).

## Demo

Check out the [demo in the Format painter](https://ckeditor.com/docs/ckeditor5/latest/features/format-painter.html#demo) feature guide.

## Documentation

See the [`@ckeditor/ckeditor5-format-painter` package](https://ckeditor.com/docs/ckeditor5/latest/api/format-painter.html) page in [CKEditor&nbsp;5 documentation](https://ckeditor.com/docs/ckeditor5/latest/) as well as the [Format painter](https://ckeditor.com/docs/ckeditor5/latest/features/format-painter.html) feature guide.

## Getting support

The CKEditor&nbsp;5 Format painter feature comes with outstanding support from a dedicated team of customer care specialists, QA engineers, and CKEditor&nbsp;5 developers. The team will gladly assist you in all aspects from setting up your account to integrating the CKEditor&nbsp;5 Format painter feature with your application.

As a licensed CKEditor&nbsp;5 Format painter feature user you can report bugs and request features directly through the CKEditor Ecosystem customer dashboard.

## License

**CKEditor&nbsp;5 Format painter feature** (https://ckeditor.com/ckeditor-5/)<br>
Copyright (c) 2003–2025, [CKSource Holding sp. z o.o.](https://cksource.com)  All rights reserved.

CKEditor&nbsp;5 Format painter feature is licensed under a commercial license and is protected by copyright law. For more information, see: [https://ckeditor.com/pricing](https://ckeditor.com/pricing).

### Trademarks

**CKEditor** is a trademark of [CKSource Holding sp. z o.o.](https://cksource.com)  All other brand and product names are trademarks, registered trademarks or service marks of their respective holders.
