/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module format-painter
 */
export { type COPY_FORMAT_COMMAND_NAME, type PASTE_FORMAT_COMMAND_NAME } from './utils.js';
export { FormatPainter } from './formatpainter.js';
export { FormatPainterEditing, type FormattingAttributesValues } from './formatpainterediting.js';
export { FormatPainterUI } from './formatpainterui.js';
export { PasteFormatCommand } from './pasteformatcommand.js';
export { CopyFormatCommand } from './copyformatcommand.js';
import './augmentation.js';
