/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module format-painter/formatpainterediting
 */
import { Plugin } from 'ckeditor5/src/core.js';
/**
 * The format painter editing feature. It introduces two commands: `copyFormat` and `pasteFormat`.
 */
export declare class FormatPainterEditing extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "FormatPainterEditing";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    init(): void;
    /**
     * @inheritDoc
     */
    destroy(): void;
}
/**
 * An object with key-value pairs describing formatting model attributes and their values.
 */
export type FormattingAttributesValues = {
    [k: string]: unknown;
};
