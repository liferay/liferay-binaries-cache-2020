/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x5b7f28=_0x34cc;(function(_0x540ed2,_0x10cf0d){var _0x5b53fa=_0x34cc,_0x570a55=_0x540ed2();while(!![]){try{var _0x3317d0=parseInt(_0x5b53fa(0x1e6))/0x1+parseInt(_0x5b53fa(0x1ed))/0x2*(parseInt(_0x5b53fa(0x1e7))/0x3)+parseInt(_0x5b53fa(0x1ef))/0x4*(-parseInt(_0x5b53fa(0x1e9))/0x5)+parseInt(_0x5b53fa(0x1e2))/0x6*(parseInt(_0x5b53fa(0x1ec))/0x7)+-parseInt(_0x5b53fa(0x1e1))/0x8+-parseInt(_0x5b53fa(0x1ee))/0x9*(parseInt(_0x5b53fa(0x1eb))/0xa)+parseInt(_0x5b53fa(0x1e5))/0xb;if(_0x3317d0===_0x10cf0d)break;else _0x570a55['push'](_0x570a55['shift']());}catch(_0x55563f){_0x570a55['push'](_0x570a55['shift']());}}}(_0x54c0,0x73bbf));import{Plugin as _0x424439}from'ckeditor5/src/core.js';function _0x54c0(){var _0x3bbd20=['isPremiumPlugin','requires','17169240AWOtAJ','3053BCNnHK','516021abiYlb','pluginName','379570oNCPEi','FormatPainter','10zvXmHf','5222OlUbwM','2tsFlvJ','3784068iKtFvY','28FQyWcB','isOfficialPlugin','5511768pgnoHt','3048rZiZBD'];_0x54c0=function(){return _0x3bbd20;};return _0x54c0();}import{FormatPainterEditing as _0x157357}from'./formatpainterediting.js';function _0x34cc(_0x37cef2,_0x1d42f5){var _0x54c0ae=_0x54c0();return _0x34cc=function(_0x34cc0b,_0x111e82){_0x34cc0b=_0x34cc0b-0x1e0;var _0x45efef=_0x54c0ae[_0x34cc0b];return _0x45efef;},_0x34cc(_0x37cef2,_0x1d42f5);}import{FormatPainterUI as _0x2bab34}from'./formatpainterui.js';export class FormatPainter extends _0x424439{static get[_0x5b7f28(0x1e4)](){return[_0x157357,_0x2bab34];}static get[_0x5b7f28(0x1e8)](){var _0x2116d8=_0x5b7f28;return _0x2116d8(0x1ea);}static get[_0x5b7f28(0x1e0)](){return!0x0;}static get[_0x5b7f28(0x1e3)](){return!0x0;}}