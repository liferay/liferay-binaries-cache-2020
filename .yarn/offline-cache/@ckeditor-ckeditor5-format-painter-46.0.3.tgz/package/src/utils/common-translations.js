/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
export function getTranslation(_0x3f6782,_0x5937ca){const t=_0x3f6782['t'];switch(_0x5937ca){case'Paint\x20formatting':return t('Paint\x20formatting');case'Copy\x20text\x20formatting':return t('Copy\x20text\x20formatting');case'Paste\x20text\x20formatting':return t('Paste\x20text\x20formatting');case'Continuous\x20painting':return t('Continuous\x20painting');case'Keeps\x20the\x20painter\x20on\x20after\x20setting\x20the\x20formatting.':return t('Keeps\x20the\x20painter\x20on\x20after\x20setting\x20the\x20formatting.');case'Formatting\x20copied.':return t('Formatting\x20copied.');case'Pasted\x20formatting.':return t('Pasted\x20formatting.');default:return _0x5937ca;}}