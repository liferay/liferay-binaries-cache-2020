/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x4a3803=_0xac50;(function(_0x168815,_0x359fff){const _0x5dd44e=_0xac50,_0xc31d69=_0x168815();while(!![]){try{const _0x1c10b0=-parseInt(_0x5dd44e(0xe5))/0x1*(-parseInt(_0x5dd44e(0xdf))/0x2)+-parseInt(_0x5dd44e(0xe4))/0x3+-parseInt(_0x5dd44e(0xdc))/0x4+parseInt(_0x5dd44e(0xe7))/0x5+parseInt(_0x5dd44e(0xe2))/0x6*(-parseInt(_0x5dd44e(0xe1))/0x7)+parseInt(_0x5dd44e(0xe8))/0x8*(-parseInt(_0x5dd44e(0xe3))/0x9)+parseInt(_0x5dd44e(0xde))/0xa;if(_0x1c10b0===_0x359fff)break;else _0xc31d69['push'](_0xc31d69['shift']());}catch(_0x1b1593){_0xc31d69['push'](_0xc31d69['shift']());}}}(_0x4d79,0xeeb37));export const COPY_FORMAT_COMMAND_NAME=_0x4a3803(0xdd);export const PASTE_FORMAT_COMMAND_NAME=_0x4a3803(0xe0);function _0xac50(_0x4da9b8,_0x536ba9){const _0x4d7984=_0x4d79();return _0xac50=function(_0xac50b8,_0x245bb9){_0xac50b8=_0xac50b8-0xdc;let _0x2829ed=_0x4d7984[_0xac50b8];return _0x2829ed;},_0xac50(_0x4da9b8,_0x536ba9);}export const CURSOR_ACTIVE_CSS_CLASS=_0x4a3803(0xe6);function _0x4d79(){const _0x3d0d87=['9OjDYew','1103406VEIxGY','132697KqTPUF','ck-format-painter-active','1814240zHvIpn','14025304vFVKwn','4008520LqoeIH','copyFormat','33061470TlNMAR','14Mpiixy','pasteFormat','35nkQHlg','596472brFFGL'];_0x4d79=function(){return _0x3d0d87;};return _0x4d79();}