/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x385d(){const _0x268f9e=['reset','change:isEnabled','editor','46560tllyYo','401646WUwsUV','isFormatting','2GmkRrg','value','getAttributes','filter','model','33976VnZqAI','document','_getFormattingAttributes','get','getAttributeProperties','refresh','fromEntries','144079krYvVr','selection','execute','commands','from','4242QXYKHy','371271YURlxy','189JHWyST','135500BjNsDk','25nhkXEz','schema','change:value'];_0x385d=function(){return _0x268f9e;};return _0x385d();}const _0x260d2d=_0xf47b;function _0xf47b(_0x353b48,_0x3b871b){const _0x385d94=_0x385d();return _0xf47b=function(_0xf47b38,_0x193430){_0xf47b38=_0xf47b38-0x1cf;let _0x1888c1=_0x385d94[_0xf47b38];return _0x1888c1;},_0xf47b(_0x353b48,_0x3b871b);}(function(_0x21b35f,_0x40f8d7){const _0x143e42=_0xf47b,_0x1a6ec7=_0x21b35f();while(!![]){try{const _0xfa557d=-parseInt(_0x143e42(0x1d0))/0x1*(-parseInt(_0x143e42(0x1e2))/0x2)+parseInt(_0x143e42(0x1d6))/0x3+parseInt(_0x143e42(0x1e7))/0x4+parseInt(_0x143e42(0x1d9))/0x5*(-parseInt(_0x143e42(0x1e0))/0x6)+parseInt(_0x143e42(0x1d5))/0x7+parseInt(_0x143e42(0x1df))/0x8+parseInt(_0x143e42(0x1d7))/0x9*(parseInt(_0x143e42(0x1d8))/0xa);if(_0xfa557d===_0x40f8d7)break;else _0x1a6ec7['push'](_0x1a6ec7['shift']());}catch(_0xd9d247){_0x1a6ec7['push'](_0x1a6ec7['shift']());}}}(_0x385d,0x38c99));import{Command as _0x230224}from'ckeditor5/src/core.js';import{PASTE_FORMAT_COMMAND_NAME as _0x3271c6}from'./utils.js';export class CopyFormatCommand extends _0x230224{constructor(_0xe60daa){const _0x52888e=_0xf47b;super(_0xe60daa),this[_0x52888e(0x1e3)]=void 0x0,this['on'](_0x52888e(0x1dd),(_0x5086f3,_0x339243,_0x460acd)=>{const _0x1c1753=_0x52888e;_0x460acd||this[_0x1c1753(0x1dc)]();}),this['on'](_0x52888e(0x1db),()=>_0xe60daa[_0x52888e(0x1d3)][_0x52888e(0x1ea)](_0x3271c6)[_0x52888e(0x1ec)]());}[_0x260d2d(0x1d2)](){const _0x3adc24=_0x260d2d;this[_0x3adc24(0x1e3)]=this[_0x3adc24(0x1e9)]();}[_0x260d2d(0x1dc)](){const _0xed0b5f=_0x260d2d;this[_0xed0b5f(0x1e3)]=void 0x0;}[_0x260d2d(0x1e9)](){const _0x5efec2=_0x260d2d,_0x4c27b8=this[_0x5efec2(0x1de)][_0x5efec2(0x1e6)],_0x33a084=_0x4c27b8[_0x5efec2(0x1e8)][_0x5efec2(0x1d1)];return Object[_0x5efec2(0x1cf)](Array[_0x5efec2(0x1d4)](_0x33a084[_0x5efec2(0x1e4)]())[_0x5efec2(0x1e5)](([_0xcf83b3])=>_0x4c27b8[_0x5efec2(0x1da)][_0x5efec2(0x1eb)](_0xcf83b3)[_0x5efec2(0x1e1)]));}}