/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import type { FormatPainter, FormatPainterEditing, FormatPainterUI, PasteFormatCommand, CopyFormatCommand, COPY_FORMAT_COMMAND_NAME, PASTE_FORMAT_COMMAND_NAME } from './index.js';
declare module '@ckeditor/ckeditor5-core' {
    interface PluginsMap {
        [FormatPainter.pluginName]: FormatPainter;
        [FormatPainterEditing.pluginName]: FormatPainterEditing;
        [FormatPainterUI.pluginName]: FormatPainterUI;
    }
    interface CommandsMap {
        [COPY_FORMAT_COMMAND_NAME]: CopyFormatCommand;
        [PASTE_FORMAT_COMMAND_NAME]: PasteFormatCommand;
    }
}
