/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x51c93f,_0x31fbe8){var _0x5f5a95=_0x1e86,_0x395277=_0x51c93f();while(!![]){try{var _0x13ff44=parseInt(_0x5f5a95(0x19b))/0x1+-parseInt(_0x5f5a95(0x198))/0x2+parseInt(_0x5f5a95(0x19a))/0x3*(parseInt(_0x5f5a95(0x19c))/0x4)+-parseInt(_0x5f5a95(0x197))/0x5+-parseInt(_0x5f5a95(0x199))/0x6+-parseInt(_0x5f5a95(0x19e))/0x7*(-parseInt(_0x5f5a95(0x1a0))/0x8)+parseInt(_0x5f5a95(0x19f))/0x9*(parseInt(_0x5f5a95(0x19d))/0xa);if(_0x13ff44===_0x31fbe8)break;else _0x395277['push'](_0x395277['shift']());}catch(_0x50082a){_0x395277['push'](_0x395277['shift']());}}}(_0x1cac,0x960de));export{FormatPainter}from'./formatpainter.js';export{FormatPainterEditing}from'./formatpainterediting.js';export{FormatPainterUI}from'./formatpainterui.js';export{PasteFormatCommand}from'./pasteformatcommand.js';function _0x1e86(_0x1d9e6e,_0x13a077){var _0x1cacf2=_0x1cac();return _0x1e86=function(_0x1e86dc,_0x598be4){_0x1e86dc=_0x1e86dc-0x197;var _0x4608fc=_0x1cacf2[_0x1e86dc];return _0x4608fc;},_0x1e86(_0x1d9e6e,_0x13a077);}function _0x1cac(){var _0x549681=['4402880FXcReU','2068088iWyJPr','949848ZXCKVA','676887qVLleS','745097JqwFHJ','4KLWUaJ','2674190wIKlVc','636454TMnRlD','18pOotmk','104jfFMVe'];_0x1cac=function(){return _0x549681;};return _0x1cac();}export{CopyFormatCommand}from'./copyformatcommand.js';import'./augmentation.js';