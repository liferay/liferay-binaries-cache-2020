/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module format-painter/utils
 */
/**
 * The name of the {@link module:format-painter/copyformatcommand~CopyFormatCommand} registered in the editor's command collection.
 *
 * @protected
 */
export declare const COPY_FORMAT_COMMAND_NAME = "copyFormat";
/**
 * The name of the {@link module:format-painter/pasteformatcommand~PasteFormatCommand} registered in the editor's command collection.
 *
 * @protected
 */
export declare const PASTE_FORMAT_COMMAND_NAME = "pasteFormat";
/**
 * The CSS class set on the editing roots during format painting by the {@link module:format-painter/formatpainterui~FormatPainterUI}.
 *
 * @protected
 */
export declare const CURSOR_ACTIVE_CSS_CLASS = "ck-format-painter-active";
