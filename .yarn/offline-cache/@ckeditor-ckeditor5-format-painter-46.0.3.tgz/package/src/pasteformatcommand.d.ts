/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import { Command, type Editor } from 'ckeditor5/src/core.js';
import type { FormattingAttributesValues } from './formatpainterediting.js';
/**
 * The command allows to paste the formatting onto the current {@link module:engine/model/selection~ModelSelection model selection}.
 *
 * @extends module:core/command~Command
 */
export declare class PasteFormatCommand extends Command {
    /**
     * @inheritDoc
     */
    constructor(editor: Editor);
    /**
     * Executes the command.
     *
     * @fires execute
     */
    execute(formattingToSet?: FormattingAttributesValues | undefined): void;
}
