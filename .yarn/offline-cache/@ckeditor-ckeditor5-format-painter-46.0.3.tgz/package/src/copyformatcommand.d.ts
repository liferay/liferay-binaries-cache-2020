/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module format-painter/copyformatcommand
 * @publicApi
 */
import { Command, type Editor } from 'ckeditor5/src/core.js';
import type { FormattingAttributesValues } from './formatpainterediting.js';
/**
 * This command copies the formatting from the current {@link module:engine/model/selection~ModelSelection model selection}
 * and stores it in its {@link module:format-painter/copyformatcommand~CopyFormatCommand#value} property.
 *
 * The formatting can then be pasted using the {@link module:format-painter/pasteformatcommand~PasteFormatCommand}.
 *
 * @extends module:core/command~Command
 */
export declare class CopyFormatCommand extends Command {
    value: FormattingAttributesValues | undefined;
    /**
     * Creates a new `CopyFormatCommand` instance.
     *
     * @param {module:core/editor/editor~Editor} editor The editor on which this command will be used.
     */
    constructor(editor: Editor);
    /**
     * Executes the command. The formatting is then stored in the {@link #value} property.
     *
     * @fires execute
     */
    execute(): void;
    /**
     * Resets the stored formatting.
     */
    reset(): void;
}
