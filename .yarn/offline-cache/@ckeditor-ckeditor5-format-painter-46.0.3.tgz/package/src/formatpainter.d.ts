/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module format-painter/formatpainter
 * @publicApi
 */
import { Plugin } from 'ckeditor5/src/core.js';
import { FormatPainterEditing } from './formatpainterediting.js';
import { FormatPainterUI } from './formatpainterui.js';
/**
 * The format painter feature.
 *
 * For a detailed overview, check the {@glink features/format-painter Format painter} feature documentation.
 *
 * @extends module:core/plugin~Plugin
 */
export declare class FormatPainter extends Plugin {
    /**
     * @inheritDoc
     */
    static get requires(): readonly [typeof FormatPainterEditing, typeof FormatPainterUI];
    /**
     * @inheritDoc
     */
    static get pluginName(): "FormatPainter";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
}
