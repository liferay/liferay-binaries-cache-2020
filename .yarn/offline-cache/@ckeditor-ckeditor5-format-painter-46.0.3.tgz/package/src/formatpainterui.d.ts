/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module format-painter/formatpainterui
 */
import { Plugin } from 'ckeditor5/src/core.js';
import '../theme/formatpainter.css';
declare const FormatPainterUI_base: import("ckeditor5/src/utils.js").Mixed<typeof Plugin, import("ckeditor5/src/utils.js").DomEmitter>;
/**
 * The format painter UI feature. It introduces the `formatPainter` dropdown with a "Continuous painting"
 * switch button.
 *
 * The first click on the dropdown button copies the formatting of the selected text.
 * Then the next click in the editor editable pastes the formatting.
 */
export declare class FormatPainterUI extends /* #__PURE__ -- @preserve */ FormatPainterUI_base {
    /**
     * @inheritDoc
     */
    static get pluginName(): "FormatPainterUI";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    init(): void;
    /**
     * @inheritDoc
     */
    afterInit(): void;
}
export {};
