/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x52461e,_0xa7efb8){var _0x11503f=_0x202c,_0x13e734=_0x52461e();while(!![]){try{var _0x1fffc6=-parseInt(_0x11503f(0x101))/0x1*(-parseInt(_0x11503f(0x103))/0x2)+parseInt(_0x11503f(0xfb))/0x3+-parseInt(_0x11503f(0xfd))/0x4*(parseInt(_0x11503f(0x100))/0x5)+-parseInt(_0x11503f(0xff))/0x6+parseInt(_0x11503f(0x104))/0x7+parseInt(_0x11503f(0x102))/0x8+-parseInt(_0x11503f(0xfc))/0x9*(parseInt(_0x11503f(0xfe))/0xa);if(_0x1fffc6===_0xa7efb8)break;else _0x13e734['push'](_0x13e734['shift']());}catch(_0x508ac2){_0x13e734['push'](_0x13e734['shift']());}}}(_0x1f51,0x8249b));function _0x202c(_0x33e81f,_0x272252){var _0x1f512e=_0x1f51();return _0x202c=function(_0x202c15,_0xfd44fd){_0x202c15=_0x202c15-0xfb;var _0x31468d=_0x1f512e[_0x202c15];return _0x31468d;},_0x202c(_0x33e81f,_0x272252);}import{CKEditorError as _0xfbb3c7}from'ckeditor5/src/utils.js';function _0x1f51(){var _0x1a1267=['2616Fxpoef','4478920bavCUV','710790pytuos','680dCGaYX','18496wHSkeZ','2372032fuMNJs','2AZaUBW','5636232JUdouN','1550028ATwraW','18khBzKf'];_0x1f51=function(){return _0x1a1267;};return _0x1f51();}