import { Rule, Token } from './types';
export declare function opt(ofRule: Rule | string): Rule;
export declare function list(ofRule: Rule | string, separator?: string | Rule): Rule;
export declare function butNot(rule: Rule, exclusions: Array<Rule>): Rule;
export declare function t(kind: string, style: string): {
    style: string;
    match: (token: Token) => boolean;
};
export declare function p(value: string, style?: string): Rule;
//# sourceMappingURL=RuleHelpers.d.ts.map