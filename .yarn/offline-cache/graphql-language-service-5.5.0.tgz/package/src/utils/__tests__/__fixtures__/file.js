module.exports = {
  example: true,
};
