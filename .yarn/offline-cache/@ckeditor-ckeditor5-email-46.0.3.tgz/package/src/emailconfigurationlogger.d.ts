/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import { type Editor, Plugin } from 'ckeditor5/src/core.js';
/**
 * A utility plugin for email integration that provides logging functionality
 * and checks for unsupported plugins and color values.
 */
export declare class EmailConfigurationLogger extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "EmailConfigurationLogger";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    constructor(editor: Editor);
    /**
     * @inheritDoc
     */
    afterInit(): void;
}
/**
 * Checks if the given color value is not supported in email clients.
 */
export declare function isUnsupportedEmailColorValue(color: string | undefined): boolean;
/**
 * Checks if the given color format is not supported in email clients.
 */
export declare function isUnsupportedEmailColorFormat(color: string | undefined): boolean;
