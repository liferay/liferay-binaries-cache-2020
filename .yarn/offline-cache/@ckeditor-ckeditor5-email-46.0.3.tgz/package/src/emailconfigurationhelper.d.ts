/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module email/emailconfigurationhelper
 * @publicApi
 */
import { Plugin } from 'ckeditor5/src/core.js';
import { HighlightEmailIntegration } from './integrations/highlight.js';
import { ImageEmailIntegration } from './integrations/image.js';
import { MathTypeEmailIntegration } from './integrations/mathtype.js';
import { ExportInlineStylesEmailIntegration } from './integrations/exportinlinestyles.js';
import { ListEmailIntegration } from './integrations/list.js';
import { TableEmailIntegration } from './integrations/table.js';
import { EmptyBlockEmailIntegration } from './integrations/emptyblock.js';
import { FontEmailIntegration } from './integrations/font.js';
import { SourceEditingEmailIntegration } from './integrations/sourceediting.js';
import { MarkdownEmailIntegration } from './integrations/markdown.js';
import { GeneralHtmlIntegrationSupport } from './integrations/generalhtmlintegration.js';
import { MergeFieldsEmailIntegration } from './integrations/mergefields.js';
import { TemplateEmailIntegration } from './integrations/template.js';
import { UploadEmailIntegration } from './integrations/upload.js';
import { MediaEmbedEmailIntegration } from './integrations/mediaembed.js';
import { TodoListEmailIntegration } from './integrations/todolist.js';
import { MultiLevelListEmailIntegration } from './integrations/listmultilevel.js';
import { LinkEmailIntegration } from './integrations/link.js';
/**
 * The email integration plugin.
 *
 * This is a "glue" plugin that integrates the email integration feature with the editor.
 */
export declare class EmailConfigurationHelper extends Plugin {
    /**
     * @inheritDoc
     */
    static get pluginName(): "EmailConfigurationHelper";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    static get requires(): readonly [typeof HighlightEmailIntegration, typeof ImageEmailIntegration, typeof MathTypeEmailIntegration, typeof ExportInlineStylesEmailIntegration, typeof ListEmailIntegration, typeof TableEmailIntegration, typeof EmptyBlockEmailIntegration, typeof FontEmailIntegration, typeof SourceEditingEmailIntegration, typeof MarkdownEmailIntegration, typeof GeneralHtmlIntegrationSupport, typeof MergeFieldsEmailIntegration, typeof TemplateEmailIntegration, typeof UploadEmailIntegration, typeof MediaEmbedEmailIntegration, typeof TodoListEmailIntegration, typeof MultiLevelListEmailIntegration, typeof LinkEmailIntegration];
    /**
     * @inheritDoc
     */
    init(): void;
    /**
     * @inheritDoc
     */
    destroy(): void;
}
