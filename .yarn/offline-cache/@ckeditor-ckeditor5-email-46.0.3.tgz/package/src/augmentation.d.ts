/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
import type { EmailConfigurationConfig } from './emailconfigurationconfig.js';
import type { EmailConfigurationHelper, EmailConfigurationLogger, EmptyBlockEmailIntegration, ExportInlineStylesEmailIntegration, FontEmailIntegration, HighlightEmailIntegration, ImageEmailIntegration, ListEmailIntegration, TableEmailIntegration, MathTypeEmailIntegration, SourceEditingEmailIntegration, MarkdownEmailIntegration } from './index.js';
declare module '@ckeditor/ckeditor5-core' {
    interface EditorConfig {
        /**
         * The configuration of the {@link module:email/emailconfigurationhelper~EmailConfigurationHelper EmailIntegration feature}.
         *
         * Read more in {@link module:email/emailconfigurationconfig~EmailConfigurationConfig}.
         */
        email?: EmailConfigurationConfig;
    }
    interface PluginsMap {
        [EmailConfigurationHelper.pluginName]: EmailConfigurationHelper;
        [EmailConfigurationLogger.pluginName]: EmailConfigurationLogger;
        [EmptyBlockEmailIntegration.pluginName]: EmptyBlockEmailIntegration;
        [ExportInlineStylesEmailIntegration.pluginName]: ExportInlineStylesEmailIntegration;
        [FontEmailIntegration.pluginName]: FontEmailIntegration;
        [HighlightEmailIntegration.pluginName]: HighlightEmailIntegration;
        [ImageEmailIntegration.pluginName]: ImageEmailIntegration;
        [ListEmailIntegration.pluginName]: ListEmailIntegration;
        [TableEmailIntegration.pluginName]: TableEmailIntegration;
        [MathTypeEmailIntegration.pluginName]: MathTypeEmailIntegration;
        [SourceEditingEmailIntegration.pluginName]: SourceEditingEmailIntegration;
        [MarkdownEmailIntegration.pluginName]: MarkdownEmailIntegration;
    }
}
