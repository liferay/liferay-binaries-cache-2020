/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module email
 */
export { EmailConfigurationHelper } from './emailconfigurationhelper.js';
export { EmailConfigurationLogger, isUnsupportedEmailColorValue, isUnsupportedEmailColorFormat } from './emailconfigurationlogger.js';
export { EmptyBlockEmailIntegration } from './integrations/emptyblock.js';
export { ExportInlineStylesEmailIntegration } from './integrations/exportinlinestyles.js';
export { FontEmailIntegration } from './integrations/font.js';
export { GeneralHtmlIntegrationSupport } from './integrations/generalhtmlintegration.js';
export { HighlightEmailIntegration } from './integrations/highlight.js';
export { ImageEmailIntegration } from './integrations/image.js';
export { LinkEmailIntegration } from './integrations/link.js';
export { ListEmailIntegration } from './integrations/list.js';
export { MultiLevelListEmailIntegration } from './integrations/listmultilevel.js';
export { MediaEmbedEmailIntegration } from './integrations/mediaembed.js';
export { MergeFieldsEmailIntegration } from './integrations/mergefields.js';
export { TableEmailIntegration } from './integrations/table.js';
export { MathTypeEmailIntegration } from './integrations/mathtype.js';
export { SourceEditingEmailIntegration } from './integrations/sourceediting.js';
export { MarkdownEmailIntegration } from './integrations/markdown.js';
export { TemplateEmailIntegration } from './integrations/template.js';
export { TodoListEmailIntegration } from './integrations/todolist.js';
export { UploadEmailIntegration } from './integrations/upload.js';
export { getEmailInlineStylesTransformations } from './emailinlinestylestransformations.js';
export type { EmailConfigurationConfig } from './emailconfigurationconfig.js';
import './augmentation.js';
