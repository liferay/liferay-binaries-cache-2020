/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module email/emailinlinestylestransformations
 * @publicApi
 */
import { type ExportInlineStylesTransformation } from '@ckeditor/ckeditor5-export-inline-styles';
/**
 * Returns a collection of style property transformations designed for email compatibility.
 *
 * These transformations convert modern CSS styles into HTML attributes better
 * supported by email clients. The transformations focus on converting alignment-related
 * CSS properties into corresponding HTML attributes.
 *
 * Examples of transformations:
 *
 * 1. Float to align:
 *    * `<img style="float: left">` → `<img align="left">`
 *
 * 2. Shorthand margin for centering:
 *    * `<table style="margin: auto"></table>` → `<table style="..." align="center"></table>`
 *    * `<table style="margin: 10px auto"></table>` → `<table style="..." align="center"></table>`
 *
 * Note:
 *
 * * The `align` attribute is only applied to the `table` and the `img` elements.
 * * The `align` attribute is not applied to elements that already have it set.
 * * The style attributes remain unchanged.
 */
export declare function getEmailInlineStylesTransformations(): Array<ExportInlineStylesTransformation>;
