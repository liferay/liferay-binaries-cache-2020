/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x4d7c(_0x11a4c7,_0x4983a7){var _0x28bf5c=_0x28bf();return _0x4d7c=function(_0x4d7c45,_0x4de331){_0x4d7c45=_0x4d7c45-0x1f1;var _0x33494b=_0x28bf5c[_0x4d7c45];return _0x33494b;},_0x4d7c(_0x11a4c7,_0x4983a7);}var _0x2ffdfe=_0x4d7c;(function(_0x178e92,_0x3b31b0){var _0x330251=_0x4d7c,_0x45c0f1=_0x178e92();while(!![]){try{var _0x337639=-parseInt(_0x330251(0x1ff))/0x1+-parseInt(_0x330251(0x1fd))/0x2*(-parseInt(_0x330251(0x206))/0x3)+-parseInt(_0x330251(0x1f5))/0x4*(parseInt(_0x330251(0x1f7))/0x5)+-parseInt(_0x330251(0x1fb))/0x6*(-parseInt(_0x330251(0x202))/0x7)+parseInt(_0x330251(0x1f3))/0x8*(parseInt(_0x330251(0x204))/0x9)+-parseInt(_0x330251(0x1f4))/0xa*(-parseInt(_0x330251(0x1f6))/0xb)+-parseInt(_0x330251(0x201))/0xc;if(_0x337639===_0x3b31b0)break;else _0x45c0f1['push'](_0x45c0f1['shift']());}catch(_0x573c5b){_0x45c0f1['push'](_0x45c0f1['shift']());}}}(_0x28bf,0x55820));import{Plugin as _0x593955}from'ckeditor5/src/core.js';function _0x28bf(){var _0x44e48b=['34UFXLzX','get','307744UOuiYE','TodoListEmailIntegration','742332UfYYiV','56XVWVdN','plugins','36jDUEzn','afterInit','97707kWEYdt','_checkUnsupportedPlugin','isOfficialPlugin','requires','16064YmJlZJ','40jHyghr','1747664bcIoRY','1398606EdTGkW','5FNjvEX','isPremiumPlugin','editor','pluginName','64854kOfhXK','TodoList'];_0x28bf=function(){return _0x44e48b;};return _0x28bf();}import{EmailConfigurationLogger as _0x4a9e0a}from'../emailconfigurationlogger.js';export class TodoListEmailIntegration extends _0x593955{static get[_0x2ffdfe(0x1f2)](){return[_0x4a9e0a];}static get[_0x2ffdfe(0x1fa)](){var _0x4803c7=_0x2ffdfe;return _0x4803c7(0x200);}static get[_0x2ffdfe(0x1f1)](){return!0x0;}static get[_0x2ffdfe(0x1f8)](){return!0x0;}[_0x2ffdfe(0x205)](){var _0x2b4949=_0x2ffdfe;this[_0x2b4949(0x1f9)][_0x2b4949(0x203)][_0x2b4949(0x1fe)](_0x4a9e0a)[_0x2b4949(0x207)](_0x2b4949(0x1fc));}}