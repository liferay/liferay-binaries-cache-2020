/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x5b4440=_0x1ca5;(function(_0x3c2528,_0x42e76c){var _0x4eabac=_0x1ca5,_0x857fb6=_0x3c2528();while(!![]){try{var _0x5eea97=-parseInt(_0x4eabac(0x1d8))/0x1+-parseInt(_0x4eabac(0x1d1))/0x2*(parseInt(_0x4eabac(0x1d0))/0x3)+-parseInt(_0x4eabac(0x1d3))/0x4*(parseInt(_0x4eabac(0x1ce))/0x5)+-parseInt(_0x4eabac(0x1e3))/0x6*(-parseInt(_0x4eabac(0x1d4))/0x7)+parseInt(_0x4eabac(0x1e2))/0x8+-parseInt(_0x4eabac(0x1dd))/0x9+-parseInt(_0x4eabac(0x1d2))/0xa*(-parseInt(_0x4eabac(0x1cf))/0xb);if(_0x5eea97===_0x42e76c)break;else _0x857fb6['push'](_0x857fb6['shift']());}catch(_0x31ca1f){_0x857fb6['push'](_0x857fb6['shift']());}}}(_0x3719,0x3a5e6));function _0x3719(){var _0x33e88c=['MathType','2658645CuCSTF','isPremiumPlugin','pluginName','isOfficialPlugin','requires','2610280LIdtRm','18JyJKUU','130665ZWAmTh','33rGWFou','189930RgEqfE','6RIgIoR','1954130dmiCln','64tjNwJo','569674vuFOZv','plugins','MathTypeEmailIntegration','afterInit','14129JYoaxY','get','_checkUnsupportedPlugin','editor'];_0x3719=function(){return _0x33e88c;};return _0x3719();}import{Plugin as _0x2b071d}from'ckeditor5/src/core.js';import{EmailConfigurationLogger as _0x3ccd64}from'../emailconfigurationlogger.js';function _0x1ca5(_0x3a34e5,_0x1b2c16){var _0x371960=_0x3719();return _0x1ca5=function(_0x1ca539,_0x4fd26c){_0x1ca539=_0x1ca539-0x1ce;var _0x4ae643=_0x371960[_0x1ca539];return _0x4ae643;},_0x1ca5(_0x3a34e5,_0x1b2c16);}export class MathTypeEmailIntegration extends _0x2b071d{static get[_0x5b4440(0x1e1)](){return[_0x3ccd64];}static get[_0x5b4440(0x1df)](){var _0x26b615=_0x5b4440;return _0x26b615(0x1d6);}static get[_0x5b4440(0x1e0)](){return!0x0;}static get[_0x5b4440(0x1de)](){return!0x0;}[_0x5b4440(0x1d7)](){var _0x516de8=_0x5b4440;this[_0x516de8(0x1db)][_0x516de8(0x1d5)][_0x516de8(0x1d9)](_0x3ccd64)[_0x516de8(0x1da)](_0x516de8(0x1dc));}}