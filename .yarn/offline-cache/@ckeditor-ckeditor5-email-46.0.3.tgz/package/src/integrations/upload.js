/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x5552cf=_0x26eb;function _0x5b19(){var _0x13f900=['get','18390sWYnoH','afterInit','Base64UploadAdapter','6CPnsXN','11jueXgI','135172IClUQG','14WcxtIn','1443800UKxntP','isOfficialPlugin','261NmFVrT','91QjbqYF','11vIRwWI','plugins','editor','UploadEmailIntegration','50305FJOqoN','pluginName','110844ZWMDpg','519036xlsqWz','52846iFuioX','12aUwDjM','isPremiumPlugin','_checkUnsupportedPlugin','requires'];_0x5b19=function(){return _0x13f900;};return _0x5b19();}(function(_0x28d8c6,_0x5cc0f0){var _0x56408e=_0x26eb,_0x2fbccd=_0x28d8c6();while(!![]){try{var _0x311a01=-parseInt(_0x56408e(0x1ad))/0x1*(-parseInt(_0x56408e(0x1b5))/0x2)+parseInt(_0x56408e(0x1a5))/0x3*(parseInt(_0x56408e(0x1a7))/0x4)+parseInt(_0x56408e(0x1b1))/0x5*(parseInt(_0x56408e(0x1b6))/0x6)+parseInt(_0x56408e(0x1a8))/0x7*(-parseInt(_0x56408e(0x1a9))/0x8)+-parseInt(_0x56408e(0x1ab))/0x9*(parseInt(_0x56408e(0x1a2))/0xa)+-parseInt(_0x56408e(0x1a6))/0xb*(parseInt(_0x56408e(0x1b3))/0xc)+parseInt(_0x56408e(0x1ac))/0xd*(parseInt(_0x56408e(0x1b4))/0xe);if(_0x311a01===_0x5cc0f0)break;else _0x2fbccd['push'](_0x2fbccd['shift']());}catch(_0x30488c){_0x2fbccd['push'](_0x2fbccd['shift']());}}}(_0x5b19,0x34559));function _0x26eb(_0x8e631e,_0x217f72){var _0x5b19ff=_0x5b19();return _0x26eb=function(_0x26eb15,_0x493652){_0x26eb15=_0x26eb15-0x1a0;var _0x1af3b0=_0x5b19ff[_0x26eb15];return _0x1af3b0;},_0x26eb(_0x8e631e,_0x217f72);}import{Plugin as _0x157d7d}from'ckeditor5/src/core.js';import{EmailConfigurationLogger as _0x8c7648}from'../emailconfigurationlogger.js';export class UploadEmailIntegration extends _0x157d7d{static get[_0x5552cf(0x1a0)](){return[_0x8c7648];}static get[_0x5552cf(0x1b2)](){var _0x2bd4c4=_0x5552cf;return _0x2bd4c4(0x1b0);}static get[_0x5552cf(0x1aa)](){return!0x0;}static get[_0x5552cf(0x1b7)](){return!0x0;}[_0x5552cf(0x1a3)](){var _0x29ab41=_0x5552cf;this[_0x29ab41(0x1af)][_0x29ab41(0x1ae)][_0x29ab41(0x1a1)](_0x8c7648)[_0x29ab41(0x1b8)](_0x29ab41(0x1a4));}}