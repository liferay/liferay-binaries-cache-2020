/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x31ebfe=_0x1cf1;(function(_0x4420fc,_0x330588){var _0x2a499e=_0x1cf1,_0x2b40ce=_0x4420fc();while(!![]){try{var _0x3e584d=parseInt(_0x2a499e(0xc7))/0x1+parseInt(_0x2a499e(0xd4))/0x2*(-parseInt(_0x2a499e(0xcf))/0x3)+-parseInt(_0x2a499e(0xd1))/0x4*(-parseInt(_0x2a499e(0xd2))/0x5)+parseInt(_0x2a499e(0xc6))/0x6+parseInt(_0x2a499e(0xce))/0x7+-parseInt(_0x2a499e(0xca))/0x8*(-parseInt(_0x2a499e(0xd3))/0x9)+-parseInt(_0x2a499e(0xcd))/0xa;if(_0x3e584d===_0x330588)break;else _0x2b40ce['push'](_0x2b40ce['shift']());}catch(_0x3e3322){_0x2b40ce['push'](_0x2b40ce['shift']());}}}(_0x57cb,0xd4751));function _0x57cb(){var _0x38d29b=['113937yUfHwS','pluginName','4QphMNV','5997415pGdXcV','7974ZZlmeO','10jWQBdb','requires','afterInit','isPremiumPlugin','MediaEmbed','get','plugins','4846704PendWm','427262CQscKN','isOfficialPlugin','MediaEmbedEmailIntegration','4160tAPrWJ','editor','_checkUnsupportedPlugin','33362670MHDdFk','10507966WNDXTz'];_0x57cb=function(){return _0x38d29b;};return _0x57cb();}import{Plugin as _0x101078}from'ckeditor5/src/core.js';import{EmailConfigurationLogger as _0x347831}from'../emailconfigurationlogger.js';function _0x1cf1(_0x43fceb,_0x5c8668){var _0x57cbc0=_0x57cb();return _0x1cf1=function(_0x1cf1dd,_0x17e9b6){_0x1cf1dd=_0x1cf1dd-0xc0;var _0x10f080=_0x57cbc0[_0x1cf1dd];return _0x10f080;},_0x1cf1(_0x43fceb,_0x5c8668);}export class MediaEmbedEmailIntegration extends _0x101078{static get[_0x31ebfe(0xc0)](){return[_0x347831];}static get[_0x31ebfe(0xd0)](){var _0x43e7d9=_0x31ebfe;return _0x43e7d9(0xc9);}static get[_0x31ebfe(0xc8)](){return!0x0;}static get[_0x31ebfe(0xc2)](){return!0x0;}[_0x31ebfe(0xc1)](){var _0x1eb449=_0x31ebfe;this[_0x1eb449(0xcb)][_0x1eb449(0xc5)][_0x1eb449(0xc4)](_0x347831)[_0x1eb449(0xcc)](_0x1eb449(0xc3));}}