/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x51df91=_0x21ea;(function(_0x43735f,_0x3a81a0){const _0xa58a89=_0x21ea,_0x152f3f=_0x43735f();while(!![]){try{const _0x3cea27=parseInt(_0xa58a89(0x104))/0x1+parseInt(_0xa58a89(0x111))/0x2+parseInt(_0xa58a89(0x116))/0x3*(parseInt(_0xa58a89(0x103))/0x4)+-parseInt(_0xa58a89(0x118))/0x5*(parseInt(_0xa58a89(0x10a))/0x6)+parseInt(_0xa58a89(0x105))/0x7*(parseInt(_0xa58a89(0x10d))/0x8)+-parseInt(_0xa58a89(0x109))/0x9+-parseInt(_0xa58a89(0x11a))/0xa;if(_0x3cea27===_0x3a81a0)break;else _0x152f3f['push'](_0x152f3f['shift']());}catch(_0x59ff45){_0x152f3f['push'](_0x152f3f['shift']());}}}(_0x25f8,0xe5085));import{Plugin as _0x42671a}from'ckeditor5/src/core.js';function _0x21ea(_0xb512fd,_0x50508c){const _0x25f8d0=_0x25f8();return _0x21ea=function(_0x21ead2,_0x24b312){_0x21ead2=_0x21ead2-0x102;let _0x2d75fa=_0x25f8d0[_0x21ead2];return _0x2d75fa;},_0x21ea(_0xb512fd,_0x50508c);}import{EmailConfigurationLogger as _0x29c32f}from'../emailconfigurationlogger.js';export class TemplateEmailIntegration extends _0x42671a{static get[_0x51df91(0x107)](){return[_0x29c32f];}static get[_0x51df91(0x10e)](){const _0x1657c2=_0x51df91;return _0x1657c2(0x115);}static get[_0x51df91(0x102)](){return!0x0;}static get[_0x51df91(0x117)](){return!0x0;}[_0x51df91(0x114)](){const _0xac179e=_0x51df91,_0x31a09d=this[_0xac179e(0x106)][_0xac179e(0x10c)][_0xac179e(0x10f)](_0x29c32f);this[_0xac179e(0x106)][_0xac179e(0x10c)][_0xac179e(0x108)](_0xac179e(0x112))||_0x31a09d[_0xac179e(0x10b)](_0xac179e(0x119),_0xac179e(0x113),_0xac179e(0x110));}}function _0x25f8(){const _0x48481d=['get','features/email-editing/email.html#template-plugin','2920322WgiepG','Template','Consider\x20enabling\x20the\x20Template\x20plugin\x20which\x20allows\x20inserting\x20predefined\x20e-mail\x20templates\x20into\x20the\x20editor.','afterInit','TemplateEmailIntegration','994218SHiPcq','isPremiumPlugin','27450sbcBwt','email-configuration-missing-template-plugin','972400nLyuHA','isOfficialPlugin','4kTXROH','340067cfOrsH','35XLqHcQ','editor','requires','has','6969798RgDeVt','1758ebnjcs','_logSuppressibleInfo','plugins','2058744Ljvcmx','pluginName'];_0x25f8=function(){return _0x48481d;};return _0x25f8();}