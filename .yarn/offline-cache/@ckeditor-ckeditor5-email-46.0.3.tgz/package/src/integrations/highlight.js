/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x2df8(){var _0x2db60e=['HighlightEmailIntegration','4394430nPflHd','_checkUnsupportedPlugin','requires','2XSDVDC','isPremiumPlugin','get','pluginName','2576ThMaHS','5504814nTgCoq','editor','2065410YEHgQU','2958qklogJ','153CXblhK','Highlight','1252NnxkqJ','afterInit','isOfficialPlugin','958923ujittV','plugins','373586gmrTLA'];_0x2df8=function(){return _0x2db60e;};return _0x2df8();}var _0x5526a0=_0x36f2;function _0x36f2(_0x5d5873,_0x19a4f9){var _0x2df88c=_0x2df8();return _0x36f2=function(_0x36f2ac,_0x41d1b9){_0x36f2ac=_0x36f2ac-0xf3;var _0xf449a3=_0x2df88c[_0x36f2ac];return _0xf449a3;},_0x36f2(_0x5d5873,_0x19a4f9);}(function(_0x2177b3,_0x15cd72){var _0x282cd4=_0x36f2,_0x1a604c=_0x2177b3();while(!![]){try{var _0x2720d4=-parseInt(_0x282cd4(0xf6))/0x1*(-parseInt(_0x282cd4(0x106))/0x2)+-parseInt(_0x282cd4(0xfe))/0x3*(-parseInt(_0x282cd4(0x101))/0x4)+parseInt(_0x282cd4(0xf3))/0x5+-parseInt(_0x282cd4(0xfb))/0x6+parseInt(_0x282cd4(0x104))/0x7+parseInt(_0x282cd4(0xfa))/0x8*(parseInt(_0x282cd4(0xff))/0x9)+-parseInt(_0x282cd4(0xfd))/0xa;if(_0x2720d4===_0x15cd72)break;else _0x1a604c['push'](_0x1a604c['shift']());}catch(_0x2b6626){_0x1a604c['push'](_0x1a604c['shift']());}}}(_0x2df8,0x8d7d7));import{Plugin as _0x1e2d45}from'ckeditor5/src/core.js';import{EmailConfigurationLogger as _0x3b3807}from'../emailconfigurationlogger.js';export class HighlightEmailIntegration extends _0x1e2d45{static get[_0x5526a0(0xf5)](){return[_0x3b3807];}static get[_0x5526a0(0xf9)](){var _0x4fd458=_0x5526a0;return _0x4fd458(0x107);}static get[_0x5526a0(0x103)](){return!0x0;}static get[_0x5526a0(0xf7)](){return!0x0;}[_0x5526a0(0x102)](){var _0x1aeae2=_0x5526a0;this[_0x1aeae2(0xfc)][_0x1aeae2(0x105)][_0x1aeae2(0xf8)](_0x3b3807)[_0x1aeae2(0xf4)](_0x1aeae2(0x100));}}