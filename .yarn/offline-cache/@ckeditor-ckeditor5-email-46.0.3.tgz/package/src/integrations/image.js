/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x2fb3f5=_0x5c81;function _0x5c81(_0x1f5216,_0x367134){var _0x126b70=_0x126b();return _0x5c81=function(_0x5c8107,_0x451304){_0x5c8107=_0x5c8107-0x152;var _0x4cf31f=_0x126b70[_0x5c8107];return _0x4cf31f;},_0x5c81(_0x1f5216,_0x367134);}function _0x126b(){var _0x202fa8=['editor','plugins','11736NokaEn','14REYkQR','67347rTxrRN','pluginName','get','_checkUnsupportedPlugin','252404IxzhYr','3070kKBtRu','ImageEmailIntegration','979860oZfzyZ','isOfficialPlugin','ImageBlock','requires','isPremiumPlugin','3454212fMszaN','7237685lTEqVv','4690TanhWw','14364256kTvaXq','afterInit'];_0x126b=function(){return _0x202fa8;};return _0x126b();}(function(_0x398b1d,_0x2ce323){var _0x54f06a=_0x5c81,_0x478601=_0x398b1d();while(!![]){try{var _0x30a8d5=-parseInt(_0x54f06a(0x166))/0x1*(parseInt(_0x54f06a(0x156))/0x2)+-parseInt(_0x54f06a(0x159))/0x3+-parseInt(_0x54f06a(0x165))/0x4*(parseInt(_0x54f06a(0x157))/0x5)+parseInt(_0x54f06a(0x15e))/0x6+-parseInt(_0x54f06a(0x15f))/0x7+parseInt(_0x54f06a(0x161))/0x8+parseInt(_0x54f06a(0x152))/0x9*(parseInt(_0x54f06a(0x160))/0xa);if(_0x30a8d5===_0x2ce323)break;else _0x478601['push'](_0x478601['shift']());}catch(_0x240b7f){_0x478601['push'](_0x478601['shift']());}}}(_0x126b,0xe864a));import{Plugin as _0x37fb80}from'ckeditor5/src/core.js';import{EmailConfigurationLogger as _0x1324a6}from'../emailconfigurationlogger.js';export class ImageEmailIntegration extends _0x37fb80{static get[_0x2fb3f5(0x15c)](){return[_0x1324a6];}static get[_0x2fb3f5(0x153)](){var _0x405e2c=_0x2fb3f5;return _0x405e2c(0x158);}static get[_0x2fb3f5(0x15a)](){return!0x0;}static get[_0x2fb3f5(0x15d)](){return!0x0;}[_0x2fb3f5(0x162)](){var _0x233467=_0x2fb3f5;this[_0x233467(0x163)][_0x233467(0x164)][_0x233467(0x154)](_0x1324a6)[_0x233467(0x155)](_0x233467(0x15b));}}