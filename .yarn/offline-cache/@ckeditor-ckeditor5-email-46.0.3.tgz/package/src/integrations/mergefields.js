/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0xc6ae07=_0x3fb4;(function(_0x57cb37,_0x5035e5){const _0xded20c=_0x3fb4,_0x144e3f=_0x57cb37();while(!![]){try{const _0x34f649=-parseInt(_0xded20c(0x1f4))/0x1*(parseInt(_0xded20c(0x204))/0x2)+-parseInt(_0xded20c(0x1f5))/0x3+-parseInt(_0xded20c(0x200))/0x4*(-parseInt(_0xded20c(0x201))/0x5)+parseInt(_0xded20c(0x1fc))/0x6*(parseInt(_0xded20c(0x1f2))/0x7)+-parseInt(_0xded20c(0x1fa))/0x8*(parseInt(_0xded20c(0x208))/0x9)+parseInt(_0xded20c(0x1f7))/0xa+-parseInt(_0xded20c(0x1f8))/0xb*(-parseInt(_0xded20c(0x206))/0xc);if(_0x34f649===_0x5035e5)break;else _0x144e3f['push'](_0x144e3f['shift']());}catch(_0x5b8573){_0x144e3f['push'](_0x144e3f['shift']());}}}(_0x4ae9,0x63f5b));import{Plugin as _0x4e1cc9}from'ckeditor5/src/core.js';import{EmailConfigurationLogger as _0x12f348}from'../emailconfigurationlogger.js';function _0x4ae9(){const _0x4148a0=['41231OLDmTS','258417aBMdcd','MergeFieldsEmailIntegration','7885650jKdYuo','891WwIlaG','has','4584GMBvtw','email-configuration-missing-merge-fields-plugin','978AnTGVs','editor','plugins','_logSuppressibleInfo','1674776GtBYkU','5gQgWRa','pluginName','get','6TZREnP','MergeFields','5064DJiEoX','isPremiumPlugin','12627AsLjbQ','requires','Consider\x20enabling\x20the\x20MergeFields\x20plugin\x20which\x20allows\x20inserting\x20dynamic\x20data\x20placeholders\x20into\x20content.','afterInit','features/email-editing/email.html#merge-fields-plugin','7805dWdTwZ','isOfficialPlugin'];_0x4ae9=function(){return _0x4148a0;};return _0x4ae9();}function _0x3fb4(_0x358b66,_0x401e27){const _0x4ae9a3=_0x4ae9();return _0x3fb4=function(_0x3fb4a8,_0x3075f1){_0x3fb4a8=_0x3fb4a8-0x1f1;let _0x206912=_0x4ae9a3[_0x3fb4a8];return _0x206912;},_0x3fb4(_0x358b66,_0x401e27);}export class MergeFieldsEmailIntegration extends _0x4e1cc9{static get[_0xc6ae07(0x209)](){return[_0x12f348];}static get[_0xc6ae07(0x202)](){const _0xc7546d=_0xc6ae07;return _0xc7546d(0x1f6);}static get[_0xc6ae07(0x1f3)](){return!0x0;}static get[_0xc6ae07(0x207)](){return!0x0;}[_0xc6ae07(0x20b)](){const _0x55776d=_0xc6ae07,_0x244ecf=this[_0x55776d(0x1fd)][_0x55776d(0x1fe)][_0x55776d(0x203)](_0x12f348);this[_0x55776d(0x1fd)][_0x55776d(0x1fe)][_0x55776d(0x1f9)](_0x55776d(0x205))||_0x244ecf[_0x55776d(0x1ff)](_0x55776d(0x1fb),_0x55776d(0x20a),_0x55776d(0x1f1));}}