/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x3fc2(_0x19359c,_0x52a647){var _0x12365a=_0x1236();return _0x3fc2=function(_0x3fc2ea,_0x1befea){_0x3fc2ea=_0x3fc2ea-0x11c;var _0x29837c=_0x12365a[_0x3fc2ea];return _0x29837c;},_0x3fc2(_0x19359c,_0x52a647);}var _0x1fde79=_0x3fc2;(function(_0x41419f,_0x22a40d){var _0x37691e=_0x3fc2,_0xec2181=_0x41419f();while(!![]){try{var _0x52dd8a=-parseInt(_0x37691e(0x11e))/0x1*(-parseInt(_0x37691e(0x123))/0x2)+-parseInt(_0x37691e(0x131))/0x3*(-parseInt(_0x37691e(0x11f))/0x4)+parseInt(_0x37691e(0x12f))/0x5*(-parseInt(_0x37691e(0x126))/0x6)+-parseInt(_0x37691e(0x124))/0x7+parseInt(_0x37691e(0x120))/0x8*(-parseInt(_0x37691e(0x125))/0x9)+parseInt(_0x37691e(0x128))/0xa*(-parseInt(_0x37691e(0x12e))/0xb)+parseInt(_0x37691e(0x134))/0xc*(parseInt(_0x37691e(0x127))/0xd);if(_0x52dd8a===_0x22a40d)break;else _0xec2181['push'](_0xec2181['shift']());}catch(_0x230166){_0xec2181['push'](_0xec2181['shift']());}}}(_0x1236,0x32bf2));import{Plugin as _0x5e9b31}from'ckeditor5/src/core.js';import{EmailConfigurationLogger as _0xefa1a}from'../emailconfigurationlogger.js';function _0x1236(){var _0x53f16d=['requires','editor','348CYZbrh','1135953IcQlTQ','99UBfSsj','30XTaAyy','253344JUqACL','2674680tpnZUW','pluginName','isOfficialPlugin','MultiLevelListEmailIntegration','get','The\x20multi-level\x20lists\x20are\x20rendered\x20incorrectly\x20in\x20Outlook\x202021.','11UAXyfl','92775eewLIt','isPremiumPlugin','9507vCJWpb','plugins','MultiLevelList','372QZSdle','_checkUnsupportedPlugin','afterInit','857vLnRCX','452yJDFrK','277064YRjnPT'];_0x1236=function(){return _0x53f16d;};return _0x1236();}export class MultiLevelListEmailIntegration extends _0x5e9b31{static get[_0x1fde79(0x121)](){return[_0xefa1a];}static get[_0x1fde79(0x129)](){var _0x121572=_0x1fde79;return _0x121572(0x12b);}static get[_0x1fde79(0x12a)](){return!0x0;}static get[_0x1fde79(0x130)](){return!0x0;}[_0x1fde79(0x11d)](){var _0x2ededb=_0x1fde79;this[_0x2ededb(0x122)][_0x2ededb(0x132)][_0x2ededb(0x12c)](_0xefa1a)[_0x2ededb(0x11c)](_0x2ededb(0x133),{'description':_0x2ededb(0x12d)});}}