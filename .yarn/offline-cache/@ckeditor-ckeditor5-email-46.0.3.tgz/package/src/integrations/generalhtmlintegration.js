/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x3a2c(){const _0x2350e8=['228sVKaPb','abbr','8521293xMnXvK','UNSUPPORTED_ELEMENTS','summary','requires','7623GxpMTR','details','button','get','output','GeneralHtmlIntegrationSupport','7vORSdg','progress','editor','bdi','10URzOZl','DataFilter','article','init','997295CWCLfS','hgroup','353799ihxxFb','nav','_logSuppressibleWarning','acronym','3878152yBCDtN','isPremiumPlugin','28LHsFLp','4114UnjInf','iframe','email-unsupported-html-element','850UDqKOk','meter','272DyfTtU','input','once','isOfficialPlugin','view','form','canvas','pluginName','has','object','register:','audio','main','1789362ccmqpY'];_0x3a2c=function(){return _0x2350e8;};return _0x3a2c();}const _0x50142d=_0x176e;(function(_0x3a9c03,_0x2636a9){const _0x56c85f=_0x176e,_0x136bfa=_0x3a9c03();while(!![]){try{const _0x29e1e7=-parseInt(_0x56c85f(0x129))/0x1*(-parseInt(_0x56c85f(0x124))/0x2)+-parseInt(_0x56c85f(0x11d))/0x3*(parseInt(_0x56c85f(0x123))/0x4)+parseInt(_0x56c85f(0x117))/0x5*(parseInt(_0x56c85f(0x106))/0x6)+-parseInt(_0x56c85f(0x113))/0x7*(parseInt(_0x56c85f(0x121))/0x8)+-parseInt(_0x56c85f(0x10d))/0x9*(-parseInt(_0x56c85f(0x127))/0xa)+-parseInt(_0x56c85f(0x109))/0xb+parseInt(_0x56c85f(0x107))/0xc*(parseInt(_0x56c85f(0x11b))/0xd);if(_0x29e1e7===_0x2636a9)break;else _0x136bfa['push'](_0x136bfa['shift']());}catch(_0x2c3009){_0x136bfa['push'](_0x136bfa['shift']());}}}(_0x3a2c,0x929ff));import{Plugin as _0x38df90}from'ckeditor5/src/core.js';function _0x176e(_0x117a32,_0xb597e6){const _0x3a2c0e=_0x3a2c();return _0x176e=function(_0x176ef5,_0x47c937){_0x176ef5=_0x176ef5-0xff;let _0x220fa2=_0x3a2c0e[_0x176ef5];return _0x220fa2;},_0x176e(_0x117a32,_0xb597e6);}import{EmailConfigurationLogger as _0x3f26ab}from'../emailconfigurationlogger.js';class f extends _0x38df90{static [_0x50142d(0x10a)]=new Set([_0x50142d(0x102),_0x50142d(0x119),_0x50142d(0x10e),_0x50142d(0x105),_0x50142d(0x11e),_0x50142d(0x10b),_0x50142d(0x108),_0x50142d(0x120),_0x50142d(0x116),_0x50142d(0x111),_0x50142d(0x11c),_0x50142d(0x12e),_0x50142d(0x12a),_0x50142d(0x10f),_0x50142d(0x104),_0x50142d(0xff),_0x50142d(0x128),_0x50142d(0x114),_0x50142d(0x125)]);static get[_0x50142d(0x10c)](){return[_0x3f26ab];}static get[_0x50142d(0x100)](){const _0x4c1386=_0x50142d;return _0x4c1386(0x112);}static get[_0x50142d(0x12c)](){return!0x0;}static get[_0x50142d(0x122)](){return!0x0;}[_0x50142d(0x11a)](){const _0x3a72e6=_0x50142d,{plugins:_0x2d8642}=this[_0x3a72e6(0x115)];if(!_0x2d8642[_0x3a72e6(0x101)](_0x3a72e6(0x118)))return;const _0x1c1866=_0x2d8642[_0x3a72e6(0x110)](_0x3a72e6(0x118)),_0x48ed5f=_0x2d8642[_0x3a72e6(0x110)](_0x3f26ab);for(const _0x5c8f90 of f[_0x3a72e6(0x10a)])_0x1c1866[_0x3a72e6(0x12b)](_0x3a72e6(0x103)+_0x5c8f90,(_0xd94954,_0x465351)=>{const _0x34786f=_0x3a72e6;_0x48ed5f[_0x34786f(0x11f)](_0x34786f(0x126),{'element':_0x465351[_0x34786f(0x12d)]});});}}export{f as GeneralHtmlIntegrationSupport};