/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x100b76=_0x15cd;(function(_0x114f2d,_0x3188db){const _0x3df5d7=_0x15cd,_0x3c522a=_0x114f2d();while(!![]){try{const _0x229c54=-parseInt(_0x3df5d7(0x86))/0x1*(-parseInt(_0x3df5d7(0x6f))/0x2)+parseInt(_0x3df5d7(0x70))/0x3+parseInt(_0x3df5d7(0x7a))/0x4*(-parseInt(_0x3df5d7(0x74))/0x5)+-parseInt(_0x3df5d7(0x78))/0x6+parseInt(_0x3df5d7(0x80))/0x7+parseInt(_0x3df5d7(0x72))/0x8+-parseInt(_0x3df5d7(0x87))/0x9;if(_0x229c54===_0x3188db)break;else _0x3c522a['push'](_0x3c522a['shift']());}catch(_0x1e795b){_0x3c522a['push'](_0x3c522a['shift']());}}}(_0x156f,0x3235f));function _0x156f(){const _0x5bd98c=['reversed','1308184fUUjAB','pluginName','5OqSVHK','email-configuration-unsupported-list-item-marker-formatting','isOfficialPlugin','ListEmailIntegration','1659876nyFJuC','list','1376372NfunQD','requires','email-configuration-unsupported-reversed-list','properties','_logSuppressibleWarning','enableListItemMarkerFormatting','2593227FccafH','plugins','afterInit','editor','get','config','307795yIYxzn','1820502uWZolO','isPremiumPlugin','2yClPvy','560703MjmHYN'];_0x156f=function(){return _0x5bd98c;};return _0x156f();}function _0x15cd(_0x17426f,_0x3f23c0){const _0x156fbe=_0x156f();return _0x15cd=function(_0x15cd7c,_0x2fc32b){_0x15cd7c=_0x15cd7c-0x6e;let _0x5998c4=_0x156fbe[_0x15cd7c];return _0x5998c4;},_0x15cd(_0x17426f,_0x3f23c0);}import{Plugin as _0x2b2e51}from'ckeditor5/src/core.js';import{EmailConfigurationLogger as _0x5a47a4}from'../emailconfigurationlogger.js';export class ListEmailIntegration extends _0x2b2e51{static get[_0x100b76(0x7b)](){return[_0x5a47a4];}static get[_0x100b76(0x73)](){const _0x2ee846=_0x100b76;return _0x2ee846(0x77);}static get[_0x100b76(0x76)](){return!0x0;}static get[_0x100b76(0x6e)](){return!0x0;}[_0x100b76(0x82)](){const _0x309fef=_0x100b76,_0x3a5706=this[_0x309fef(0x83)][_0x309fef(0x81)][_0x309fef(0x84)](_0x5a47a4),_0x14ebdc=this[_0x309fef(0x83)][_0x309fef(0x85)][_0x309fef(0x84)](_0x309fef(0x79));_0x14ebdc&&_0x14ebdc[_0x309fef(0x7d)]&&_0x14ebdc[_0x309fef(0x7d)][_0x309fef(0x71)]&&_0x3a5706[_0x309fef(0x7e)](_0x309fef(0x7c)),_0x14ebdc&&_0x14ebdc[_0x309fef(0x7f)]&&_0x3a5706[_0x309fef(0x7e)](_0x309fef(0x75));}}