/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-licensing-options
 */
/**
 * @module email/integrations/highlight
 * @publicApi
 */
import { Plugin } from 'ckeditor5/src/core.js';
import { EmailConfigurationLogger } from '../emailconfigurationlogger.js';
/**
 * A plugin that warns about using Highlight plugin in the email integration.
 */
export declare class HighlightEmailIntegration extends Plugin {
    /**
     * @inheritDoc
     */
    static get requires(): readonly [typeof EmailConfigurationLogger];
    /**
     * @inheritDoc
     */
    static get pluginName(): "HighlightEmailIntegration";
    /**
     * @inheritDoc
     */
    static get isOfficialPlugin(): true;
    /**
     * @inheritDoc
     */
    static get isPremiumPlugin(): true;
    /**
     * @inheritDoc
     */
    afterInit(): void;
}
