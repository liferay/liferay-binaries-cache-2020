/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x2e0e(_0x440832,_0x17b429){const _0x1d4dae=_0x1d4d();return _0x2e0e=function(_0x2e0e5d,_0x8e51ca){_0x2e0e5d=_0x2e0e5d-0x11b;let _0x590f9c=_0x1d4dae[_0x2e0e5d];return _0x590f9c;},_0x2e0e(_0x440832,_0x17b429);}const _0x2485d3=_0x2e0e;(function(_0x23c632,_0xc4cd3d){const _0x43f520=_0x2e0e,_0x5b27b5=_0x23c632();while(!![]){try{const _0x1116d2=parseInt(_0x43f520(0x11f))/0x1*(parseInt(_0x43f520(0x11c))/0x2)+parseInt(_0x43f520(0x12a))/0x3+-parseInt(_0x43f520(0x12b))/0x4+parseInt(_0x43f520(0x120))/0x5*(-parseInt(_0x43f520(0x124))/0x6)+-parseInt(_0x43f520(0x12d))/0x7+-parseInt(_0x43f520(0x130))/0x8+parseInt(_0x43f520(0x11d))/0x9;if(_0x1116d2===_0xc4cd3d)break;else _0x5b27b5['push'](_0x5b27b5['shift']());}catch(_0x220f58){_0x5b27b5['push'](_0x5b27b5['shift']());}}}(_0x1d4d,0x3d6d2));import{Plugin as _0x4ce3d2}from'ckeditor5/src/core.js';import{EmailConfigurationLogger as _0x13afc7}from'../emailconfigurationlogger.js';export class SourceEditingEmailIntegration extends _0x4ce3d2{static get[_0x2485d3(0x122)](){return[_0x13afc7];}static get[_0x2485d3(0x123)](){const _0x6a052b=_0x2485d3;return _0x6a052b(0x12e);}static get[_0x2485d3(0x129)](){return!0x0;}static get[_0x2485d3(0x11b)](){return!0x0;}[_0x2485d3(0x121)](){const _0xe902ec=_0x2485d3,{plugins:_0x41bfe7}=this[_0xe902ec(0x12c)],_0x55173b=_0x41bfe7[_0xe902ec(0x125)](_0x13afc7);_0x41bfe7[_0xe902ec(0x127)](_0xe902ec(0x12f))||_0x41bfe7[_0xe902ec(0x127)](_0xe902ec(0x11e))||_0x55173b[_0xe902ec(0x128)](_0xe902ec(0x126));}}function _0x1d4d(){const _0x55fb4e=['SourceEditing','151072GGUTGn','isPremiumPlugin','18Pzqrzk','8792757ZrZbyo','SourceEditingEnhanced','28183HSHnCk','1937885osvhXs','afterInit','requires','pluginName','6znQQbb','get','email-configuration-missing-source-editing-plugin','has','_logSuppressibleWarning','isOfficialPlugin','125526LysuOI','1670380rvvlZb','editor','1377628LDWjHu','SourceEditingEmailIntegration'];_0x1d4d=function(){return _0x55fb4e;};return _0x1d4d();}