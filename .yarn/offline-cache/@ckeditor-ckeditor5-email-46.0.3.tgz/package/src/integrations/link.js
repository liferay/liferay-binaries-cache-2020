/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
var _0x46025c=_0x3b8b;(function(_0x54998f,_0x1e6e76){var _0x5bf80e=_0x3b8b,_0x43b02a=_0x54998f();while(!![]){try{var _0xdc59f=-parseInt(_0x5bf80e(0x9e))/0x1+-parseInt(_0x5bf80e(0xab))/0x2+parseInt(_0x5bf80e(0xaa))/0x3+parseInt(_0x5bf80e(0xa6))/0x4*(parseInt(_0x5bf80e(0xa3))/0x5)+parseInt(_0x5bf80e(0xa9))/0x6+parseInt(_0x5bf80e(0xa8))/0x7+-parseInt(_0x5bf80e(0x9d))/0x8;if(_0xdc59f===_0x1e6e76)break;else _0x43b02a['push'](_0x43b02a['shift']());}catch(_0x8e5ab2){_0x43b02a['push'](_0x43b02a['shift']());}}}(_0x313c,0x7d17f));import{Plugin as _0xb978f6}from'ckeditor5/src/core.js';import{EmailConfigurationLogger as _0x1f78ff}from'../emailconfigurationlogger.js';function _0x3b8b(_0x48ba6d,_0x5a8737){var _0x313ce3=_0x313c();return _0x3b8b=function(_0x3b8b7b,_0x463360){_0x3b8b7b=_0x3b8b7b-0x99;var _0x1a83d=_0x313ce3[_0x3b8b7b];return _0x1a83d;},_0x3b8b(_0x48ba6d,_0x5a8737);}export class LinkEmailIntegration extends _0xb978f6{static get[_0x46025c(0xa4)](){return[_0x1f78ff];}static get[_0x46025c(0xa0)](){var _0x3146ed=_0x46025c;return _0x3146ed(0xac);}static get[_0x46025c(0xa5)](){return!0x0;}static get[_0x46025c(0xa1)](){return!0x0;}[_0x46025c(0xa2)](){var _0x14f283=_0x46025c;this[_0x14f283(0xa7)][_0x14f283(0x9c)][_0x14f283(0x9a)](_0x1f78ff)[_0x14f283(0x9f)](_0x14f283(0x9b),{'description':_0x14f283(0x99)});}}function _0x313c(){var _0x177cd9=['1781858xaUzno','LinkEmailIntegration','Block\x20images\x20are\x20unsupported\x20in\x20email\x20environments.\x20The\x20LinkImage\x20plugin\x20is\x20designed\x20to\x20work\x20exclusively\x20with\x20block\x20images,\x20which\x20makes\x20it\x20not\x20applicable\x20for\x20email\x20integration.\x20Inline\x20images\x20are\x20still\x20supported\x20and\x20function\x20correctly\x20with\x20the\x20standard\x20Link\x20feature.','get','LinkImage','plugins','9429976gecFft','411316htHAqk','_checkUnsupportedPlugin','pluginName','isPremiumPlugin','afterInit','70uXHRrD','requires','isOfficialPlugin','60052PwqByg','editor','5739916vVdKYZ','5863260ugROhf','2957985qzMEWl'];_0x313c=function(){return _0x177cd9;};return _0x313c();}