/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x145d(){var _0x52450f=['570840ofUTTj','1104366CvXkvX','afterInit','editor','16950696KQLcjg','pluginName','isOfficialPlugin','626330AJBJJy','1470894MDDTYK','6DtcVSD','plugins','requires','get','3020535IJgHmR','isPremiumPlugin','222736keUUxc','Markdown','_checkUnsupportedPlugin','MarkdownEmailIntegration'];_0x145d=function(){return _0x52450f;};return _0x145d();}var _0x55e246=_0x5208;function _0x5208(_0x118f45,_0x2d3ccb){var _0x145df7=_0x145d();return _0x5208=function(_0x52086f,_0x40cdf5){_0x52086f=_0x52086f-0x150;var _0x548d2a=_0x145df7[_0x52086f];return _0x548d2a;},_0x5208(_0x118f45,_0x2d3ccb);}(function(_0x1b01cb,_0x12c1f7){var _0x2cc805=_0x5208,_0x422e76=_0x1b01cb();while(!![]){try{var _0x131326=-parseInt(_0x2cc805(0x155))/0x1+parseInt(_0x2cc805(0x15b))/0x2+parseInt(_0x2cc805(0x15d))/0x3*(parseInt(_0x2cc805(0x150))/0x4)+-parseInt(_0x2cc805(0x154))/0x5+-parseInt(_0x2cc805(0x15c))/0x6+-parseInt(_0x2cc805(0x161))/0x7+parseInt(_0x2cc805(0x158))/0x8;if(_0x131326===_0x12c1f7)break;else _0x422e76['push'](_0x422e76['shift']());}catch(_0xe1b06){_0x422e76['push'](_0x422e76['shift']());}}}(_0x145d,0x9e3f6));import{Plugin as _0x42e476}from'ckeditor5/src/core.js';import{EmailConfigurationLogger as _0x577feb}from'../emailconfigurationlogger.js';export class MarkdownEmailIntegration extends _0x42e476{static get[_0x55e246(0x15f)](){return[_0x577feb];}static get[_0x55e246(0x159)](){var _0x310836=_0x55e246;return _0x310836(0x153);}static get[_0x55e246(0x15a)](){return!0x0;}static get[_0x55e246(0x162)](){return!0x0;}[_0x55e246(0x156)](){var _0x407f71=_0x55e246;this[_0x407f71(0x157)][_0x407f71(0x15e)][_0x407f71(0x160)](_0x577feb)[_0x407f71(0x152)](_0x407f71(0x151));}}