/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x1c9a(){const _0x28335c=['ExportInlineStyles','3874302JjVUJU','email-configuration-missing-export-inline-styles-plugin','has','_logSuppressibleWarning','3511377eNPAYx','3256729WHxFQg','editor','215qaDHUn','ExportInlineStylesEmailIntegration','plugins','requires','144425JLoEeo','isPremiumPlugin','123336ZVUyGg','34ewMYTG','67812aCsKYC','isOfficialPlugin','get','pluginName','afterInit','2250088EMHZXe'];_0x1c9a=function(){return _0x28335c;};return _0x1c9a();}const _0x11728e=_0x47d4;function _0x47d4(_0x33db51,_0x319fe2){const _0x1c9ada=_0x1c9a();return _0x47d4=function(_0x47d440,_0x208197){_0x47d440=_0x47d440-0x127;let _0x5b46f5=_0x1c9ada[_0x47d440];return _0x5b46f5;},_0x47d4(_0x33db51,_0x319fe2);}(function(_0x2e0ce7,_0xe6b182){const _0x247a52=_0x47d4,_0x4fdd97=_0x2e0ce7();while(!![]){try{const _0x44ade9=-parseInt(_0x247a52(0x12e))/0x1+parseInt(_0x247a52(0x131))/0x2*(parseInt(_0x247a52(0x132))/0x3)+parseInt(_0x247a52(0x130))/0x4*(parseInt(_0x247a52(0x12a))/0x5)+-parseInt(_0x247a52(0x139))/0x6+parseInt(_0x247a52(0x128))/0x7+-parseInt(_0x247a52(0x137))/0x8+-parseInt(_0x247a52(0x127))/0x9;if(_0x44ade9===_0xe6b182)break;else _0x4fdd97['push'](_0x4fdd97['shift']());}catch(_0xae9c8f){_0x4fdd97['push'](_0x4fdd97['shift']());}}}(_0x1c9a,0xae45d));import{Plugin as _0x1186d4}from'ckeditor5/src/core.js';import{EmailConfigurationLogger as _0x342337}from'../emailconfigurationlogger.js';export class ExportInlineStylesEmailIntegration extends _0x1186d4{static get[_0x11728e(0x12d)](){return[_0x342337];}static get[_0x11728e(0x135)](){const _0x1c732c=_0x11728e;return _0x1c732c(0x12b);}static get[_0x11728e(0x133)](){return!0x0;}static get[_0x11728e(0x12f)](){return!0x0;}[_0x11728e(0x136)](){const _0xc21906=_0x11728e,_0x426dbc=this[_0xc21906(0x129)][_0xc21906(0x12c)][_0xc21906(0x134)](_0x342337);this[_0xc21906(0x129)][_0xc21906(0x12c)][_0xc21906(0x13b)](_0xc21906(0x138))||_0x426dbc[_0xc21906(0x13c)](_0xc21906(0x13a));}}