/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
const _0x130b91=_0x1b7a;(function(_0x4b80e8,_0x6ee598){const _0x5f1ccb=_0x1b7a,_0x37dff8=_0x4b80e8();while(!![]){try{const _0x548e2a=-parseInt(_0x5f1ccb(0x1c6))/0x1*(-parseInt(_0x5f1ccb(0x1c5))/0x2)+parseInt(_0x5f1ccb(0x1d4))/0x3*(parseInt(_0x5f1ccb(0x1d5))/0x4)+parseInt(_0x5f1ccb(0x1c3))/0x5+-parseInt(_0x5f1ccb(0x1d2))/0x6+-parseInt(_0x5f1ccb(0x1be))/0x7+parseInt(_0x5f1ccb(0x1c8))/0x8*(-parseInt(_0x5f1ccb(0x1c4))/0x9)+-parseInt(_0x5f1ccb(0x1d0))/0xa*(-parseInt(_0x5f1ccb(0x1c0))/0xb);if(_0x548e2a===_0x6ee598)break;else _0x37dff8['push'](_0x37dff8['shift']());}catch(_0x38f126){_0x37dff8['push'](_0x37dff8['shift']());}}}(_0x1bbc,0x18ee6));function _0x1b7a(_0x242301,_0x4677a9){const _0x1bbcbf=_0x1bbc();return _0x1b7a=function(_0x1b7ae3,_0x202c9e){_0x1b7ae3=_0x1b7ae3-0x1bc;let _0x55745c=_0x1bbcbf[_0x1b7ae3];return _0x55745c;},_0x1b7a(_0x242301,_0x4677a9);}import{Plugin as _0x23e69c}from'ckeditor5/src/core.js';import{EmailConfigurationLogger as _0x5239e8}from'../emailconfigurationlogger.js';function _0x1bbc(){const _0x6a171e=['49158Wdegnd','254KCMvNQ','375iBufmf','pluginName','184uHTPzt','EmptyBlock','Consider\x20enabling\x20the\x20EmptyBlock\x20plugin\x20to\x20ensure\x20that\x20exported\x20content\x20has\x20empty\x20blocks.','email-configuration-missing-empty-block-plugin','plugins','EmptyBlockEmailIntegration','features/email-editing/email.html#empty-block-plugin','isOfficialPlugin','1798810aNspcM','has','803862XtgNxa','_logSuppressibleInfo','978tvuEZH','84PdIKHx','requires','isPremiumPlugin','466753qlQQpr','get','22zPMPTn','editor','afterInit','70835gqDrML'];_0x1bbc=function(){return _0x6a171e;};return _0x1bbc();}export class EmptyBlockEmailIntegration extends _0x23e69c{static get[_0x130b91(0x1bc)](){return[_0x5239e8];}static get[_0x130b91(0x1c7)](){const _0x40e064=_0x130b91;return _0x40e064(0x1cd);}static get[_0x130b91(0x1cf)](){return!0x0;}static get[_0x130b91(0x1bd)](){return!0x0;}[_0x130b91(0x1c2)](){const _0x22c44b=_0x130b91,_0x124fe4=this[_0x22c44b(0x1c1)][_0x22c44b(0x1cc)][_0x22c44b(0x1bf)](_0x5239e8);this[_0x22c44b(0x1c1)][_0x22c44b(0x1cc)][_0x22c44b(0x1d1)](_0x22c44b(0x1c9))||_0x124fe4[_0x22c44b(0x1d3)](_0x22c44b(0x1cb),_0x22c44b(0x1ca),_0x22c44b(0x1ce));}}