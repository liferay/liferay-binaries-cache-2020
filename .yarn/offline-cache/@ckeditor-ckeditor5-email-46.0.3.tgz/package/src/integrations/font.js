/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
function _0x5774(){const _0x3dcab3=['FontBackgroundColorEditing','1703826AqbKaS','_validateConfigColorFormat','fontBackgroundColor','1374357lvIiGc','isOfficialPlugin','383919VcfvzJ','.colorPicker.format','pluginName','editor','plugins','_checkColorConfig','9FrpCxU','.documentColors','130865GiBHuW','config','fontColor','FontColorEditing','requires','9459304wbAErd','afterInit','.colors','has','221424hSuLbQ','get','96KsWFif','41675WsDAFX','FontEmailIntegration','_validateConfigColorValue','isPremiumPlugin'];_0x5774=function(){return _0x3dcab3;};return _0x5774();}const _0x18a6e4=_0x18a3;function _0x18a3(_0x59da0c,_0x450bef){const _0x5774ac=_0x5774();return _0x18a3=function(_0x18a310,_0x2afaab){_0x18a310=_0x18a310-0xcf;let _0x1f725b=_0x5774ac[_0x18a310];return _0x1f725b;},_0x18a3(_0x59da0c,_0x450bef);}(function(_0x2b5258,_0x58e7ce){const _0x588ec1=_0x18a3,_0x53364f=_0x2b5258();while(!![]){try{const _0xd8fa63=parseInt(_0x588ec1(0xec))/0x1+-parseInt(_0x588ec1(0xe7))/0x2+-parseInt(_0x588ec1(0xea))/0x3+parseInt(_0x588ec1(0xe1))/0x4*(parseInt(_0x588ec1(0xe2))/0x5)+parseInt(_0x588ec1(0xdf))/0x6+-parseInt(_0x588ec1(0xd6))/0x7+-parseInt(_0x588ec1(0xdb))/0x8*(-parseInt(_0x588ec1(0xd4))/0x9);if(_0xd8fa63===_0x58e7ce)break;else _0x53364f['push'](_0x53364f['shift']());}catch(_0x565e50){_0x53364f['push'](_0x53364f['shift']());}}}(_0x5774,0x73db5));import{Plugin as _0x20b2e8}from'ckeditor5/src/core.js';import{EmailConfigurationLogger as _0x5016e5}from'../emailconfigurationlogger.js';export class FontEmailIntegration extends _0x20b2e8{static get[_0x18a6e4(0xda)](){return[_0x5016e5];}static get[_0x18a6e4(0xd0)](){const _0x46c503=_0x18a6e4;return _0x46c503(0xe3);}static get[_0x18a6e4(0xeb)](){return!0x0;}static get[_0x18a6e4(0xe5)](){return!0x0;}[_0x18a6e4(0xdc)](){const _0x28b577=_0x18a6e4,{plugins:_0x15e0a4}=this[_0x28b577(0xd1)];_0x15e0a4[_0x28b577(0xde)](_0x28b577(0xd9))&&this[_0x28b577(0xd3)](_0x28b577(0xd8)),_0x15e0a4[_0x28b577(0xde)](_0x28b577(0xe6))&&this[_0x28b577(0xd3)](_0x28b577(0xe9));}[_0x18a6e4(0xd3)](_0x1e65bd){const _0x1f0759=_0x18a6e4,_0x37d17b=this[_0x1f0759(0xd1)][_0x1f0759(0xd2)][_0x1f0759(0xe0)](_0x5016e5);this[_0x1f0759(0xd1)][_0x1f0759(0xd7)][_0x1f0759(0xe0)](_0x1e65bd)&&(_0x37d17b[_0x1f0759(0xe4)](_0x1e65bd+_0x1f0759(0xdd)),_0x37d17b[_0x1f0759(0xe4)](_0x1e65bd+_0x1f0759(0xd5)),_0x37d17b[_0x1f0759(0xe8)](_0x1e65bd+_0x1f0759(0xcf)));}}