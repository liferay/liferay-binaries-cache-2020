/*
 *             Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
(function(_0x22112f,_0x550a43){const _0x4a977a=_0x138a,_0x4513d2=_0x22112f();while(!![]){try{const _0x36782d=-parseInt(_0x4a977a(0x1ea))/0x1+parseInt(_0x4a977a(0x1de))/0x2+-parseInt(_0x4a977a(0x1ec))/0x3*(parseInt(_0x4a977a(0x1d7))/0x4)+-parseInt(_0x4a977a(0x1e7))/0x5*(-parseInt(_0x4a977a(0x1ed))/0x6)+-parseInt(_0x4a977a(0x1da))/0x7*(parseInt(_0x4a977a(0x1d9))/0x8)+-parseInt(_0x4a977a(0x1e9))/0x9*(-parseInt(_0x4a977a(0x1e8))/0xa)+-parseInt(_0x4a977a(0x1dc))/0xb*(-parseInt(_0x4a977a(0x1dd))/0xc);if(_0x36782d===_0x550a43)break;else _0x4513d2['push'](_0x4513d2['shift']());}catch(_0x5d8d3e){_0x4513d2['push'](_0x4513d2['shift']());}}}(_0x4730,0x6ae54));import{dropImportantStyleSuffix as _0x281aa6}from'@ckeditor/ckeditor5-export-inline-styles';function _0x138a(_0x33c1af,_0x552535){const _0x473065=_0x4730();return _0x138a=function(_0x138a5a,_0x244d16){_0x138a5a=_0x138a5a-0x1d5;let _0x12e771=_0x473065[_0x138a5a];return _0x12e771;},_0x138a(_0x33c1af,_0x552535);}function _0x4730(){const _0xf2cbbc=['right','center','float','includes','IMG','764710zIbCJP','180mCyybo','395253hQRjmw','543034NIGFTQ','auto','185973suUVzg','24xzqEgA','setAttribute','getAsString','align','4Ykfnvq','TABLE','8vSoztA','4604957xgdhoK','tagName','1661NKzivC','20820iRBvAf','72922myCVqB','margin-right','left','margin-left'];_0x4730=function(){return _0xf2cbbc;};return _0x4730();}export function getEmailInlineStylesTransformations(){return[(_0x4b17f6,_0xa34a92)=>{const _0x93632b=_0x138a;if(![_0x93632b(0x1d8),_0x93632b(0x1e6)][_0x93632b(0x1e5)](_0x4b17f6[_0x93632b(0x1db)]))return;const _0xd3ddfc=_0xa34a92[_0x93632b(0x1d5)](_0x93632b(0x1e4));if(_0xd3ddfc){const _0x2c9acf=_0x281aa6(_0xd3ddfc);_0x93632b(0x1e0)!==_0x2c9acf&&_0x93632b(0x1e2)!==_0x2c9acf||_0x4b17f6[_0x93632b(0x1ee)](_0x93632b(0x1d6),_0x2c9acf);}},(_0x49c20b,_0x50e64c)=>{const _0x4c0142=_0x138a;if(_0x4c0142(0x1d8)!==_0x49c20b[_0x4c0142(0x1db)])return;const _0x5c1320=_0x50e64c[_0x4c0142(0x1d5)](_0x4c0142(0x1e1)),_0x26aa6e=_0x50e64c[_0x4c0142(0x1d5)](_0x4c0142(0x1df));_0x5c1320&&_0x26aa6e&&_0x4c0142(0x1eb)===_0x281aa6(_0x5c1320)&&_0x4c0142(0x1eb)===_0x281aa6(_0x26aa6e)&&_0x49c20b[_0x4c0142(0x1ee)](_0x4c0142(0x1d6),_0x4c0142(0x1e3));}];}